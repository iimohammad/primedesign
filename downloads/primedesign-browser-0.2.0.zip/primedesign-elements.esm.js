var e0 = Object.defineProperty;
var t0 = (d, s, o) => s in d ? e0(d, s, { enumerable: !0, configurable: !0, writable: !0, value: o }) : d[s] = o;
var nt = (d, s, o) => t0(d, typeof s != "symbol" ? s + "" : s, o);
function a0(d) {
  return d && d.__esModule && Object.prototype.hasOwnProperty.call(d, "default") ? d.default : d;
}
var So = { exports: {} }, tr = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Th;
function l0() {
  if (Th) return tr;
  Th = 1;
  var d = Symbol.for("react.transitional.element"), s = Symbol.for("react.fragment");
  function o(u, c, f) {
    var m = null;
    if (f !== void 0 && (m = "" + f), c.key !== void 0 && (m = "" + c.key), "key" in c) {
      f = {};
      for (var h in c)
        h !== "key" && (f[h] = c[h]);
    } else f = c;
    return c = f.ref, {
      $$typeof: d,
      type: u,
      key: m,
      ref: c !== void 0 ? c : null,
      props: f
    };
  }
  return tr.Fragment = s, tr.jsx = o, tr.jsxs = o, tr;
}
var Eh;
function n0() {
  return Eh || (Eh = 1, So.exports = l0()), So.exports;
}
var i = n0(), wo = { exports: {} }, xe = {};
/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ch;
function i0() {
  if (Ch) return xe;
  Ch = 1;
  var d = Symbol.for("react.transitional.element"), s = Symbol.for("react.portal"), o = Symbol.for("react.fragment"), u = Symbol.for("react.strict_mode"), c = Symbol.for("react.profiler"), f = Symbol.for("react.consumer"), m = Symbol.for("react.context"), h = Symbol.for("react.forward_ref"), v = Symbol.for("react.suspense"), j = Symbol.for("react.memo"), x = Symbol.for("react.lazy"), b = Symbol.for("react.activity"), y = Symbol.for("react.view_transition"), z = Symbol.iterator;
  function O(N) {
    return N === null || typeof N != "object" ? null : (N = z && N[z] || N["@@iterator"], typeof N == "function" ? N : null);
  }
  var E = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, R = Object.assign, U = {};
  function H(N, Q, te) {
    this.props = N, this.context = Q, this.refs = U, this.updater = te || E;
  }
  H.prototype.isReactComponent = {}, H.prototype.setState = function(N, Q) {
    if (typeof N != "object" && typeof N != "function" && N != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, N, Q, "setState");
  }, H.prototype.forceUpdate = function(N) {
    this.updater.enqueueForceUpdate(this, N, "forceUpdate");
  };
  function V() {
  }
  V.prototype = H.prototype;
  function W(N, Q, te) {
    this.props = N, this.context = Q, this.refs = U, this.updater = te || E;
  }
  var J = W.prototype = new V();
  J.constructor = W, R(J, H.prototype), J.isPureReactComponent = !0;
  var se = Array.isArray;
  function G() {
  }
  var X = { H: null, A: null, T: null, S: null }, me = Object.prototype.hasOwnProperty;
  function pe(N, Q, te) {
    var ae = te.ref;
    return {
      $$typeof: d,
      type: N,
      key: Q,
      ref: ae !== void 0 ? ae : null,
      props: te
    };
  }
  function $(N, Q) {
    return pe(N.type, Q, N.props);
  }
  function ce(N) {
    return typeof N == "object" && N !== null && N.$$typeof === d;
  }
  function I(N) {
    var Q = { "=": "=0", ":": "=2" };
    return "$" + N.replace(/[=:]/g, function(te) {
      return Q[te];
    });
  }
  var De = /\/+/g;
  function Ee(N, Q) {
    return typeof N == "object" && N !== null && N.key != null ? I("" + N.key) : Q.toString(36);
  }
  function L(N) {
    switch (N.status) {
      case "fulfilled":
        return N.value;
      case "rejected":
        throw N.reason;
      default:
        switch (typeof N.status == "string" ? N.then(G, G) : (N.status = "pending", N.then(
          function(Q) {
            N.status === "pending" && (N.status = "fulfilled", N.value = Q);
          },
          function(Q) {
            N.status === "pending" && (N.status = "rejected", N.reason = Q);
          }
        )), N.status) {
          case "fulfilled":
            return N.value;
          case "rejected":
            throw N.reason;
        }
    }
    throw N;
  }
  function P(N, Q, te, ae, we) {
    var Ae = typeof N;
    (Ae === "undefined" || Ae === "boolean") && (N = null);
    var ze = !1;
    if (N === null) ze = !0;
    else
      switch (Ae) {
        case "bigint":
        case "string":
        case "number":
          ze = !0;
          break;
        case "object":
          switch (N.$$typeof) {
            case d:
            case s:
              ze = !0;
              break;
            case x:
              return ze = N._init, P(
                ze(N._payload),
                Q,
                te,
                ae,
                we
              );
          }
      }
    if (ze)
      return we = we(N), ze = ae === "" ? "." + Ee(N, 0) : ae, se(we) ? (te = "", ze != null && (te = ze.replace(De, "$&/") + "/"), P(we, Q, te, "", function(wt) {
        return wt;
      })) : we != null && (ce(we) && (we = $(
        we,
        te + (we.key == null || N && N.key === we.key ? "" : ("" + we.key).replace(
          De,
          "$&/"
        ) + "/") + ze
      )), Q.push(we)), 1;
    ze = 0;
    var le = ae === "" ? "." : ae + ":";
    if (se(N))
      for (var oe = 0; oe < N.length; oe++)
        ae = N[oe], Ae = le + Ee(ae, oe), ze += P(
          ae,
          Q,
          te,
          Ae,
          we
        );
    else if (oe = O(N), typeof oe == "function")
      for (N = oe.call(N), oe = 0; !(ae = N.next()).done; )
        ae = ae.value, Ae = le + Ee(ae, oe++), ze += P(
          ae,
          Q,
          te,
          Ae,
          we
        );
    else if (Ae === "object") {
      if (typeof N.then == "function")
        return P(
          L(N),
          Q,
          te,
          ae,
          we
        );
      throw Q = String(N), Error(
        "Objects are not valid as a React child (found: " + (Q === "[object Object]" ? "object with keys {" + Object.keys(N).join(", ") + "}" : Q) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return ze;
  }
  function re(N, Q, te) {
    if (N == null) return N;
    var ae = [], we = 0;
    return P(N, ae, "", "", function(Ae) {
      return Q.call(te, Ae, we++);
    }), ae;
  }
  function Ce(N) {
    if (N._status === -1) {
      var Q = N._result, te = Q();
      te.then(
        function(ae) {
          (N._status === 0 || N._status === -1) && (N._status = 1, N._result = ae, te.status === void 0 && (te.status = "fulfilled", te.value = ae));
        },
        function(ae) {
          (N._status === 0 || N._status === -1) && (N._status = 2, N._result = ae, te.status === void 0 && (te.status = "rejected", te.reason = ae));
        }
      ), N._status === -1 && (N._status = 0, N._result = te);
    }
    if (N._status === 1) return N._result.default;
    throw N._result;
  }
  var he = typeof reportError == "function" ? reportError : function(N) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var Q = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof N == "object" && N !== null && typeof N.message == "string" ? String(N.message) : String(N),
        error: N
      });
      if (!window.dispatchEvent(Q)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", N);
      return;
    }
    console.error(N);
  };
  function ge(N) {
    var Q = X.T, te = {};
    te.types = Q !== null ? Q.types : null, X.T = te;
    try {
      var ae = N(), we = X.S;
      we !== null && we(te, ae), typeof ae == "object" && ae !== null && typeof ae.then == "function" && ae.then(G, he);
    } catch (Ae) {
      he(Ae);
    } finally {
      Q !== null && te.types !== null && (Q.types = te.types), X.T = Q;
    }
  }
  function We(N) {
    var Q = X.T;
    if (Q !== null) {
      var te = Q.types;
      te === null ? Q.types = [N] : te.indexOf(N) === -1 && te.push(N);
    } else ge(We.bind(null, N));
  }
  var St = {
    map: re,
    forEach: function(N, Q, te) {
      re(
        N,
        function() {
          Q.apply(this, arguments);
        },
        te
      );
    },
    count: function(N) {
      var Q = 0;
      return re(N, function() {
        Q++;
      }), Q;
    },
    toArray: function(N) {
      return re(N, function(Q) {
        return Q;
      }) || [];
    },
    only: function(N) {
      if (!ce(N))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return N;
    }
  };
  return xe.Activity = b, xe.Children = St, xe.Component = H, xe.Fragment = o, xe.Profiler = c, xe.PureComponent = W, xe.StrictMode = u, xe.Suspense = v, xe.ViewTransition = y, xe.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = X, xe.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(N) {
      return X.H.useMemoCache(N);
    }
  }, xe.addTransitionType = We, xe.cache = function(N) {
    return function() {
      return N.apply(null, arguments);
    };
  }, xe.cacheSignal = function() {
    return null;
  }, xe.cloneElement = function(N, Q, te) {
    if (N == null)
      throw Error(
        "The argument must be a React element, but you passed " + N + "."
      );
    var ae = R({}, N.props), we = N.key;
    if (Q != null)
      for (Ae in Q.key !== void 0 && (we = "" + Q.key), Q)
        !me.call(Q, Ae) || Ae === "key" || Ae === "__self" || Ae === "__source" || Ae === "ref" && Q.ref === void 0 || (ae[Ae] = Q[Ae]);
    var Ae = arguments.length - 2;
    if (Ae === 1) ae.children = te;
    else if (1 < Ae) {
      for (var ze = Array(Ae), le = 0; le < Ae; le++)
        ze[le] = arguments[le + 2];
      ae.children = ze;
    }
    return pe(N.type, we, ae);
  }, xe.createContext = function(N) {
    return N = {
      $$typeof: m,
      _currentValue: N,
      _currentValue2: N,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, N.Provider = N, N.Consumer = {
      $$typeof: f,
      _context: N
    }, N;
  }, xe.createElement = function(N, Q, te) {
    var ae, we = {}, Ae = null;
    if (Q != null)
      for (ae in Q.key !== void 0 && (Ae = "" + Q.key), Q)
        me.call(Q, ae) && ae !== "key" && ae !== "__self" && ae !== "__source" && (we[ae] = Q[ae]);
    var ze = arguments.length - 2;
    if (ze === 1) we.children = te;
    else if (1 < ze) {
      for (var le = Array(ze), oe = 0; oe < ze; oe++)
        le[oe] = arguments[oe + 2];
      we.children = le;
    }
    if (N && N.defaultProps)
      for (ae in ze = N.defaultProps, ze)
        we[ae] === void 0 && (we[ae] = ze[ae]);
    return pe(N, Ae, we);
  }, xe.createRef = function() {
    return { current: null };
  }, xe.forwardRef = function(N) {
    return { $$typeof: h, render: N };
  }, xe.isValidElement = ce, xe.lazy = function(N) {
    return {
      $$typeof: x,
      _payload: { _status: -1, _result: N },
      _init: Ce
    };
  }, xe.memo = function(N, Q) {
    return {
      $$typeof: j,
      type: N,
      compare: Q === void 0 ? null : Q
    };
  }, xe.startTransition = ge, xe.unstable_useCacheRefresh = function() {
    return X.H.useCacheRefresh();
  }, xe.use = function(N) {
    return X.H.use(N);
  }, xe.useActionState = function(N, Q, te) {
    return X.H.useActionState(N, Q, te);
  }, xe.useCallback = function(N, Q) {
    return X.H.useCallback(N, Q);
  }, xe.useContext = function(N) {
    return X.H.useContext(N);
  }, xe.useDebugValue = function() {
  }, xe.useDeferredValue = function(N, Q) {
    return X.H.useDeferredValue(N, Q);
  }, xe.useEffect = function(N, Q) {
    return X.H.useEffect(N, Q);
  }, xe.useEffectEvent = function(N) {
    return X.H.useEffectEvent(N);
  }, xe.useId = function() {
    return X.H.useId();
  }, xe.useImperativeHandle = function(N, Q, te) {
    return X.H.useImperativeHandle(N, Q, te);
  }, xe.useInsertionEffect = function(N, Q) {
    return X.H.useInsertionEffect(N, Q);
  }, xe.useLayoutEffect = function(N, Q) {
    return X.H.useLayoutEffect(N, Q);
  }, xe.useMemo = function(N, Q) {
    return X.H.useMemo(N, Q);
  }, xe.useOptimistic = function(N, Q) {
    return X.H.useOptimistic(N, Q);
  }, xe.useReducer = function(N, Q, te) {
    return X.H.useReducer(N, Q, te);
  }, xe.useRef = function(N) {
    return X.H.useRef(N);
  }, xe.useState = function(N) {
    return X.H.useState(N);
  }, xe.useSyncExternalStore = function(N, Q, te) {
    return X.H.useSyncExternalStore(
      N,
      Q,
      te
    );
  }, xe.useTransition = function() {
    return X.H.useTransition();
  }, xe.version = "19.3.1", xe;
}
var Ah;
function Bo() {
  return Ah || (Ah = 1, wo.exports = i0()), wo.exports;
}
var w = Bo();
const r0 = /* @__PURE__ */ a0(w);
var No = { exports: {} }, zt = {};
/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Mh;
function d0() {
  if (Mh) return zt;
  Mh = 1;
  var d = Bo();
  function s(x) {
    var b = "https://react.dev/errors/" + x;
    if (1 < arguments.length) {
      b += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var y = 2; y < arguments.length; y++)
        b += "&args[]=" + encodeURIComponent(arguments[y]);
    }
    return "Minified React error #" + x + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function o() {
  }
  var u = {
    d: {
      f: o,
      r: function() {
        throw Error(s(522));
      },
      D: o,
      C: o,
      L: o,
      m: o,
      X: o,
      S: o,
      M: o
    },
    p: 0,
    findDOMNode: null
  }, c = Symbol.for("react.portal"), f = Symbol.for("react.recoverable"), m = Symbol.for("react.optimistic_key");
  function h(x, b, y) {
    var z = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: c,
      key: z == null ? null : z === m ? m : "" + z,
      children: x,
      containerInfo: b,
      implementation: y
    };
  }
  var v = d.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function j(x, b) {
    if (x === "font") return "";
    if (typeof b == "string")
      return b === "use-credentials" ? b : "";
  }
  return zt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = u, zt.browser = function(x) {
    return { $$typeof: f, _reason: x };
  }, zt.createPortal = function(x, b) {
    var y = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!b || b.nodeType !== 1 && b.nodeType !== 9 && b.nodeType !== 11)
      throw Error(s(299));
    return h(x, b, null, y);
  }, zt.flushSync = function(x) {
    var b = v.T, y = u.p;
    try {
      if (v.T = null, u.p = 2, x) return x();
    } finally {
      v.T = b, u.p = y, u.d.f();
    }
  }, zt.preconnect = function(x, b) {
    typeof x == "string" && (b ? (b = b.crossOrigin, b = typeof b == "string" ? b === "use-credentials" ? b : "" : void 0) : b = null, u.d.C(x, b));
  }, zt.prefetchDNS = function(x) {
    typeof x == "string" && u.d.D(x);
  }, zt.preinit = function(x, b) {
    if (typeof x == "string" && b && typeof b.as == "string") {
      var y = b.as, z = j(y, b.crossOrigin), O = typeof b.integrity == "string" ? b.integrity : void 0, E = typeof b.fetchPriority == "string" ? b.fetchPriority : void 0;
      y === "style" ? u.d.S(
        x,
        typeof b.precedence == "string" ? b.precedence : void 0,
        {
          crossOrigin: z,
          integrity: O,
          fetchPriority: E
        }
      ) : y === "script" && u.d.X(x, {
        crossOrigin: z,
        integrity: O,
        fetchPriority: E,
        nonce: typeof b.nonce == "string" ? b.nonce : void 0
      });
    }
  }, zt.preinitModule = function(x, b) {
    if (typeof x == "string")
      if (typeof b == "object" && b !== null) {
        if (b.as == null || b.as === "script") {
          var y = j(
            b.as,
            b.crossOrigin
          );
          u.d.M(x, {
            crossOrigin: y,
            integrity: typeof b.integrity == "string" ? b.integrity : void 0,
            nonce: typeof b.nonce == "string" ? b.nonce : void 0,
            fetchPriority: typeof b.fetchPriority == "string" ? b.fetchPriority : void 0
          });
        }
      } else b == null && u.d.M(x);
  }, zt.preload = function(x, b) {
    if (typeof x == "string" && typeof b == "object" && b !== null && typeof b.as == "string") {
      var y = b.as, z = j(y, b.crossOrigin);
      u.d.L(x, y, {
        crossOrigin: z,
        integrity: typeof b.integrity == "string" ? b.integrity : void 0,
        nonce: typeof b.nonce == "string" ? b.nonce : void 0,
        type: typeof b.type == "string" ? b.type : void 0,
        fetchPriority: typeof b.fetchPriority == "string" ? b.fetchPriority : void 0,
        referrerPolicy: typeof b.referrerPolicy == "string" ? b.referrerPolicy : void 0,
        imageSrcSet: typeof b.imageSrcSet == "string" ? b.imageSrcSet : void 0,
        imageSizes: typeof b.imageSizes == "string" ? b.imageSizes : void 0,
        media: typeof b.media == "string" ? b.media : void 0
      });
    }
  }, zt.preloadModule = function(x, b) {
    if (typeof x == "string")
      if (b) {
        var y = j(b.as, b.crossOrigin);
        u.d.m(x, {
          as: typeof b.as == "string" && b.as !== "script" ? b.as : void 0,
          crossOrigin: y,
          integrity: typeof b.integrity == "string" ? b.integrity : void 0,
          nonce: typeof b.nonce == "string" ? b.nonce : void 0,
          fetchPriority: typeof b.fetchPriority == "string" ? b.fetchPriority : void 0
        });
      } else u.d.m(x);
  }, zt.requestFormReset = function(x) {
    u.d.r(x);
  }, zt.unstable_batchedUpdates = function(x, b) {
    return x(b);
  }, zt.useFormState = function(x, b, y) {
    return v.H.useFormState(x, b, y);
  }, zt.useFormStatus = function() {
    return v.H.useHostTransitionStatus();
  }, zt.version = "19.3.1", zt;
}
var Oh;
function Kh() {
  if (Oh) return No.exports;
  Oh = 1;
  function d() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(d);
      } catch (s) {
        console.error(s);
      }
  }
  return d(), No.exports = d0(), No.exports;
}
var Jh = Kh(), To = { exports: {} }, ar = {}, Eo = { exports: {} }, Co = {};
/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Dh;
function s0() {
  return Dh || (Dh = 1, (function(d) {
    function s(L, P) {
      var re = L.length;
      L.push(P);
      e: for (; 0 < re; ) {
        var Ce = re - 1 >>> 1, he = L[Ce];
        if (0 < c(he, P))
          L[Ce] = P, L[re] = he, re = Ce;
        else break e;
      }
    }
    function o(L) {
      return L.length === 0 ? null : L[0];
    }
    function u(L) {
      if (L.length === 0) return null;
      var P = L[0], re = L.pop();
      if (re !== P) {
        L[0] = re;
        e: for (var Ce = 0, he = L.length, ge = he >>> 1; Ce < ge; ) {
          var We = 2 * (Ce + 1) - 1, St = L[We], N = We + 1, Q = L[N];
          if (0 > c(St, re))
            N < he && 0 > c(Q, St) ? (L[Ce] = Q, L[N] = re, Ce = N) : (L[Ce] = St, L[We] = re, Ce = We);
          else if (N < he && 0 > c(Q, re))
            L[Ce] = Q, L[N] = re, Ce = N;
          else break e;
        }
      }
      return P;
    }
    function c(L, P) {
      var re = L.sortIndex - P.sortIndex;
      return re !== 0 ? re : L.id - P.id;
    }
    if (d.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
      var f = performance;
      d.unstable_now = function() {
        return f.now();
      };
    } else {
      var m = Date, h = m.now();
      d.unstable_now = function() {
        return m.now() - h;
      };
    }
    var v = [], j = [], x = 1, b = null, y = 3, z = !1, O = !1, E = !1, R = !1, U = typeof setTimeout == "function" ? setTimeout : null, H = typeof clearTimeout == "function" ? clearTimeout : null, V = typeof setImmediate < "u" ? setImmediate : null;
    function W(L) {
      for (var P = o(j); P !== null; ) {
        if (P.callback === null) u(j);
        else if (P.startTime <= L)
          u(j), P.sortIndex = P.expirationTime, s(v, P);
        else break;
        P = o(j);
      }
    }
    function J(L) {
      if (E = !1, W(L), !O)
        if (o(v) !== null)
          O = !0, se || (se = !0, ce());
        else {
          var P = o(j);
          P !== null && Ee(J, P.startTime - L);
        }
    }
    var se = !1, G = -1, X = 5, me = -1;
    function pe() {
      return R ? !0 : !(d.unstable_now() - me < X);
    }
    function $() {
      if (R = !1, se) {
        var L = d.unstable_now();
        me = L;
        var P = !0;
        try {
          e: {
            O = !1, E && (E = !1, H(G), G = -1), z = !0;
            var re = y;
            try {
              t: {
                for (W(L), b = o(v); b !== null && !(b.expirationTime > L && pe()); ) {
                  var Ce = b.callback;
                  if (typeof Ce == "function") {
                    b.callback = null, y = b.priorityLevel;
                    var he = Ce(
                      b.expirationTime <= L
                    );
                    if (L = d.unstable_now(), typeof he == "function") {
                      b.callback = he, W(L), P = !0;
                      break t;
                    }
                    b === o(v) && u(v), W(L);
                  } else u(v);
                  b = o(v);
                }
                if (b !== null) P = !0;
                else {
                  var ge = o(j);
                  ge !== null && Ee(
                    J,
                    ge.startTime - L
                  ), P = !1;
                }
              }
              break e;
            } finally {
              b = null, y = re, z = !1;
            }
            P = void 0;
          }
        } finally {
          P ? ce() : se = !1;
        }
      }
    }
    var ce;
    if (typeof V == "function")
      ce = function() {
        V($);
      };
    else if (typeof MessageChannel < "u") {
      var I = new MessageChannel(), De = I.port2;
      I.port1.onmessage = $, ce = function() {
        De.postMessage(null);
      };
    } else
      ce = function() {
        U($, 0);
      };
    function Ee(L, P) {
      G = U(function() {
        L(d.unstable_now());
      }, P);
    }
    d.unstable_IdlePriority = 5, d.unstable_ImmediatePriority = 1, d.unstable_LowPriority = 4, d.unstable_NormalPriority = 3, d.unstable_Profiling = null, d.unstable_UserBlockingPriority = 2, d.unstable_cancelCallback = function(L) {
      L.callback = null;
    }, d.unstable_forceFrameRate = function(L) {
      0 > L || 125 < L ? console.error(
        "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
      ) : X = 0 < L ? Math.floor(1e3 / L) : 5;
    }, d.unstable_getCurrentPriorityLevel = function() {
      return y;
    }, d.unstable_next = function(L) {
      switch (y) {
        case 1:
        case 2:
        case 3:
          var P = 3;
          break;
        default:
          P = y;
      }
      var re = y;
      y = P;
      try {
        return L();
      } finally {
        y = re;
      }
    }, d.unstable_requestPaint = function() {
      R = !0;
    }, d.unstable_runWithPriority = function(L, P) {
      switch (L) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          L = 3;
      }
      var re = y;
      y = L;
      try {
        return P();
      } finally {
        y = re;
      }
    }, d.unstable_scheduleCallback = function(L, P, re) {
      var Ce = d.unstable_now();
      switch (typeof re == "object" && re !== null ? (re = re.delay, re = typeof re == "number" && 0 < re ? Ce + re : Ce) : re = Ce, L) {
        case 1:
          var he = -1;
          break;
        case 2:
          he = 250;
          break;
        case 5:
          he = 1073741823;
          break;
        case 4:
          he = 1e4;
          break;
        default:
          he = 5e3;
      }
      return he = re + he, L = {
        id: x++,
        callback: P,
        priorityLevel: L,
        startTime: re,
        expirationTime: he,
        sortIndex: -1
      }, re > Ce ? (L.sortIndex = re, s(j, L), o(v) === null && L === o(j) && (E ? (H(G), G = -1) : E = !0, Ee(J, re - Ce))) : (L.sortIndex = he, s(v, L), O || z || (O = !0, se || (se = !0, ce()))), L;
    }, d.unstable_shouldYield = pe, d.unstable_wrapCallback = function(L) {
      var P = y;
      return function() {
        var re = y;
        y = P;
        try {
          return L.apply(this, arguments);
        } finally {
          y = re;
        }
      };
    };
  })(Co)), Co;
}
var qh;
function u0() {
  return qh || (qh = 1, Eo.exports = s0()), Eo.exports;
}
/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var kh;
function o0() {
  if (kh) return ar;
  kh = 1;
  var d = u0(), s = Bo(), o = Kh();
  function u(e) {
    var t = "https://react.dev/errors/" + e;
    if (1 < arguments.length) {
      t += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        t += "&args[]=" + encodeURIComponent(arguments[a]);
    }
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function c(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
  }
  function f(e) {
    for (var t = e, a = t; a && !a.alternate; )
      t = a, (t.flags & 4098) !== 0 && (e = t.return), a = t.return;
    for (; t.return; ) t = t.return;
    return t.tag === 3 ? e : null;
  }
  function m(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function h(e) {
    if (e.tag === 31) {
      var t = e.memoizedState;
      if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function v(e) {
    if (f(e) !== e)
      throw Error(u(188));
  }
  function j(e) {
    var t = e.alternate;
    if (!t) {
      if (t = f(e), t === null) throw Error(u(188));
      return t !== e ? null : e;
    }
    for (var a = e, l = t; ; ) {
      var n = a.return;
      if (n === null) break;
      var r = n.alternate;
      if (r === null) {
        if (l = n.return, l !== null) {
          a = l;
          continue;
        }
        break;
      }
      if (n.child === r.child) {
        for (r = n.child; r; ) {
          if (r === a) return v(n), e;
          if (r === l) return v(n), t;
          r = r.sibling;
        }
        throw Error(u(188));
      }
      if (a.return !== l.return) a = n, l = r;
      else {
        for (var p = !1, g = n.child; g; ) {
          if (g === a) {
            p = !0, a = n, l = r;
            break;
          }
          if (g === l) {
            p = !0, l = n, a = r;
            break;
          }
          g = g.sibling;
        }
        if (!p) {
          for (g = r.child; g; ) {
            if (g === a) {
              p = !0, a = r, l = n;
              break;
            }
            if (g === l) {
              p = !0, l = r, a = n;
              break;
            }
            g = g.sibling;
          }
          if (!p) throw Error(u(189));
        }
      }
      if (a.alternate !== l) throw Error(u(190));
    }
    if (a.tag !== 3) throw Error(u(188));
    return a.stateNode.current === a ? e : t;
  }
  function x(e) {
    var t = e.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return e;
    for (e = e.child; e !== null; ) {
      if (t = x(e), t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  function b(e, t, a, l, n, r) {
    for (; e !== null; ) {
      if ((e.tag === 5 || e.tag === 27 || e.tag === 6) && a(e, l, n, r) || (e.tag !== 22 || e.memoizedState === null) && (t || e.tag !== 5 && e.tag !== 27) && b(
        e.child,
        t,
        a,
        l,
        n,
        r
      ))
        return !0;
      e = e.sibling;
    }
    return !1;
  }
  function y(e) {
    for (e = e.return; e !== null; ) {
      if (e.tag === 3 || e.tag === 5 || e.tag === 27) return e;
      e = e.return;
    }
    return null;
  }
  function z(e) {
    var t = !1;
    for (e = e.return; e !== null && (e.tag === 4 && (t = !0), !(e.tag === 3 || e.tag === 5 || e.tag === 27)); )
      e = e.return;
    return t;
  }
  function O(e) {
    var t = [null, null], a = y(e);
    return a === null || E(
      t,
      e,
      a.child,
      { foundSelf: !1 }
    ), t;
  }
  function E(e, t, a, l) {
    for (; a !== null; ) {
      if (a === t) l.foundSelf = !0;
      else if (a.tag === 5 || a.tag === 27 || a.tag === 6) {
        if (l.foundSelf) return e[1] = a, !0;
        e[0] = a;
      } else if ((a.tag !== 22 || a.memoizedState === null) && E(
        e,
        t,
        a.child,
        l
      ))
        return !0;
      a = a.sibling;
    }
    return !1;
  }
  function R(e) {
    switch (e.tag) {
      case 5:
      case 27:
      case 6:
        return e.stateNode;
      case 3:
        return e.stateNode.containerInfo;
      default:
        throw Error(u(559));
    }
  }
  var U = null, H = null;
  function V(e, t, a) {
    return e === a ? !0 : e === t ? (U = e, !0) : !1;
  }
  function W(e, t, a) {
    return e === a ? (H = e, !1) : e === t ? (H !== null && (U = e), !0) : !1;
  }
  function J(e) {
    if (e === null) return null;
    do
      e = e === null ? null : e.return;
    while (e && e.tag !== 5 && e.tag !== 27 && e.tag !== 3);
    return e || null;
  }
  function se(e, t, a) {
    for (var l = 0, n = e; n; n = a(n)) l++;
    n = 0;
    for (var r = t; r; r = a(r)) n++;
    for (; 0 < l - n; ) e = a(e), l--;
    for (; 0 < n - l; ) t = a(t), n--;
    for (; l--; ) {
      if (e === t || t !== null && e === t.alternate)
        return e;
      e = a(e), t = a(t);
    }
    return null;
  }
  var G = Object.assign, X = Symbol.for("react.element"), me = Symbol.for("react.transitional.element"), pe = Symbol.for("react.portal"), $ = Symbol.for("react.fragment"), ce = Symbol.for("react.strict_mode"), I = Symbol.for("react.profiler"), De = Symbol.for("react.consumer"), Ee = Symbol.for("react.context"), L = Symbol.for("react.forward_ref"), P = Symbol.for("react.suspense"), re = Symbol.for("react.suspense_list"), Ce = Symbol.for("react.memo"), he = Symbol.for("react.lazy"), ge = Symbol.for("react.activity"), We = Symbol.for("react.legacy_hidden"), St = Symbol.for("react.memo_cache_sentinel"), N = Symbol.for("react.view_transition"), Q = Symbol.for("react.recoverable"), te = Symbol.iterator;
  function ae(e) {
    return e === null || typeof e != "object" ? null : (e = te && e[te] || e["@@iterator"], typeof e == "function" ? e : null);
  }
  var we = Symbol.for("react.client.reference");
  function Ae(e) {
    if (e == null) return null;
    if (typeof e == "function")
      return e.$$typeof === we ? null : e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case $:
        return "Fragment";
      case I:
        return "Profiler";
      case ce:
        return "StrictMode";
      case P:
        return "Suspense";
      case re:
        return "SuspenseList";
      case ge:
        return "Activity";
      case N:
        return "ViewTransition";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case pe:
          return "Portal";
        case Ee:
          return e.displayName || "Context";
        case De:
          return (e._context.displayName || "Context") + ".Consumer";
        case L:
          var t = e.render;
          return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Ce:
          return t = e.displayName || null, t !== null ? t : Ae(e.type) || "Memo";
        case he:
          t = e._payload, e = e._init;
          try {
            return Ae(e(t));
          } catch {
          }
      }
    return null;
  }
  var ze = Array.isArray, le = s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, oe = o.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, wt = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, Al = [], _a = -1;
  function Nt(e) {
    return { current: e };
  }
  function $e(e) {
    0 > _a || (e.current = Al[_a], Al[_a] = null, _a--);
  }
  function Ye(e, t) {
    _a++, Al[_a] = e.current, e.current = t;
  }
  var Qt = Nt(null), Ml = Nt(null), Ot = Nt(null), Ol = Nt(null);
  function un(e, t) {
    switch (Ye(Ot, t), Ye(Ml, e), Ye(Qt, null), t.nodeType) {
      case 9:
      case 11:
        e = (e = t.documentElement) && (e = e.namespaceURI) ? Rm(e) : 0;
        break;
      default:
        if (e = t.tagName, t = t.namespaceURI)
          t = Rm(t), e = Um(t, e);
        else
          switch (e) {
            case "svg":
              e = 1;
              break;
            case "math":
              e = 2;
              break;
            default:
              e = 0;
          }
    }
    $e(Qt), Ye(Qt, e);
  }
  function Ma() {
    $e(Qt), $e(Ml), $e(Ot);
  }
  function Z(e) {
    var t = e.memoizedState;
    t !== null && (Pn._currentValue = t.memoizedState, Ye(Ol, e)), t = Qt.current;
    var a = Um(t, e.type);
    t !== a && (Ye(Ml, e), Ye(Qt, a));
  }
  function qe(e) {
    Ml.current === e && ($e(Qt), $e(Ml)), Ol.current === e && ($e(Ol), Pn._currentValue = wt);
  }
  var ve, Pe;
  function ht(e) {
    if (ve === void 0)
      try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        ve = t && t[1] || "", Pe = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
    return `
` + ve + e + Pe;
  }
  var Oa = !1;
  function on(e, t) {
    if (!e || Oa) return "";
    Oa = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var l = {
        DetermineComponentFrameRoot: function() {
          try {
            if (t) {
              var Y = function() {
                throw Error();
              };
              if (Object.defineProperty(Y.prototype, "props", {
                set: function() {
                  throw Error();
                }
              }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(Y, []);
                } catch (F) {
                  var C = F;
                }
                Reflect.construct(e, [], Y);
              } else {
                try {
                  Y.call();
                } catch (F) {
                  C = F;
                }
                Y = !1;
                try {
                  var q = Object.getOwnPropertyDescriptor(
                    e.prototype,
                    "props"
                  );
                  Object.defineProperty(e.prototype, "props", {
                    configurable: !0,
                    set: function() {
                      throw Error();
                    }
                  }), Y = !0, new e();
                } finally {
                  Y && (q !== void 0 ? Object.defineProperty(e.prototype, "props", q) : delete e.prototype.props);
                }
              }
            } else {
              try {
                throw Error();
              } catch (F) {
                C = F;
              }
              (Y = e()) && typeof Y.catch == "function" && Y.catch(function() {
              });
            }
          } catch (F) {
            if (F && C && typeof F.stack == "string")
              return [F.stack, C.stack];
          }
          return [null, null];
        }
      };
      l.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var n = Object.getOwnPropertyDescriptor(
        l.DetermineComponentFrameRoot,
        "name"
      );
      n && n.configurable && Object.defineProperty(
        l.DetermineComponentFrameRoot,
        "name",
        { value: "DetermineComponentFrameRoot" }
      );
      var r = l.DetermineComponentFrameRoot(), p = r[0], g = r[1];
      if (p && g) {
        var S = p.split(`
`), M = g.split(`
`);
        for (n = l = 0; l < S.length && !S[l].includes("DetermineComponentFrameRoot"); )
          l++;
        for (; n < M.length && !M[n].includes(
          "DetermineComponentFrameRoot"
        ); )
          n++;
        if (l === S.length || n === M.length)
          for (l = S.length - 1, n = M.length - 1; 1 <= l && 0 <= n && S[l] !== M[n]; )
            n--;
        for (; 1 <= l && 0 <= n; l--, n--)
          if (S[l] !== M[n]) {
            if (l !== 1 || n !== 1)
              do
                if (l--, n--, 0 > n || S[l] !== M[n]) {
                  var k = `
` + S[l].replace(" at new ", " at ");
                  return e.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", e.displayName)), k;
                }
              while (1 <= l && 0 <= n);
            break;
          }
      }
    } finally {
      Oa = !1, Error.prepareStackTrace = a;
    }
    return (a = e ? e.displayName || e.name : "") ? ht(a) : "";
  }
  function nb(e, t) {
    switch (e.tag) {
      case 26:
      case 27:
      case 5:
        return ht(e.type);
      case 16:
        return ht("Lazy");
      case 13:
        return e.child !== t && t !== null ? ht("Suspense Fallback") : ht("Suspense");
      case 19:
        return ht("SuspenseList");
      case 0:
      case 15:
        return on(e.type, !1);
      case 11:
        return on(e.type.render, !1);
      case 1:
        return on(e.type, !0);
      case 31:
        return ht("Activity");
      case 30:
        return ht("ViewTransition");
      default:
        return "";
    }
  }
  function ac(e) {
    try {
      var t = "", a = null;
      do
        t += nb(e, a), a = e, e = e.return;
      while (e);
      return t;
    } catch (l) {
      return `
Error generating stack: ` + l.message + `
` + l.stack;
    }
  }
  var Kd = Object.prototype.hasOwnProperty, Jd = d.unstable_scheduleCallback, Fd = d.unstable_cancelCallback, ib = d.unstable_shouldYield, rb = d.unstable_requestPaint, Xt = d.unstable_now, db = d.unstable_getCurrentPriorityLevel, lc = d.unstable_ImmediatePriority, nc = d.unstable_UserBlockingPriority, pr = d.unstable_NormalPriority, sb = d.unstable_LowPriority, ic = d.unstable_IdlePriority, ub = d.log, ob = d.unstable_setDisableYieldValue, si = null, Vt = null;
  function $a(e) {
    if (typeof ub == "function" && ob(e), Vt && typeof Vt.setStrictMode == "function")
      try {
        Vt.setStrictMode(si, e);
      } catch {
      }
  }
  var Lt = Math.clz32 ? Math.clz32 : fb, cb = Math.log, pb = Math.LN2;
  function fb(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (cb(e) / pb | 0) | 0;
  }
  var fr = 256, mr = 262144, hr = 4194304;
  function Dl(e) {
    var t = e & 42;
    if (t !== 0) return t;
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return e & -e;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return e & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return e;
    }
  }
  function gr(e, t, a) {
    var l = e.pendingLanes;
    if (l === 0) return 0;
    var n = 0, r = e.suspendedLanes, p = e.pingedLanes;
    e = e.warmLanes;
    var g = l & 134217727;
    return g !== 0 ? (l = g & ~r, l !== 0 ? n = Dl(l) : (p &= g, p !== 0 ? n = Dl(p) : a || (a = g & ~e, a !== 0 && (n = Dl(a))))) : (g = l & ~r, g !== 0 ? n = Dl(g) : p !== 0 ? n = Dl(p) : a || (a = l & ~e, a !== 0 && (n = Dl(a)))), n === 0 ? 0 : t !== 0 && t !== n && (t & r) === 0 && (r = n & -n, a = t & -t, r >= a || r === 32 && (a & 4194048) !== 0) ? t : n;
  }
  function ui(e, t) {
    return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
  }
  function rc(e, t) {
    (t & 8) !== 0 && (t |= t & 32);
    var a = e.entangledLanes;
    if (a !== 0)
      for (e = e.entanglements, a &= t; 0 < a; ) {
        var l = 31 - Lt(a), n = 1 << l;
        t |= e[l], a &= ~n;
      }
    return t;
  }
  function mb(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function dc() {
    var e = hr;
    return hr <<= 1, (hr & 62914560) === 0 && (hr = 4194304), e;
  }
  function Wd(e) {
    for (var t = [], a = 0; 31 > a; a++) t.push(e);
    return t;
  }
  function oi(e, t) {
    e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
  }
  function hb(e, t, a, l, n, r) {
    var p = e.pendingLanes;
    e.pendingLanes = a, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= a, e.entangledLanes &= a, e.errorRecoveryDisabledLanes &= a, e.shellSuspendCounter = 0;
    var g = e.entanglements, S = e.expirationTimes, M = e.hiddenUpdates;
    for (a = p & ~a; 0 < a; ) {
      var k = 31 - Lt(a), Y = 1 << k;
      g[k] = 0, S[k] = -1;
      var C = M[k];
      if (C !== null)
        for (M[k] = null, k = 0; k < C.length; k++) {
          var q = C[k];
          q !== null && (q.lane &= -536870913);
        }
      a &= ~Y;
    }
    l !== 0 && sc(e, l, 0), r !== 0 && n === 0 && e.tag !== 0 && (e.suspendedLanes |= r & ~(p & ~t));
  }
  function sc(e, t, a) {
    e.pendingLanes |= t, e.suspendedLanes &= ~t;
    var l = 31 - Lt(t);
    e.entangledLanes |= t, e.entanglements[l] = e.entanglements[l] | 1073741824 | a & 261930;
  }
  function uc(e, t) {
    var a = e.entangledLanes |= t;
    for (e = e.entanglements; a; ) {
      var l = 31 - Lt(a), n = 1 << l;
      n & t | e[l] & t && (e[l] |= t), a &= ~n;
    }
  }
  function oc(e, t) {
    var a = t & -t;
    return a = (a & 42) !== 0 ? 1 : Id(a), (a & (e.suspendedLanes | t)) !== 0 ? 0 : a;
  }
  function Id(e) {
    switch (e) {
      case 2:
        e = 1;
        break;
      case 8:
        e = 4;
        break;
      case 32:
        e = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        e = 128;
        break;
      case 268435456:
        e = 134217728;
        break;
      default:
        e = 0;
    }
    return e;
  }
  function Pd(e) {
    return e &= -e, 2 < e ? 8 < e ? (e & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function cc() {
    var e = oe.p;
    return e !== 0 ? e : (e = window.event, e === void 0 ? 32 : xh(e.type));
  }
  function pc(e, t) {
    var a = oe.p;
    try {
      return oe.p = e, t();
    } finally {
      oe.p = a;
    }
  }
  var Da = Math.random().toString(36).slice(2), gt = "__reactFiber$" + Da, Dt = "__reactProps$" + Da, cn = "__reactContainer$" + Da, fc = "__reactEvents$" + Da, gb = "__reactListeners$" + Da, bb = "__reactHandles$" + Da, mc = "__reactResources$" + Da, ci = "__reactMarker$" + Da, br = "__reactLoad$" + Da;
  function vr(e) {
    delete e[gt], delete e[Dt], delete e[gb], delete e[bb];
  }
  function ql(e) {
    var t;
    if (t = e[gt]) return t;
    for (var a = e.parentNode; a; ) {
      if (t = a[cn] || a[gt]) {
        if (a = t.alternate, t.child !== null || a !== null && a.child !== null)
          for (e = $m(e); e !== null; ) {
            if (a = e[gt]) return a;
            e = $m(e);
          }
        return t;
      }
      e = a, a = e.parentNode;
    }
    return null;
  }
  function pn(e) {
    if (e = e[gt] || e[cn]) {
      var t = e.tag;
      if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3)
        return e;
    }
    return null;
  }
  function pi(e) {
    var t = e.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
    throw Error(u(33));
  }
  function fn(e) {
    var t = e[mc];
    return t || (t = e[mc] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), t;
  }
  function ct(e) {
    e[ci] = !0;
  }
  function hc(e) {
    e[br] = void 0;
  }
  var gc = /* @__PURE__ */ new Set(), bc = {};
  function kl(e, t) {
    mn(e, t), mn(e + "Capture", t);
  }
  function mn(e, t) {
    for (bc[e] = t, e = 0; e < t.length; e++)
      gc.add(t[e]);
  }
  var vb = RegExp(
    "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"
  ), vc = {}, xc = {};
  function xb(e) {
    return Kd.call(xc, e) ? !0 : Kd.call(vc, e) ? !1 : vb.test(e) ? xc[e] = !0 : (vc[e] = !0, !1);
  }
  var He = !1;
  function yc() {
    var e = He;
    return He = !1, e;
  }
  function xr(e, t, a) {
    if (xb(t))
      if (a === null) e.removeAttribute(t);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
            e.removeAttribute(t);
            return;
          case "boolean":
            var l = t.toLowerCase().slice(0, 5);
            if (l !== "data-" && l !== "aria-") {
              e.removeAttribute(t);
              return;
            }
        }
        e.setAttribute(t, a);
      }
  }
  function yr(e, t, a) {
    if (a === null) e.removeAttribute(t);
    else {
      switch (typeof a) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          e.removeAttribute(t);
          return;
      }
      e.setAttribute(t, a);
    }
  }
  function qa(e, t, a, l) {
    if (l === null) e.removeAttribute(a);
    else {
      switch (typeof l) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          e.removeAttribute(a);
          return;
      }
      e.setAttributeNS(t, a, l);
    }
  }
  function Gt(e) {
    switch (typeof e) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function jc(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function yb(e, t, a) {
    var l = Object.getOwnPropertyDescriptor(
      e.constructor.prototype,
      t
    );
    if (!e.hasOwnProperty(t) && typeof l < "u" && typeof l.get == "function" && typeof l.set == "function") {
      var n = l.get, r = l.set;
      return Object.defineProperty(e, t, {
        configurable: !0,
        get: function() {
          return n.call(this);
        },
        set: function(p) {
          a = "" + p, r.call(this, p);
        }
      }), Object.defineProperty(e, t, {
        enumerable: l.enumerable
      }), {
        getValue: function() {
          return a;
        },
        setValue: function(p) {
          a = "" + p;
        },
        stopTracking: function() {
          e._valueTracker = null, delete e[t];
        }
      };
    }
  }
  function _d(e) {
    if (!e._valueTracker) {
      var t = jc(e) ? "checked" : "value";
      e._valueTracker = yb(
        e,
        t,
        "" + e[t]
      );
    }
  }
  function zc(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var a = t.getValue(), l = "";
    return e && (l = jc(e) ? e.checked ? "true" : "false" : e.value), e = l, e !== a ? (t.setValue(e), !0) : !1;
  }
  var jb = /[\n"\\]/g;
  function ea(e) {
    return e.replace(
      jb,
      function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      }
    );
  }
  function $d(e, t, a, l, n, r, p, g) {
    e.name = "", p != null && typeof p != "function" && typeof p != "symbol" && typeof p != "boolean" ? e.type = p : e.removeAttribute("type"), t != null ? p === "number" ? (t === 0 && e.value === "" || e.value != t) && (e.value = "" + Gt(t)) : e.value !== "" + Gt(t) && (e.value = "" + Gt(t)) : p !== "submit" && p !== "reset" || e.removeAttribute("value"), t != null ? p === "number" && e.value == t ? es(e, Gt(e.value)) : es(e, Gt(t)) : a != null ? es(e, Gt(a)) : l != null && e.removeAttribute("value"), n == null && r != null && (e.defaultChecked = !!r), n != null && (e.checked = n && typeof n != "function" && typeof n != "symbol"), g != null && typeof g != "function" && typeof g != "symbol" && typeof g != "boolean" ? e.name = "" + Gt(g) : e.removeAttribute("name");
  }
  function Sc(e, t, a, l, n, r, p, g) {
    if (r != null && typeof r != "function" && typeof r != "symbol" && typeof r != "boolean" && (e.type = r), t != null || a != null) {
      if (!(r !== "submit" && r !== "reset" || t != null)) {
        _d(e);
        return;
      }
      a = a != null ? "" + Gt(a) : "", t = t != null ? "" + Gt(t) : a, g || t === e.value || (e.value = t), e.defaultValue = t;
    }
    l = l ?? n, l = typeof l != "function" && typeof l != "symbol" && !!l, e.checked = g ? e.checked : !!l, e.defaultChecked = !!l, p != null && typeof p != "function" && typeof p != "symbol" && typeof p != "boolean" && (e.name = p), _d(e);
  }
  function es(e, t) {
    e.defaultValue !== "" + t && (e.defaultValue = "" + t);
  }
  function hn(e, t, a, l) {
    if (e = e.options, t) {
      t = {};
      for (var n = 0; n < a.length; n++)
        t["$" + a[n]] = !0;
      for (a = 0; a < e.length; a++)
        n = t.hasOwnProperty("$" + e[a].value), e[a].selected !== n && (e[a].selected = n), n && l && (e[a].defaultSelected = !0);
    } else {
      for (a = "" + Gt(a), t = null, n = 0; n < e.length; n++) {
        if (e[n].value === a) {
          e[n].selected = !0, l && (e[n].defaultSelected = !0);
          return;
        }
        t !== null || e[n].disabled || (t = e[n]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function wc(e, t, a) {
    if (t != null && (t = "" + Gt(t), t !== e.value && (e.value = t), a == null)) {
      e.defaultValue !== t && (e.defaultValue = t);
      return;
    }
    e.defaultValue = a != null ? "" + Gt(a) : "";
  }
  function Nc(e, t, a, l) {
    if (t == null) {
      if (l != null) {
        if (a != null) throw Error(u(92));
        if (ze(l)) {
          if (1 < l.length) throw Error(u(93));
          l = l[0];
        }
        a = l;
      }
      a == null && (a = ""), t = a;
    }
    a = Gt(t), e.defaultValue = a, l = e.textContent, l === a && l !== "" && l !== null && (e.value = l), _d(e);
  }
  function gn(e, t) {
    if (t) {
      var a = e.firstChild;
      if (a && a === e.lastChild && a.nodeType === 3) {
        a.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var zb = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " "
    )
  );
  function Tc(e, t, a) {
    var l = t.indexOf("--") === 0;
    a == null || typeof a == "boolean" || a === "" ? l ? e.setProperty(t, "") : t === "float" ? e.cssFloat = "" : e[t] = "" : l ? e.setProperty(t, a) : typeof a != "number" || a === 0 || zb.has(t) ? t === "float" ? e.cssFloat = a : e[t] = ("" + a).trim() : e[t] = a + "px";
  }
  function Ec(e, t, a) {
    if (t != null && typeof t != "object")
      throw Error(u(62));
    if (e = e.style, a != null) {
      for (var l in a)
        !a.hasOwnProperty(l) || t != null && t.hasOwnProperty(l) || (l.indexOf("--") === 0 ? e.setProperty(l, "") : l === "float" ? e.cssFloat = "" : e[l] = "", He = !0);
      for (var n in t)
        l = t[n], t.hasOwnProperty(n) && a[n] !== l && (Tc(e, n, l), He = !0);
    } else
      for (var r in t)
        t.hasOwnProperty(r) && Tc(e, r, t[r]);
  }
  function ts(e) {
    if (e.indexOf("-") === -1) return !1;
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var Sb = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["maskType", "mask-type"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), wb = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function jr(e) {
    return wb.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
  }
  function ba() {
  }
  var as = null;
  function ls(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
  }
  var bn = null, vn = null;
  function Cc(e) {
    var t = pn(e);
    if (t && (e = t.stateNode)) {
      var a = e[Dt] || null;
      e: switch (e = t.stateNode, t.type) {
        case "input":
          if ($d(
            e,
            a.value,
            a.defaultValue,
            a.defaultValue,
            a.checked,
            a.defaultChecked,
            a.type,
            a.name
          ), t = a.name, a.type === "radio" && t != null) {
            for (a = e; a.parentNode; ) a = a.parentNode;
            for (a = a.querySelectorAll(
              'input[name="' + ea(
                "" + t
              ) + '"][type="radio"]'
            ), t = 0; t < a.length; t++) {
              var l = a[t];
              if (l !== e && l.form === e.form) {
                var n = l[Dt] || null;
                if (!n) throw Error(u(90));
                $d(
                  l,
                  n.value,
                  n.defaultValue,
                  n.defaultValue,
                  n.checked,
                  n.defaultChecked,
                  n.type,
                  n.name
                );
              }
            }
            for (t = 0; t < a.length; t++)
              l = a[t], l.form === e.form && zc(l);
          }
          break e;
        case "textarea":
          wc(e, a.value, a.defaultValue);
          break e;
        case "select":
          t = a.value, t != null && hn(e, !!a.multiple, t, !1);
      }
    }
  }
  var ns = !1;
  function Ac(e, t, a) {
    if (ns) return e(t, a);
    ns = !0;
    try {
      var l = e(t);
      return l;
    } finally {
      if (ns = !1, (bn !== null || vn !== null) && (jd(), bn && (t = bn, e = vn, vn = bn = null, Cc(t), e)))
        for (t = 0; t < e.length; t++) Cc(e[t]);
    }
  }
  function fi(e, t) {
    var a = e.stateNode;
    if (a === null) return null;
    var l = a[Dt] || null;
    if (l === null) return null;
    a = l[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (l = !l.disabled) || (e = e.type, l = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !l;
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (a && typeof a != "function")
      throw Error(
        u(231, t, typeof a)
      );
    return a;
  }
  var ka = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), is = !1;
  if (ka)
    try {
      var mi = {};
      Object.defineProperty(mi, "passive", {
        get: function() {
          is = !0;
        }
      }), window.addEventListener("test", mi, mi), window.removeEventListener("test", mi, mi);
    } catch {
      is = !1;
    }
  var el = null, rs = null, zr = null;
  function Mc() {
    if (zr) return zr;
    var e, t = rs, a = t.length, l, n = "value" in el ? el.value : el.textContent, r = n.length;
    for (e = 0; e < a && t[e] === n[e]; e++) ;
    var p = a - e;
    for (l = 1; l <= p && t[a - l] === n[r - l]; l++) ;
    return zr = n.slice(e, 1 < l ? 1 - l : void 0);
  }
  function Sr(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
  }
  function wr() {
    return !0;
  }
  function Oc() {
    return !1;
  }
  function Et(e) {
    function t(a, l, n, r, p) {
      this._reactName = a, this._targetInst = n, this.type = l, this.nativeEvent = r, this.target = p, this.currentTarget = null;
      for (var g in e)
        e.hasOwnProperty(g) && (a = e[g], this[g] = a ? a(r) : r[g]);
      return this.isDefaultPrevented = (r.defaultPrevented != null ? r.defaultPrevented : r.returnValue === !1) ? wr : Oc, this.isPropagationStopped = Oc, this;
    }
    return G(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var a = this.nativeEvent;
        a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = wr);
      },
      stopPropagation: function() {
        var a = this.nativeEvent;
        a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = wr);
      },
      persist: function() {
      },
      isPersistent: wr
    }), t;
  }
  var tl = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, Nr = Et(tl), hi = G({}, tl, { view: 0, detail: 0 }), Nb = Et(hi), ds, ss, gi, Tr = G({}, hi, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: os,
    button: 0,
    buttons: 0,
    relatedTarget: function(e) {
      return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
    },
    movementX: function(e) {
      return "movementX" in e ? e.movementX : (e !== gi && (gi && e.type === "mousemove" ? (ds = e.screenX - gi.screenX, ss = e.screenY - gi.screenY) : ss = ds = 0, gi = e), ds);
    },
    movementY: function(e) {
      return "movementY" in e ? e.movementY : ss;
    }
  }), Dc = Et(Tr), Tb = G({}, Tr, { dataTransfer: 0 }), Eb = Et(Tb), Cb = G({}, hi, { relatedTarget: 0 }), us = Et(Cb), Ab = G({}, tl, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), Mb = Et(Ab), Ob = G({}, tl, {
    clipboardData: function(e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    }
  }), Db = Et(Ob), qb = G({}, tl, { data: 0 }), qc = Et(qb), kb = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, Rb = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, Ub = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function Hb(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = Ub[e]) ? !!t[e] : !1;
  }
  function os() {
    return Hb;
  }
  var Bb = G({}, hi, {
    key: function(e) {
      if (e.key) {
        var t = kb[e.key] || e.key;
        if (t !== "Unidentified") return t;
      }
      return e.type === "keypress" ? (e = Sr(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? Rb[e.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: os,
    charCode: function(e) {
      return e.type === "keypress" ? Sr(e) : 0;
    },
    keyCode: function(e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function(e) {
      return e.type === "keypress" ? Sr(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    }
  }), Yb = Et(Bb), Qb = G({}, Tr, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), kc = Et(Qb), Xb = G({}, tl, { submitter: 0 }), Vb = Et(Xb), Lb = G({}, hi, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: os
  }), Gb = Et(Lb), Zb = G({}, tl, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), Kb = Et(Zb), Jb = G({}, Tr, {
    deltaX: function(e) {
      return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
    },
    deltaY: function(e) {
      return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Fb = Et(Jb), Wb = G({}, tl, {
    newState: 0,
    oldState: 0,
    source: 0
  }), Ib = Et(Wb), Pb = [9, 13, 27, 32], cs = ka && "CompositionEvent" in window, bi = null;
  ka && "documentMode" in document && (bi = document.documentMode);
  var _b = ka && "TextEvent" in window && !bi, Rc = ka && (!cs || bi && 8 < bi && 11 >= bi), Uc = " ", Hc = !1;
  function Bc(e, t) {
    switch (e) {
      case "keyup":
        return Pb.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Yc(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
  }
  var xn = !1;
  function $b(e, t) {
    switch (e) {
      case "compositionend":
        return Yc(t);
      case "keypress":
        return t.which !== 32 ? null : (Hc = !0, Uc);
      case "textInput":
        return e = t.data, e === Uc && Hc ? null : e;
      default:
        return null;
    }
  }
  function ev(e, t) {
    if (xn)
      return e === "compositionend" || !cs && Bc(e, t) ? (e = Mc(), zr = rs = el = null, xn = !1, e) : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
          if (t.char && 1 < t.char.length)
            return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Rc && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var tv = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function Qc(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!tv[e.type] : t === "textarea";
  }
  function Xc(e, t, a, l) {
    bn ? vn ? vn.push(l) : vn = [l] : bn = l, t = Ed(t, "onChange"), 0 < t.length && (a = new Nr(
      "onChange",
      "change",
      null,
      a,
      l
    ), e.push({ event: a, listeners: t }));
  }
  var vi = null, xi = null;
  function av(e) {
    Am(e, 0);
  }
  function Er(e) {
    var t = pi(e);
    if (zc(t)) return e;
  }
  function Vc(e, t) {
    if (e === "change") return t;
  }
  var Lc = !1;
  if (ka) {
    var ps;
    if (ka) {
      var fs = "oninput" in document;
      if (!fs) {
        var Gc = document.createElement("div");
        Gc.setAttribute("oninput", "return;"), fs = typeof Gc.oninput == "function";
      }
      ps = fs;
    } else ps = !1;
    Lc = ps && (!document.documentMode || 9 < document.documentMode);
  }
  function Zc() {
    vi && (vi.detachEvent("onpropertychange", Kc), xi = vi = null);
  }
  function Kc(e) {
    if (e.propertyName === "value" && Er(xi)) {
      var t = [];
      Xc(
        t,
        xi,
        e,
        ls(e)
      ), Ac(av, t);
    }
  }
  function lv(e, t, a) {
    e === "focusin" ? (Zc(), vi = t, xi = a, vi.attachEvent("onpropertychange", Kc)) : e === "focusout" && Zc();
  }
  function nv(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Er(xi);
  }
  function iv(e, t) {
    if (e === "click") return Er(t);
  }
  function rv(e, t) {
    if (e === "input" || e === "change")
      return Er(t);
  }
  function dv(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
  }
  var Zt = typeof Object.is == "function" ? Object.is : dv;
  function yi(e, t) {
    if (Zt(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null)
      return !1;
    var a = Object.keys(e), l = Object.keys(t);
    if (a.length !== l.length) return !1;
    for (l = 0; l < a.length; l++) {
      var n = a[l];
      if (!Kd.call(t, n) || !Zt(e[n], t[n]))
        return !1;
    }
    return !0;
  }
  function ms(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Jc(e) {
    for (; e && e.firstChild; ) e = e.firstChild;
    return e;
  }
  function Fc(e, t) {
    var a = Jc(e);
    e = 0;
    for (var l; a; ) {
      if (a.nodeType === 3) {
        if (l = e + a.textContent.length, e <= t && l >= t)
          return { node: a, offset: t - e };
        e = l;
      }
      e: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break e;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = Jc(a);
    }
  }
  function Wc(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Wc(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1;
  }
  function Ic(e) {
    e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
    for (var t = ms(e.document); t instanceof e.HTMLIFrameElement; ) {
      try {
        var a = typeof t.contentWindow.location.href == "string";
      } catch {
        a = !1;
      }
      if (a) e = t.contentWindow;
      else break;
      t = ms(e.document);
    }
    return t;
  }
  function hs(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
  }
  var sv = ka && "documentMode" in document && 11 >= document.documentMode, yn = null, gs = null, ji = null, bs = !1;
  function Pc(e, t, a) {
    var l = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    bs || yn == null || yn !== ms(l) || (l = yn, "selectionStart" in l && hs(l) ? l = { start: l.selectionStart, end: l.selectionEnd } : (l = (l.ownerDocument && l.ownerDocument.defaultView || window).getSelection(), l = {
      anchorNode: l.anchorNode,
      anchorOffset: l.anchorOffset,
      focusNode: l.focusNode,
      focusOffset: l.focusOffset
    }), ji && yi(ji, l) || (ji = l, l = Ed(gs, "onSelect"), 0 < l.length && (t = new Nr(
      "onSelect",
      "select",
      null,
      t,
      a
    ), e.push({ event: t, listeners: l }), t.target = yn)));
  }
  function Rl(e, t) {
    var a = {};
    return a[e.toLowerCase()] = t.toLowerCase(), a["Webkit" + e] = "webkit" + t, a["Moz" + e] = "moz" + t, a;
  }
  var jn = {
    animationend: Rl("Animation", "AnimationEnd"),
    animationiteration: Rl("Animation", "AnimationIteration"),
    animationstart: Rl("Animation", "AnimationStart"),
    transitionrun: Rl("Transition", "TransitionRun"),
    transitionstart: Rl("Transition", "TransitionStart"),
    transitioncancel: Rl("Transition", "TransitionCancel"),
    transitionend: Rl("Transition", "TransitionEnd")
  }, vs = {}, _c = {};
  ka && (_c = document.createElement("div").style, "AnimationEvent" in window || (delete jn.animationend.animation, delete jn.animationiteration.animation, delete jn.animationstart.animation), "TransitionEvent" in window || delete jn.transitionend.transition);
  function Ul(e) {
    if (vs[e]) return vs[e];
    if (!jn[e]) return e;
    var t = jn[e], a;
    for (a in t)
      if (t.hasOwnProperty(a) && a in _c)
        return vs[e] = t[a];
    return e;
  }
  var $c = Ul("animationend"), ep = Ul("animationiteration"), tp = Ul("animationstart"), uv = Ul("transitionrun"), ov = Ul("transitionstart"), cv = Ul("transitioncancel"), ap = Ul("transitionend"), lp = /* @__PURE__ */ new Map(), xs = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
    " "
  );
  xs.push("scrollEnd");
  function ua(e, t) {
    lp.set(e, t), kl(t, [e]);
  }
  var pv = 0;
  function Ra(e, t) {
    if (e.name != null && e.name !== "auto") return e.name;
    if (t.autoName !== null) return t.autoName;
    e = fa.identifierPrefix;
    var a = pv++;
    return e = "_" + e + "t_" + a.toString(32) + "_", t.autoName = e;
  }
  function np(e) {
    if (e == null || typeof e == "string")
      return e;
    var t = null, a = Xn;
    if (a !== null)
      for (var l = 0; l < a.length; l++) {
        var n = e[a[l]];
        if (n != null) {
          if (n === "none") return "none";
          t = t == null ? n : t + (" " + n);
        }
      }
    return t ?? e.default;
  }
  function Ua(e, t) {
    return e = np(e), t = np(t), t == null ? e === "auto" ? null : e : t === "auto" ? null : t;
  }
  var Cr = typeof reportError == "function" ? reportError : function(e) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var t = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
        error: e
      });
      if (!window.dispatchEvent(t)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", e);
      return;
    }
    console.error(e);
  }, ta = [], zn = 0, ys = 0;
  function Ar() {
    for (var e = zn, t = ys = zn = 0; t < e; ) {
      var a = ta[t];
      ta[t++] = null;
      var l = ta[t];
      ta[t++] = null;
      var n = ta[t];
      ta[t++] = null;
      var r = ta[t];
      if (ta[t++] = null, l !== null && n !== null) {
        var p = l.pending;
        p === null ? n.next = n : (n.next = p.next, p.next = n), l.pending = n;
      }
      r !== 0 && ip(a, n, r);
    }
  }
  function Mr(e, t, a, l) {
    ta[zn++] = e, ta[zn++] = t, ta[zn++] = a, ta[zn++] = l, ys |= l, e.lanes |= l, e = e.alternate, e !== null && (e.lanes |= l);
  }
  function js(e, t, a, l) {
    return Mr(e, t, a, l), Or(e);
  }
  function Hl(e, t) {
    return Mr(e, null, null, t), Or(e);
  }
  function ip(e, t, a) {
    e.lanes |= a;
    var l = e.alternate;
    l !== null && (l.lanes |= a);
    for (var n = !1, r = e.return; r !== null; )
      r.childLanes |= a, l = r.alternate, l !== null && (l.childLanes |= a), r.tag === 22 && (e = r.stateNode, e === null || e._visibility & 1 || (n = !0)), e = r, r = r.return;
    return e.tag === 3 ? (r = e.stateNode, n && t !== null && (n = 31 - Lt(a), e = r.hiddenUpdates, l = e[n], l === null ? e[n] = [t] : l.push(t), t.lane = a | 536870912), r) : null;
  }
  function Or(e) {
    if (50 < Li)
      throw Li = 0, yd = null, Error(u(185));
    for (var t = e.return; t !== null; )
      e = t, t = e.return;
    return e.tag === 3 ? e.stateNode : null;
  }
  var Sn = {};
  function fv(e, t, a, l) {
    this.tag = e, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = l, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function qt(e, t, a, l) {
    return new fv(e, t, a, l);
  }
  function zs(e) {
    return e = e.prototype, !(!e || !e.isReactComponent);
  }
  function Ha(e, t) {
    var a = e.alternate;
    return a === null ? (a = qt(
      e.tag,
      t,
      e.key,
      e.mode
    ), a.elementType = e.elementType, a.type = e.type, a.stateNode = e.stateNode, a.alternate = e, e.alternate = a) : (a.pendingProps = t, a.type = e.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = e.flags & 1206910976, a.childLanes = e.childLanes, a.lanes = e.lanes, a.child = e.child, a.memoizedProps = e.memoizedProps, a.memoizedState = e.memoizedState, a.updateQueue = e.updateQueue, t = e.dependencies, a.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, a.sibling = e.sibling, a.index = e.index, a.ref = e.ref, a.refCleanup = e.refCleanup, a;
  }
  function rp(e, t) {
    e.flags &= 1206910978;
    var a = e.alternate;
    return a === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = a.childLanes, e.lanes = a.lanes, e.child = a.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = a.memoizedProps, e.memoizedState = a.memoizedState, e.updateQueue = a.updateQueue, e.type = a.type, t = a.dependencies, e.dependencies = t === null ? null : {
      lanes: t.lanes,
      firstContext: t.firstContext
    }), e;
  }
  function Dr(e, t, a, l, n, r) {
    var p = 0;
    if (l = e, typeof l == "function") zs(l) && (p = 1);
    else if (typeof l == "string")
      p = Xx(
        e,
        a,
        Qt.current
      ) ? 26 : e === "html" || e === "head" || e === "body" ? 27 : 5;
    else
      e: switch (l) {
        case ge:
          return e = qt(31, a, t, n), e.elementType = ge, e.lanes = r, e;
        case $:
          return Bl(a.children, n, r, t);
        case ce:
          p = 8, n |= 24;
          break;
        case I:
          return e = qt(12, a, t, n | 2), e.elementType = I, e.lanes = r, e;
        case P:
          return e = qt(13, a, t, n), e.elementType = P, e.lanes = r, e;
        case re:
          return e = qt(19, a, t, n), e.elementType = re, e.lanes = r, e;
        case We:
        case N:
          return e = n | 32, e = qt(30, a, t, e), e.elementType = N, e.lanes = r, e.stateNode = {
            autoName: null,
            paired: null,
            clones: null,
            ref: null
          }, e;
        default:
          if (typeof l == "object" && l !== null)
            switch (l.$$typeof) {
              case Ee:
                p = 10;
                break e;
              case De:
                p = 9;
                break e;
              case L:
                p = 11;
                break e;
              case Ce:
                p = 14;
                break e;
              case he:
                p = 16, l = null;
                break e;
            }
          p = 29, a = Error(
            u(130, e === null ? "null" : typeof e, "")
          ), l = null;
      }
    return t = qt(p, a, t, n), t.elementType = e, t.type = l, t.lanes = r, t;
  }
  function Bl(e, t, a, l) {
    return e = qt(7, e, l, t), e.lanes = a, e;
  }
  function Ss(e, t, a) {
    return e = qt(6, e, null, t), e.lanes = a, e;
  }
  function dp(e) {
    var t = qt(18, null, null, 0);
    return t.stateNode = e, t;
  }
  function ws(e, t, a) {
    return t = qt(
      4,
      e.children !== null ? e.children : [],
      e.key,
      t
    ), t.lanes = a, t.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      implementation: e.implementation
    }, t;
  }
  var sp = /* @__PURE__ */ new WeakMap();
  function aa(e, t) {
    if (typeof e == "object" && e !== null) {
      var a = sp.get(e);
      return a !== void 0 ? a : (t = {
        value: e,
        source: t,
        stack: ac(t)
      }, sp.set(e, t), t);
    }
    return {
      value: e,
      source: t,
      stack: ac(t)
    };
  }
  var wn = [], Nn = 0, qr = null, zi = 0, la = [], na = 0, al = null, va = 1, xa = "";
  function Ba(e, t) {
    wn[Nn++] = zi, wn[Nn++] = qr, qr = e, zi = t;
  }
  function up(e, t, a) {
    la[na++] = va, la[na++] = xa, la[na++] = al, al = e;
    var l = va;
    e = xa;
    var n = 32 - Lt(l) - 1;
    l &= ~(1 << n), a += 1;
    var r = 32 - Lt(t) + n;
    if (30 < r) {
      var p = n - n % 5;
      r = (l & (1 << p) - 1).toString(32), l >>= p, n -= p, va = 1 << 32 - Lt(t) + n | a << n | l, xa = r + e;
    } else
      va = 1 << r | a << n | l, xa = e;
  }
  function kr(e) {
    e.return !== null && (Ba(e, 1), up(e, 1, 0));
  }
  function Ns(e) {
    for (; e === qr; )
      qr = wn[--Nn], wn[Nn] = null, zi = wn[--Nn], wn[Nn] = null;
    for (; e === al; )
      al = la[--na], la[na] = null, xa = la[--na], la[na] = null, va = la[--na], la[na] = null;
  }
  function op(e, t) {
    la[na++] = va, la[na++] = xa, la[na++] = al, va = t.id, xa = t.overflow, al = e;
  }
  var pt = null, Je = null, Se = !1, ll = null, ia = !1, Ts = Error(u(519));
  function nl(e) {
    var t = Error(
      u(
        418,
        1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML",
        ""
      )
    );
    throw Si(aa(t, e)), Ts;
  }
  function cp(e) {
    var t = e.stateNode, a = e.type, l = e.memoizedProps;
    switch (t[gt] = e, t[Dt] = l, a) {
      case "dialog":
        Te("cancel", t), Te("close", t);
        break;
      case "iframe":
      case "object":
      case "embed":
        Te("load", t);
        break;
      case "video":
      case "audio":
        for (a = 0; a < Zi.length; a++)
          Te(Zi[a], t);
        break;
      case "source":
        Te("error", t);
        break;
      case "img":
      case "image":
      case "link":
        Te("error", t), Te("load", t);
        break;
      case "details":
        Te("toggle", t);
        break;
      case "input":
        Te("invalid", t), Sc(
          t,
          l.value,
          l.defaultValue,
          l.checked,
          l.defaultChecked,
          l.type,
          l.name,
          !0
        );
        break;
      case "select":
        Te("invalid", t);
        break;
      case "textarea":
        Te("invalid", t), Nc(t, l.value, l.defaultValue, l.children);
    }
    a = l.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || t.textContent === "" + a || l.suppressHydrationWarning === !0 || qm(t.textContent, a) ? (l.popover != null && (Te("beforetoggle", t), Te("toggle", t)), l.onScroll != null && Te("scroll", t), l.onScrollEnd != null && Te("scrollend", t), l.onClick != null && (t.onclick = ba), t = !0) : t = !1, t || nl(e, !0);
  }
  function Rr(e) {
    for (pt = e.return; pt; )
      switch (pt.tag) {
        case 5:
        case 31:
        case 13:
          ia = !1;
          return;
        case 27:
        case 3:
          ia = !0;
          return;
        default:
          pt = pt.return;
      }
  }
  function Tn(e) {
    if (e !== pt) return !1;
    if (!Se) return Rr(e), Se = !0, !1;
    var t = e.tag, a;
    if ((a = t !== 3 && t !== 27) && ((a = t === 5) && (a = e.type, a = !(a !== "form" && a !== "button") || ao(e.type, e.memoizedProps)), a = !a), a && Je && nl(e), Rr(e), t === 13) {
      if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(u(317));
      Je = _m(e);
    } else if (t === 31) {
      if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(u(317));
      Je = _m(e);
    } else
      t === 27 ? (t = Je, yl(e.type) ? (e = po, po = null, Je = e) : Je = t) : Je = pt ? da(e.stateNode.nextSibling) : null;
    return !0;
  }
  function Yl() {
    Je = pt = null, Se = !1;
  }
  function Es() {
    var e = ll;
    return e !== null && (Ut === null ? Ut = e : Ut.push.apply(
      Ut,
      e
    ), ll = null), e;
  }
  function Si(e) {
    ll === null ? ll = [e] : ll.push(e);
  }
  var Cs = Nt(null), Ql = null, Ya = null;
  function il(e, t, a) {
    Ye(Cs, t._currentValue), t._currentValue = a;
  }
  function Qa(e) {
    e._currentValue = Cs.current, $e(Cs);
  }
  function Ur(e, t, a) {
    for (; e !== null; ) {
      var l = e.alternate;
      if ((e.childLanes & t) !== t ? (e.childLanes |= t, l !== null && (l.childLanes |= t)) : l !== null && (l.childLanes & t) !== t && (l.childLanes |= t), e === a) break;
      e = e.return;
    }
  }
  function As(e, t, a, l) {
    var n = e.child;
    for (n !== null && (n.return = e); n !== null; ) {
      var r = n.dependencies;
      if (r !== null) {
        var p = n.child;
        r = r.firstContext;
        e: for (; r !== null; ) {
          var g = r;
          r = n;
          for (var S = 0; S < t.length; S++)
            if (g.context === t[S]) {
              r.lanes |= a, g = r.alternate, g !== null && (g.lanes |= a), Ur(
                r.return,
                a,
                e
              ), l || (p = null);
              break e;
            }
          r = g.next;
        }
      } else if (n.tag === 18) {
        if (p = n.return, p === null) throw Error(u(341));
        p.lanes |= a, r = p.alternate, r !== null && (r.lanes |= a), Ur(p, a, e), p = null;
      } else
        n.tag === 13 && n.memoizedState !== null && n.memoizedState.dehydrated === null ? (n.lanes |= a, p = n.alternate, p !== null && (p.lanes |= a), Ur(
          n.return,
          a,
          e
        ), p = n.child, p = p !== null ? p.sibling : null) : p = n.child;
      if (p !== null) p.return = n;
      else
        for (p = n; p !== null; ) {
          if (p === e) {
            p = null;
            break;
          }
          if (n = p.sibling, n !== null) {
            n.return = p.return, p = n;
            break;
          }
          p = p.return;
        }
      n = p;
    }
  }
  function Xl(e, t, a, l) {
    e = null;
    for (var n = t, r = !1; n !== null; ) {
      if (!r) {
        if ((n.flags & 524288) !== 0) r = !0;
        else if ((n.flags & 262144) !== 0) break;
      }
      if (n.tag === 10) {
        var p = n.alternate;
        if (p === null) throw Error(u(387));
        if (p = p.memoizedProps, p !== null) {
          var g = n.type;
          Zt(n.pendingProps.value, p.value) || (e !== null ? e.push(g) : e = [g]);
        }
      } else if (n === Ol.current) {
        if (p = n.alternate, p === null) throw Error(u(387));
        p.memoizedState.memoizedState !== n.memoizedState.memoizedState && (e !== null ? e.push(Pn) : e = [Pn]);
      }
      n = n.return;
    }
    return e !== null && As(
      t,
      e,
      a,
      l
    ), t.flags |= 262144, e !== null;
  }
  function Hr(e) {
    for (e = e.firstContext; e !== null; ) {
      if (!Zt(
        e.context._currentValue,
        e.memoizedValue
      ))
        return !0;
      e = e.next;
    }
    return !1;
  }
  function Vl(e) {
    Ql = e, Ya = null, e = e.dependencies, e !== null && (e.firstContext = null);
  }
  function bt(e) {
    return pp(Ql, e);
  }
  function Br(e, t) {
    return Ql === null && Vl(e), pp(e, t);
  }
  function pp(e, t) {
    var a = t._currentValue;
    if (t = { context: t, memoizedValue: a, next: null }, Ya === null) {
      if (e === null) throw Error(u(308));
      Ya = t, e.dependencies = { lanes: 0, firstContext: t }, e.flags |= 524288;
    } else Ya = Ya.next = t;
    return a;
  }
  var mv = typeof AbortController < "u" ? AbortController : function() {
    var e = [], t = this.signal = {
      aborted: !1,
      addEventListener: function(a, l) {
        e.push(l);
      }
    };
    this.abort = function() {
      t.aborted = !0, e.forEach(function(a) {
        return a();
      });
    };
  }, hv = d.unstable_scheduleCallback, gv = d.unstable_NormalPriority, rt = {
    $$typeof: Ee,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function Ms() {
    return {
      controller: new mv(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function wi(e) {
    e.refCount--, e.refCount === 0 && hv(gv, function() {
      e.controller.abort();
    });
  }
  function fp(e, t) {
    if ((e.pendingLanes & 4194048) !== 0) {
      var a = e.transitionTypes;
      for (a === null && (a = e.transitionTypes = []), e = 0; e < t.length; e++) {
        var l = t[e];
        a.indexOf(l) === -1 && a.push(l);
      }
    }
  }
  var Ni = null;
  function bv(e) {
    var t = e.transitionTypes;
    return e.transitionTypes = null, t;
  }
  var Ti = null, Os = 0, Ll = 0, En = null;
  function vv(e, t) {
    if (Ti === null) {
      var a = Ti = [];
      Os = 0, Ll = Ju(), En = {
        status: "pending",
        value: void 0,
        then: function(l) {
          a.push(l);
        }
      };
    }
    return Os++, t.then(mp, mp), t;
  }
  function mp() {
    if (--Os === 0 && (Ni = null, Ti !== null)) {
      En !== null && (En.status = "fulfilled");
      var e = Ti;
      Ti = null, Ll = 0, En = null;
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
  }
  function xv(e, t) {
    var a = [], l = {
      status: "pending",
      value: null,
      reason: null,
      then: function(n) {
        a.push(n);
      }
    };
    return e.then(
      function() {
        l.status = "fulfilled", l.value = t;
        for (var n = 0; n < a.length; n++) (0, a[n])(t);
      },
      function(n) {
        for (l.status = "rejected", l.reason = n, n = 0; n < a.length; n++)
          (0, a[n])(void 0);
      }
    ), l;
  }
  var hp = le.S;
  le.S = function(e, t) {
    if (sm = Xt(), typeof t == "object" && t !== null && typeof t.then == "function" && vv(e, t), Ni !== null)
      for (var a = Zn; a !== null; )
        fp(a, Ni), a = a.next;
    if (a = e.types, a !== null) {
      for (var l = Zn; l !== null; )
        fp(l, a), l = l.next;
      if (Ll !== 0) {
        l = Ni, l === null && (l = Ni = []);
        for (var n = 0; n < a.length; n++) {
          var r = a[n];
          l.indexOf(r) === -1 && l.push(r);
        }
      }
    }
    hp !== null && hp(e, t);
  };
  var Gl = Nt(null);
  function Ds() {
    var e = Gl.current;
    return e !== null ? e : Ze.pooledCache;
  }
  function Yr(e, t) {
    t === null ? Ye(Gl, Gl.current) : Ye(Gl, t.pool);
  }
  function gp() {
    var e = Ds();
    return e === null ? null : { parent: rt._currentValue, pool: e };
  }
  var Cn = Error(u(460)), qs = Error(u(474)), Qr = Error(u(542)), Xr = { then: function() {
  } };
  function bp(e) {
    return e = e.status, e === "fulfilled" || e === "rejected";
  }
  function vp(e, t, a) {
    switch (a = e[a], a === void 0 ? e.push(t) : a !== t && (t.then(ba, ba), t = a), t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw e = t.reason, yp(e), e === void 0 && !("reason" in t) ? Error(u(600)) : e;
      default:
        if (typeof t.status == "string") t.then(ba, ba);
        else {
          if (e = Ze, e !== null && 100 < e.shellSuspendCounter)
            throw Error(u(482));
          e = t, e.status = "pending", e.then(
            function(l) {
              if (t.status === "pending") {
                var n = t;
                n.status = "fulfilled", n.value = l;
              }
            },
            function(l) {
              if (t.status === "pending") {
                var n = t;
                n.status = "rejected", n.reason = l;
              }
            }
          );
        }
        switch (t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw e = t.reason, yp(e), e;
        }
        throw Kl = t, Cn;
    }
  }
  function Zl(e) {
    try {
      var t = e._init;
      return t(e._payload);
    } catch (a) {
      throw a !== null && typeof a == "object" && typeof a.then == "function" ? (Kl = a, Cn) : a;
    }
  }
  var Kl = null;
  function xp() {
    if (Kl === null) throw Error(u(459));
    var e = Kl;
    return Kl = null, e;
  }
  function yp(e) {
    if (e === Cn || e === Qr)
      throw Error(u(483));
  }
  var An = null, Ei = 0;
  function Vr(e) {
    var t = Ei;
    return Ei += 1, An === null && (An = []), vp(An, e, t);
  }
  function rl(e, t) {
    t = t.props.ref, e.ref = t !== void 0 ? t : null;
  }
  function Lr(e, t) {
    throw t.$$typeof === X ? Error(u(525)) : (e = Object.prototype.toString.call(t), Error(
      u(
        31,
        e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e
      )
    ));
  }
  function jp(e) {
    function t(A, T) {
      if (e) {
        var D = A.deletions;
        D === null ? (A.deletions = [T], A.flags |= 16) : D.push(T);
      }
    }
    function a(A, T) {
      if (!e) return null;
      for (; T !== null; )
        t(A, T), T = T.sibling;
      return null;
    }
    function l(A) {
      for (var T = /* @__PURE__ */ new Map(); A !== null; )
        A.key === null ? T.set(A.index, A) : T.set(A.key, A), A = A.sibling;
      return T;
    }
    function n(A, T) {
      return A = Ha(A, T), A.index = 0, A.sibling = null, A;
    }
    function r(A, T, D) {
      return A.index = D, e ? (D = A.alternate, D !== null ? (D = D.index, D < T ? (A.flags |= 2, T) : D) : (A.flags |= 134217730, T)) : (A.flags |= 1048576, T);
    }
    function p(A) {
      return e && A.alternate === null && (A.flags |= 134217730), A;
    }
    function g(A, T, D, B) {
      return T === null || T.tag !== 6 ? (T = Ss(D, A.mode, B), T.return = A, T) : (T = n(T, D), T.return = A, T);
    }
    function S(A, T, D, B) {
      var ee = D.type;
      return ee === $ ? (A = k(
        A,
        T,
        D.props.children,
        B,
        D.key
      ), rl(A, D), A) : T !== null && (T.elementType === ee || typeof ee == "object" && ee !== null && ee.$$typeof === he && Zl(ee) === T.type) ? (T = n(T, D.props), rl(T, D), T.return = A, T) : (T = Dr(
        D.type,
        D.key,
        D.props,
        null,
        A.mode,
        B
      ), rl(T, D), T.return = A, T);
    }
    function M(A, T, D, B) {
      return T === null || T.tag !== 4 || T.stateNode.containerInfo !== D.containerInfo || T.stateNode.implementation !== D.implementation ? (T = ws(D, A.mode, B), T.return = A, T) : (T = n(T, D.children || []), T.return = A, T);
    }
    function k(A, T, D, B, ee) {
      return T === null || T.tag !== 7 ? (T = Bl(
        D,
        A.mode,
        B,
        ee
      ), T.return = A, T) : (T = n(T, D), T.return = A, T);
    }
    function Y(A, T, D) {
      if (typeof T == "string" && T !== "" || typeof T == "number" || typeof T == "bigint")
        return T = Ss(
          "" + T,
          A.mode,
          D
        ), T.return = A, T;
      if (typeof T == "object" && T !== null) {
        switch (T.$$typeof) {
          case me:
            return D = Dr(
              T.type,
              T.key,
              T.props,
              null,
              A.mode,
              D
            ), rl(D, T), D.return = A, D;
          case pe:
            return T = ws(
              T,
              A.mode,
              D
            ), T.return = A, T;
          case he:
            return T = Zl(T), Y(A, T, D);
        }
        if (ze(T) || ae(T))
          return T = Bl(
            T,
            A.mode,
            D,
            null
          ), T.return = A, T;
        if (typeof T.then == "function")
          return Y(A, Vr(T), D);
        if (T.$$typeof === Ee)
          return Y(
            A,
            Br(A, T),
            D
          );
        Lr(A, T);
      }
      return null;
    }
    function C(A, T, D, B) {
      var ee = T !== null ? T.key : null;
      if (typeof D == "string" && D !== "" || typeof D == "number" || typeof D == "bigint")
        return ee !== null ? null : g(A, T, "" + D, B);
      if (typeof D == "object" && D !== null) {
        switch (D.$$typeof) {
          case me:
            return D.key === ee ? S(A, T, D, B) : null;
          case pe:
            return D.key === ee ? M(A, T, D, B) : null;
          case he:
            return D = Zl(D), C(A, T, D, B);
        }
        if (ze(D) || ae(D))
          return ee !== null ? null : k(A, T, D, B, null);
        if (typeof D.then == "function")
          return C(
            A,
            T,
            Vr(D),
            B
          );
        if (D.$$typeof === Ee)
          return C(
            A,
            T,
            Br(A, D),
            B
          );
        Lr(A, D);
      }
      return null;
    }
    function q(A, T, D, B, ee) {
      if (typeof B == "string" && B !== "" || typeof B == "number" || typeof B == "bigint")
        return A = A.get(D) || null, g(T, A, "" + B, ee);
      if (typeof B == "object" && B !== null) {
        switch (B.$$typeof) {
          case me:
            return A = A.get(
              B.key === null ? D : B.key
            ) || null, S(T, A, B, ee);
          case pe:
            return A = A.get(
              B.key === null ? D : B.key
            ) || null, M(T, A, B, ee);
          case he:
            return B = Zl(B), q(
              A,
              T,
              D,
              B,
              ee
            );
        }
        if (ze(B) || ae(B))
          return A = A.get(D) || null, k(T, A, B, ee, null);
        if (typeof B.then == "function")
          return q(
            A,
            T,
            D,
            Vr(B),
            ee
          );
        if (B.$$typeof === Ee)
          return q(
            A,
            T,
            D,
            Br(T, B),
            ee
          );
        Lr(T, B);
      }
      return null;
    }
    function F(A, T, D, B) {
      for (var ee = null, Oe = null, de = T, fe = T = 0, ut = null; de !== null && fe < D.length; fe++) {
        de.index > fe ? (ut = de, de = null) : ut = de.sibling;
        var Re = C(
          A,
          de,
          D[fe],
          B
        );
        if (Re === null) {
          de === null && (de = ut);
          break;
        }
        e && de && Re.alternate === null && t(A, de), T = r(Re, T, fe), Oe === null ? ee = Re : Oe.sibling = Re, Oe = Re, de = ut;
      }
      if (fe === D.length)
        return a(A, de), Se && Ba(A, fe), ee;
      if (de === null) {
        for (; fe < D.length; fe++)
          de = Y(A, D[fe], B), de !== null && (T = r(
            de,
            T,
            fe
          ), Oe === null ? ee = de : Oe.sibling = de, Oe = de);
        return Se && Ba(A, fe), ee;
      }
      for (de = l(de); fe < D.length; fe++)
        ut = q(
          de,
          A,
          fe,
          D[fe],
          B
        ), ut !== null && (e && (Re = ut.alternate, Re !== null && de.delete(Re.key === null ? fe : Re.key)), T = r(
          ut,
          T,
          fe
        ), Oe === null ? ee = ut : Oe.sibling = ut, Oe = ut);
      return e && de.forEach(function(Nl) {
        return t(A, Nl);
      }), Se && Ba(A, fe), ee;
    }
    function ne(A, T, D, B) {
      if (D == null) throw Error(u(151));
      for (var ee = null, Oe = null, de = T, fe = T = 0, ut = null, Re = D.next(); de !== null && !Re.done; fe++, Re = D.next()) {
        de.index > fe ? (ut = de, de = null) : ut = de.sibling;
        var Nl = C(A, de, Re.value, B);
        if (Nl === null) {
          de === null && (de = ut);
          break;
        }
        e && de && Nl.alternate === null && t(A, de), T = r(Nl, T, fe), Oe === null ? ee = Nl : Oe.sibling = Nl, Oe = Nl, de = ut;
      }
      if (Re.done)
        return a(A, de), Se && Ba(A, fe), ee;
      if (de === null) {
        for (; !Re.done; fe++, Re = D.next())
          Re = Y(A, Re.value, B), Re !== null && (T = r(Re, T, fe), Oe === null ? ee = Re : Oe.sibling = Re, Oe = Re);
        return Se && Ba(A, fe), ee;
      }
      for (de = l(de); !Re.done; fe++, Re = D.next())
        Re = q(de, A, fe, Re.value, B), Re !== null && (e && (ut = Re.alternate, ut !== null && de.delete(
          ut.key === null ? fe : ut.key
        )), T = r(Re, T, fe), Oe === null ? ee = Re : Oe.sibling = Re, Oe = Re);
      return e && de.forEach(function($x) {
        return t(A, $x);
      }), Se && Ba(A, fe), ee;
    }
    function je(A, T, D, B) {
      if (typeof D == "object" && D !== null && D.type === $ && D.key === null && D.props.ref === void 0 && (D = D.props.children), typeof D == "object" && D !== null) {
        switch (D.$$typeof) {
          case me:
            e: {
              for (var ee = D.key; T !== null; ) {
                if (T.key === ee) {
                  if (ee = D.type, ee === $) {
                    if (T.tag === 7) {
                      a(
                        A,
                        T.sibling
                      ), B = n(
                        T,
                        D.props.children
                      ), rl(B, D), B.return = A, A = B;
                      break e;
                    }
                  } else if (T.elementType === ee || typeof ee == "object" && ee !== null && ee.$$typeof === he && Zl(ee) === T.type) {
                    a(
                      A,
                      T.sibling
                    ), B = n(T, D.props), rl(B, D), B.return = A, A = B;
                    break e;
                  }
                  a(A, T);
                  break;
                } else t(A, T);
                T = T.sibling;
              }
              D.type === $ ? (B = Bl(
                D.props.children,
                A.mode,
                B,
                D.key
              ), rl(B, D), B.return = A, A = B) : (B = Dr(
                D.type,
                D.key,
                D.props,
                null,
                A.mode,
                B
              ), rl(B, D), B.return = A, A = B);
            }
            return p(A);
          case pe:
            e: {
              for (ee = D.key; T !== null; ) {
                if (T.key === ee)
                  if (T.tag === 4 && T.stateNode.containerInfo === D.containerInfo && T.stateNode.implementation === D.implementation) {
                    a(
                      A,
                      T.sibling
                    ), B = n(T, D.children || []), B.return = A, A = B;
                    break e;
                  } else {
                    a(A, T);
                    break;
                  }
                else t(A, T);
                T = T.sibling;
              }
              B = ws(D, A.mode, B), B.return = A, A = B;
            }
            return p(A);
          case he:
            return D = Zl(D), je(
              A,
              T,
              D,
              B
            );
        }
        if (ze(D))
          return F(
            A,
            T,
            D,
            B
          );
        if (ae(D)) {
          if (ee = ae(D), typeof ee != "function") throw Error(u(150));
          return D = ee.call(D), ne(
            A,
            T,
            D,
            B
          );
        }
        if (typeof D.then == "function")
          return je(
            A,
            T,
            Vr(D),
            B
          );
        if (D.$$typeof === Ee)
          return je(
            A,
            T,
            Br(A, D),
            B
          );
        Lr(A, D);
      }
      return typeof D == "string" && D !== "" || typeof D == "number" || typeof D == "bigint" ? (D = "" + D, T !== null && T.tag === 6 ? (a(A, T.sibling), B = n(T, D), B.return = A, A = B) : (a(A, T), B = Ss(D, A.mode, B), B.return = A, A = B), p(A)) : a(A, T);
    }
    return function(A, T, D, B) {
      try {
        Ei = 0;
        var ee = je(
          A,
          T,
          D,
          B
        );
        return An = null, ee;
      } catch (de) {
        if (de === Cn || de === Qr) throw de;
        var Oe = qt(29, de, null, A.mode);
        return Oe.lanes = B, Oe.return = A, Oe;
      } finally {
      }
    };
  }
  var Jl = jp(!0), zp = jp(!1), dl = !1;
  function ks(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null
    };
  }
  function Rs(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
      baseState: e.baseState,
      firstBaseUpdate: e.firstBaseUpdate,
      lastBaseUpdate: e.lastBaseUpdate,
      shared: e.shared,
      callbacks: null
    });
  }
  function sl(e) {
    return { lane: e, tag: 0, payload: null, callback: null, next: null };
  }
  function ul(e, t, a) {
    var l = e.updateQueue;
    if (l === null) return null;
    if (l = l.shared, (Be & 2) !== 0) {
      var n = l.pending;
      return n === null ? t.next = t : (t.next = n.next, n.next = t), l.pending = t, t = Or(e), ip(e, null, a), t;
    }
    return Mr(e, l, t, a), Or(e);
  }
  function Ci(e, t, a) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (a & 4194048) !== 0)) {
      var l = t.lanes;
      l &= e.pendingLanes, a |= l, t.lanes = a, uc(e, a);
    }
  }
  function Us(e, t) {
    var a = e.updateQueue, l = e.alternate;
    if (l !== null && (l = l.updateQueue, a === l)) {
      var n = null, r = null;
      if (a = a.firstBaseUpdate, a !== null) {
        do {
          var p = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null
          };
          r === null ? n = r = p : r = r.next = p, a = a.next;
        } while (a !== null);
        r === null ? n = r = t : r = r.next = t;
      } else n = r = t;
      a = {
        baseState: l.baseState,
        firstBaseUpdate: n,
        lastBaseUpdate: r,
        shared: l.shared,
        callbacks: l.callbacks
      }, e.updateQueue = a;
      return;
    }
    e = a.lastBaseUpdate, e === null ? a.firstBaseUpdate = t : e.next = t, a.lastBaseUpdate = t;
  }
  var Hs = !1;
  function Ai() {
    if (Hs) {
      var e = En;
      if (e !== null) throw e;
    }
  }
  function Mi(e, t, a, l) {
    Hs = !1;
    var n = e.updateQueue;
    dl = !1;
    var r = n.firstBaseUpdate, p = n.lastBaseUpdate, g = n.shared.pending;
    if (g !== null) {
      n.shared.pending = null;
      var S = g, M = S.next;
      S.next = null, p === null ? r = M : p.next = M, p = S;
      var k = e.alternate;
      k !== null && (k = k.updateQueue, g = k.lastBaseUpdate, g !== p && (g === null ? k.firstBaseUpdate = M : g.next = M, k.lastBaseUpdate = S));
    }
    if (r !== null) {
      var Y = n.baseState;
      p = 0, k = M = S = null, g = r;
      do {
        var C = g.lane & -536870913, q = C !== g.lane;
        if (q ? (Me & C) === C : (l & C) === C) {
          C !== 0 && C === Ll && (Hs = !0), k !== null && (k = k.next = {
            lane: 0,
            tag: g.tag,
            payload: g.payload,
            callback: null,
            next: null
          });
          e: {
            var F = e, ne = g;
            C = t;
            var je = a;
            switch (ne.tag) {
              case 1:
                if (F = ne.payload, typeof F == "function") {
                  Y = F.call(je, Y, C);
                  break e;
                }
                Y = F;
                break e;
              case 3:
                F.flags = F.flags & -65537 | 128;
              case 0:
                if (F = ne.payload, C = typeof F == "function" ? F.call(je, Y, C) : F, C == null) break e;
                Y = G({}, Y, C);
                break e;
              case 2:
                dl = !0;
            }
          }
          C = g.callback, C !== null && (e.flags |= 64, q && (e.flags |= 8192), q = n.callbacks, q === null ? n.callbacks = [C] : q.push(C));
        } else
          q = {
            lane: C,
            tag: g.tag,
            payload: g.payload,
            callback: g.callback,
            next: null
          }, k === null ? (M = k = q, S = Y) : k = k.next = q, p |= C;
        if (g = g.next, g === null) {
          if (g = n.shared.pending, g === null)
            break;
          q = g, g = q.next, q.next = null, n.lastBaseUpdate = q, n.shared.pending = null;
        }
      } while (!0);
      k === null && (S = Y), n.baseState = S, n.firstBaseUpdate = M, n.lastBaseUpdate = k, r === null && (n.shared.lanes = 0), gl |= p, e.lanes = p, e.memoizedState = Y;
    }
  }
  function Sp(e, t) {
    if (typeof e != "function")
      throw Error(u(191, e));
    e.call(t);
  }
  function wp(e, t) {
    var a = e.callbacks;
    if (a !== null)
      for (e.callbacks = null, e = 0; e < a.length; e++)
        Sp(a[e], t);
  }
  var ol = Nt(null), Gr = Nt(0);
  function Np(e, t) {
    e = Za, Ye(Gr, e), Ye(ol, t), Za = e | t.baseLanes;
  }
  function Bs() {
    Ye(Gr, Za), Ye(ol, ol.current);
  }
  function Ys() {
    Za = Gr.current, $e(ol), $e(Gr);
  }
  var vt = Nt(null), Tt = null;
  function cl(e) {
    var t = e.alternate;
    Ye(xt, xt.current & 1), Ye(vt, e), Tt === null && (t === null || ol.current !== null || t.memoizedState !== null) && (Tt = e);
  }
  function Qs(e) {
    Ye(xt, xt.current), Ye(vt, e), Tt === null && (Tt = e);
  }
  function Tp(e) {
    e.tag === 22 ? (Ye(xt, xt.current), Ye(vt, e), Tt === null && (Tt = e)) : pl();
  }
  function pl() {
    Ye(xt, xt.current), Ye(vt, vt.current);
  }
  function Kt(e) {
    $e(vt), Tt === e && (Tt = null), $e(xt);
  }
  var xt = Nt(0);
  function Oi(e, t) {
    Ye(vt, vt.current), Ye(xt, t);
  }
  function Xs(e) {
    $e(xt), $e(vt), Tt === e && (Tt = null);
  }
  function Zr(e) {
    for (var t = e; t !== null; ) {
      if (t.tag === 13) {
        var a = t.memoizedState;
        if (a !== null && (a = a.dehydrated, a === null || oo(a) || co(a)))
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== "independent") {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var Xa = 0, ye = null, Ge = null, dt = null, Kr = !1, Mn = !1, Fl = !1, Jr = 0, Di = 0, On = null, yv = 0;
  function tt() {
    throw Error(u(321));
  }
  function Vs(e, t) {
    if (t === null) return !1;
    for (var a = 0; a < t.length && a < e.length; a++)
      if (!Zt(e[a], t[a])) return !1;
    return !0;
  }
  function Ls(e, t, a, l, n, r) {
    return Xa = r, ye = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, le.H = e === null || e.memoizedState === null ? of : cf, Fl = !1, r = a(l, n), Fl = !1, Mn && (r = Cp(
      t,
      a,
      l,
      n
    )), Ep(e), r;
  }
  function Ep(e) {
    le.H = ed;
    var t = Ge !== null && Ge.next !== null;
    if (Xa = 0, dt = Ge = ye = null, Kr = !1, Di = 0, On = null, t) throw Error(u(300));
    e === null || st || (e = e.dependencies, e !== null && Hr(e) && (st = !0));
  }
  function Cp(e, t, a, l) {
    ye = e;
    var n = 0;
    do {
      if (Mn && (On = null), Di = 0, Mn = !1, 25 <= n) throw Error(u(301));
      if (n += 1, dt = Ge = null, e.updateQueue != null) {
        var r = e.updateQueue;
        r.lastEffect = null, r.events = null, r.stores = null, r.memoCache != null && (r.memoCache.index = 0);
      }
      le.H = Cv, r = t(a, l);
    } while (Mn);
    return r;
  }
  function jv() {
    var e = le.H, t = e.useState()[0];
    return t = typeof t.then == "function" ? qi(t) : t, e = e.useState()[0], (Ge !== null ? Ge.memoizedState : null) !== e && (ye.flags |= 1024), t;
  }
  function Gs() {
    var e = Jr !== 0;
    return Jr = 0, e;
  }
  function Zs(e, t, a) {
    t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a;
  }
  function Ks(e) {
    if (Kr) {
      for (e = e.memoizedState; e !== null; ) {
        var t = e.queue;
        t !== null && (t.pending = null), e = e.next;
      }
      Kr = !1;
    }
    Xa = 0, dt = Ge = ye = null, Mn = !1, Di = Jr = 0, On = null;
  }
  function Ct() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return dt === null ? ye.memoizedState = dt = e : dt = dt.next = e, dt;
  }
  function lt() {
    if (Ge === null) {
      var e = ye.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Ge.next;
    var t = dt === null ? ye.memoizedState : dt.next;
    if (t !== null)
      dt = t, Ge = e;
    else {
      if (e === null)
        throw ye.alternate === null ? Error(u(467)) : Error(u(310));
      Ge = e, e = {
        memoizedState: Ge.memoizedState,
        baseState: Ge.baseState,
        baseQueue: Ge.baseQueue,
        queue: Ge.queue,
        next: null
      }, dt === null ? ye.memoizedState = dt = e : dt = dt.next = e;
    }
    return dt;
  }
  function Fr() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function qi(e) {
    var t = Di;
    return Di += 1, On === null && (On = []), e = vp(On, e, t), t = ye, (dt === null ? t.memoizedState : dt.next) === null && (t = t.alternate, le.H = t === null || t.memoizedState === null ? of : cf), e;
  }
  function Wr(e) {
    if (e !== null && typeof e == "object") {
      if (typeof e.then == "function") return qi(e);
      if (e.$$typeof === Q) return;
      if (e.$$typeof === Ee) return bt(e);
    }
    throw Error(u(438, String(e)));
  }
  function Js(e) {
    var t = null, a = ye.updateQueue;
    if (a !== null && (t = a.memoCache), t == null) {
      var l = ye.alternate;
      l !== null && (l = l.updateQueue, l !== null && (l = l.memoCache, l != null && (t = {
        data: l.data.map(function(n) {
          return n.slice();
        }),
        index: 0
      })));
    }
    if (t == null && (t = { data: [], index: 0 }), a === null && (a = Fr(), ye.updateQueue = a), a.memoCache = t, a = t.data[t.index], a === void 0)
      for (a = t.data[t.index] = Array(e), l = 0; l < e; l++)
        a[l] = St;
    return t.index++, a;
  }
  function Va(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Ir(e) {
    var t = lt();
    return Fs(t, Ge, e);
  }
  function Fs(e, t, a) {
    var l = e.queue;
    if (l === null) throw Error(u(311));
    l.lastRenderedReducer = a;
    var n = e.baseQueue, r = l.pending;
    if (r !== null) {
      if (n !== null) {
        var p = n.next;
        n.next = r.next, r.next = p;
      }
      t.baseQueue = n = r, l.pending = null;
    }
    if (r = e.baseState, n === null) e.memoizedState = r;
    else {
      t = n.next;
      var g = p = null, S = null, M = t, k = !1;
      do {
        var Y = M.lane & -536870913;
        if (Y !== M.lane ? (Me & Y) === Y : (Xa & Y) === Y) {
          var C = M.revertLane;
          if (C === 0)
            S !== null && (S = S.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: M.action,
              hasEagerState: M.hasEagerState,
              eagerState: M.eagerState,
              next: null
            }), Y === Ll && (k = !0);
          else if ((Xa & C) === C) {
            M = M.next, C === Ll && (k = !0);
            continue;
          } else
            Y = {
              lane: 0,
              revertLane: M.revertLane,
              gesture: null,
              action: M.action,
              hasEagerState: M.hasEagerState,
              eagerState: M.eagerState,
              next: null
            }, S === null ? (g = S = Y, p = r) : S = S.next = Y, ye.lanes |= C, gl |= C;
          Y = M.action, Fl && a(r, Y), r = M.hasEagerState ? M.eagerState : a(r, Y);
        } else
          C = {
            lane: Y,
            revertLane: M.revertLane,
            gesture: M.gesture,
            action: M.action,
            hasEagerState: M.hasEagerState,
            eagerState: M.eagerState,
            next: null
          }, S === null ? (g = S = C, p = r) : S = S.next = C, ye.lanes |= Y, gl |= Y;
        M = M.next;
      } while (M !== null && M !== t);
      if (S === null ? p = r : S.next = g, !Zt(r, e.memoizedState) && (st = !0, k && (a = En, a !== null)))
        throw a;
      e.memoizedState = r, e.baseState = p, e.baseQueue = S, l.lastRenderedState = r;
    }
    return n === null && (l.lanes = 0), [e.memoizedState, l.dispatch];
  }
  function Ws(e) {
    var t = lt(), a = t.queue;
    if (a === null) throw Error(u(311));
    a.lastRenderedReducer = e;
    var l = a.dispatch, n = a.pending, r = t.memoizedState;
    if (n !== null) {
      a.pending = null;
      var p = n = n.next;
      do
        r = e(r, p.action), p = p.next;
      while (p !== n);
      Zt(r, t.memoizedState) || (st = !0), t.memoizedState = r, t.baseQueue === null && (t.baseState = r), a.lastRenderedState = r;
    }
    return [r, l];
  }
  function Ap(e, t, a) {
    var l = ye, n = lt(), r = Se;
    if (r) {
      if (a === void 0) throw Error(u(407));
      a = a();
    } else a = t();
    var p = !Zt(
      (Ge || n).memoizedState,
      a
    );
    if (p && (n.memoizedState = a, st = !0), n = n.queue, _s(Dp.bind(null, l, n, e), [
      e
    ]), e = n.getSnapshot !== t || p || dt !== null && (dt.memoizedState.tag & 1) !== 0, Dn(
      e ? 9 : 8,
      { destroy: void 0 },
      Op.bind(null, l, n, a, t),
      null
    ), e) {
      if (l.flags |= 2048, Ze === null) throw Error(u(349));
      r || (Xa & 127) !== 0 || Mp(l, t, a);
    }
    return a;
  }
  function Mp(e, t, a) {
    e.flags |= 16384, e = { getSnapshot: t, value: a }, t = ye.updateQueue, t === null ? (t = Fr(), ye.updateQueue = t, t.stores = [e]) : (a = t.stores, a === null ? t.stores = [e] : a.push(e));
  }
  function Op(e, t, a, l) {
    t.value = a, t.getSnapshot = l, qp(t) && kp(e);
  }
  function Dp(e, t, a) {
    return a(function() {
      qp(t) && kp(e);
    });
  }
  function qp(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var a = t();
      return !Zt(e, a);
    } catch {
      return !0;
    }
  }
  function kp(e) {
    var t = Hl(e, 2);
    t !== null && Ht(t, e, 2);
  }
  function Is(e) {
    var t = Ct();
    if (typeof e == "function") {
      var a = e;
      if (e = a(), Fl) {
        $a(!0);
        try {
          a();
        } finally {
          $a(!1);
        }
      }
    }
    return t.memoizedState = t.baseState = e, t.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Va,
      lastRenderedState: e
    }, t;
  }
  function Rp(e, t, a, l) {
    return e.baseState = a, Fs(
      e,
      Ge,
      typeof l == "function" ? l : Va
    );
  }
  function zv(e, t, a, l, n) {
    if ($r(e)) throw Error(u(485));
    if (e = t.action, e !== null) {
      var r = {
        payload: n,
        action: e,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(p) {
          r.listeners.push(p);
        }
      };
      le.T !== null ? a(!0) : r.isTransition = !1, l(r), a = t.pending, a === null ? (r.next = t.pending = r, Up(t, r)) : (r.next = a.next, t.pending = a.next = r);
    }
  }
  function Up(e, t) {
    var a = t.action, l = t.payload, n = e.state;
    if (t.isTransition) {
      var r = le.T, p = {};
      p.types = r !== null ? r.types : null, le.T = p;
      try {
        var g = a(n, l), S = le.S;
        S !== null && S(p, g), Hp(e, t, g);
      } catch (M) {
        Ps(e, t, M);
      } finally {
        r !== null && p.types !== null && (r.types = p.types), le.T = r;
      }
    } else
      try {
        r = a(n, l), Hp(e, t, r);
      } catch (M) {
        Ps(e, t, M);
      }
  }
  function Hp(e, t, a) {
    a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(
      function(l) {
        Bp(e, t, l);
      },
      function(l) {
        return Ps(e, t, l);
      }
    ) : Bp(e, t, a);
  }
  function Bp(e, t, a) {
    t.status = "fulfilled", t.value = a, Yp(t), e.state = a, t = e.pending, t !== null && (a = t.next, a === t ? e.pending = null : (a = a.next, t.next = a, Up(e, a)));
  }
  function Ps(e, t, a) {
    var l = e.pending;
    if (e.pending = null, l !== null) {
      l = l.next;
      do
        t.status = "rejected", t.reason = a, Yp(t), t = t.next;
      while (t !== l);
    }
    e.action = null;
  }
  function Yp(e) {
    e = e.listeners;
    for (var t = 0; t < e.length; t++) (0, e[t])();
  }
  function Qp(e, t) {
    return t;
  }
  function Xp(e, t) {
    if (Se) {
      var a = Ze.formState;
      if (a !== null) {
        e: {
          var l = ye;
          if (Se) {
            if (Je) {
              t: {
                for (var n = Je, r = ia; n.nodeType !== 8; ) {
                  if (!r) {
                    n = null;
                    break t;
                  }
                  if (n = da(
                    n.nextSibling
                  ), n === null) {
                    n = null;
                    break t;
                  }
                }
                r = n.data, n = r === "F!" || r === "F" ? n : null;
              }
              if (n) {
                Je = da(
                  n.nextSibling
                ), l = n.data === "F!";
                break e;
              }
            }
            nl(l);
          }
          l = !1;
        }
        l && (t = a[0]);
      }
    }
    return a = Ct(), a.memoizedState = a.baseState = t, l = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Qp,
      lastRenderedState: t
    }, a.queue = l, a = df.bind(
      null,
      ye,
      l
    ), l.dispatch = a, l = Is(!1), r = lu.bind(
      null,
      ye,
      !1,
      l.queue
    ), l = Ct(), n = {
      state: t,
      dispatch: null,
      action: e,
      pending: null
    }, l.queue = n, a = zv.bind(
      null,
      ye,
      n,
      r,
      a
    ), n.dispatch = a, l.memoizedState = e, [t, a, !1];
  }
  function Vp(e) {
    var t = lt();
    return Lp(t, Ge, e);
  }
  function Lp(e, t, a) {
    if (t = Fs(
      e,
      t,
      Qp
    )[0], e = Ir(Va)[0], typeof t == "object" && t !== null && typeof t.then == "function")
      try {
        var l = qi(t);
      } catch (p) {
        throw p === Cn ? Qr : p;
      }
    else l = t;
    t = lt();
    var n = t.queue, r = n.dispatch;
    return a !== t.memoizedState && (ye.flags |= 2048, Dn(
      9,
      { destroy: void 0 },
      Sv.bind(null, n, a),
      null
    )), [l, r, e];
  }
  function Sv(e, t) {
    e.action = t;
  }
  function Gp(e) {
    var t = lt(), a = Ge;
    if (a !== null)
      return Lp(t, a, e);
    lt(), t = t.memoizedState, a = lt();
    var l = a.queue.dispatch;
    return a.memoizedState = e, [t, l, !1];
  }
  function Dn(e, t, a, l) {
    return e = { tag: e, create: a, deps: l, inst: t, next: null }, t = ye.updateQueue, t === null && (t = Fr(), ye.updateQueue = t), a = t.lastEffect, a === null ? t.lastEffect = e.next = e : (l = a.next, a.next = e, e.next = l, t.lastEffect = e), e;
  }
  function Zp() {
    return lt().memoizedState;
  }
  function Pr(e, t, a, l) {
    var n = Ct();
    ye.flags |= e, n.memoizedState = Dn(
      1 | t,
      { destroy: void 0 },
      a,
      l === void 0 ? null : l
    );
  }
  function _r(e, t, a, l) {
    var n = lt();
    l = l === void 0 ? null : l;
    var r = n.memoizedState.inst;
    Ge !== null && l !== null && Vs(l, Ge.memoizedState.deps) ? n.memoizedState = Dn(t, r, a, l) : (ye.flags |= e, n.memoizedState = Dn(
      1 | t,
      r,
      a,
      l
    ));
  }
  function Kp(e, t) {
    Pr(8390656, 8, e, t);
  }
  function _s(e, t) {
    _r(2048, 8, e, t);
  }
  function wv(e) {
    ye.flags |= 4;
    var t = ye.updateQueue;
    if (t === null)
      t = Fr(), ye.updateQueue = t, t.events = [e];
    else {
      var a = t.events;
      a === null ? t.events = [e] : a.push(e);
    }
  }
  function Jp(e) {
    var t = lt().memoizedState;
    return wv({ ref: t, nextImpl: e }), function() {
      if ((Be & 2) !== 0) throw Error(u(440));
      return t.impl.apply(void 0, arguments);
    };
  }
  function Fp(e, t) {
    return _r(4, 2, e, t);
  }
  function Wp(e, t) {
    return _r(4, 4, e, t);
  }
  function Ip(e, t) {
    if (typeof t == "function") {
      e = e();
      var a = t(e);
      return function() {
        typeof a == "function" ? a() : t(null);
      };
    }
    if (t != null)
      return e = e(), t.current = e, function() {
        t.current = null;
      };
  }
  function Pp(e, t, a) {
    a = a != null ? a.concat([e]) : null, _r(4, 4, Ip.bind(null, t, e), a);
  }
  function $s() {
  }
  function _p(e, t) {
    var a = lt();
    t = t === void 0 ? null : t;
    var l = a.memoizedState;
    return t !== null && Vs(t, l[1]) ? l[0] : (a.memoizedState = [e, t], e);
  }
  function $p(e, t) {
    var a = lt();
    t = t === void 0 ? null : t;
    var l = a.memoizedState;
    if (t !== null && Vs(t, l[1]))
      return l[0];
    if (l = e(), Fl) {
      $a(!0);
      try {
        e();
      } finally {
        $a(!1);
      }
    }
    return a.memoizedState = [l, t], l;
  }
  function eu(e, t, a) {
    return a === void 0 || (Xa & 1073741824) !== 0 && (Me & 261930) === 0 ? e.memoizedState = t : (e.memoizedState = a, e = om(), ye.lanes |= e, gl |= e, a);
  }
  function ef(e, t, a, l) {
    return Zt(a, t) ? a : ol.current !== null ? (e = eu(e, a, l), Zt(e, t) || (st = !0), e) : (Xa & 106) === 0 || (Xa & 1073741824) !== 0 && (Me & 261930) === 0 ? (st = !0, e.memoizedState = a) : (e = om(), ye.lanes |= e, gl |= e, t);
  }
  function tf(e, t, a, l, n) {
    var r = oe.p;
    oe.p = r !== 0 && 8 > r ? r : 8;
    var p = le.T, g = {};
    g.types = p !== null ? p.types : null, le.T = g, lu(e, !1, t, a);
    try {
      var S = n(), M = le.S;
      if (M !== null && M(g, S), S !== null && typeof S == "object" && typeof S.then == "function") {
        var k = xv(
          S,
          l
        );
        ki(
          e,
          t,
          k,
          It(e)
        );
      } else
        ki(
          e,
          t,
          l,
          It(e)
        );
    } catch (Y) {
      ki(
        e,
        t,
        { then: function() {
        }, status: "rejected", reason: Y },
        It()
      );
    } finally {
      oe.p = r, p !== null && g.types !== null && (p.types = g.types), le.T = p;
    }
  }
  function Nv() {
  }
  function tu(e, t, a, l) {
    if (e.tag !== 5) throw Error(u(476));
    var n = af(e).queue;
    tf(
      e,
      n,
      t,
      wt,
      a === null ? Nv : function() {
        return lf(e), a(l);
      }
    );
  }
  function af(e) {
    var t = e.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: wt,
      baseState: wt,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Va,
        lastRenderedState: wt
      },
      next: null
    };
    var a = {};
    return t.next = {
      memoizedState: a,
      baseState: a,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Va,
        lastRenderedState: a
      },
      next: null
    }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t;
  }
  function lf(e) {
    var t = af(e);
    t.next === null && (t = e.alternate.memoizedState), ki(
      e,
      t.next.queue,
      {},
      It()
    );
  }
  function au() {
    return bt(Pn);
  }
  function nf() {
    return lt().memoizedState;
  }
  function rf() {
    return lt().memoizedState;
  }
  function Tv(e) {
    for (var t = e.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var a = It();
          e = sl(a);
          var l = ul(t, e, a);
          l !== null && (Ht(l, t, a), Ci(l, t, a)), t = { cache: Ms() }, e.payload = t;
          return;
      }
      t = t.return;
    }
  }
  function Ev(e, t, a) {
    var l = It();
    a = {
      lane: l,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, $r(e) ? sf(t, a) : (a = js(e, t, a, l), a !== null && (Ht(a, e, l), uf(a, t, l)));
  }
  function df(e, t, a) {
    var l = It();
    ki(e, t, a, l);
  }
  function ki(e, t, a, l) {
    var n = {
      lane: l,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if ($r(e)) sf(t, n);
    else {
      var r = e.alternate;
      if (e.lanes === 0 && (r === null || r.lanes === 0) && (r = t.lastRenderedReducer, r !== null))
        try {
          var p = t.lastRenderedState, g = r(p, a);
          if (n.hasEagerState = !0, n.eagerState = g, Zt(g, p))
            return Mr(e, t, n, 0), Ze === null && Ar(), !1;
        } catch {
        } finally {
        }
      if (a = js(e, t, n, l), a !== null)
        return Ht(a, e, l), uf(a, t, l), !0;
    }
    return !1;
  }
  function lu(e, t, a, l) {
    if (l = {
      lane: 2,
      revertLane: Ju(),
      gesture: null,
      action: l,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, $r(e)) {
      if (t) throw Error(u(479));
    } else
      t = js(
        e,
        a,
        l,
        2
      ), t !== null && Ht(t, e, 2);
  }
  function $r(e) {
    var t = e.alternate;
    return e === ye || t !== null && t === ye;
  }
  function sf(e, t) {
    Mn = Kr = !0;
    var a = e.pending;
    a === null ? t.next = t : (t.next = a.next, a.next = t), e.pending = t;
  }
  function uf(e, t, a) {
    if ((a & 4194048) !== 0) {
      var l = t.lanes;
      l &= e.pendingLanes, a |= l, t.lanes = a, uc(e, a);
    }
  }
  var ed = {
    readContext: bt,
    use: Wr,
    useCallback: tt,
    useContext: tt,
    useEffect: tt,
    useImperativeHandle: tt,
    useLayoutEffect: tt,
    useInsertionEffect: tt,
    useMemo: tt,
    useReducer: tt,
    useRef: tt,
    useState: tt,
    useDebugValue: tt,
    useDeferredValue: tt,
    useTransition: tt,
    useSyncExternalStore: tt,
    useId: tt,
    useHostTransitionStatus: tt,
    useFormState: tt,
    useActionState: tt,
    useOptimistic: tt,
    useMemoCache: tt,
    useCacheRefresh: tt,
    useEffectEvent: tt
  }, of = {
    readContext: bt,
    use: Wr,
    useCallback: function(e, t) {
      return Ct().memoizedState = [
        e,
        t === void 0 ? null : t
      ], e;
    },
    useContext: bt,
    useEffect: Kp,
    useImperativeHandle: function(e, t, a) {
      a = a != null ? a.concat([e]) : null, Pr(
        4194308,
        4,
        Ip.bind(null, t, e),
        a
      );
    },
    useLayoutEffect: function(e, t) {
      return Pr(4194308, 4, e, t);
    },
    useInsertionEffect: function(e, t) {
      Pr(4, 2, e, t);
    },
    useMemo: function(e, t) {
      var a = Ct();
      t = t === void 0 ? null : t;
      var l = e();
      if (Fl) {
        $a(!0);
        try {
          e();
        } finally {
          $a(!1);
        }
      }
      return a.memoizedState = [l, t], l;
    },
    useReducer: function(e, t, a) {
      var l = Ct();
      if (a !== void 0) {
        var n = a(t);
        if (Fl) {
          $a(!0);
          try {
            a(t);
          } finally {
            $a(!1);
          }
        }
      } else n = t;
      return l.memoizedState = l.baseState = n, e = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: e,
        lastRenderedState: n
      }, l.queue = e, e = e.dispatch = Ev.bind(
        null,
        ye,
        e
      ), [l.memoizedState, e];
    },
    useRef: function(e) {
      var t = Ct();
      return e = { current: e }, t.memoizedState = e;
    },
    useState: function(e) {
      e = Is(e);
      var t = e.queue, a = df.bind(null, ye, t);
      return t.dispatch = a, [e.memoizedState, a];
    },
    useDebugValue: $s,
    useDeferredValue: function(e, t) {
      var a = Ct();
      return eu(a, e, t);
    },
    useTransition: function() {
      var e = Is(!1);
      return e = tf.bind(
        null,
        ye,
        e.queue,
        !0,
        !1
      ), Ct().memoizedState = e, [!1, e];
    },
    useSyncExternalStore: function(e, t, a) {
      var l = ye, n = Ct();
      if (Se) {
        if (a === void 0)
          throw Error(u(407));
        a = a();
      } else {
        if (a = t(), Ze === null)
          throw Error(u(349));
        (Me & 127) !== 0 || Mp(l, t, a);
      }
      n.memoizedState = a;
      var r = { value: a, getSnapshot: t };
      return n.queue = r, Kp(Dp.bind(null, l, r, e), [
        e
      ]), l.flags |= 2048, Dn(
        9,
        { destroy: void 0 },
        Op.bind(
          null,
          l,
          r,
          a,
          t
        ),
        null
      ), a;
    },
    useId: function() {
      var e = Ct(), t = Ze.identifierPrefix;
      if (Se) {
        var a = xa, l = va;
        a = (l & ~(1 << 32 - Lt(l) - 1)).toString(32) + a, t = "_" + t + "R_" + a, a = Jr++, 0 < a && (t += "H" + a.toString(32)), t += "_";
      } else
        a = yv++, t = "_" + t + "r_" + a.toString(32) + "_";
      return e.memoizedState = t;
    },
    useHostTransitionStatus: au,
    useFormState: Xp,
    useActionState: Xp,
    useOptimistic: function(e) {
      var t = Ct();
      t.memoizedState = t.baseState = e;
      var a = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return t.queue = a, t = lu.bind(
        null,
        ye,
        !0,
        a
      ), a.dispatch = t, [e, t];
    },
    useMemoCache: Js,
    useCacheRefresh: function() {
      return Ct().memoizedState = Tv.bind(
        null,
        ye
      );
    },
    useEffectEvent: function(e) {
      var t = Ct(), a = { impl: e };
      return t.memoizedState = a, function() {
        if ((Be & 2) !== 0)
          throw Error(u(440));
        return a.impl.apply(void 0, arguments);
      };
    }
  }, cf = {
    readContext: bt,
    use: Wr,
    useCallback: _p,
    useContext: bt,
    useEffect: _s,
    useImperativeHandle: Pp,
    useInsertionEffect: Fp,
    useLayoutEffect: Wp,
    useMemo: $p,
    useReducer: Ir,
    useRef: Zp,
    useState: function() {
      return Ir(Va);
    },
    useDebugValue: $s,
    useDeferredValue: function(e, t) {
      var a = lt();
      return ef(
        a,
        Ge.memoizedState,
        e,
        t
      );
    },
    useTransition: function() {
      var e = Ir(Va)[0], t = lt().memoizedState;
      return [
        typeof e == "boolean" ? e : qi(e),
        t
      ];
    },
    useSyncExternalStore: Ap,
    useId: nf,
    useHostTransitionStatus: au,
    useFormState: Vp,
    useActionState: Vp,
    useOptimistic: function(e, t) {
      var a = lt();
      return Rp(a, Ge, e, t);
    },
    useMemoCache: Js,
    useCacheRefresh: rf,
    useEffectEvent: Jp
  }, Cv = {
    readContext: bt,
    use: Wr,
    useCallback: _p,
    useContext: bt,
    useEffect: _s,
    useImperativeHandle: Pp,
    useInsertionEffect: Fp,
    useLayoutEffect: Wp,
    useMemo: $p,
    useReducer: Ws,
    useRef: Zp,
    useState: function() {
      return Ws(Va);
    },
    useDebugValue: $s,
    useDeferredValue: function(e, t) {
      var a = lt();
      return Ge === null ? eu(a, e, t) : ef(
        a,
        Ge.memoizedState,
        e,
        t
      );
    },
    useTransition: function() {
      var e = Ws(Va)[0], t = lt().memoizedState;
      return [
        typeof e == "boolean" ? e : qi(e),
        t
      ];
    },
    useSyncExternalStore: Ap,
    useId: nf,
    useHostTransitionStatus: au,
    useFormState: Gp,
    useActionState: Gp,
    useOptimistic: function(e, t) {
      var a = lt();
      return Ge !== null ? Rp(a, Ge, e, t) : (a.baseState = e, [e, a.queue.dispatch]);
    },
    useMemoCache: Js,
    useCacheRefresh: rf,
    useEffectEvent: Jp
  };
  function nu(e, t, a, l) {
    t = e.memoizedState, a = a(l, t), a = a == null ? t : G({}, t, a), e.memoizedState = a, e.lanes === 0 && (e.updateQueue.baseState = a);
  }
  var iu = {
    enqueueSetState: function(e, t, a) {
      e = e._reactInternals;
      var l = It(), n = sl(l);
      n.payload = t, a != null && (n.callback = a), t = ul(e, n, l), t !== null && (Ht(t, e, l), Ci(t, e, l));
    },
    enqueueReplaceState: function(e, t, a) {
      e = e._reactInternals;
      var l = It(), n = sl(l);
      n.tag = 1, n.payload = t, a != null && (n.callback = a), t = ul(e, n, l), t !== null && (Ht(t, e, l), Ci(t, e, l));
    },
    enqueueForceUpdate: function(e, t) {
      e = e._reactInternals;
      var a = It(), l = sl(a);
      l.tag = 2, t != null && (l.callback = t), t = ul(e, l, a), t !== null && (Ht(t, e, a), Ci(t, e, a));
    }
  };
  function pf(e, t, a, l, n, r, p) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(l, r, p) : t.prototype && t.prototype.isPureReactComponent ? !yi(a, l) || !yi(n, r) : !0;
  }
  function ff(e, t, a, l) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, l), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, l), t.state !== e && iu.enqueueReplaceState(t, t.state, null);
  }
  function Wl(e, t) {
    var a = t;
    if ("ref" in t) {
      a = {};
      for (var l in t)
        l !== "ref" && (a[l] = t[l]);
    }
    if (e = e.defaultProps) {
      a === t && (a = G({}, a));
      for (var n in e)
        a[n] === void 0 && (a[n] = e[n]);
    }
    return a;
  }
  function mf(e) {
    Cr(e);
  }
  function hf(e) {
    console.error(e);
  }
  function gf(e) {
    Cr(e);
  }
  function td(e, t) {
    try {
      var a = e.onUncaughtError;
      a(t.value, { componentStack: t.stack });
    } catch (l) {
      setTimeout(function() {
        throw l;
      });
    }
  }
  function bf(e, t, a) {
    try {
      var l = e.onCaughtError;
      l(a.value, {
        componentStack: a.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null
      });
    } catch (n) {
      setTimeout(function() {
        throw n;
      });
    }
  }
  function ru(e, t, a) {
    return a = sl(a), a.tag = 3, a.payload = { element: null }, a.callback = function() {
      td(e, t);
    }, a;
  }
  function vf(e) {
    return e = sl(e), e.tag = 3, e;
  }
  function xf(e, t, a, l) {
    var n = a.type.getDerivedStateFromError;
    if (typeof n == "function") {
      var r = l.value;
      e.payload = function() {
        return n(r);
      }, e.callback = function() {
        bf(t, a, l);
      };
    }
    var p = a.stateNode;
    p !== null && typeof p.componentDidCatch == "function" && (e.callback = function() {
      bf(t, a, l), typeof n != "function" && (bl === null ? bl = /* @__PURE__ */ new Set([this]) : bl.add(this));
      var g = l.stack;
      this.componentDidCatch(l.value, {
        componentStack: g !== null ? g : ""
      });
    });
  }
  function Av(e, t, a, l, n) {
    if (a.flags |= 32768, l !== null && typeof l == "object" && typeof l.then == "function") {
      if (t = a.alternate, t !== null && Xl(
        t,
        a,
        n,
        !0
      ), a = vt.current, a !== null) {
        switch (a.tag) {
          case 31:
          case 13:
          case 19:
            return Tt === null ? zd() : a.alternate === null && at === 0 && (at = 3), a.flags &= -257, a.flags |= 65536, a.lanes = n, l === Xr ? a.flags |= 16384 : (t = a.updateQueue, t === null ? a.updateQueue = /* @__PURE__ */ new Set([l]) : t.add(l), Gu(e, l, n)), !1;
          case 22:
            return a.flags |= 65536, l === Xr ? a.flags |= 16384 : (t = a.updateQueue, t === null ? (t = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([l])
            }, a.updateQueue = t) : (a = t.retryQueue, a === null ? t.retryQueue = /* @__PURE__ */ new Set([l]) : a.add(l)), Gu(e, l, n)), !1;
        }
        throw Error(u(435, a.tag));
      }
      return Gu(e, l, n), zd(), !1;
    }
    if (Se)
      return t = vt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = n, l !== Ts && (e = Error(u(422), { cause: l }), Si(aa(e, a)))) : (l !== Ts && (t = Error(u(423), {
        cause: l
      }), Si(
        aa(t, a)
      )), e = e.current.alternate, e.flags |= 65536, n &= -n, e.lanes |= n, l = aa(l, a), n = ru(
        e.stateNode,
        l,
        n
      ), Us(e, n), at !== 4 && (at = 2)), !1;
    var r = Error(u(520), { cause: l });
    if (r = aa(r, a), Vi === null ? Vi = [r] : Vi.push(r), at !== 4 && (at = 2), t === null) return !0;
    l = aa(l, a), a = t;
    do {
      switch (a.tag) {
        case 3:
          return a.flags |= 65536, e = n & -n, a.lanes |= e, e = ru(a.stateNode, l, e), Us(a, e), !1;
        case 1:
          if (t = a.type, r = a.stateNode, (a.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || r !== null && typeof r.componentDidCatch == "function" && (bl === null || !bl.has(r))))
            return a.flags |= 65536, n &= -n, a.lanes |= n, n = vf(n), xf(
              n,
              e,
              a,
              l
            ), Us(a, n), !1;
          break;
        case 22:
          if (a.memoizedState !== null)
            return a.flags |= 65536, !1;
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var du = Error(u(461)), st = !1;
  function ot(e, t, a, l) {
    t.child = e === null ? zp(t, null, a, l) : Jl(
      t,
      e.child,
      a,
      l
    );
  }
  function yf(e, t, a, l, n) {
    a = a.render;
    var r = t.ref;
    if ("ref" in l) {
      var p = {};
      for (var g in l)
        g !== "ref" && (p[g] = l[g]);
    } else p = l;
    return Vl(t), l = Ls(
      e,
      t,
      a,
      p,
      r,
      n
    ), g = Gs(), e !== null && !st ? (Zs(e, t, n), La(e, t, n)) : (Se && g && kr(t), t.flags |= 1, ot(e, t, l, n), t.child);
  }
  function jf(e, t, a, l, n) {
    if (e === null) {
      var r = a.type;
      return typeof r == "function" && !zs(r) && r.defaultProps === void 0 && a.compare === null ? (t.tag = 15, t.type = r, zf(
        e,
        t,
        r,
        l,
        n
      )) : (e = Dr(
        a.type,
        null,
        l,
        t,
        t.mode,
        n
      ), e.ref = t.ref, e.return = t, t.child = e);
    }
    if (r = e.child, !hu(e, n)) {
      var p = r.memoizedProps;
      if (a = a.compare, a = a !== null ? a : yi, a(p, l) && e.ref === t.ref)
        return La(e, t, n);
    }
    return t.flags |= 1, e = Ha(r, l), e.ref = t.ref, e.return = t, t.child = e;
  }
  function zf(e, t, a, l, n) {
    if (e !== null) {
      var r = e.memoizedProps;
      if (yi(r, l) && e.ref === t.ref)
        if (st = !1, t.pendingProps = l = r, hu(e, n))
          (e.flags & 131072) !== 0 && (st = !0);
        else
          return t.lanes = e.lanes, La(e, t, n);
    }
    return su(
      e,
      t,
      a,
      l,
      n
    );
  }
  function Sf(e, t, a, l) {
    var n = l.children, r = e !== null ? e.memoizedState : null;
    if (e === null && t.stateNode === null && (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), l.mode === "hidden") {
      if ((t.flags & 128) !== 0) {
        if (r = r !== null ? r.baseLanes | a : a, e !== null) {
          for (l = t.child = e.child, n = 0; l !== null; )
            n = n | l.lanes | l.childLanes, l = l.sibling;
          l = n & ~r;
        } else l = 0, t.child = null;
        return wf(
          e,
          t,
          r,
          a,
          l
        );
      }
      if ((a & 536870912) !== 0)
        t.memoizedState = { baseLanes: 0, cachePool: null }, e !== null && Yr(
          t,
          r !== null ? r.cachePool : null
        ), r !== null ? Np(t, r) : Bs(), Tp(t);
      else
        return l = t.lanes = 536870912, wf(
          e,
          t,
          r !== null ? r.baseLanes | a : a,
          a,
          l
        );
    } else
      r !== null ? (Yr(t, r.cachePool), Np(t, r), pl(), t.memoizedState = null) : (e !== null && Yr(t, null), Bs(), pl());
    return ot(e, t, n, a), t.child;
  }
  function Ri(e, t) {
    return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), t.sibling;
  }
  function wf(e, t, a, l, n) {
    var r = Ds();
    return r = r === null ? null : { parent: rt._currentValue, pool: r }, t.memoizedState = {
      baseLanes: a,
      cachePool: r
    }, e !== null && Yr(t, null), Bs(), Tp(t), e !== null && Xl(e, t, l, !0), t.childLanes = n, null;
  }
  function ad(e, t) {
    return t = ld(
      { mode: t.mode, children: t.children },
      e.mode
    ), t.ref = e.ref, e.child = t, t.return = e, t;
  }
  function Nf(e, t, a) {
    return Jl(t, e.child, null, a), e = ad(t, t.pendingProps), e.flags |= 2, Kt(t), t.memoizedState = null, e;
  }
  function Mv(e, t, a) {
    var l = t.pendingProps, n = (t.flags & 128) !== 0;
    if (t.flags &= -129, e === null) {
      if (Se) {
        if (l.mode === "hidden")
          return e = ad(t, l), t.lanes = 536870912, e.memoizedState = { baseLanes: 0, cachePool: null }, Ri(null, e);
        if (Qs(t), (e = Je) ? (e = Pm(
          e,
          ia
        ), e = e !== null && e.data === "&" ? e : null, e !== null && (t.memoizedState = {
          dehydrated: e,
          treeContext: al !== null ? { id: va, overflow: xa } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = dp(e), a.return = t, t.child = a, pt = t, Je = null)) : e = null, e === null) throw nl(t);
        return t.lanes = 536870912, null;
      }
      return ad(t, l);
    }
    var r = e.memoizedState;
    if (r !== null) {
      var p = r.dehydrated;
      if (Qs(t), n)
        if (t.flags & 256)
          t.flags &= -257, t = Nf(
            e,
            t,
            a
          );
        else if (t.memoizedState !== null)
          t.child = e.child, t.flags |= 128, t = null;
        else throw Error(u(558));
      else if (st || Xl(e, t, a, !1), n = (a & e.childLanes) !== 0, st || n) {
        if (ol.current === null) {
          if (l = Ze, l !== null && (p = oc(l, a), p !== 0 && p !== r.retryLane))
            throw r.retryLane = p, Hl(e, p), Ht(l, e, p), du;
          zd();
        }
        t = Nf(
          e,
          t,
          a
        );
      } else
        e = r.treeContext, Je = da(p.nextSibling), pt = t, Se = !0, ll = null, ia = !1, e !== null && op(t, e), t = ad(t, l), t.flags |= 134221824;
      return t;
    }
    return e = Ha(e.child, {
      mode: l.mode,
      children: l.children
    }), e.ref = t.ref, t.child = e, e.return = t, e;
  }
  function qn(e, t) {
    var a = t.ref;
    if (a === null)
      e !== null && e.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof a != "function" && typeof a != "object")
        throw Error(u(284));
      (e === null || e.ref !== a) && (t.flags |= 4194816);
    }
  }
  function su(e, t, a, l, n) {
    return Vl(t), a = Ls(
      e,
      t,
      a,
      l,
      void 0,
      n
    ), l = Gs(), e !== null && !st ? (Zs(e, t, n), La(e, t, n)) : (Se && l && kr(t), t.flags |= 1, ot(e, t, a, n), t.child);
  }
  function Tf(e, t, a, l, n, r) {
    return Vl(t), t.updateQueue = null, a = Cp(
      t,
      l,
      a,
      n
    ), Ep(e), l = Gs(), e !== null && !st ? (Zs(e, t, r), La(e, t, r)) : (Se && l && kr(t), t.flags |= 1, ot(e, t, a, r), t.child);
  }
  function Ef(e, t, a, l, n) {
    if (Vl(t), t.stateNode === null) {
      var r = Sn, p = a.contextType;
      typeof p == "object" && p !== null && (r = bt(p)), r = new a(l, r), t.memoizedState = r.state !== null && r.state !== void 0 ? r.state : null, r.updater = iu, t.stateNode = r, r._reactInternals = t, r = t.stateNode, r.props = l, r.state = t.memoizedState, r.refs = {}, ks(t), p = a.contextType, r.context = typeof p == "object" && p !== null ? bt(p) : Sn, r.state = t.memoizedState, p = a.getDerivedStateFromProps, typeof p == "function" && (nu(
        t,
        a,
        p,
        l
      ), r.state = t.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof r.getSnapshotBeforeUpdate == "function" || typeof r.UNSAFE_componentWillMount != "function" && typeof r.componentWillMount != "function" || (p = r.state, typeof r.componentWillMount == "function" && r.componentWillMount(), typeof r.UNSAFE_componentWillMount == "function" && r.UNSAFE_componentWillMount(), p !== r.state && iu.enqueueReplaceState(r, r.state, null), Mi(t, l, r, n), Ai(), r.state = t.memoizedState), typeof r.componentDidMount == "function" && (t.flags |= 4194308), l = !0;
    } else if (e === null) {
      r = t.stateNode;
      var g = t.memoizedProps, S = Wl(a, g);
      r.props = S;
      var M = r.context, k = a.contextType;
      p = Sn, typeof k == "object" && k !== null && (p = bt(k));
      var Y = a.getDerivedStateFromProps;
      k = typeof Y == "function" || typeof r.getSnapshotBeforeUpdate == "function", g = t.pendingProps !== g, k || typeof r.UNSAFE_componentWillReceiveProps != "function" && typeof r.componentWillReceiveProps != "function" || (g || M !== p) && ff(
        t,
        r,
        l,
        p
      ), dl = !1;
      var C = t.memoizedState;
      r.state = C, Mi(t, l, r, n), Ai(), M = t.memoizedState, g || C !== M || dl ? (typeof Y == "function" && (nu(
        t,
        a,
        Y,
        l
      ), M = t.memoizedState), (S = dl || pf(
        t,
        a,
        S,
        l,
        C,
        M,
        p
      )) ? (k || typeof r.UNSAFE_componentWillMount != "function" && typeof r.componentWillMount != "function" || (typeof r.componentWillMount == "function" && r.componentWillMount(), typeof r.UNSAFE_componentWillMount == "function" && r.UNSAFE_componentWillMount()), typeof r.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof r.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = l, t.memoizedState = M), r.props = l, r.state = M, r.context = p, l = S) : (typeof r.componentDidMount == "function" && (t.flags |= 4194308), l = !1);
    } else {
      r = t.stateNode, Rs(e, t), p = t.memoizedProps, k = Wl(a, p), r.props = k, Y = t.pendingProps, C = r.context, M = a.contextType, S = Sn, typeof M == "object" && M !== null && (S = bt(M)), g = a.getDerivedStateFromProps, (M = typeof g == "function" || typeof r.getSnapshotBeforeUpdate == "function") || typeof r.UNSAFE_componentWillReceiveProps != "function" && typeof r.componentWillReceiveProps != "function" || (p !== Y || C !== S) && ff(
        t,
        r,
        l,
        S
      ), dl = !1, C = t.memoizedState, r.state = C, Mi(t, l, r, n), Ai();
      var q = t.memoizedState;
      p !== Y || C !== q || dl || e !== null && e.dependencies !== null && Hr(e.dependencies) ? (typeof g == "function" && (nu(
        t,
        a,
        g,
        l
      ), q = t.memoizedState), (k = dl || pf(
        t,
        a,
        k,
        l,
        C,
        q,
        S
      ) || e !== null && e.dependencies !== null && Hr(e.dependencies)) ? (M || typeof r.UNSAFE_componentWillUpdate != "function" && typeof r.componentWillUpdate != "function" || (typeof r.componentWillUpdate == "function" && r.componentWillUpdate(l, q, S), typeof r.UNSAFE_componentWillUpdate == "function" && r.UNSAFE_componentWillUpdate(
        l,
        q,
        S
      )), typeof r.componentDidUpdate == "function" && (t.flags |= 4), typeof r.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof r.componentDidUpdate != "function" || p === e.memoizedProps && C === e.memoizedState || (t.flags |= 4), typeof r.getSnapshotBeforeUpdate != "function" || p === e.memoizedProps && C === e.memoizedState || (t.flags |= 1024), t.memoizedProps = l, t.memoizedState = q), r.props = l, r.state = q, r.context = S, l = k) : (typeof r.componentDidUpdate != "function" || p === e.memoizedProps && C === e.memoizedState || (t.flags |= 4), typeof r.getSnapshotBeforeUpdate != "function" || p === e.memoizedProps && C === e.memoizedState || (t.flags |= 1024), l = !1);
    }
    return r = l, qn(e, t), l = (t.flags & 128) !== 0, r || l ? (r = t.stateNode, a = l && typeof a.getDerivedStateFromError != "function" ? null : r.render(), t.flags |= 1, e !== null && l ? (t.child = Jl(
      t,
      e.child,
      null,
      n
    ), t.child = Jl(
      t,
      null,
      a,
      n
    )) : ot(e, t, a, n), t.memoizedState = r.state, e = t.child) : e = La(
      e,
      t,
      n
    ), e;
  }
  function Cf(e, t, a, l) {
    return Yl(), t.flags |= 256, ot(e, t, a, l), t.child;
  }
  var uu = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function ou(e) {
    return { baseLanes: e, cachePool: gp() };
  }
  function cu(e, t, a) {
    return e = e !== null ? e.childLanes & ~a : 0, t && (e |= Wt), e;
  }
  function Af(e, t, a) {
    var l = t.pendingProps, n = !1, r = (t.flags & 128) !== 0, p;
    if ((p = r) || (p = e !== null && e.memoizedState === null ? !1 : (xt.current & 2) !== 0), p && (n = !0, t.flags &= -129), p = (t.flags & 32) !== 0, t.flags &= -33, e === null) {
      if (Se) {
        if (n ? cl(t) : pl(), (e = Je) ? (e = Pm(
          e,
          ia
        ), e = e !== null && e.data !== "&" ? e : null, e !== null && (t.memoizedState = {
          dehydrated: e,
          treeContext: al !== null ? { id: va, overflow: xa } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = dp(e), a.return = t, t.child = a, pt = t, Je = null)) : e = null, e === null) throw nl(t);
        return co(e) ? t.lanes = 32 : t.lanes = 536870912, null;
      }
      return r = l.children, l = l.fallback, n ? (pl(), n = t.mode, r = ld(
        { mode: "hidden", children: r },
        n
      ), l = Bl(
        l,
        n,
        a,
        null
      ), r.return = t, l.return = t, r.sibling = l, t.child = r, l = t.child, l.memoizedState = ou(a), l.childLanes = cu(
        e,
        p,
        a
      ), t.memoizedState = uu, Ri(null, l)) : (cl(t), pu(t, r));
    }
    var g = e.memoizedState;
    if (g !== null) {
      var S = g.dehydrated;
      if (S !== null)
        return Ov(
          e,
          t,
          r,
          p,
          l,
          S,
          g,
          a
        );
    }
    return n ? (pl(), n = l.fallback, r = t.mode, g = e.child, S = g.sibling, l = Ha(g, {
      mode: "hidden",
      children: l.children
    }), l.subtreeFlags = g.subtreeFlags & 1206910976, S !== null ? n = Ha(S, n) : (n = Bl(
      n,
      r,
      a,
      null
    ), n.flags |= 2), n.return = t, l.return = t, l.sibling = n, t.child = l, Ri(null, l), l = t.child, n = e.child.memoizedState, n === null ? n = ou(a) : (r = n.cachePool, r !== null ? (g = rt._currentValue, r = r.parent !== g ? { parent: g, pool: g } : r) : r = gp(), n = {
      baseLanes: n.baseLanes | a,
      cachePool: r
    }), l.memoizedState = n, l.childLanes = cu(
      e,
      p,
      a
    ), t.memoizedState = uu, Ri(e.child, l)) : (cl(t), a = e.child, e = a.sibling, a = Ha(a, {
      mode: "visible",
      children: l.children
    }), a.return = t, a.sibling = null, e !== null && (p = t.deletions, p === null ? (t.deletions = [e], t.flags |= 16) : p.push(e)), t.child = a, t.memoizedState = null, a);
  }
  function pu(e, t) {
    return t = ld(
      { mode: "visible", children: t },
      e.mode
    ), t.return = e, e.child = t;
  }
  function ld(e, t) {
    return e = qt(22, e, null, t), e.lanes = 0, e;
  }
  function nd(e, t, a) {
    return Jl(t, e.child, null, a), e = pu(
      t,
      t.pendingProps.children
    ), e.flags |= 2, t.memoizedState = null, e;
  }
  function Ov(e, t, a, l, n, r, p, g) {
    if (a)
      return t.flags & 256 ? (cl(t), t.flags &= -257, nd(
        e,
        t,
        g
      )) : t.memoizedState !== null ? (pl(), t.child = e.child, t.flags |= 128, null) : (pl(), r = n.fallback, p = t.mode, n = ld(
        { mode: "visible", children: n.children },
        p
      ), r = Bl(
        r,
        p,
        g,
        null
      ), r.flags |= 2, n.return = t, r.return = t, n.sibling = r, t.child = n, Jl(t, e.child, null, g), n = t.child, n.memoizedState = ou(g), n.childLanes = cu(
        e,
        l,
        g
      ), t.memoizedState = uu, Ri(null, n));
    if (cl(t), co(r)) {
      if (l = r.nextSibling && r.nextSibling.dataset, l) var S = l.dgst;
      return l = S, l !== "" && (n = Error(u(419)), n.stack = "", n.digest = l, Si({ value: n, source: null, stack: null })), nd(
        e,
        t,
        g
      );
    }
    if (st || Xl(e, t, g, !1), l = (g & e.childLanes) !== 0, st || l) {
      if (ol.current !== null)
        return nd(
          e,
          t,
          g
        );
      if (l = Ze, l !== null && (n = oc(
        l,
        g
      ), n !== 0 && n !== p.retryLane))
        throw p.retryLane = n, Hl(e, n), Ht(l, e, n), du;
      return oo(r) || zd(), nd(
        e,
        t,
        g
      );
    }
    return oo(r) ? (t.flags |= 192, t.child = e.child, null) : (e = p.treeContext, Je = da(r.nextSibling), pt = t, Se = !0, ll = null, ia = !1, e !== null && op(t, e), t = pu(
      t,
      n.children
    ), t.flags |= 134221824, t);
  }
  function Mf(e, t, a) {
    e.lanes |= t;
    var l = e.alternate;
    l !== null && (l.lanes |= t), Ur(e.return, t, a);
  }
  function Of(e) {
    for (var t = null; e !== null; ) {
      var a = e.alternate;
      a !== null && Zr(a) === null && (t = e), e = e.sibling;
    }
    return t;
  }
  function id(e, t, a, l, n, r) {
    var p = e.memoizedState;
    p === null ? e.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: l,
      tail: a,
      tailMode: n,
      treeForkCount: r
    } : (p.isBackwards = t, p.rendering = null, p.renderingStartTime = 0, p.last = l, p.tail = a, p.tailMode = n, p.treeForkCount = r);
  }
  function fu(e) {
    var t = e.child;
    for (e.child = null; t !== null; ) {
      var a = t.sibling;
      t.sibling = e.child, e.child = t, t = a;
    }
  }
  function mu(e, t, a) {
    var l = t.pendingProps, n = l.revealOrder, r = l.tail;
    l = l.children;
    var p = xt.current;
    if (t.flags & 128)
      return Oi(t, p), null;
    var g = (p & 2) !== 0;
    if (g ? (p = p & 1 | 2, t.flags |= 128) : p &= 1, Oi(t, p), n === "backwards" && e !== null ? (fu(e), ot(e, t, l, a), fu(e)) : ot(e, t, l, a), l = Se ? zi : 0, !g && e !== null && (e.flags & 128) !== 0)
      e: for (e = t.child; e !== null; ) {
        if (e.tag === 13)
          e.memoizedState !== null && Mf(e, a, t);
        else if (e.tag === 19)
          Mf(e, a, t);
        else if (e.child !== null) {
          e.child.return = e, e = e.child;
          continue;
        }
        if (e === t) break e;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t)
            break e;
          e = e.return;
        }
        e.sibling.return = e.return, e = e.sibling;
      }
    switch (n) {
      case "backwards":
        a = Of(t.child), a === null ? (n = t.child, t.child = null) : (n = a.sibling, a.sibling = null, fu(t)), id(
          t,
          !0,
          n,
          null,
          r,
          l
        );
        break;
      case "unstable_legacy-backwards":
        for (a = null, n = t.child, t.child = null; n !== null; ) {
          if (e = n.alternate, e !== null && Zr(e) === null) {
            t.child = n;
            break;
          }
          e = n.sibling, n.sibling = a, a = n, n = e;
        }
        id(
          t,
          !0,
          a,
          null,
          r,
          l
        );
        break;
      case "together":
        id(
          t,
          !1,
          null,
          null,
          void 0,
          l
        );
        break;
      case "independent":
        t.memoizedState = null;
        break;
      default:
        a = Of(t.child), a === null ? (n = t.child, t.child = null) : (n = a.sibling, a.sibling = null), id(
          t,
          !1,
          n,
          a,
          r,
          l
        );
    }
    return t.child;
  }
  function Df(e, t, a) {
    var l = t.pendingProps;
    return il(t, t.type, l.value), ot(e, t, l.children, a), t.child;
  }
  function La(e, t, a) {
    if (e !== null && (t.dependencies = e.dependencies), gl |= t.lanes, (a & t.childLanes) === 0)
      if (e !== null) {
        if (Xl(
          e,
          t,
          a,
          !1
        ), (a & t.childLanes) === 0)
          return null;
      } else return null;
    if (e !== null && t.child !== e.child)
      throw Error(u(153));
    if (t.child !== null) {
      for (e = t.child, a = Ha(e, e.pendingProps), t.child = a, a.return = t; e.sibling !== null; )
        e = e.sibling, a = a.sibling = Ha(e, e.pendingProps), a.return = t;
      a.sibling = null;
    }
    return t.child;
  }
  function hu(e, t) {
    return (e.lanes & t) !== 0 ? !0 : (e = e.dependencies, !!(e !== null && Hr(e)));
  }
  function Dv(e, t, a) {
    switch (t.tag) {
      case 3:
        un(t, t.stateNode.containerInfo), il(t, rt, e.memoizedState.cache), Yl();
        break;
      case 27:
      case 5:
        Z(t);
        break;
      case 4:
        un(t, t.stateNode.containerInfo);
        break;
      case 10:
        il(
          t,
          t.type,
          t.memoizedProps.value
        );
        break;
      case 31:
        if (t.memoizedState !== null)
          return t.flags |= 128, Qs(t), null;
        break;
      case 13:
        var l = t.memoizedState;
        if (l !== null) {
          if (l.dehydrated !== null)
            return cl(t), t.flags |= 128, null;
          l = Xl(
            e,
            t,
            a,
            !1
          );
          var n = t.child.childLanes;
          return l || (a & n) !== 0 ? Af(e, t, a) : (cl(t), e = La(
            e,
            t,
            a
          ), e !== null ? e.sibling : null);
        }
        cl(t);
        break;
      case 19:
        if (t.flags & 128)
          return mu(
            e,
            t,
            a
          );
        if (n = (e.flags & 128) !== 0, l = (a & t.childLanes) !== 0, l || (Xl(
          e,
          t,
          a,
          !1
        ), l = (a & t.childLanes) !== 0), n) {
          if (l)
            return mu(
              e,
              t,
              a
            );
          t.flags |= 128;
        }
        if (n = t.memoizedState, n !== null && (n.rendering = null, n.tail = null, n.lastEffect = null), Oi(t, xt.current), l) break;
        return null;
      case 22:
        return t.lanes = 0, Sf(
          e,
          t,
          a,
          t.pendingProps
        );
      case 24:
        il(t, rt, e.memoizedState.cache);
    }
    return La(e, t, a);
  }
  function qf(e, t, a) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps)
        st = !0;
      else {
        if (!hu(e, a) && (t.flags & 128) === 0)
          return st = !1, Dv(
            e,
            t,
            a
          );
        st = (e.flags & 131072) !== 0;
      }
    else
      st = !1, Se && (t.flags & 1048576) !== 0 && up(t, zi, t.index);
    switch (t.lanes = 0, t.tag) {
      case 16:
        e: {
          var l = t.pendingProps;
          if (e = Zl(t.elementType), t.type = e, typeof e == "function")
            zs(e) ? (l = Wl(e, l), t.tag = 1, t = Ef(
              null,
              t,
              e,
              l,
              a
            )) : (t.tag = 0, t = su(
              null,
              t,
              e,
              l,
              a
            ));
          else {
            if (e != null) {
              var n = e.$$typeof;
              if (n === L) {
                t.tag = 11, t = yf(
                  null,
                  t,
                  e,
                  l,
                  a
                );
                break e;
              } else if (n === Ce) {
                t.tag = 14, t = jf(
                  null,
                  t,
                  e,
                  l,
                  a
                );
                break e;
              } else if (n === Ee) {
                t.tag = 10, t.type = e, t = Df(
                  null,
                  t,
                  a
                );
                break e;
              }
            }
            throw t = Ae(e) || e, Error(u(306, t, ""));
          }
        }
        return t;
      case 0:
        return su(
          e,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 1:
        return l = t.type, n = Wl(
          l,
          t.pendingProps
        ), Ef(
          e,
          t,
          l,
          n,
          a
        );
      case 3:
        e: {
          if (un(
            t,
            t.stateNode.containerInfo
          ), e === null) throw Error(u(387));
          l = t.pendingProps;
          var r = t.memoizedState;
          n = r.element, Rs(e, t), Mi(t, l, null, a);
          var p = t.memoizedState;
          if (l = p.cache, il(t, rt, l), l !== r.cache && As(
            t,
            [rt],
            a,
            !0
          ), Ai(), l = p.element, r.isDehydrated)
            if (r = {
              element: l,
              isDehydrated: !1,
              cache: p.cache
            }, t.updateQueue.baseState = r, t.memoizedState = r, t.flags & 256) {
              t = Cf(
                e,
                t,
                l,
                a
              );
              break e;
            } else if (l !== n) {
              n = aa(
                Error(u(424)),
                t
              ), Si(n), t = Cf(
                e,
                t,
                l,
                a
              );
              break e;
            } else {
              switch (e = t.stateNode.containerInfo, e.nodeType) {
                case 9:
                  e = e.body;
                  break;
                default:
                  e = e.nodeName === "HTML" ? e.ownerDocument.body : e;
              }
              for (Je = da(e.firstChild), pt = t, Se = !0, ll = null, ia = !0, a = zp(
                t,
                null,
                l,
                a
              ), t.child = a; a; )
                a.flags = a.flags & -3 | 134221824, a = a.sibling;
            }
          else {
            if (Yl(), l === n) {
              t = La(
                e,
                t,
                a
              );
              break e;
            }
            ot(e, t, l, a);
          }
          t = t.child;
        }
        return t;
      case 26:
        return qn(e, t), e === null ? (a = nh(
          t.type,
          null,
          t.pendingProps,
          null
        )) ? t.memoizedState = a : Se || (t.stateNode = Hm(
          t.type,
          t.pendingProps,
          Ot.current,
          t
        )) : t.memoizedState = nh(
          t.type,
          e.memoizedProps,
          t.pendingProps,
          e.memoizedState
        ), null;
      case 27:
        return Z(t), e === null && Se && (l = t.stateNode = eh(
          t.type,
          t.pendingProps,
          Ot.current
        ), pt = t, ia = !0, n = Je, yl(t.type) ? (po = n, Je = da(l.firstChild)) : Je = n), ot(
          e,
          t,
          t.pendingProps.children,
          a
        ), qn(e, t), e === null && (t.flags |= 4194304), t.child;
      case 5:
        return e === null && Se && ((n = l = Je) && (l = Tx(
          l,
          t.type,
          t.pendingProps,
          ia
        ), l !== null ? (t.stateNode = l, pt = t, Je = da(l.firstChild), ia = !1, n = !0) : n = !1), n || nl(t)), Z(t), n = t.type, r = t.pendingProps, p = e !== null ? e.memoizedProps : null, l = r.children, ao(n, r) ? l = null : p !== null && ao(n, p) && (t.flags |= 32), t.memoizedState !== null && (n = Ls(
          e,
          t,
          jv,
          null,
          null,
          a
        ), Pn._currentValue = n), qn(e, t), ot(e, t, l, a), t.child;
      case 6:
        return e === null && Se && ((e = a = Je) && (a = Ex(
          a,
          t.pendingProps,
          ia
        ), a !== null ? (t.stateNode = a, pt = t, Je = null, e = !0) : e = !1), e || nl(t)), null;
      case 13:
        return Af(e, t, a);
      case 4:
        return un(
          t,
          t.stateNode.containerInfo
        ), l = t.pendingProps, e === null ? t.child = Jl(
          t,
          null,
          l,
          a
        ) : ot(e, t, l, a), t.child;
      case 11:
        return yf(
          e,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 7:
        return l = t.pendingProps, qn(e, t), ot(e, t, l, a), t.child;
      case 8:
        return ot(
          e,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 12:
        return ot(
          e,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 10:
        return Df(e, t, a);
      case 9:
        return n = t.type._context, l = t.pendingProps.children, Vl(t), n = bt(n), l = l(n), t.flags |= 1, ot(e, t, l, a), t.child;
      case 14:
        return jf(
          e,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 15:
        return zf(
          e,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 19:
        return mu(e, t, a);
      case 31:
        return Mv(e, t, a);
      case 22:
        return Sf(
          e,
          t,
          a,
          t.pendingProps
        );
      case 24:
        return Vl(t), l = bt(rt), e === null ? (n = Ds(), n === null && (n = Ze, r = Ms(), n.pooledCache = r, r.refCount++, r !== null && (n.pooledCacheLanes |= a), n = r), t.memoizedState = { parent: l, cache: n }, ks(t), il(t, rt, n)) : ((e.lanes & a) !== 0 && (Rs(e, t), Mi(t, null, null, a), Ai()), n = e.memoizedState, r = t.memoizedState, n.parent !== l ? (n = { parent: l, cache: l }, t.memoizedState = n, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = n), il(t, rt, l)) : (l = r.cache, il(t, rt, l), l !== n.cache && As(
          t,
          [rt],
          a,
          !0
        ))), ot(
          e,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 30:
        return t.stateNode === null && (t.stateNode = {
          autoName: null,
          paired: null,
          clones: null,
          ref: null
        }), l = t.pendingProps, l.name != null && l.name !== "auto" ? t.flags |= e === null ? 18882560 : 18874368 : Se && kr(t), e !== null && e.memoizedProps.name !== l.name ? t.flags |= 4194816 : qn(e, t), ot(e, t, l.children, a), t.child;
      case 29:
        throw t.pendingProps;
    }
    throw Error(u(156, t.tag));
  }
  function Ga(e) {
    e.flags |= 4;
  }
  function gu(e, t, a, l, n) {
    var r;
    if ((r = (e.mode & 32) !== 0) && (r = a === null ? sh(t, l) : sh(t, l) && (l.src !== a.src || l.srcSet !== a.srcSet)), r) {
      if (e.flags |= 16777216, (n & 335544128) === n)
        if (e.stateNode.complete) e.flags |= 8192;
        else if (mm()) e.flags |= 8192;
        else
          throw Kl = Xr, qs;
    } else e.flags &= -16777217;
  }
  function kf(e, t) {
    if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0)
      e.flags &= -16777217;
    else if (e.flags |= 16777216, !uh(t))
      if (mm()) e.flags |= 8192;
      else
        throw Kl = Xr, qs;
  }
  function rd(e, t) {
    t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag !== 22 ? dc() : 536870912, e.lanes |= t, Bn |= t);
  }
  function Ui(e, t) {
    if (!Se)
      switch (e.tailMode) {
        case "visible":
          break;
        case "collapsed":
          for (var a = e.tail, l = null; a !== null; )
            a.alternate !== null && (l = a), a = a.sibling;
          l === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : l.sibling = null;
          break;
        default:
          for (t = e.tail, a = null; t !== null; )
            t.alternate !== null && (a = t), t = t.sibling;
          a === null ? e.tail = null : a.sibling = null;
      }
  }
  function Fe(e) {
    var t = e.alternate !== null && e.alternate.child === e.child, a = 0, l = 0;
    if (t)
      for (var n = e.child; n !== null; )
        a |= n.lanes | n.childLanes, l |= n.subtreeFlags & 1206910976, l |= n.flags & 1206910976, n.return = e, n = n.sibling;
    else
      for (n = e.child; n !== null; )
        a |= n.lanes | n.childLanes, l |= n.subtreeFlags, l |= n.flags, n.return = e, n = n.sibling;
    return e.subtreeFlags |= l, e.childLanes = a, t;
  }
  function qv(e, t, a) {
    var l = t.pendingProps;
    switch (Ns(t), t.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Fe(t), null;
      case 1:
        return Fe(t), null;
      case 3:
        return a = t.stateNode, l = null, e !== null && (l = e.memoizedState.cache), t.memoizedState.cache !== l && (t.flags |= 2048), Qa(rt), Ma(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (e === null || e.child === null) && (Tn(t) ? Ga(t) : e === null || e.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, Es())), Fe(t), null;
      case 26:
        var n = t.type, r = t.memoizedState;
        return e === null ? (Ga(t), r !== null ? (Fe(t), kf(t, r)) : (Fe(t), gu(
          t,
          n,
          null,
          l,
          a
        ))) : r ? r !== e.memoizedState ? (Ga(t), Fe(t), kf(t, r)) : (Fe(t), t.flags &= -16777217) : (e = e.memoizedProps, e !== l && Ga(t), Fe(t), gu(
          t,
          n,
          e,
          l,
          a
        )), null;
      case 27:
        if (qe(t), a = Ot.current, n = t.type, e !== null && t.stateNode != null)
          e.memoizedProps !== l && Ga(t);
        else {
          if (!l) {
            if (t.stateNode === null)
              throw Error(u(166));
            return Fe(t), t.subtreeFlags &= -33554433, null;
          }
          e = Qt.current, Tn(t) ? cp(t) : (e = eh(n, l, a), t.stateNode = e, Ga(t));
        }
        return Fe(t), t.subtreeFlags &= -33554433, null;
      case 5:
        if (qe(t), n = t.type, e !== null && t.stateNode != null)
          e.memoizedProps !== l && Ga(t);
        else {
          if (!l) {
            if (t.stateNode === null)
              throw Error(u(166));
            return Fe(t), t.subtreeFlags &= -33554433, null;
          }
          if (r = Qt.current, Tn(t))
            cp(t);
          else {
            var p = Ji(
              Ot.current
            );
            switch (r) {
              case 1:
                r = p.createElementNS(
                  "http://www.w3.org/2000/svg",
                  n
                );
                break;
              case 2:
                r = p.createElementNS(
                  "http://www.w3.org/1998/Math/MathML",
                  n
                );
                break;
              default:
                switch (n) {
                  case "svg":
                    r = p.createElementNS(
                      "http://www.w3.org/2000/svg",
                      n
                    );
                    break;
                  case "math":
                    r = p.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      n
                    );
                    break;
                  case "script":
                    r = p.createElement("div"), r.innerHTML = "<script><\/script>", r = r.removeChild(
                      r.firstChild
                    );
                    break;
                  case "select":
                    r = typeof l.is == "string" ? p.createElement("select", {
                      is: l.is
                    }) : p.createElement("select"), l.multiple ? r.multiple = !0 : l.size && (r.size = l.size);
                    break;
                  default:
                    r = typeof l.is == "string" ? p.createElement(n, { is: l.is }) : p.createElement(n);
                }
            }
            r[gt] = t, r[Dt] = l;
            e: for (p = t.child; p !== null; ) {
              if (p.tag === 5 || p.tag === 6)
                r.appendChild(p.stateNode);
              else if (p.tag !== 4 && p.tag !== 27 && p.child !== null) {
                p.child.return = p, p = p.child;
                continue;
              }
              if (p === t) break e;
              for (; p.sibling === null; ) {
                if (p.return === null || p.return === t)
                  break e;
                p = p.return;
              }
              p.sibling.return = p.return, p = p.sibling;
            }
            t.stateNode = r;
            e: switch (jt(r, n, l), n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                l = !!l.autoFocus;
                break e;
              case "img":
                l = !0;
                break e;
              default:
                l = !1;
            }
            l && Ga(t);
          }
        }
        return Fe(t), t.subtreeFlags &= -33554433, gu(
          t,
          t.type,
          e === null ? null : e.memoizedProps,
          t.pendingProps,
          a
        ), null;
      case 6:
        if (e && t.stateNode != null)
          e.memoizedProps !== l && Ga(t);
        else {
          if (typeof l != "string" && t.stateNode === null)
            throw Error(u(166));
          if (e = Ot.current, Tn(t)) {
            if (e = t.stateNode, a = t.memoizedProps, l = null, n = pt, n !== null)
              switch (n.tag) {
                case 27:
                case 5:
                  l = n.memoizedProps;
              }
            e[gt] = t, e = !!(e.nodeValue === a || l !== null && l.suppressHydrationWarning === !0 || qm(e.nodeValue, a)), e || nl(t, !0);
          } else
            e = Ji(e).createTextNode(
              l
            ), e[gt] = t, t.stateNode = e;
        }
        return Fe(t), null;
      case 31:
        if (a = t.memoizedState, e === null || e.memoizedState !== null) {
          if (l = Tn(t), a !== null) {
            if (e === null) {
              if (!l) throw Error(u(318));
              if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(u(557));
              e[gt] = t;
            } else
              Yl(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            Fe(t), e = !1;
          } else
            a = Es(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = a), e = !0;
          if (!e)
            return t.flags & 256 ? (Kt(t), t) : (Kt(t), null);
          if ((t.flags & 128) !== 0)
            throw Error(u(558));
        }
        return Fe(t), null;
      case 13:
        if (l = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
          if (n = Tn(t), l !== null && l.dehydrated !== null) {
            if (e === null) {
              if (!n) throw Error(u(318));
              if (n = t.memoizedState, n = n !== null ? n.dehydrated : null, !n) throw Error(u(317));
              n[gt] = t;
            } else
              Yl(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            Fe(t), n = !1;
          } else
            n = Es(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), n = !0;
          if (!n)
            return t.flags & 256 ? (Kt(t), t) : (Kt(t), null);
        }
        return Kt(t), (t.flags & 128) !== 0 ? (t.lanes = a, t) : (a = l !== null, e = e !== null && e.memoizedState !== null, a && (l = t.child, n = null, l.alternate !== null && l.alternate.memoizedState !== null && l.alternate.memoizedState.cachePool !== null && (n = l.alternate.memoizedState.cachePool.pool), r = null, l.memoizedState !== null && l.memoizedState.cachePool !== null && (r = l.memoizedState.cachePool.pool), r !== n && (l.flags |= 2048)), a !== e && a && (t.child.flags |= 8192), rd(t, t.updateQueue), Fe(t), null);
      case 4:
        return Ma(), e === null && Pu(t.stateNode.containerInfo), t.flags |= 67108864, Fe(t), null;
      case 10:
        return Qa(t.type), Fe(t), null;
      case 19:
        if (Xs(t), l = t.memoizedState, l === null) return Fe(t), null;
        if (n = (t.flags & 128) !== 0, r = l.rendering, r === null)
          if (n) Ui(l, !1);
          else {
            if (at !== 0 || e !== null && (e.flags & 128) !== 0)
              for (e = t.child; e !== null; ) {
                if (r = Zr(e), r !== null) {
                  for (t.flags |= 128, Ui(l, !1), e = r.updateQueue, t.updateQueue = e, rd(t, e), t.subtreeFlags = 0, e = a, a = t.child; a !== null; )
                    rp(a, e), a = a.sibling;
                  return Oi(
                    t,
                    xt.current & 1 | 2
                  ), Se && Ba(t, l.treeForkCount), t.child;
                }
                e = e.sibling;
              }
            l.tail !== null && Xt() > vd && (t.flags |= 128, n = !0, Ui(l, !1), t.lanes = 4194304);
          }
        else {
          if (!n)
            if (e = Zr(r), e !== null) {
              if (t.flags |= 128, n = !0, e = e.updateQueue, t.updateQueue = e, rd(t, e), Ui(l, !0), l.tail === null && l.tailMode !== "collapsed" && l.tailMode !== "visible" && !r.alternate && !Se)
                return Fe(t), null;
            } else
              2 * Xt() - l.renderingStartTime > vd && a !== 536870912 && (t.flags |= 128, n = !0, Ui(l, !1), t.lanes = 4194304);
          l.isBackwards ? (r.sibling = t.child, t.child = r) : (e = l.last, e !== null ? e.sibling = r : t.child = r, l.last = r);
        }
        if (l.tail !== null) {
          e = l.tail;
          e: {
            for (a = e; a !== null; ) {
              if (a.alternate !== null) {
                a = !1;
                break e;
              }
              a = a.sibling;
            }
            a = !0;
          }
          return l.rendering = e, l.tail = e.sibling, l.renderingStartTime = Xt(), e.sibling = null, r = xt.current, r = n ? r & 1 | 2 : r & 1, l.tailMode === "visible" || l.tailMode === "collapsed" || !a || Se ? Oi(t, r) : (a = r, Ye(vt, t), Ye(xt, a), Tt === null && (Tt = t)), Se && Ba(t, l.treeForkCount), e;
        }
        return Fe(t), null;
      case 22:
      case 23:
        return Kt(t), Ys(), l = t.memoizedState !== null, e !== null ? e.memoizedState !== null !== l && (t.flags |= 8192) : l && (t.flags |= 8192), l ? (a & 536870912) !== 0 && (t.flags & 128) === 0 && (Fe(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Fe(t), a = t.updateQueue, a !== null && rd(t, a.retryQueue), a = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (a = e.memoizedState.cachePool.pool), l = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), l !== a && (t.flags |= 2048), e !== null && $e(Gl), null;
      case 24:
        return a = null, e !== null && (a = e.memoizedState.cache), t.memoizedState.cache !== a && (t.flags |= 2048), Qa(rt), Fe(t), null;
      case 25:
        return null;
      case 30:
        return t.flags |= 33554432, Fe(t), null;
    }
    throw Error(u(156, t.tag));
  }
  function kv(e, t) {
    switch (Ns(t), t.tag) {
      case 1:
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 3:
        return Qa(rt), Ma(), e = t.flags, (e & 65536) !== 0 && (e & 128) === 0 ? (t.flags = e & -65537 | 128, t) : null;
      case 26:
      case 27:
      case 5:
        return qe(t), null;
      case 31:
        if (t.memoizedState !== null) {
          if (Kt(t), t.alternate === null)
            throw Error(u(340));
          Yl();
        }
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 13:
        if (Kt(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
          if (t.alternate === null)
            throw Error(u(340));
          Yl();
        }
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 19:
        return Xs(t), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, e = t.memoizedState, e !== null && (e.rendering = null, e.tail = null), t.flags |= 4, t) : null;
      case 4:
        return Ma(), null;
      case 10:
        return Qa(t.type), null;
      case 22:
      case 23:
        return Kt(t), Ys(), e !== null && $e(Gl), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 24:
        return Qa(rt), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Rf(e, t) {
    switch (Ns(t), t.tag) {
      case 3:
        Qa(rt), Ma();
        break;
      case 26:
      case 27:
      case 5:
        qe(t);
        break;
      case 4:
        Ma();
        break;
      case 31:
        t.memoizedState !== null && Kt(t);
        break;
      case 13:
        Kt(t);
        break;
      case 19:
        Xs(t);
        break;
      case 10:
        Qa(t.type);
        break;
      case 22:
      case 23:
        Kt(t), Ys(), e !== null && $e(Gl);
        break;
      case 24:
        Qa(rt);
    }
  }
  function Hi(e, t) {
    try {
      var a = t.updateQueue, l = a !== null ? a.lastEffect : null;
      if (l !== null) {
        var n = l.next;
        a = n;
        do {
          if ((a.tag & e) === e) {
            l = void 0;
            var r = a.create, p = a.inst;
            l = r(), p.destroy = l;
          }
          a = a.next;
        } while (a !== n);
      }
    } catch (g) {
      Ve(t, t.return, g);
    }
  }
  function fl(e, t, a) {
    try {
      var l = t.updateQueue, n = l !== null ? l.lastEffect : null;
      if (n !== null) {
        var r = n.next;
        l = r;
        do {
          if ((l.tag & e) === e) {
            var p = l.inst, g = p.destroy;
            if (g !== void 0) {
              p.destroy = void 0, n = t;
              var S = a, M = g;
              try {
                M();
              } catch (k) {
                Ve(
                  n,
                  S,
                  k
                );
              }
            }
          }
          l = l.next;
        } while (l !== r);
      }
    } catch (k) {
      Ve(t, t.return, k);
    }
  }
  function Uf(e) {
    var t = e.updateQueue;
    if (t !== null) {
      var a = e.stateNode;
      try {
        wp(t, a);
      } catch (l) {
        Ve(e, e.return, l);
      }
    }
  }
  function Hf(e, t, a) {
    a.props = Wl(
      e.type,
      e.memoizedProps
    ), a.state = e.memoizedState;
    try {
      a.componentWillUnmount();
    } catch (l) {
      Ve(e, t, l);
    }
  }
  function ya(e, t) {
    try {
      var a = e.ref;
      if (a !== null) {
        switch (e.tag) {
          case 26:
          case 27:
          case 5:
            var l = e.stateNode;
            break;
          case 30:
            var n = e.stateNode, r = Ra(e.memoizedProps, n);
            (n.ref === null || n.ref.name !== r) && (n.ref = Gm(r)), l = n.ref;
            break;
          case 7:
            if (e.stateNode === null) {
              var p = new Pt(e);
              b(
                e.child,
                !1,
                wx,
                p,
                void 0,
                void 0
              ), e.stateNode = p;
            }
            l = e.stateNode;
            break;
          default:
            l = e.stateNode;
        }
        typeof a == "function" ? e.refCleanup = a(l) : a.current = l;
      }
    } catch (g) {
      Ve(e, t, g);
    }
  }
  function yt(e, t) {
    var a = e.ref, l = e.refCleanup;
    if (a !== null)
      if (typeof l == "function")
        try {
          l();
        } catch (n) {
          Ve(e, t, n);
        } finally {
          e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
        }
      else if (typeof a == "function")
        try {
          a(null);
        } catch (n) {
          Ve(e, t, n);
        }
      else a.current = null;
  }
  function dd(e, t) {
    if ((e.tag === 5 || e.tag === 27 || e.tag === 6) && e.alternate === null && t !== null)
      for (var a = 0; a < t.length; a++)
        Im(
          e.stateNode,
          t[a]
        );
  }
  function Bf(e) {
    for (var t = e.return; t !== null && (vu(t) && Im(e.stateNode, t.stateNode), !bu(t)); )
      t = t.return;
  }
  function Bi(e) {
    for (var t = e.return; t !== null && (vu(t) && Nx(e.stateNode, t.stateNode), !bu(t)); )
      t = t.return;
  }
  function bu(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 27;
  }
  function vu(e) {
    return e && e.tag === 7 && e.stateNode !== null;
  }
  function xu(e) {
    var t = e.type, a = e.memoizedProps, l = e.stateNode;
    try {
      e: switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          a.autoFocus && l.focus();
          break e;
        case "img":
          a.src ? l.src = a.src : a.srcSet && (l.srcset = a.srcSet);
      }
    } catch (n) {
      Ve(e, e.return, n);
    }
  }
  function yu(e, t, a) {
    try {
      var l = e.stateNode;
      rx(l, e.type, a, t), l[Dt] = t;
    } catch (n) {
      Ve(e, e.return, n);
    }
  }
  function Yf(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && yl(e.type) || e.tag === 4;
  }
  function ju(e) {
    e: for (; ; ) {
      for (; e.sibling === null; ) {
        if (e.return === null || Yf(e.return)) return null;
        e = e.return;
      }
      for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
        if (e.tag === 27 && yl(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue e;
        e.child.return = e, e = e.child;
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function zu(e, t, a, l) {
    var n = e.tag;
    if (n === 5 || n === 6)
      n = e.stateNode, t ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(n, t) : (t = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, t.appendChild(n), a = a._reactRootContainer, a != null || t.onclick !== null || (t.onclick = ba)), dd(e, l), He = !0;
    else if (n !== 4 && (n === 27 && (dd(e, l), l = null, yl(e.type) && (a = e.stateNode, t = null)), e = e.child, e !== null))
      for (zu(
        e,
        t,
        a,
        l
      ), e = e.sibling; e !== null; )
        zu(
          e,
          t,
          a,
          l
        ), e = e.sibling;
  }
  function sd(e, t, a, l) {
    var n = e.tag;
    if (n === 5 || n === 6)
      n = e.stateNode, t ? a.insertBefore(n, t) : a.appendChild(n), dd(e, l), He = !0;
    else if (n !== 4 && (n === 27 && (dd(e, l), l = null, yl(e.type) && (a = e.stateNode)), e = e.child, e !== null))
      for (sd(
        e,
        t,
        a,
        l
      ), e = e.sibling; e !== null; )
        sd(
          e,
          t,
          a,
          l
        ), e = e.sibling;
  }
  function Qf(e) {
    var t = e.stateNode, a = e.memoizedProps;
    try {
      for (var l = e.type, n = t.attributes; n.length; )
        t.removeAttributeNode(n[0]);
      jt(t, l, a), t[gt] = e, t[Dt] = a;
    } catch (r) {
      Ve(e, e.return, r);
    }
  }
  var ud = !1, Jt = null;
  function Xf(e) {
    (e.tag === 30 || (e.subtreeFlags & 33554432) !== 0) && (ud = !0);
  }
  var ja = null;
  function Vf() {
    var e = ja;
    return ja = null, e;
  }
  var kt = 0;
  function kn(e, t, a, l, n) {
    return kt = 0, Lf(
      e.child,
      t,
      a,
      l,
      n
    );
  }
  function Lf(e, t, a, l, n) {
    for (var r = !1; e !== null; ) {
      if (e.tag === 5) {
        var p = e.stateNode;
        if (l !== null) {
          var g = io(p);
          l.push(g), g.view && (r = !0);
        } else
          r || io(p).view && (r = !0);
        ud = !0, Vm(
          p,
          kt === 0 ? t : t + "_" + kt,
          a
        ), kt++;
      } else (e.tag !== 22 || e.memoizedState === null) && (e.tag === 30 && n || Lf(
        e.child,
        t,
        a,
        l,
        n
      ) && (r = !0));
      e = e.sibling;
    }
    return r;
  }
  function za(e, t) {
    for (; e !== null; )
      e.tag === 5 ? Lm(e.stateNode, e.memoizedProps) : (e.tag !== 22 || e.memoizedState === null) && (e.tag === 30 && t || za(
        e.child,
        t
      )), e = e.sibling;
  }
  function od(e) {
    if ((e.subtreeFlags & 18874368) !== 0)
      for (e = e.child; e !== null; ) {
        if ((e.tag !== 22 || e.memoizedState === null) && (od(e), e.tag === 30 && (e.flags & 18874368) !== 0 && e.stateNode.paired)) {
          var t = e.memoizedProps;
          if (t.name == null || t.name === "auto")
            throw Error(u(544));
          var a = t.name;
          t = Ua(t.default, t.share), t !== "none" && (kn(
            e,
            a,
            t,
            null,
            !1
          ) || za(e.child, !1));
        }
        e = e.sibling;
      }
  }
  function Su(e, t) {
    if (e.tag === 30) {
      var a = e.stateNode, l = e.memoizedProps, n = Ra(l, a), r = Ua(
        l.default,
        a.paired ? l.share : l.enter
      );
      r !== "none" ? kn(e, n, r, null, !1) ? (od(e), a.paired || t || Vn(e, l.onEnter)) : za(e.child, !1) : od(e);
    } else if ((e.subtreeFlags & 33554432) !== 0)
      for (e = e.child; e !== null; )
        Su(e, t), e = e.sibling;
    else od(e);
  }
  function wu(e) {
    if (Jt !== null && Jt.size !== 0) {
      var t = Jt;
      if ((e.subtreeFlags & 18874368) !== 0)
        for (e = e.child; e !== null; ) {
          if (e.tag !== 22 || e.memoizedState === null) {
            if (e.tag === 30 && (e.flags & 18874368) !== 0) {
              var a = e.memoizedProps, l = a.name;
              if (l != null && l !== "auto") {
                var n = t.get(l);
                if (n !== void 0) {
                  var r = Ua(
                    a.default,
                    a.share
                  );
                  if (r !== "none" && (kn(
                    e,
                    l,
                    r,
                    null,
                    !1
                  ) ? (r = e.stateNode, n.paired = r, r.paired = n, Vn(e, a.onShare)) : za(e.child, !1)), t.delete(l), t.size === 0) break;
                }
              }
            }
            wu(e);
          }
          e = e.sibling;
        }
    }
  }
  function Nu(e) {
    if (e.tag === 30) {
      var t = e.memoizedProps, a = Ra(t, e.stateNode), l = Jt !== null ? Jt.get(a) : void 0, n = Ua(
        t.default,
        l !== void 0 ? t.share : t.exit
      );
      n !== "none" && (kn(e, a, n, null, !1) ? l !== void 0 ? (n = e.stateNode, l.paired = n, n.paired = l, Jt.delete(a), Vn(e, t.onShare)) : Vn(e, t.onExit) : za(e.child, !1)), Jt !== null && wu(e);
    } else if ((e.subtreeFlags & 33554432) !== 0)
      for (e = e.child; e !== null; )
        Nu(e), e = e.sibling;
    else
      Jt !== null && wu(e);
  }
  function Gf(e) {
    for (e = e.child; e !== null; ) {
      if (e.tag === 30) {
        var t = e.memoizedProps, a = Ra(t, e.stateNode);
        t = Ua(t.default, t.update), e.flags &= -5, t !== "none" && kn(
          e,
          a,
          t,
          e.memoizedState = [],
          !1
        );
      } else
        (e.subtreeFlags & 33554432) !== 0 && Gf(e);
      e = e.sibling;
    }
  }
  function Tu(e) {
    if ((e.subtreeFlags & 18874368) !== 0)
      for (e = e.child; e !== null; ) {
        if (e.tag !== 22 || e.memoizedState === null) {
          if (e.tag === 30 && (e.flags & 18874368) !== 0) {
            var t = e.stateNode;
            t.paired !== null && (t.paired = null, za(e.child, !1));
          }
          Tu(e);
        }
        e = e.sibling;
      }
  }
  function cd(e) {
    if (e.tag === 30)
      e.stateNode.paired = null, za(e.child, !1), Tu(e);
    else if ((e.subtreeFlags & 33554432) !== 0)
      for (e = e.child; e !== null; )
        cd(e), e = e.sibling;
    else Tu(e);
  }
  function Zf(e) {
    for (e = e.child; e !== null; )
      e.tag === 30 ? za(e.child, !1) : (e.subtreeFlags & 33554432) !== 0 && Zf(e), e = e.sibling;
  }
  function Eu(e, t, a, l, n, r, p) {
    for (var g = !1; t !== null; ) {
      if (t.tag === 5) {
        var S = t.stateNode;
        if (r !== null && kt < r.length) {
          var M = r[kt], k = io(S);
          (M.view || k.view) && (g = !0);
          var Y;
          if (Y = (e.flags & 4) === 0)
            if (k.clip) Y = !0;
            else {
              Y = M.rect;
              var C = k.rect;
              Y = Y.y !== C.y || Y.x !== C.x || Y.height !== C.height || Y.width !== C.width;
            }
          Y && (e.flags |= 4), k.abs ? k = !M.abs : (M = M.rect, k = k.rect, k = M.height !== k.height || M.width !== k.width), k && (e.flags |= 32);
        } else e.flags |= 32;
        (e.flags & 4) !== 0 && Vm(
          S,
          kt === 0 ? a : a + "_" + kt,
          n
        ), g && (e.flags & 4) !== 0 || (ja === null && (ja = []), ja.push(
          S,
          kt === 0 ? l : l + "_" + kt,
          t.memoizedProps
        )), kt++;
      } else (t.tag !== 22 || t.memoizedState === null) && (t.tag === 30 && p ? e.flags |= t.flags & 32 : Eu(
        e,
        t.child,
        a,
        l,
        n,
        r,
        p
      ) && (g = !0));
      t = t.sibling;
    }
    return g;
  }
  function Kf(e, t) {
    for (e = e.child; e !== null; ) {
      if (e.tag === 30) {
        var a = e.memoizedProps, l = e.stateNode, n = Ra(a, l), r = Ua(a.default, a.update), p;
        p = e.memoizedState, e.memoizedState = null, l = e;
        var g = e.child;
        kt = 0, n = Eu(
          l,
          g,
          n,
          n,
          r,
          p,
          !1
        ), (e.flags & 4) !== 0 && n && Vn(e, a.onUpdate);
      } else
        (e.subtreeFlags & 33554432) !== 0 && Kf(e);
      e = e.sibling;
    }
  }
  var ft = !1, Qe = !1, Sa = !1, Cu = !1, Jf = typeof WeakSet == "function" ? WeakSet : Set, mt = null, wa = !1, Yi = !1, pd = !1, Au = !1;
  function Rv(e, t, a) {
    if (e = e.containerInfo, eo = _n, e = Ic(e), hs(e)) {
      if ("selectionStart" in e)
        var l = {
          start: e.selectionStart,
          end: e.selectionEnd
        };
      else
        e: {
          l = (l = e.ownerDocument) && l.defaultView || window;
          var n = l.getSelection && l.getSelection();
          if (n && n.rangeCount !== 0) {
            l = n.anchorNode;
            var r = n.anchorOffset, p = n.focusNode;
            n = n.focusOffset;
            try {
              l.nodeType, p.nodeType;
            } catch {
              l = null;
              break e;
            }
            var g = 0, S = -1, M = -1, k = 0, Y = 0, C = e, q = null;
            t: for (; ; ) {
              for (var F; C !== l || r !== 0 && C.nodeType !== 3 || (S = g + r), C !== p || n !== 0 && C.nodeType !== 3 || (M = g + n), C.nodeType === 3 && (g += C.nodeValue.length), (F = C.firstChild) !== null; )
                q = C, C = F;
              for (; ; ) {
                if (C === e) break t;
                if (q === l && ++k === r && (S = g), q === p && ++Y === n && (M = g), (F = C.nextSibling) !== null) break;
                C = q, q = C.parentNode;
              }
              C = F;
            }
            l = S === -1 || M === -1 ? null : { start: S, end: M };
          } else l = null;
        }
      l = l || { start: 0, end: 0 };
    } else l = null;
    for (to = { focusedElem: e, selectionRange: l }, _n = !1, a = (a & 335544064) === a, mt = t, t = a ? 9270 : 1024; mt !== null; ) {
      if (e = mt, a && (l = e.deletions, l !== null))
        for (r = 0; r < l.length; r++)
          a && Nu(l[r]);
      if (e.alternate === null && (e.flags & 2) !== 0)
        a && Xf(e), fd(a);
      else {
        if (e.tag === 22) {
          if (l = e.alternate, e.memoizedState !== null) {
            l !== null && l.memoizedState === null && a && Nu(l), fd(a);
            continue;
          } else if (l !== null && l.memoizedState !== null) {
            a && Xf(e), fd(a);
            continue;
          }
        }
        l = e.child, (e.subtreeFlags & t) !== 0 && l !== null ? (l.return = e, mt = l) : (a && Gf(e), fd(a));
      }
    }
    Jt = null;
  }
  function fd(e) {
    for (; mt !== null; ) {
      var t = mt, a = e, l = t.alternate, n = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if ((n & 1024) !== 0 && l !== null) {
            a = void 0, n = l.memoizedProps, l = l.memoizedState;
            var r = t.stateNode;
            try {
              var p = Wl(
                t.type,
                n
              );
              a = r.getSnapshotBeforeUpdate(
                p,
                l
              ), r.__reactInternalSnapshotBeforeUpdate = a;
            } catch (g) {
              Ve(t, t.return, g);
            }
          }
          break;
        case 3:
          if ((n & 1024) !== 0) {
            if (l = t.stateNode.containerInfo, a = l.nodeType, a === 9)
              uo(l);
            else if (a === 1)
              switch (l.nodeName) {
                case "HEAD":
                case "HTML":
                case "BODY":
                  uo(l);
                  break;
                default:
                  l.textContent = "";
              }
          }
          break;
        case 5:
        case 26:
        case 27:
        case 6:
        case 4:
        case 17:
          break;
        case 30:
          a && l !== null && (a = Ra(
            l.memoizedProps,
            l.stateNode
          ), n = t.memoizedProps, n = Ua(n.default, n.update), n !== "none" && kn(
            l,
            a,
            n,
            l.memoizedState = [],
            !0
          ));
          break;
        default:
          if ((n & 1024) !== 0) throw Error(u(163));
      }
      if (l = t.sibling, l !== null) {
        l.return = t.return, mt = l;
        break;
      }
      mt = t.return;
    }
  }
  function Ff(e, t, a) {
    var l = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        Na(e, a), l & 4 && Hi(5, a);
        break;
      case 1:
        if (Na(e, a), l & 4)
          if (e = a.stateNode, t === null)
            try {
              e.componentDidMount();
            } catch (p) {
              Ve(a, a.return, p);
            }
          else {
            var n = Wl(
              a.type,
              t.memoizedProps
            );
            t = t.memoizedState;
            try {
              e.componentDidUpdate(
                n,
                t,
                e.__reactInternalSnapshotBeforeUpdate
              );
            } catch (p) {
              Ve(
                a,
                a.return,
                p
              );
            }
          }
        l & 64 && Uf(a), l & 512 && ya(a, a.return);
        break;
      case 3:
        if (Na(e, a), l & 64 && (e = a.updateQueue, e !== null)) {
          if (t = null, a.child !== null)
            switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
          try {
            wp(e, t);
          } catch (p) {
            Ve(a, a.return, p);
          }
        }
        break;
      case 27:
        t === null && l & 4 && Qf(a);
      case 26:
      case 5:
        Na(e, a), t === null && l & 4 && xu(a), l & 512 && ya(a, a.return);
        break;
      case 12:
        Na(e, a);
        break;
      case 31:
        Na(e, a), l & 4 && _f(e, a);
        break;
      case 13:
        Na(e, a), l & 4 && $f(e, a), l & 64 && (e = a.memoizedState, e !== null && (e = e.dehydrated, e !== null && (a = Jv.bind(
          null,
          a
        ), Cx(e, a))));
        break;
      case 22:
        if (l = a.memoizedState !== null || ft, !l) {
          var r = t !== null && t.memoizedState !== null || Qe;
          t = ft, n = Qe, ft = l, (Qe = r) && !n ? (l = 2, (a.subtreeFlags & 8772) !== 0 && (l |= 1), pa(
            e,
            a,
            l
          )) : Na(e, a), ft = t, Qe = n;
        }
        break;
      case 30:
        Na(e, a), l & 512 && ya(a, a.return);
        break;
      case 7:
        l & 512 && ya(a, a.return);
      default:
        Na(e, a);
    }
  }
  function Mu(e, t) {
    for (e = e.child; e !== null; )
      Wf(e, t), e = e.sibling;
  }
  function Wf(e, t) {
    switch (e.tag) {
      case 5:
      case 26:
        try {
          var a = e.stateNode;
          if (t) {
            var l = a.style;
            typeof l.setProperty == "function" ? l.setProperty("display", "none", "important") : l.display = "none";
          } else {
            var n = e.stateNode, r = e.memoizedProps.style, p = r != null && r.hasOwnProperty("display") ? r.display : null;
            n.style.display = p == null || typeof p == "boolean" ? "" : ("" + p).trim();
          }
        } catch (S) {
          Ve(e, e.return, S);
        }
        Ou(e, t);
        break;
      case 6:
        try {
          e.stateNode.nodeValue = t ? "" : e.memoizedProps, He = !0;
        } catch (S) {
          Ve(e, e.return, S);
        }
        break;
      case 18:
        try {
          var g = e.stateNode;
          t ? Xm(g, !0) : Xm(e.stateNode, !1);
        } catch (S) {
          Ve(e, e.return, S);
        }
        break;
      case 22:
      case 23:
        e.memoizedState === null && Mu(e, t);
        break;
      default:
        Mu(e, t);
    }
  }
  function Ou(e, t) {
    if (e.subtreeFlags & 67108864)
      for (e = e.child; e !== null; ) {
        e: {
          var a = e, l = t;
          switch (a.tag) {
            case 4:
              Wf(a, l);
              break e;
            case 22:
              a.memoizedState === null && Ou(a, l);
              break e;
            default:
              Ou(a, l);
          }
        }
        e = e.sibling;
      }
  }
  function If(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, If(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && vr(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
  }
  var _e = null, Rt = !1;
  function oa(e, t, a) {
    for (a = a.child; a !== null; )
      Pf(e, t, a), a = a.sibling;
  }
  function Pf(e, t, a) {
    if (Vt && typeof Vt.onCommitFiberUnmount == "function")
      try {
        Vt.onCommitFiberUnmount(si, a);
      } catch {
      }
    switch (a.tag) {
      case 26:
        Qe || yt(a, t), oa(
          e,
          t,
          a
        ), a.memoizedState ? a.memoizedState.count-- : a.stateNode && !Qe && (a = a.stateNode, a.parentNode.removeChild(a));
        break;
      case 27:
        Qe || yt(a, t), Bi(a);
        var l = _e, n = Rt;
        yl(a.type) && (_e = a.stateNode, Rt = !1), oa(
          e,
          t,
          a
        ), th(
          a.stateNode,
          a.type,
          a.memoizedProps
        ), _e = l, Rt = n;
        break;
      case 5:
        Qe || yt(a, t), Bi(a);
      case 6:
        if (a.tag === 6 && Bi(a), l = _e, n = Rt, _e = null, oa(
          e,
          t,
          a
        ), _e = l, Rt = n, _e !== null)
          if (Rt)
            try {
              (_e.nodeType === 9 ? _e.body : _e.nodeName === "HTML" ? _e.ownerDocument.body : _e).removeChild(a.stateNode), He = !0;
            } catch (r) {
              Ve(
                a,
                t,
                r
              );
            }
          else
            try {
              _e.removeChild(a.stateNode), He = !0;
            } catch (r) {
              Ve(
                a,
                t,
                r
              );
            }
        break;
      case 18:
        _e !== null && (Rt ? (e = _e, Qm(
          e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e,
          a.stateNode
        ), $n(e)) : Qm(_e, a.stateNode));
        break;
      case 4:
        l = _e, n = Rt, _e = a.stateNode.containerInfo, Rt = !0, oa(
          e,
          t,
          a
        ), _e = l, Rt = n;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        fl(2, a, t), Qe || fl(4, a, t), oa(
          e,
          t,
          a
        );
        break;
      case 1:
        Qe || (yt(a, t), l = a.stateNode, typeof l.componentWillUnmount == "function" && Hf(
          a,
          t,
          l
        )), oa(
          e,
          t,
          a
        );
        break;
      case 21:
        oa(
          e,
          t,
          a
        );
        break;
      case 22:
        Qe = (l = Qe) || a.memoizedState !== null, oa(
          e,
          t,
          a
        ), Qe = l;
        break;
      case 30:
        yt(a, t), oa(
          e,
          t,
          a
        );
        break;
      case 7:
        Qe || yt(a, t), oa(
          e,
          t,
          a
        );
        break;
      default:
        oa(
          e,
          t,
          a
        );
    }
  }
  function _f(e, t) {
    if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
      e = e.dehydrated;
      try {
        $n(e);
      } catch (a) {
        Ve(t, t.return, a);
      }
    }
  }
  function $f(e, t) {
    if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null))))
      try {
        $n(e);
      } catch (a) {
        Ve(t, t.return, a);
      }
  }
  function Uv(e) {
    switch (e.tag) {
      case 31:
      case 13:
      case 19:
        var t = e.stateNode;
        return t === null && (t = e.stateNode = new Jf()), t;
      case 22:
        return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new Jf()), t;
      default:
        throw Error(u(435, e.tag));
    }
  }
  function md(e, t) {
    var a = Uv(e);
    t.forEach(function(l) {
      if (!a.has(l)) {
        a.add(l);
        var n = Fv.bind(null, e, l);
        l.then(n, n);
      }
    });
  }
  function At(e, t, a) {
    var l = t.deletions;
    if (l !== null)
      for (var n = 0; n < l.length; n++) {
        var r = l[n], p = e, g = t, S = g;
        e: for (; S !== null; ) {
          switch (S.tag) {
            case 27:
              if (yl(S.type)) {
                _e = S.stateNode, Rt = !1;
                break e;
              }
              break;
            case 5:
              _e = S.stateNode, Rt = !1;
              break e;
            case 3:
            case 4:
              _e = S.stateNode.containerInfo, Rt = !0;
              break e;
          }
          S = S.return;
        }
        if (_e === null) throw Error(u(160));
        Pf(p, g, r), _e = null, Rt = !1, p = r.alternate, p !== null && (p.return = null), r.return = null;
      }
    if (t.subtreeFlags & 13886)
      for (t = t.child; t !== null; )
        em(t, e, a), t = t.sibling;
  }
  var ca = null;
  function em(e, t, a) {
    var l = e.alternate, n = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if (n & 4 && (l = e.updateQueue, l = l !== null ? l.events : null, l !== null))
          for (var r = 0; r < l.length; r++) {
            var p = l[r];
            p.ref.impl = p.nextImpl;
          }
        At(t, e, a), Mt(e), n & 4 && (fl(3, e, e.return), Hi(3, e), fl(5, e, e.return));
        break;
      case 1:
        At(t, e, a), Mt(e), n & 512 && (Qe || l === null || yt(l, l.return)), n & 64 && ft && (e = e.updateQueue, e !== null && (t = e.callbacks, t !== null && (a = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = a === null ? t : a.concat(t))));
        break;
      case 26:
        if (r = ca, At(t, e, a), Mt(e), n & 512 && (Qe || l === null || yt(l, l.return)), n & 4)
          if (n = l !== null ? l.memoizedState : null, a = e.memoizedState, l === null)
            if (a === null)
              if (e.stateNode === null)
                if (ft)
                  e.stateNode = Hm(
                    e.type,
                    e.memoizedProps,
                    t.containerInfo,
                    e
                  );
                else {
                  e: {
                    t = e.type, a = e.memoizedProps, n = r.ownerDocument || r;
                    t: switch (t) {
                      case "title":
                        l = n.getElementsByTagName("title")[0], (!l || l[ci] || l[gt] || l.namespaceURI === "http://www.w3.org/2000/svg" || l.hasAttribute("itemprop")) && (l = n.createElement(t), n.head.insertBefore(
                          l,
                          n.querySelector("head > title")
                        )), jt(l, t, a), l[gt] = e, ct(l), t = l;
                        break e;
                      case "link":
                        if (r = dh(
                          "link",
                          "href",
                          n
                        ).get(t + (a.href || ""))) {
                          for (p = 0; p < r.length; p++)
                            if (l = r[p], l.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && l.getAttribute("rel") === (a.rel == null ? null : a.rel) && l.getAttribute("title") === (a.title == null ? null : a.title) && l.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                              r.splice(p, 1);
                              break t;
                            }
                        }
                        l = n.createElement(t), jt(l, t, a), n.head.appendChild(l);
                        break;
                      case "meta":
                        if (r = dh(
                          "meta",
                          "content",
                          n
                        ).get(t + (a.content || ""))) {
                          for (p = 0; p < r.length; p++)
                            if (l = r[p], l.getAttribute("content") === (a.content == null ? null : "" + a.content) && l.getAttribute("name") === (a.name == null ? null : a.name) && l.getAttribute("property") === (a.property == null ? null : a.property) && l.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && l.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                              r.splice(p, 1);
                              break t;
                            }
                        }
                        l = n.createElement(t), jt(l, t, a), n.head.appendChild(l);
                        break;
                      default:
                        throw Error(u(468, t));
                    }
                    l[gt] = e, ct(l), t = l;
                  }
                  e.stateNode = t;
                }
              else
                ft || go(r, e.type, e.stateNode);
            else
              e.stateNode = rh(
                r,
                a,
                e.memoizedProps
              );
          else
            n !== a ? (n === null ? (t = l.stateNode, t === null || Qe || t.parentNode.removeChild(t)) : n.count--, a === null ? ft || go(r, e.type, e.stateNode) : rh(r, a, e.memoizedProps)) : a === null && e.stateNode !== null && yu(
              e,
              e.memoizedProps,
              l.memoizedProps
            );
        break;
      case 27:
        At(t, e, a), Mt(e), n & 512 && (Qe || l === null || yt(l, l.return)), l !== null && n & 4 && yu(
          e,
          e.memoizedProps,
          l.memoizedProps
        );
        break;
      case 5:
        if (r = Sa, Sa = !1, At(t, e, a), Sa = r, Mt(e), n & 512 && (Qe || l === null || yt(l, l.return)), e.flags & 32) {
          t = e.stateNode;
          try {
            gn(t, ""), He = !0;
          } catch (k) {
            Ve(e, e.return, k);
          }
        }
        n & 4 && e.stateNode != null && (t = e.memoizedProps, yu(
          e,
          t,
          l !== null ? l.memoizedProps : t
        )), n & 1024 && (Cu = !0);
        break;
      case 6:
        if (At(t, e, a), Mt(e), n & 4) {
          if (e.stateNode === null)
            throw Error(u(162));
          t = e.memoizedProps, a = e.stateNode;
          try {
            a.nodeValue = t, He = !0;
          } catch (k) {
            Ve(e, e.return, k);
          }
        }
        break;
      case 3:
        if (He = !1, Ad = null, r = ca, ca = Fi(t.containerInfo), At(t, e, a), ca = r, Mt(e), n & 4 && l !== null && l.memoizedState.isDehydrated)
          try {
            $n(t.containerInfo);
          } catch (k) {
            Ve(e, e.return, k);
          }
        Cu && (Cu = !1, tm(e)), He = !1;
        break;
      case 4:
        n = Sa, Sa = ft, l = yc(), r = ca, ca = Fi(
          e.stateNode.containerInfo
        ), At(t, e, a), Mt(e), ca = r, He && Yi && (pd = !0), He = l, Sa = n;
        break;
      case 12:
        At(t, e, a), Mt(e);
        break;
      case 31:
        At(t, e, a), Mt(e), n & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, md(e, t)));
        break;
      case 13:
        At(t, e, a), Mt(e), e.child.flags & 8192 && e.memoizedState !== null != (l !== null && l.memoizedState !== null) && (bd = Xt()), n & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, md(e, t)));
        break;
      case 22:
        r = e.memoizedState !== null, p = l !== null && l.memoizedState !== null;
        var g = ft, S = Qe, M = Sa;
        ft = g || r, Sa = M || r, Qe = S || p, At(t, e, a), Qe = S, Sa = M, ft = g, Mt(e), n & 8192 && (t = e.stateNode, t._visibility = r ? t._visibility & -2 : t._visibility | 1, !r || l === null || p || ft || Qe || (t = p || Qe, a = ft, l = Qe, ft = r || ft, Qe = t, ml(e, 2), ft = a, Qe = l), !r && Sa || Mu(e, r)), n & 4 && (t = e.updateQueue, t !== null && (a = t.retryQueue, a !== null && (t.retryQueue = null, md(e, a))));
        break;
      case 19:
        At(t, e, a), Mt(e), n & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, md(e, t)));
        break;
      case 30:
        n & 512 && (Qe || l === null || yt(l, l.return)), n = yc(), r = Yi, p = (a & 335544064) === a, g = e.memoizedProps, Yi = p && Ua(
          g.default,
          g.update
        ) !== "none", At(t, e, a), Mt(e), p && l !== null && He && (e.flags |= 4), Yi = r, He = n;
        break;
      case 21:
        break;
      case 7:
        n & 512 && (Qe || l === null || yt(l, l.return)), l && l.stateNode !== null && (l.stateNode._fragmentFiber = e);
      default:
        At(t, e, a), Mt(e);
    }
  }
  function Mt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        for (var a, l = e.return; l !== null; ) {
          if (Yf(l)) {
            a = l;
            break;
          }
          l = l.return;
        }
        l = null;
        for (var n = e.return; n !== null; ) {
          if (vu(n)) {
            var r = n.stateNode;
            l === null ? l = [r] : l.push(r);
          }
          if (bu(n)) break;
          n = n.return;
        }
        var p = l;
        if (a == null) throw Error(u(160));
        switch (a.tag) {
          case 27:
            var g = a.stateNode, S = ju(e);
            sd(
              e,
              S,
              g,
              p
            );
            break;
          case 5:
            var M = a.stateNode;
            a.flags & 32 && (gn(M, ""), a.flags &= -33);
            var k = ju(e);
            sd(
              e,
              k,
              M,
              p
            );
            break;
          case 3:
          case 4:
            var Y = a.stateNode.containerInfo, C = ju(e);
            zu(
              e,
              C,
              Y,
              p
            );
            break;
          default:
            throw Error(u(161));
        }
      } catch (q) {
        Ve(e, e.return, q);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function tm(e) {
    if (e.subtreeFlags & 1024)
      for (e = e.child; e !== null; ) {
        var t = e;
        tm(t), t.tag === 5 && t.flags & 1024 && (t = t.stateNode, _n = !0, t.reset(), _n = !1), e = e.sibling;
      }
  }
  function Rn(e, t) {
    if (t.subtreeFlags & 9270)
      for (t = t.child; t !== null; )
        am(t, e), t = t.sibling;
    else Kf(t);
  }
  function am(e, t) {
    var a = e.alternate;
    if (a === null) Su(e, !1);
    else
      switch (e.tag) {
        case 3:
          if (Au = wa = !1, Vf(), Rn(t, e), !wa && !pd) {
            if (e = ja, e !== null)
              for (var l = 0; l < e.length; l += 3) {
                a = e[l];
                var n = e[l + 1];
                Lm(a, e[l + 2]), a = a.ownerDocument.documentElement, a !== null && a.animate(
                  { opacity: [0, 0], pointerEvents: ["none", "none"] },
                  {
                    duration: 0,
                    fill: "forwards",
                    pseudoElement: "::view-transition-group(" + n + ")"
                  }
                );
              }
            e = t.containerInfo, e = e.nodeType === 9 ? e.documentElement : e.ownerDocument.documentElement, e !== null && e.style.viewTransitionName === "" && (e.style.viewTransitionName = "none", e.animate(
              { opacity: [0, 0], pointerEvents: ["none", "none"] },
              {
                duration: 0,
                fill: "forwards",
                pseudoElement: "::view-transition-group(root)"
              }
            ), e.animate(
              { width: [0, 0], height: [0, 0] },
              {
                duration: 0,
                fill: "forwards",
                pseudoElement: "::view-transition"
              }
            )), Au = !0;
          }
          ja = null;
          break;
        case 5:
          Rn(t, e);
          break;
        case 4:
          l = wa, wa = !1, Rn(t, e), wa && (pd = !0), wa = l;
          break;
        case 22:
          e.memoizedState === null && (a.memoizedState !== null ? Su(e, !1) : Rn(t, e));
          break;
        case 30:
          l = wa, n = Vf(), wa = !1, Rn(t, e), wa && (e.flags |= 4);
          var r = e.memoizedProps, p = e.stateNode;
          t = Ra(r, p), p = Ra(a.memoizedProps, p);
          var g = Ua(r.default, r.update);
          g === "none" ? t = !1 : (r = a.memoizedState, a.memoizedState = null, a = e.child, kt = 0, t = Eu(
            e,
            a,
            t,
            p,
            g,
            r,
            !0
          ), kt !== (r === null ? 0 : r.length) && (e.flags |= 32)), (e.flags & 4) !== 0 && t ? (Vn(
            e,
            e.memoizedProps.onUpdate
          ), ja = n) : n !== null && (n.push.apply(n, ja), ja = n), wa = (e.flags & 32) !== 0 ? !0 : l;
          break;
        default:
          Rn(t, e);
      }
  }
  function Na(e, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; )
        Ff(e, t.alternate, t), t = t.sibling;
  }
  function ml(e, t) {
    for (e = e.child; e !== null; ) {
      var a = e, l = t;
      switch (a.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          fl(4, a, a.return), ml(
            a,
            l
          );
          break;
        case 1:
          yt(a, a.return);
          var n = a.stateNode;
          typeof n.componentWillUnmount == "function" && Hf(
            a,
            a.return,
            n
          ), ml(
            a,
            l
          );
          break;
        case 27:
          (l & 2) !== 0 && th(
            a.stateNode,
            a.type,
            a.memoizedProps
          );
        case 5:
          yt(a, a.return), a.tag !== 5 && a.tag !== 27 || Bi(a), ml(
            a,
            l
          );
          break;
        case 6:
          Bi(a);
          break;
        case 26:
          yt(a, a.return), n = a.stateNode, a.memoizedState !== null || n === null || Qe || n.parentNode.removeChild(n), ml(
            a,
            l
          );
          break;
        case 22:
          a.memoizedState === null && ml(
            a,
            l
          );
          break;
        case 30:
          yt(a, a.return), ml(
            a,
            l
          );
          break;
        case 7:
          yt(a, a.return);
        default:
          ml(
            a,
            l
          );
      }
      e = e.sibling;
    }
  }
  function pa(e, t, a) {
    for (a = (t.subtreeFlags & 8772) !== 0 ? a : a & -2, t = t.child; t !== null; ) {
      var l = t.alternate, n = e, r = t, p = r.flags, g = (a & 1) !== 0;
      switch (r.tag) {
        case 0:
        case 11:
        case 15:
          pa(
            n,
            r,
            a
          ), Hi(4, r);
          break;
        case 1:
          if (pa(
            n,
            r,
            a
          ), l = r, n = l.stateNode, typeof n.componentDidMount == "function")
            try {
              n.componentDidMount();
            } catch (k) {
              Ve(l, l.return, k);
            }
          if (l = r, n = l.updateQueue, n !== null) {
            var S = l.stateNode;
            try {
              var M = n.shared.hiddenCallbacks;
              if (M !== null)
                for (n.shared.hiddenCallbacks = null, n = 0; n < M.length; n++)
                  Sp(M[n], S);
            } catch (k) {
              Ve(l, l.return, k);
            }
          }
          g && p & 64 && Uf(r), ya(r, r.return);
          break;
        case 27:
          (a & 2) !== 0 && Qf(r);
        case 5:
          r.tag !== 5 && r.tag !== 27 || Bf(r), pa(
            n,
            r,
            a
          ), g && l === null && p & 4 && xu(r), ya(r, r.return);
          break;
        case 6:
          Bf(r);
          break;
        case 26:
          S = r.stateNode, r.memoizedState !== null || S === null || ft || go(
            Fi(S.ownerDocument),
            r.type,
            S
          ), pa(
            n,
            r,
            a
          ), g && l === null && p & 4 && xu(r), ya(r, r.return);
          break;
        case 12:
          pa(
            n,
            r,
            a
          );
          break;
        case 31:
          pa(
            n,
            r,
            a
          ), g && p & 4 && _f(n, r);
          break;
        case 13:
          pa(
            n,
            r,
            a
          ), g && p & 4 && $f(n, r);
          break;
        case 22:
          r.memoizedState === null && pa(
            n,
            r,
            a
          ), ya(r, r.return);
          break;
        case 30:
          pa(
            n,
            r,
            a
          ), ya(r, r.return);
          break;
        case 7:
          ya(r, r.return);
        default:
          pa(
            n,
            r,
            a
          );
      }
      t = t.sibling;
    }
  }
  function Du(e, t) {
    var a = null;
    e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (a = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== a && (e != null && e.refCount++, a != null && wi(a));
  }
  function qu(e, t) {
    e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && wi(e));
  }
  function ra(e, t, a, l) {
    var n = (a & 335544064) === a;
    if (t.subtreeFlags & (n ? 10262 : 10256))
      for (t = t.child; t !== null; )
        lm(
          e,
          t,
          a,
          l
        ), t = t.sibling;
    else n && Zf(t);
  }
  function lm(e, t, a, l) {
    var n = (a & 335544064) === a;
    n && t.alternate === null && t.return !== null && t.return.alternate !== null && cd(t);
    var r = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        ra(
          e,
          t,
          a,
          l
        ), r & 2048 && Hi(9, t);
        break;
      case 1:
        ra(
          e,
          t,
          a,
          l
        );
        break;
      case 3:
        ra(
          e,
          t,
          a,
          l
        ), n && Au && (e = e.containerInfo, e = e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e, e.style.viewTransitionName === "root" && (e.style.viewTransitionName = ""), e = e.ownerDocument.documentElement, e !== null && e.style.viewTransitionName === "none" && (e.style.viewTransitionName = "")), r & 2048 && (r = null, t.alternate !== null && (r = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== r && (t.refCount++, r != null && wi(r)));
        break;
      case 12:
        if (r & 2048) {
          ra(
            e,
            t,
            a,
            l
          ), r = t.stateNode;
          try {
            var p = t.memoizedProps, g = p.id, S = p.onPostCommit;
            typeof S == "function" && S(
              g,
              t.alternate === null ? "mount" : "update",
              r.passiveEffectDuration,
              -0
            );
          } catch (M) {
            Ve(t, t.return, M);
          }
        } else
          ra(
            e,
            t,
            a,
            l
          );
        break;
      case 31:
        ra(
          e,
          t,
          a,
          l
        );
        break;
      case 13:
        ra(
          e,
          t,
          a,
          l
        );
        break;
      case 23:
        break;
      case 22:
        p = t.stateNode, g = t.alternate, t.memoizedState !== null ? (n && g !== null && g.memoizedState === null && cd(g), p._visibility & 2 ? ra(
          e,
          t,
          a,
          l
        ) : Qi(
          e,
          t
        )) : (n && g !== null && g.memoizedState !== null && cd(t), p._visibility & 2 ? ra(
          e,
          t,
          a,
          l
        ) : (p._visibility |= 2, Un(
          e,
          t,
          a,
          l,
          (t.subtreeFlags & 10256) !== 0 || !1
        ))), r & 2048 && Du(g, t);
        break;
      case 24:
        ra(
          e,
          t,
          a,
          l
        ), r & 2048 && qu(t.alternate, t);
        break;
      case 30:
        n && (r = t.alternate, r !== null && (za(r.child, !0), za(t.child, !0))), ra(
          e,
          t,
          a,
          l
        );
        break;
      default:
        ra(
          e,
          t,
          a,
          l
        );
    }
  }
  function Un(e, t, a, l, n) {
    for (n = n && ((t.subtreeFlags & 10256) !== 0 || !1), t = t.child; t !== null; ) {
      var r = e, p = t, g = a, S = l, M = p.flags;
      switch (p.tag) {
        case 0:
        case 11:
        case 15:
          Un(
            r,
            p,
            g,
            S,
            n
          ), Hi(8, p);
          break;
        case 23:
          break;
        case 22:
          var k = p.stateNode;
          p.memoizedState !== null ? k._visibility & 2 ? Un(
            r,
            p,
            g,
            S,
            n
          ) : Qi(
            r,
            p
          ) : (k._visibility |= 2, Un(
            r,
            p,
            g,
            S,
            n
          )), n && M & 2048 && Du(
            p.alternate,
            p
          );
          break;
        case 24:
          Un(
            r,
            p,
            g,
            S,
            n
          ), n && M & 2048 && qu(p.alternate, p);
          break;
        default:
          Un(
            r,
            p,
            g,
            S,
            n
          );
      }
      t = t.sibling;
    }
  }
  function Qi(e, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var a = e, l = t, n = l.flags;
        switch (l.tag) {
          case 22:
            Qi(a, l), n & 2048 && Du(
              l.alternate,
              l
            );
            break;
          case 24:
            Qi(a, l), n & 2048 && qu(l.alternate, l);
            break;
          default:
            Qi(a, l);
        }
        t = t.sibling;
      }
  }
  var Il = 8192;
  function Pl(e, t, a) {
    if (e.subtreeFlags & Il)
      for (e = e.child; e !== null; )
        nm(
          e,
          t,
          a
        ), e = e.sibling;
  }
  function nm(e, t, a) {
    switch (e.tag) {
      case 26:
        Pl(
          e,
          t,
          a
        ), e.flags & Il && (e.memoizedState !== null ? Vx(
          a,
          ca,
          e.memoizedState,
          e.memoizedProps
        ) : (e = e.stateNode, (t & 335544128) === t && ch(a, e)));
        break;
      case 5:
        Pl(
          e,
          t,
          a
        ), e.flags & Il && (e = e.stateNode, (t & 335544128) === t && ch(a, e));
        break;
      case 3:
      case 4:
        var l = ca;
        ca = Fi(e.stateNode.containerInfo), Pl(
          e,
          t,
          a
        ), ca = l;
        break;
      case 22:
        e.memoizedState === null && (l = e.alternate, l !== null && l.memoizedState !== null ? (l = Il, Il = 16777216, Pl(
          e,
          t,
          a
        ), Il = l) : Pl(
          e,
          t,
          a
        ));
        break;
      case 30:
        if ((e.flags & Il) !== 0 && (l = e.memoizedProps.name, l != null && l !== "auto")) {
          var n = e.stateNode;
          n.paired = null, Jt === null && (Jt = /* @__PURE__ */ new Map()), Jt.set(l, n);
        }
        Pl(
          e,
          t,
          a
        );
        break;
      default:
        Pl(
          e,
          t,
          a
        );
    }
  }
  function im(e) {
    var t = e.alternate;
    if (t !== null && (e = t.child, e !== null)) {
      t.child = null;
      do
        t = e.sibling, e.sibling = null, e = t;
      while (e !== null);
    }
  }
  function Xi(e) {
    var t = e.deletions;
    if ((e.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var l = t[a];
          mt = l, dm(
            l,
            e
          );
        }
      im(e);
    }
    if (e.subtreeFlags & 10256)
      for (e = e.child; e !== null; )
        rm(e), e = e.sibling;
  }
  function rm(e) {
    switch (e.tag) {
      case 0:
      case 11:
      case 15:
        Xi(e), e.flags & 2048 && fl(9, e, e.return);
        break;
      case 3:
        Xi(e);
        break;
      case 12:
        Xi(e);
        break;
      case 22:
        var t = e.stateNode;
        e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, hd(e)) : Xi(e);
        break;
      default:
        Xi(e);
    }
  }
  function hd(e) {
    var t = e.deletions;
    if ((e.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var l = t[a];
          mt = l, dm(
            l,
            e
          );
        }
      im(e);
    }
    for (e = e.child; e !== null; ) {
      switch (t = e, t.tag) {
        case 0:
        case 11:
        case 15:
          fl(8, t, t.return), hd(t);
          break;
        case 22:
          a = t.stateNode, a._visibility & 2 && (a._visibility &= -3, hd(t));
          break;
        default:
          hd(t);
      }
      e = e.sibling;
    }
  }
  function dm(e, t) {
    for (; mt !== null; ) {
      var a = mt;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          fl(8, a, t);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var l = a.memoizedState.cachePool.pool;
            l != null && l.refCount++;
          }
          break;
        case 24:
          wi(a.memoizedState.cache);
      }
      if (l = a.child, l !== null) l.return = a, mt = l;
      else
        e: for (a = e; mt !== null; ) {
          l = mt;
          var n = l.sibling, r = l.return;
          if (If(l), l === a) {
            mt = null;
            break e;
          }
          if (n !== null) {
            n.return = r, mt = n;
            break e;
          }
          mt = r;
        }
    }
  }
  var Hv = {
    getCacheForType: function(e) {
      var t = bt(rt), a = t.data.get(e);
      return a === void 0 && (a = e(), t.data.set(e, a)), a;
    },
    cacheSignal: function() {
      return bt(rt).controller.signal;
    }
  }, Bv = typeof WeakMap == "function" ? WeakMap : Map, Be = 0, Ze = null, Ne = null, Me = 0, Xe = 0, Ft = null, hl = !1, Hn = !1, ku = !1, Za = 0, at = 0, gl = 0, _l = 0, gd = 0, Wt = 0, Bn = 0, Vi = null, Ut = null, Ru = !1, bd = 0, sm = 0, vd = 1 / 0, xd = null, bl = null, et = 0, fa = null, $l = null, Ta = 0, Uu = 0, Hu = null, um = null, Yn = null, Qn = null, Xn = null, Li = 0, yd = null;
  function It() {
    return (Be & 2) !== 0 && Me !== 0 ? Me & -Me : le.T !== null ? Ju() : cc();
  }
  function om() {
    if (Wt === 0)
      if ((Me & 536870912) === 0 || Se) {
        var e = mr;
        mr <<= 1, (mr & 3932160) === 0 && (mr = 262144), Wt = e;
      } else Wt = 536870912;
    return e = vt.current, e !== null && (e.flags |= 32), Wt;
  }
  function Vn(e, t) {
    if (t != null) {
      var a = e.stateNode, l = a.ref;
      l === null && (l = a.ref = Gm(
        Ra(e.memoizedProps, a)
      )), Qn === null && (Qn = []), Qn.push(t.bind(null, l));
    }
  }
  function Ht(e, t, a) {
    (e === Ze && (Xe === 2 || Xe === 9) || e.cancelPendingCommit !== null) && (Ln(e, 0), vl(
      e,
      Me,
      Wt,
      !1
    )), oi(e, a), ((Be & 2) === 0 || e !== Ze) && (e === Ze && ((Be & 2) === 0 && (_l |= a), at === 4 && vl(
      e,
      Me,
      Wt,
      !1
    )), Ea(e));
  }
  function cm(e, t, a) {
    if ((Be & 6) !== 0) throw Error(u(327));
    var l = !a && (t & 127) === 0 && (t & e.expiredLanes) === 0 || ui(e, t), n = l ? Xv(e, t) : Yu(e, t, !0), r = l;
    do {
      if (n === 0) {
        Hn && !l && vl(e, t, 0, !1);
        break;
      } else {
        if (a = e.current.alternate, r && !Yv(a)) {
          n = Yu(e, t, !1), r = !1;
          continue;
        }
        if (n === 2) {
          if (r = t, e.errorRecoveryDisabledLanes & r)
            var p = 0;
          else
            p = e.pendingLanes & -536870913, p = p !== 0 ? p : p & 536870912 ? 536870912 : 0;
          if (p !== 0) {
            t = p;
            e: {
              var g = e;
              n = Vi;
              var S = g.current.memoizedState.isDehydrated;
              if (S && (Ln(g, p).flags |= 256), p = Yu(
                g,
                p,
                !1
              ), p !== 2 && p !== 6) {
                if (ku && !S) {
                  g.errorRecoveryDisabledLanes |= r, _l |= r, n = 4;
                  break e;
                }
                r = Ut, Ut = n, r !== null && (Ut === null ? Ut = r : Ut.push.apply(
                  Ut,
                  r
                ));
              }
              n = p;
            }
            if (r = !1, n !== 2) continue;
          }
        }
        if (n === 1) {
          Ln(e, 0), vl(e, t, 0, !0);
          break;
        }
        e: {
          switch (l = e, r = n, r) {
            case 0:
            case 1:
              throw Error(u(345));
            case 4:
              if ((t & 4194048) !== t && (t & 62914560) !== t)
                break;
            case 6:
              vl(
                l,
                t,
                Wt,
                !hl
              );
              break e;
            case 2:
              Ut = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(u(329));
          }
          if ((t & 62914560) === t && (n = bd + 300 - Xt(), 10 < n)) {
            if (vl(
              l,
              t,
              Wt,
              !hl
            ), gr(l, 0, !0) !== 0) break e;
            Ta = t, l.timeoutHandle = no(
              pm.bind(
                null,
                l,
                a,
                Ut,
                xd,
                Ru,
                t,
                Wt,
                _l,
                Bn,
                hl,
                r,
                "Throttled",
                -0,
                0
              ),
              n
            );
            break e;
          }
          pm(
            l,
            a,
            Ut,
            xd,
            Ru,
            t,
            Wt,
            _l,
            Bn,
            hl,
            r,
            null,
            -0,
            0
          );
        }
      }
      break;
    } while (!0);
    Ea(e);
  }
  function pm(e, t, a, l, n, r, p, g, S, M, k, Y, C, q) {
    e.timeoutHandle = -1;
    var F = t.subtreeFlags, ne = (r & 335544064) === r;
    if (Y = null, (ne || F & 8192 || (F & 16785408) === 16785408) && (Y = {
      stylesheets: null,
      count: 0,
      imgCount: 0,
      imgBytes: 0,
      suspenseyImages: [],
      waitingForImages: !0,
      waitingForViewTransition: !1,
      unsuspend: ba
    }, Jt = null, nm(
      t,
      r,
      Y
    ), ne && (F = Y, ne = e.containerInfo, ne = (ne.nodeType === 9 ? ne : ne.ownerDocument).__reactViewTransition, ne != null && (F.count++, F.waitingForViewTransition = !0, F = Pi.bind(F), ne.finished.then(F, F))), F = (r & 62914560) === r ? bd - Xt() : (r & 4194048) === r ? sm - Xt() : 0, F = Lx(
      Y,
      F
    ), F !== null)) {
      Ta = r, e.cancelPendingCommit = F(
        ym.bind(
          null,
          e,
          t,
          r,
          a,
          l,
          n,
          p,
          g,
          S,
          M,
          k,
          Y,
          null,
          C,
          q
        )
      ), vl(e, r, p, !M);
      return;
    }
    ym(
      e,
      t,
      r,
      a,
      l,
      n,
      p,
      g,
      S,
      M,
      k,
      Y
    );
  }
  function Yv(e) {
    for (var t = e; ; ) {
      var a = t.tag;
      if ((a === 0 || a === 11 || a === 15) && t.flags & 16384 && (a = t.updateQueue, a !== null && (a = a.stores, a !== null)))
        for (var l = 0; l < a.length; l++) {
          var n = a[l], r = n.getSnapshot;
          n = n.value;
          try {
            if (!Zt(r(), n)) return !1;
          } catch {
            return !1;
          }
        }
      if (a = t.child, t.subtreeFlags & 16384 && a !== null)
        a.return = t, t = a;
      else {
        if (t === e) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
    }
    return !0;
  }
  function vl(e, t, a, l) {
    t = rc(e, t), t &= ~gd, t &= ~_l, e.suspendedLanes |= t, e.pingedLanes &= ~t, l && (e.warmLanes |= t), l = e.expirationTimes;
    for (var n = t; 0 < n; ) {
      var r = 31 - Lt(n), p = 1 << r;
      l[r] = -1, n &= ~p;
    }
    a !== 0 && sc(e, a, t);
  }
  function jd() {
    return (Be & 6) === 0 ? (Gi(0), !1) : !0;
  }
  function Bu() {
    if (Ne !== null) {
      if (Xe === 0)
        var e = Ne.return;
      else
        e = Ne, Ya = Ql = null, Ks(e), An = null, Ei = 0, e = Ne;
      for (; e !== null; )
        Rf(e.alternate, e), e = e.return;
      Ne = null;
    }
  }
  function Ln(e, t) {
    var a = e.timeoutHandle;
    return a !== -1 && (e.timeoutHandle = -1, ux(a)), a = e.cancelPendingCommit, a !== null && (e.cancelPendingCommit = null, a()), Ta = 0, Bu(), Ze = e, Ne = a = Ha(e.current, null), Me = t, Xe = 0, Ft = null, hl = !1, Hn = ui(e, t), ku = !1, Bn = Wt = gd = _l = gl = at = 0, Ut = Vi = null, Ru = !1, Za = rc(e, t), Ar(), a;
  }
  function fm(e, t) {
    ye = null, le.H = ed, t === Cn || t === Qr ? (t = xp(), Xe = 3) : t === qs ? (t = xp(), Xe = 4) : Xe = t === du ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, Ft = t, Ne === null && (at = 1, td(
      e,
      aa(t, e.current)
    ));
  }
  function mm() {
    var e = vt.current;
    return e === null ? !0 : (Me & 4194048) === Me ? Tt === null : (Me & 62914560) === Me || (Me & 536870912) !== 0 ? e === Tt : !1;
  }
  function hm() {
    var e = le.H;
    return le.H = ed, e === null ? ed : e;
  }
  function gm() {
    var e = le.A;
    return le.A = Hv, e;
  }
  function zd() {
    at = 4, hl || (Me & 4194048) !== Me && vt.current !== null || (Hn = !0), (gl & 134217727) === 0 && (_l & 134217727) === 0 || Ze === null || vl(
      Ze,
      Me,
      Wt,
      !1
    );
  }
  function Yu(e, t, a) {
    var l = Be;
    Be |= 2;
    var n = hm(), r = gm();
    (Ze !== e || Me !== t) && (xd = null, Ln(e, t)), t = !1;
    var p = at;
    e: do
      try {
        if (Xe !== 0 && Ne !== null) {
          var g = Ne, S = Ft;
          switch (Xe) {
            case 8:
              Bu(), p = 6;
              break e;
            case 3:
            case 2:
            case 9:
            case 6:
              vt.current === null && (t = !0);
              var M = Xe;
              if (Xe = 0, Ft = null, Gn(e, g, S, M), a && Hn) {
                p = 0;
                break e;
              }
              break;
            default:
              M = Xe, Xe = 0, Ft = null, Gn(e, g, S, M);
          }
        }
        Qv(), p = at;
        break;
      } catch (k) {
        fm(e, k);
      }
    while (!0);
    return t && e.shellSuspendCounter++, Ya = Ql = null, Be = l, le.H = n, le.A = r, Ne === null && (Ze = null, Me = 0, Ar()), p;
  }
  function Qv() {
    for (; Ne !== null; ) bm(Ne);
  }
  function Xv(e, t) {
    var a = Be;
    Be |= 2;
    var l = hm(), n = gm();
    Ze !== e || Me !== t ? (xd = null, vd = Xt() + 500, Ln(e, t)) : Hn = ui(
      e,
      t
    );
    e: do
      try {
        if (Xe !== 0 && Ne !== null) {
          t = Ne;
          var r = Ft;
          t: switch (Xe) {
            case 1:
              Xe = 0, Ft = null, Gn(e, t, r, 1);
              break;
            case 2:
            case 9:
              if (bp(r)) {
                Xe = 0, Ft = null, vm(t);
                break;
              }
              t = function() {
                Xe !== 2 && Xe !== 9 || Ze !== e || (Xe = 7), Ea(e);
              }, r.then(t, t);
              break e;
            case 3:
              Xe = 7;
              break e;
            case 4:
              Xe = 5;
              break e;
            case 7:
              bp(r) ? (Xe = 0, Ft = null, vm(t)) : (Xe = 0, Ft = null, Gn(e, t, r, 7));
              break;
            case 5:
              var p = null;
              switch (Ne.tag) {
                case 26:
                  p = Ne.memoizedState;
                case 5:
                case 27:
                  var g = Ne;
                  if (p ? uh(p) : g.stateNode.complete) {
                    Xe = 0, Ft = null;
                    var S = g.sibling;
                    if (S !== null) Ne = S;
                    else {
                      var M = g.return;
                      M !== null ? (Ne = M, Sd(M)) : Ne = null;
                    }
                    break t;
                  }
              }
              Xe = 0, Ft = null, Gn(e, t, r, 5);
              break;
            case 6:
              Xe = 0, Ft = null, Gn(e, t, r, 6);
              break;
            case 8:
              Bu(), at = 6;
              break e;
            default:
              throw Error(u(462));
          }
        }
        Vv();
        break;
      } catch (k) {
        fm(e, k);
      }
    while (!0);
    return Ya = Ql = null, le.H = l, le.A = n, Be = a, Ne !== null ? 0 : (Ze = null, Me = 0, Ar(), at);
  }
  function Vv() {
    for (; Ne !== null && !ib(); )
      bm(Ne);
  }
  function bm(e) {
    var t = qf(e.alternate, e, Za);
    e.memoizedProps = e.pendingProps, t === null ? Sd(e) : Ne = t;
  }
  function vm(e) {
    var t = e, a = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = Tf(
          a,
          t,
          t.pendingProps,
          t.type,
          void 0,
          Me
        );
        break;
      case 11:
        t = Tf(
          a,
          t,
          t.pendingProps,
          t.type.render,
          t.ref,
          Me
        );
        break;
      case 5:
        Ks(t);
        var l = t;
        l === pt && (Se ? (Rr(l), l.tag === 5 && l.stateNode != null && (Je = l.stateNode)) : (Rr(l), Se = !0));
      default:
        Rf(a, t), t = Ne = rp(t, Za), t = qf(a, t, Za);
    }
    e.memoizedProps = e.pendingProps, t === null ? Sd(e) : Ne = t;
  }
  function Gn(e, t, a, l) {
    Ya = Ql = null, Ks(t), An = null, Ei = 0;
    var n = t.return;
    try {
      if (Av(
        e,
        n,
        t,
        a,
        Me
      )) {
        at = 1, td(
          e,
          aa(a, e.current)
        ), Ne = null;
        return;
      }
    } catch (r) {
      if (n !== null) throw Ne = n, r;
      at = 1, td(
        e,
        aa(a, e.current)
      ), Ne = null;
      return;
    }
    t.flags & 32768 ? (Se || l === 1 ? e = !0 : Hn || (Me & 536870912) !== 0 ? e = !1 : (hl = e = !0, (l === 2 || l === 9 || l === 3 || l === 6) && (l = vt.current, l !== null && l.tag === 13 && (l.flags |= 16384))), xm(t, e)) : Sd(t);
  }
  function Sd(e) {
    var t = e;
    do {
      if ((t.flags & 32768) !== 0) {
        xm(
          t,
          hl
        );
        return;
      }
      e = t.return;
      var a = qv(
        t.alternate,
        t,
        Za
      );
      if (a !== null) {
        Ne = a;
        return;
      }
      if (t = t.sibling, t !== null) {
        Ne = t;
        return;
      }
      Ne = t = e;
    } while (t !== null);
    at === 0 && (at = 5);
  }
  function xm(e, t) {
    do {
      var a = kv(e.alternate, e);
      if (a !== null) {
        a.flags &= 32767, Ne = a;
        return;
      }
      if (a = e.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !t && (e = e.sibling, e !== null)) {
        Ne = e;
        return;
      }
      Ne = e = a;
    } while (e !== null);
    at = 6, Ne = null;
  }
  function ym(e, t, a, l, n, r, p, g, S, M, k, Y) {
    e.cancelPendingCommit = null;
    do
      wd();
    while (et !== 0);
    if ((Be & 6) !== 0) throw Error(u(327));
    if (t !== null) {
      if (t === e.current) throw Error(u(177));
      e === Ze && (Ne = Ze = null, Me = 0), $l = t, fa = e, Ta = a, Hu = n, um = l, Lv(
        e,
        t,
        a,
        p,
        g,
        S,
        Y
      );
    }
  }
  function Lv(e, t, a, l, n, r, p) {
    var g = t.lanes | t.childLanes;
    if (Uu = g, g |= ys, hb(
      e,
      a,
      g,
      l,
      n,
      r
    ), Qn = null, (a & 335544064) === a ? (Xn = bv(e), l = 10262) : (Xn = null, l = 10256), (t.subtreeFlags & l) !== 0 || (t.flags & l) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, Wv(pr, function() {
      return Lu(), null;
    })) : (e.callbackNode = null, e.callbackPriority = 0), ud = !1, l = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || l) {
      l = le.T, le.T = null, n = oe.p, oe.p = 2, r = Be, Be |= 4;
      try {
        Rv(e, t, a);
      } finally {
        Be = r, oe.p = n, le.T = l;
      }
    }
    et = 1, ud ? Yn = hx(
      p,
      e.containerInfo,
      Xn,
      Qu,
      Xu,
      Zv,
      Vu,
      Lu,
      Gv
    ) : (Qu(), Xu(), Vu());
  }
  function Gv(e) {
    if (et !== 0) {
      var t = fa.onRecoverableError;
      t(e, { componentStack: null });
    }
  }
  function Zv() {
    et === 3 && (et = 0, am($l, fa), et = 4);
  }
  function Qu() {
    if (et === 1) {
      et = 0;
      var e = fa, t = $l, a = Ta, l = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || l) {
        l = le.T, le.T = null;
        var n = oe.p;
        oe.p = 2;
        var r = Be;
        Be |= 4;
        try {
          Yi = pd = !1, em(t, e, a), a = to;
          var p = Ic(e.containerInfo), g = a.focusedElem, S = a.selectionRange;
          if (p !== g && g && g.ownerDocument && Wc(
            g.ownerDocument.documentElement,
            g
          )) {
            if (S !== null && hs(g)) {
              var M = S.start, k = S.end;
              if (k === void 0 && (k = M), "selectionStart" in g)
                g.selectionStart = M, g.selectionEnd = Math.min(
                  k,
                  g.value.length
                );
              else {
                var Y = g.ownerDocument || document, C = Y && Y.defaultView || window;
                if (C.getSelection) {
                  var q = C.getSelection(), F = g.textContent.length, ne = Math.min(S.start, F), je = S.end === void 0 ? ne : Math.min(S.end, F);
                  !q.extend && ne > je && (p = je, je = ne, ne = p);
                  var A = Fc(
                    g,
                    ne
                  ), T = Fc(
                    g,
                    je
                  );
                  if (A && T && (q.rangeCount !== 1 || q.anchorNode !== A.node || q.anchorOffset !== A.offset || q.focusNode !== T.node || q.focusOffset !== T.offset)) {
                    var D = Y.createRange();
                    D.setStart(A.node, A.offset), q.removeAllRanges(), ne > je ? (q.addRange(D), q.extend(T.node, T.offset)) : (D.setEnd(T.node, T.offset), q.addRange(D));
                  }
                }
              }
            }
            for (Y = [], q = g; q = q.parentNode; )
              q.nodeType === 1 && Y.push({
                element: q,
                left: q.scrollLeft,
                top: q.scrollTop
              });
            for (typeof g.focus == "function" && g.focus(), g = 0; g < Y.length; g++) {
              var B = Y[g];
              B.element.scrollLeft = B.left, B.element.scrollTop = B.top;
            }
          }
          _n = !!eo, to = eo = null;
        } finally {
          Be = r, oe.p = n, le.T = l;
        }
      }
      e.current = t, et = 2;
    }
  }
  function Xu() {
    if (et === 2) {
      et = 0;
      var e = fa, t = $l, a = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || a) {
        a = le.T, le.T = null;
        var l = oe.p;
        oe.p = 2;
        var n = Be;
        Be |= 4;
        try {
          Ff(e, t.alternate, t);
        } finally {
          Be = n, oe.p = l, le.T = a;
        }
      }
      et = 3;
    }
  }
  function Vu() {
    if (et === 4 || et === 3) {
      et = 0;
      var e = Yn;
      Yn = null, rb();
      var t = fa, a = $l, l = Ta, n = um, r = (l & 335544064) === l ? 10262 : 10256;
      if ((a.subtreeFlags & r) !== 0 || (a.flags & r) !== 0 ? et = 5 : (et = 0, $l = fa = null, jm(t, t.pendingLanes)), r = t.pendingLanes, r === 0 && (bl = null), Pd(l), a = a.stateNode, Vt && typeof Vt.onCommitFiberRoot == "function")
        try {
          Vt.onCommitFiberRoot(
            si,
            a,
            void 0,
            (a.current.flags & 128) === 128
          );
        } catch {
        }
      if (n !== null) {
        a = le.T, r = oe.p, oe.p = 2, le.T = null;
        try {
          for (var p = t.onRecoverableError, g = 0; g < n.length; g++) {
            var S = n[g];
            p(S.value, {
              componentStack: S.stack
            });
          }
        } finally {
          le.T = a, oe.p = r;
        }
      }
      if (n = Qn, p = Xn, Xn = null, n !== null && (Qn = null, p === null && (p = []), e !== null))
        for (S = 0; S < n.length; S++)
          a = (0, n[S])(
            p
          ), a !== void 0 && e.finished.finally(a);
      (Ta & 3) !== 0 && wd(), Ea(t), r = t.pendingLanes, (l & 261930) !== 0 && (r & 42) !== 0 ? t === yd ? Li++ : (Li = 0, yd = t) : (Li = 0, yd = null), Gi(0);
    }
  }
  function jm(e, t) {
    (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, wi(t)));
  }
  function wd() {
    return Yn !== null && (Yn.skipTransition(), Yn = null), Qu(), Xu(), Vu(), Lu();
  }
  function Lu() {
    if (et !== 5) return !1;
    var e = fa, t = Uu;
    Uu = 0;
    var a = Pd(Ta), l = le.T, n = oe.p;
    try {
      oe.p = 32 > a ? 32 : a, le.T = null, a = Hu, Hu = null;
      var r = fa, p = Ta;
      if (et = 0, $l = fa = null, Ta = 0, (Be & 6) !== 0) throw Error(u(331));
      var g = Be;
      if (Be |= 4, rm(r.current), lm(
        r,
        r.current,
        p,
        a
      ), Be = g, Gi(0, !1), Vt && typeof Vt.onPostCommitFiberRoot == "function")
        try {
          Vt.onPostCommitFiberRoot(si, r);
        } catch {
        }
      return !0;
    } finally {
      oe.p = n, le.T = l, jm(e, t);
    }
  }
  function zm(e, t, a) {
    t = aa(a, t), t = ru(e.stateNode, t, 2), e = ul(e, t, 2), e !== null && (oi(e, 2), Ea(e));
  }
  function Ve(e, t, a) {
    if (e.tag === 3)
      zm(e, e, a);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          zm(
            t,
            e,
            a
          );
          break;
        } else if (t.tag === 1) {
          var l = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof l.componentDidCatch == "function" && (bl === null || !bl.has(l))) {
            e = aa(a, e), a = vf(2), l = ul(t, a, 2), l !== null && (xf(
              a,
              l,
              t,
              e
            ), oi(l, 2), Ea(l));
            break;
          }
        }
        t = t.return;
      }
  }
  function Gu(e, t, a) {
    var l = e.pingCache;
    if (l === null) {
      l = e.pingCache = new Bv();
      var n = /* @__PURE__ */ new Set();
      l.set(t, n);
    } else
      n = l.get(t), n === void 0 && (n = /* @__PURE__ */ new Set(), l.set(t, n));
    n.has(a) || (ku = !0, n.add(a), e = Kv.bind(null, e, t, a), t.then(e, e));
  }
  function Kv(e, t, a) {
    var l = e.pingCache;
    l !== null && l.delete(t), e.pingedLanes |= e.suspendedLanes & a, e.warmLanes &= ~a, Ze === e && (Me & a) === a && ((at === 4 || at === 3 && (Me & 62914560) === Me && 300 > Xt() - bd) && (Be & 2) === 0 ? Ln(e, 0) : gd |= a, Bn === Me && (Bn = 0)), Ea(e);
  }
  function Sm(e, t) {
    t === 0 && (t = dc()), e = Hl(e, t), e !== null && (oi(e, t), Ea(e));
  }
  function Jv(e) {
    var t = e.memoizedState, a = 0;
    t !== null && (a = t.retryLane), Sm(e, a);
  }
  function Fv(e, t) {
    var a = 0;
    switch (e.tag) {
      case 31:
      case 13:
        var l = e.stateNode, n = e.memoizedState;
        n !== null && (a = n.retryLane);
        break;
      case 19:
        l = e.stateNode;
        break;
      case 22:
        l = e.stateNode._retryCache;
        break;
      default:
        throw Error(u(314));
    }
    l !== null && l.delete(t), Sm(e, a);
  }
  function Wv(e, t) {
    return Jd(e, t);
  }
  var Zn = null, Kn = null, Zu = !1, Nd = !1, Ku = !1, xl = 0;
  function Ea(e) {
    e !== Kn && e.next === null && (Kn === null ? Zn = Kn = e : Kn = Kn.next = e), Nd = !0, Zu || (Zu = !0, Pv());
  }
  function Gi(e, t) {
    if (!Ku && Nd) {
      Ku = !0;
      do
        for (var a = !1, l = Zn; l !== null; ) {
          if (e !== 0) {
            var n = l.pendingLanes;
            if (n === 0) var r = 0;
            else {
              var p = l.suspendedLanes, g = l.pingedLanes;
              r = (1 << 31 - Lt(42 | e) + 1) - 1, r &= n & ~(p & ~g), r = r & 201326741 ? r & 201326741 | 1 : r ? r | 2 : 0;
            }
            r !== 0 && (a = !0, Em(l, r));
          } else
            r = Me, r = gr(
              l,
              l === Ze ? r : 0,
              l.cancelPendingCommit !== null || l.timeoutHandle !== -1
            ), (r & 3) === 0 || ui(l, r) || (a = !0, Em(l, r));
          l = l.next;
        }
      while (a);
      Ku = !1;
    }
  }
  function Iv() {
    wm();
  }
  function wm() {
    Nd = Zu = !1;
    var e = 0;
    xl !== 0 && sx() && (e = xl);
    for (var t = Xt(), a = null, l = Zn; l !== null; ) {
      var n = l.next, r = Nm(l, t);
      r === 0 ? (l.next = null, a === null ? Zn = n : a.next = n, n === null && (Kn = a)) : (a = l, (e !== 0 || (r & 3) !== 0) && (Nd = !0)), l = n;
    }
    et !== 0 && et !== 5 || Gi(e), xl !== 0 && (xl = 0);
  }
  function Nm(e, t) {
    for (var a = e.suspendedLanes, l = e.pingedLanes, n = e.expirationTimes, r = e.pendingLanes & -62914561; 0 < r; ) {
      var p = 31 - Lt(r), g = 1 << p, S = n[p];
      S === -1 ? ((g & a) === 0 || (g & l) !== 0) && (n[p] = mb(g, t)) : S <= t && (e.expiredLanes |= g), r &= ~g;
    }
    if (t = Ze, a = Me, a = gr(
      e,
      e === t ? a : 0,
      e.cancelPendingCommit !== null || e.timeoutHandle !== -1
    ), l = e.callbackNode, a === 0 || e === t && (Xe === 2 || Xe === 9) || e.cancelPendingCommit !== null)
      return l !== null && l !== null && Fd(l), e.callbackNode = null, e.callbackPriority = 0;
    if ((a & 3) === 0 || ui(e, a)) {
      if (t = a & -a, t === e.callbackPriority) return t;
      switch (l !== null && Fd(l), Pd(a)) {
        case 2:
        case 8:
          a = nc;
          break;
        case 32:
          a = pr;
          break;
        case 268435456:
          a = ic;
          break;
        default:
          a = pr;
      }
      return l = Tm.bind(null, e), a = Jd(a, l), e.callbackPriority = t, e.callbackNode = a, t;
    }
    return l !== null && l !== null && Fd(l), e.callbackPriority = 2, e.callbackNode = null, 2;
  }
  function Tm(e, t) {
    if (et !== 0 && et !== 5)
      return e.callbackNode = null, e.callbackPriority = 0, null;
    var a = e.callbackNode;
    if (wd() && e.callbackNode !== a)
      return null;
    var l = Me;
    return l = gr(
      e,
      e === Ze ? l : 0,
      e.cancelPendingCommit !== null || e.timeoutHandle !== -1
    ), l === 0 ? null : (cm(e, l, t), Nm(e, Xt()), e.callbackNode != null && e.callbackNode === a ? Tm.bind(null, e) : null);
  }
  function Em(e, t) {
    if (wd()) return null;
    cm(e, t, !0);
  }
  function Pv() {
    ox(function() {
      (Be & 6) !== 0 ? Jd(
        lc,
        Iv
      ) : wm();
    });
  }
  function Ju() {
    if (xl === 0) {
      var e = Ll;
      e === 0 && (e = fr, fr <<= 1, (fr & 261888) === 0 && (fr = 256)), xl = e;
    }
    return xl;
  }
  function Cm(e) {
    return e == null || typeof e == "symbol" || typeof e == "boolean" ? null : typeof e == "function" ? e : jr(e);
  }
  function _v(e, t, a, l, n) {
    if (t === "submit" && a && a.stateNode === n) {
      var r = Cm(
        (n[Dt] || null).action
      ), p = l.submitter;
      p && (t = (t = p[Dt] || null) ? Cm(t.formAction) : p.getAttribute("formAction"), t !== null && (r = t, p = null));
      var g = new Nr(
        "action",
        "action",
        null,
        l,
        n
      );
      e.push({
        event: g,
        listeners: [
          {
            instance: null,
            listener: function() {
              if (l.defaultPrevented) {
                if (xl !== 0) {
                  var S = new FormData(n, p);
                  tu(
                    a,
                    {
                      pending: !0,
                      data: S,
                      method: n.method,
                      action: r
                    },
                    null,
                    S
                  );
                }
              } else
                typeof r == "function" && (g.preventDefault(), S = new FormData(n, p), tu(
                  a,
                  {
                    pending: !0,
                    data: S,
                    method: n.method,
                    action: r
                  },
                  r,
                  S
                ));
            },
            currentTarget: n
          }
        ]
      });
    }
  }
  for (var Fu = 0; Fu < xs.length; Fu++) {
    var Wu = xs[Fu], $v = Wu.toLowerCase(), ex = Wu[0].toUpperCase() + Wu.slice(1);
    ua(
      $v,
      "on" + ex
    );
  }
  ua($c, "onAnimationEnd"), ua(ep, "onAnimationIteration"), ua(tp, "onAnimationStart"), ua("dblclick", "onDoubleClick"), ua("focusin", "onFocus"), ua("focusout", "onBlur"), ua(uv, "onTransitionRun"), ua(ov, "onTransitionStart"), ua(cv, "onTransitionCancel"), ua(ap, "onTransitionEnd"), mn("onMouseEnter", ["mouseout", "mouseover"]), mn("onMouseLeave", ["mouseout", "mouseover"]), mn("onPointerEnter", ["pointerout", "pointerover"]), mn("onPointerLeave", ["pointerout", "pointerover"]), kl(
    "onChange",
    "change click focusin focusout input keydown keyup selectionchange".split(" ")
  ), kl(
    "onSelect",
    "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
      " "
    )
  ), kl("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), kl(
    "onCompositionEnd",
    "compositionend focusout keydown keypress keyup mousedown".split(" ")
  ), kl(
    "onCompositionStart",
    "compositionstart focusout keydown keypress keyup mousedown".split(" ")
  ), kl(
    "onCompositionUpdate",
    "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
  );
  var Zi = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
    " "
  ), tx = new Set(
    "beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Zi)
  );
  function Am(e, t) {
    t = (t & 4) !== 0;
    for (var a = 0; a < e.length; a++) {
      var l = e[a], n = l.event;
      l = l.listeners;
      e: {
        var r = void 0;
        if (t)
          for (var p = l.length - 1; 0 <= p; p--) {
            var g = l[p], S = g.instance, M = g.currentTarget;
            if (g = g.listener, S !== r && n.isPropagationStopped())
              break e;
            r = g, n.currentTarget = M;
            try {
              r(n);
            } catch (k) {
              Cr(k);
            }
            n.currentTarget = null, r = S;
          }
        else
          for (p = 0; p < l.length; p++) {
            if (g = l[p], S = g.instance, M = g.currentTarget, g = g.listener, S !== r && n.isPropagationStopped())
              break e;
            r = g, n.currentTarget = M;
            try {
              r(n);
            } catch (k) {
              Cr(k);
            }
            n.currentTarget = null, r = S;
          }
      }
    }
  }
  function Te(e, t) {
    var a = t[fc];
    a === void 0 && (a = t[fc] = /* @__PURE__ */ new Set());
    var l = e + "__bubble";
    a.has(l) || (Mm(t, e, 2, !1), a.add(l));
  }
  function Iu(e, t, a) {
    var l = 0;
    t && (l |= 4), Mm(
      a,
      e,
      l,
      t
    );
  }
  var Td = "_reactListening" + Math.random().toString(36).slice(2);
  function Pu(e) {
    if (!e[Td]) {
      e[Td] = !0, gc.forEach(function(a) {
        a !== "selectionchange" && (tx.has(a) || Iu(a, !1, e), Iu(a, !0, e));
      });
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[Td] || (t[Td] = !0, Iu("selectionchange", !1, t));
    }
  }
  function Mm(e, t, a, l) {
    switch (xh(t)) {
      case 2:
        var n = Jx;
        break;
      case 8:
        n = Fx;
        break;
      default:
        n = vo;
    }
    a = n.bind(
      null,
      t,
      a,
      e
    ), n = void 0, !is || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (n = !0), l ? n !== void 0 ? e.addEventListener(t, a, {
      capture: !0,
      passive: n
    }) : e.addEventListener(t, a, !0) : n !== void 0 ? e.addEventListener(t, a, {
      passive: n
    }) : e.addEventListener(t, a, !1);
  }
  function _u(e, t, a, l, n) {
    var r = l;
    if ((t & 1) === 0 && (t & 2) === 0 && l !== null)
      e: for (; ; ) {
        if (l === null) return;
        var p = l.tag;
        if (p === 3 || p === 4) {
          var g = l.stateNode.containerInfo;
          if (g === n) break;
          if (p === 4)
            for (p = l.return; p !== null; ) {
              var S = p.tag;
              if ((S === 3 || S === 4) && p.stateNode.containerInfo === n)
                return;
              p = p.return;
            }
          for (; g !== null; ) {
            if (p = ql(g), p === null) return;
            if (S = p.tag, S === 5 || S === 6 || S === 26 || S === 27) {
              l = r = p;
              continue e;
            }
            g = g.parentNode;
          }
        }
        l = l.return;
      }
    Ac(function() {
      var M = r, k = ls(a), Y = [];
      e: {
        var C = lp.get(e);
        if (C !== void 0) {
          var q = Nr, F = e;
          switch (e) {
            case "keypress":
              if (Sr(a) === 0) break e;
            case "keydown":
            case "keyup":
              q = Yb;
              break;
            case "focusin":
              F = "focus", q = us;
              break;
            case "focusout":
              F = "blur", q = us;
              break;
            case "beforeblur":
            case "afterblur":
              q = us;
              break;
            case "click":
              if (a.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              q = Dc;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              q = Eb;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              q = Gb;
              break;
            case $c:
            case ep:
            case tp:
              q = Mb;
              break;
            case ap:
              q = Kb;
              break;
            case "scroll":
            case "scrollend":
              q = Nb;
              break;
            case "wheel":
              q = Fb;
              break;
            case "copy":
            case "cut":
            case "paste":
              q = Db;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              q = kc;
              break;
            case "submit":
              q = Vb;
              break;
            case "toggle":
            case "beforetoggle":
              q = Ib;
          }
          var ne = (t & 4) !== 0, je = !ne && (e === "scroll" || e === "scrollend"), A = ne ? C !== null ? C + "Capture" : null : C;
          ne = [];
          for (var T = M, D; T !== null; ) {
            var B = T;
            if (D = B.stateNode, B = B.tag, B !== 5 && B !== 26 && B !== 27 || D === null || A === null || (B = fi(T, A), B != null && ne.push(
              Ki(T, B, D)
            )), je) break;
            T = T.return;
          }
          0 < ne.length && (C = new q(
            C,
            F,
            null,
            a,
            k
          ), Y.push({ event: C, listeners: ne }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (q = e === "mouseover" || e === "pointerover", C = e === "mouseout" || e === "pointerout", q && a !== as && (F = a.relatedTarget || a.fromElement) && (ql(F) || F[cn]))
            break e;
          (C || q) && (F = k.window === k ? k : (q = k.ownerDocument) ? q.defaultView || q.parentWindow : window, C ? (q = a.relatedTarget || a.toElement, C = M, q = q ? ql(q) : null, q !== null && (je = f(q), ne = q.tag, q !== je || ne !== 5 && ne !== 27 && ne !== 6) && (q = null)) : (C = null, q = M), C !== q && (ne = Dc, B = "onMouseLeave", A = "onMouseEnter", T = "mouse", (e === "pointerout" || e === "pointerover") && (ne = kc, B = "onPointerLeave", A = "onPointerEnter", T = "pointer"), je = C == null ? F : pi(C), D = q == null ? F : pi(q), F = new ne(
            B,
            T + "leave",
            C,
            a,
            k
          ), F.target = je, F.relatedTarget = D, B = null, ql(k) === M && (ne = new ne(
            A,
            T + "enter",
            q,
            a,
            k
          ), ne.target = D, ne.relatedTarget = je, B = ne), je = B, ne = C && q ? se(
            C,
            q,
            ax
          ) : null, C !== null && Om(
            Y,
            F,
            C,
            ne,
            !1
          ), q !== null && je !== null && Om(
            Y,
            je,
            q,
            ne,
            !0
          )));
        }
        e: {
          if (C = M ? pi(M) : window, q = C.nodeName && C.nodeName.toLowerCase(), q === "select" || q === "input" && C.type === "file")
            var ee = Vc;
          else if (Qc(C))
            if (Lc)
              ee = rv;
            else {
              ee = nv;
              var Oe = lv;
            }
          else
            q = C.nodeName, !q || q.toLowerCase() !== "input" || C.type !== "checkbox" && C.type !== "radio" ? M && ts(M.elementType) && (ee = Vc) : ee = iv;
          if (ee && (ee = ee(e, M))) {
            Xc(
              Y,
              ee,
              a,
              k
            );
            break e;
          }
          Oe && Oe(e, C, M);
        }
        switch (Oe = M ? pi(M) : window, e) {
          case "focusin":
            (Qc(Oe) || Oe.contentEditable === "true") && (yn = Oe, gs = M, ji = null);
            break;
          case "focusout":
            ji = gs = yn = null;
            break;
          case "mousedown":
            bs = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            bs = !1, Pc(Y, a, k);
            break;
          case "selectionchange":
            if (sv) break;
          case "keydown":
          case "keyup":
            Pc(Y, a, k);
        }
        var de;
        if (cs)
          e: {
            switch (e) {
              case "compositionstart":
                var fe = "onCompositionStart";
                break e;
              case "compositionend":
                fe = "onCompositionEnd";
                break e;
              case "compositionupdate":
                fe = "onCompositionUpdate";
                break e;
            }
            fe = void 0;
          }
        else
          xn ? Bc(e, a) && (fe = "onCompositionEnd") : e === "keydown" && a.keyCode === 229 && (fe = "onCompositionStart");
        fe && (Rc && a.locale !== "ko" && (xn || fe !== "onCompositionStart" ? fe === "onCompositionEnd" && xn && (de = Mc()) : (el = k, rs = "value" in el ? el.value : el.textContent, xn = !0)), Oe = Ed(M, fe), 0 < Oe.length && (fe = new qc(
          fe,
          e,
          null,
          a,
          k
        ), Y.push({ event: fe, listeners: Oe }), de ? fe.data = de : (de = Yc(a), de !== null && (fe.data = de)))), (de = _b ? $b(e, a) : ev(e, a)) && (fe = Ed(M, "onBeforeInput"), 0 < fe.length && (Oe = new qc(
          "onBeforeInput",
          "beforeinput",
          null,
          a,
          k
        ), Y.push({
          event: Oe,
          listeners: fe
        }), Oe.data = de)), _v(
          Y,
          e,
          M,
          a,
          k
        );
      }
      Am(Y, t);
    });
  }
  function Ki(e, t, a) {
    return {
      instance: e,
      listener: t,
      currentTarget: a
    };
  }
  function Ed(e, t) {
    for (var a = t + "Capture", l = []; e !== null; ) {
      var n = e, r = n.stateNode;
      if (n = n.tag, n !== 5 && n !== 26 && n !== 27 || r === null || (n = fi(e, a), n != null && l.unshift(
        Ki(e, n, r)
      ), n = fi(e, t), n != null && l.push(
        Ki(e, n, r)
      )), e.tag === 3) return l;
      e = e.return;
    }
    return [];
  }
  function ax(e) {
    if (e === null) return null;
    do
      e = e.return;
    while (e && e.tag !== 5 && e.tag !== 27);
    return e || null;
  }
  function Om(e, t, a, l, n) {
    for (var r = t._reactName, p = []; a !== null && a !== l; ) {
      var g = a, S = g.alternate, M = g.stateNode;
      if (g = g.tag, S !== null && S === l) break;
      g !== 5 && g !== 26 && g !== 27 || M === null || (S = M, n ? (M = fi(a, r), M != null && p.unshift(
        Ki(a, M, S)
      )) : n || (M = fi(a, r), M != null && p.push(
        Ki(a, M, S)
      ))), a = a.return;
    }
    p.length !== 0 && e.push({ event: t, listeners: p });
  }
  var lx = /\r\n?/g, nx = /\u0000|\uFFFD/g;
  function Dm(e) {
    return (typeof e == "string" ? e : "" + e).replace(lx, `
`).replace(nx, "");
  }
  function qm(e, t) {
    return t = Dm(t), Dm(e) === t;
  }
  function Le(e, t, a, l, n, r) {
    switch (a) {
      case "children":
        if (typeof l == "string")
          t === "body" || t === "textarea" && l === "" || gn(e, l);
        else if (typeof l == "number" || typeof l == "bigint")
          t !== "body" && gn(e, "" + l);
        else return;
        break;
      case "className":
        yr(e, "class", l);
        break;
      case "tabIndex":
        yr(e, "tabindex", l);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        yr(e, a, l);
        break;
      case "style":
        Ec(e, l, r);
        return;
      case "data":
        if (t !== "object") {
          yr(e, "data", l);
          break;
        }
      case "src":
      case "href":
        if (l === "" && (t !== "a" || a !== "href")) {
          e.removeAttribute(a);
          break;
        }
        if (l == null || typeof l == "function" || typeof l == "symbol" || typeof l == "boolean") {
          e.removeAttribute(a);
          break;
        }
        l = jr(l), e.setAttribute(a, l);
        break;
      case "action":
      case "formAction":
        if (typeof l == "function") {
          e.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')"
          );
          break;
        } else
          typeof r == "function" && (a === "formAction" ? (t !== "input" && Le(e, t, "name", n.name, n, null), Le(
            e,
            t,
            "formEncType",
            n.formEncType,
            n,
            null
          ), Le(
            e,
            t,
            "formMethod",
            n.formMethod,
            n,
            null
          ), Le(
            e,
            t,
            "formTarget",
            n.formTarget,
            n,
            null
          )) : (Le(e, t, "encType", n.encType, n, null), Le(e, t, "method", n.method, n, null), Le(e, t, "target", n.target, n, null)));
        if (l == null || typeof l == "symbol" || typeof l == "boolean") {
          e.removeAttribute(a);
          break;
        }
        l = jr(l), e.setAttribute(a, l);
        break;
      case "onClick":
        l != null && (e.onclick = ba);
        return;
      case "onScroll":
        l != null && Te("scroll", e);
        return;
      case "onScrollEnd":
        l != null && Te("scrollend", e);
        return;
      case "dangerouslySetInnerHTML":
        if (l != null) {
          if (typeof l != "object" || !("__html" in l))
            throw Error(u(61));
          if (a = l.__html, a != null) {
            if (n.children != null) throw Error(u(60));
            (r != null ? r.__html : void 0) !== a && (e.innerHTML = a);
          }
        }
        break;
      case "multiple":
        e.multiple = l && typeof l != "function" && typeof l != "symbol";
        break;
      case "muted":
        e.muted = l && typeof l != "function" && typeof l != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (l == null || typeof l == "function" || typeof l == "boolean" || typeof l == "symbol") {
          e.removeAttribute("xlink:href");
          break;
        }
        a = jr(l), e.setAttributeNS(
          "http://www.w3.org/1999/xlink",
          "xlink:href",
          a
        );
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        l != null && typeof l != "function" && typeof l != "symbol" ? e.setAttribute(a, l) : e.removeAttribute(a);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "credentialless":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        l && typeof l != "function" && typeof l != "symbol" ? e.setAttribute(a, "") : e.removeAttribute(a);
        break;
      case "capture":
      case "download":
        l === !0 ? e.setAttribute(a, "") : l !== !1 && l != null && typeof l != "function" && typeof l != "symbol" ? e.setAttribute(a, l) : e.removeAttribute(a);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        l != null && typeof l != "function" && typeof l != "symbol" && !isNaN(l) && 1 <= l ? e.setAttribute(a, l) : e.removeAttribute(a);
        break;
      case "rowSpan":
      case "start":
        l == null || typeof l == "function" || typeof l == "symbol" || isNaN(l) ? e.removeAttribute(a) : e.setAttribute(a, l);
        break;
      case "popover":
        Te("beforetoggle", e), Te("toggle", e), xr(e, "popover", l);
        break;
      case "xlinkActuate":
        qa(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:actuate",
          l
        );
        break;
      case "xlinkArcrole":
        qa(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:arcrole",
          l
        );
        break;
      case "xlinkRole":
        qa(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:role",
          l
        );
        break;
      case "xlinkShow":
        qa(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:show",
          l
        );
        break;
      case "xlinkTitle":
        qa(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:title",
          l
        );
        break;
      case "xlinkType":
        qa(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:type",
          l
        );
        break;
      case "xmlBase":
        qa(
          e,
          "http://www.w3.org/XML/1998/namespace",
          "xml:base",
          l
        );
        break;
      case "xmlLang":
        qa(
          e,
          "http://www.w3.org/XML/1998/namespace",
          "xml:lang",
          l
        );
        break;
      case "xmlSpace":
        qa(
          e,
          "http://www.w3.org/XML/1998/namespace",
          "xml:space",
          l
        );
        break;
      case "is":
        xr(e, "is", l);
        break;
      case "innerText":
      case "textContent":
        return;
      default:
        if (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N")
          a = Sb.get(a) || a, xr(e, a, l);
        else return;
    }
    He = !0;
  }
  function $u(e, t, a, l, n, r) {
    switch (a) {
      case "style":
        Ec(e, l, r);
        return;
      case "dangerouslySetInnerHTML":
        if (l != null) {
          if (typeof l != "object" || !("__html" in l))
            throw Error(u(61));
          if (a = l.__html, a != null) {
            if (n.children != null) throw Error(u(60));
            (r != null ? r.__html : void 0) !== a && (e.innerHTML = a);
          }
        }
        break;
      case "children":
        if (typeof l == "string") gn(e, l);
        else if (typeof l == "number" || typeof l == "bigint")
          gn(e, "" + l);
        else return;
        break;
      case "onScroll":
        l != null && Te("scroll", e);
        return;
      case "onScrollEnd":
        l != null && Te("scrollend", e);
        return;
      case "onClick":
        l != null && (e.onclick = ba);
        return;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        return;
      case "innerText":
      case "textContent":
        return;
      default:
        if (!bc.hasOwnProperty(a))
          e: {
            if (a[0] === "o" && a[1] === "n" && (n = a.endsWith("Capture"), r = a.slice(2, n ? a.length - 7 : void 0), t = e[Dt] || null, t = t != null ? t[a] : null, typeof t == "function" && e.removeEventListener(r, t, n), typeof l == "function")) {
              typeof t != "function" && t !== null && (a in e ? e[a] = null : e.hasAttribute(a) && e.removeAttribute(a)), e.addEventListener(r, l, n);
              break e;
            }
            He = !0, a in e ? e[a] = l : l === !0 ? e.setAttribute(a, "") : xr(e, a, l);
          }
        return;
    }
    He = !0;
  }
  function jt(e, t, a) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        Te("error", e), Te("load", e);
        var l = !1, n = !1, r;
        for (r in a)
          if (a.hasOwnProperty(r)) {
            var p = a[r];
            if (p != null)
              switch (r) {
                case "src":
                  l = !0;
                  break;
                case "srcSet":
                  n = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(u(137, t));
                default:
                  Le(e, t, r, p, a, null);
              }
          }
        n && Le(e, t, "srcSet", a.srcSet, a, null), l && Le(e, t, "src", a.src, a, null);
        return;
      case "input":
        Te("invalid", e);
        var g = r = p = n = null, S = null, M = null;
        for (l in a)
          if (a.hasOwnProperty(l)) {
            var k = a[l];
            if (k != null)
              switch (l) {
                case "name":
                  n = k;
                  break;
                case "type":
                  p = k;
                  break;
                case "checked":
                  S = k;
                  break;
                case "defaultChecked":
                  M = k;
                  break;
                case "value":
                  r = k;
                  break;
                case "defaultValue":
                  g = k;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (k != null)
                    throw Error(u(137, t));
                  break;
                default:
                  Le(e, t, l, k, a, null);
              }
          }
        Sc(
          e,
          r,
          g,
          S,
          M,
          p,
          n,
          !1
        );
        return;
      case "select":
        Te("invalid", e), l = p = r = null;
        for (n in a)
          if (a.hasOwnProperty(n) && (g = a[n], g != null))
            switch (n) {
              case "value":
                r = g;
                break;
              case "defaultValue":
                p = g;
                break;
              case "multiple":
                l = g;
              default:
                Le(e, t, n, g, a, null);
            }
        t = r, a = p, e.multiple = !!l, t != null ? hn(e, !!l, t, !1) : a != null && hn(e, !!l, a, !0);
        return;
      case "textarea":
        Te("invalid", e), r = n = l = null;
        for (p in a)
          if (a.hasOwnProperty(p) && (g = a[p], g != null))
            switch (p) {
              case "value":
                l = g;
                break;
              case "defaultValue":
                n = g;
                break;
              case "children":
                r = g;
                break;
              case "dangerouslySetInnerHTML":
                if (g != null) throw Error(u(91));
                break;
              default:
                Le(e, t, p, g, a, null);
            }
        Nc(e, l, n, r);
        return;
      case "option":
        for (S in a)
          if (a.hasOwnProperty(S) && (l = a[S], l != null))
            switch (S) {
              case "selected":
                e.selected = l && typeof l != "function" && typeof l != "symbol";
                break;
              default:
                Le(e, t, S, l, a, null);
            }
        return;
      case "dialog":
        Te("beforetoggle", e), Te("toggle", e), Te("cancel", e), Te("close", e);
        break;
      case "iframe":
      case "object":
        Te("load", e);
        break;
      case "video":
      case "audio":
        for (l = 0; l < Zi.length; l++)
          Te(Zi[l], e);
        break;
      case "image":
        Te("error", e), Te("load", e);
        break;
      case "details":
        Te("toggle", e);
        break;
      case "embed":
      case "source":
      case "link":
        Te("error", e), Te("load", e);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (M in a)
          if (a.hasOwnProperty(M) && (l = a[M], l != null))
            switch (M) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(u(137, t));
              default:
                Le(e, t, M, l, a, null);
            }
        return;
      default:
        if (ts(t)) {
          for (k in a)
            a.hasOwnProperty(k) && (l = a[k], l !== void 0 && $u(
              e,
              t,
              k,
              l,
              a,
              void 0
            ));
          return;
        }
    }
    for (g in a)
      a.hasOwnProperty(g) && (l = a[g], l != null && Le(e, t, g, l, a, null));
  }
  var ix = {};
  function rx(e, t, a, l) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var n = null, r = null, p = null, g = null, S = null, M = null, k = null;
        for (q in a) {
          var Y = a[q];
          if (a.hasOwnProperty(q) && Y != null)
            switch (q) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                S = Y;
              default:
                l.hasOwnProperty(q) || Le(e, t, q, null, l, Y);
            }
        }
        for (var C in l) {
          var q = l[C];
          if (Y = a[C], l.hasOwnProperty(C) && (q != null || Y != null))
            switch (C) {
              case "type":
                q !== Y && (He = !0), r = q;
                break;
              case "name":
                q !== Y && (He = !0), n = q;
                break;
              case "checked":
                q !== Y && (He = !0), M = q;
                break;
              case "defaultChecked":
                q !== Y && (He = !0), k = q;
                break;
              case "value":
                q !== Y && (He = !0), p = q;
                break;
              case "defaultValue":
                q !== Y && (He = !0), g = q;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (q != null)
                  throw Error(u(137, t));
                break;
              default:
                q !== Y && Le(
                  e,
                  t,
                  C,
                  q,
                  l,
                  Y
                );
            }
        }
        $d(
          e,
          p,
          g,
          S,
          M,
          k,
          r,
          n
        );
        return;
      case "select":
        q = p = g = C = null;
        for (r in a)
          if (S = a[r], a.hasOwnProperty(r) && S != null)
            switch (r) {
              case "value":
                break;
              case "multiple":
                q = S;
              default:
                l.hasOwnProperty(r) || Le(
                  e,
                  t,
                  r,
                  null,
                  l,
                  S
                );
            }
        for (n in l)
          if (r = l[n], S = a[n], l.hasOwnProperty(n) && (r != null || S != null))
            switch (n) {
              case "value":
                r !== S && (He = !0), C = r;
                break;
              case "defaultValue":
                r !== S && (He = !0), g = r;
                break;
              case "multiple":
                r !== S && (He = !0), p = r;
              default:
                r !== S && Le(
                  e,
                  t,
                  n,
                  r,
                  l,
                  S
                );
            }
        t = g, a = p, l = q, C != null ? hn(e, !!a, C, !1) : !!l != !!a && (t != null ? hn(e, !!a, t, !0) : hn(e, !!a, a ? [] : "", !1));
        return;
      case "textarea":
        q = C = null;
        for (g in a)
          if (n = a[g], a.hasOwnProperty(g) && n != null && !l.hasOwnProperty(g))
            switch (g) {
              case "value":
                break;
              case "children":
                break;
              default:
                Le(e, t, g, null, l, n);
            }
        for (p in l)
          if (n = l[p], r = a[p], l.hasOwnProperty(p) && (n != null || r != null))
            switch (p) {
              case "value":
                n !== r && (He = !0), C = n;
                break;
              case "defaultValue":
                n !== r && (He = !0), q = n;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (n != null) throw Error(u(91));
                break;
              default:
                n !== r && Le(e, t, p, n, l, r);
            }
        wc(e, C, q);
        return;
      case "option":
        for (var F in a)
          if (C = a[F], a.hasOwnProperty(F) && C != null && !l.hasOwnProperty(F))
            switch (F) {
              case "selected":
                e.selected = !1;
                break;
              default:
                Le(
                  e,
                  t,
                  F,
                  null,
                  l,
                  C
                );
            }
        for (S in l)
          if (C = l[S], q = a[S], l.hasOwnProperty(S) && C !== q && (C != null || q != null))
            switch (S) {
              case "selected":
                C !== q && (He = !0), e.selected = C && typeof C != "function" && typeof C != "symbol";
                break;
              default:
                Le(
                  e,
                  t,
                  S,
                  C,
                  l,
                  q
                );
            }
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var ne in a)
          C = a[ne], a.hasOwnProperty(ne) && C != null && !l.hasOwnProperty(ne) && Le(e, t, ne, null, l, C);
        for (M in l)
          if (C = l[M], q = a[M], l.hasOwnProperty(M) && C !== q && (C != null || q != null))
            switch (M) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (C != null)
                  throw Error(u(137, t));
                break;
              default:
                Le(
                  e,
                  t,
                  M,
                  C,
                  l,
                  q
                );
            }
        return;
      default:
        if (ts(t)) {
          for (var je in a)
            C = a[je], a.hasOwnProperty(je) && C !== void 0 && !l.hasOwnProperty(je) && $u(
              e,
              t,
              je,
              void 0,
              l,
              C
            );
          for (k in l)
            C = l[k], q = a[k], !l.hasOwnProperty(k) || C === q || C === void 0 && q === void 0 || $u(
              e,
              t,
              k,
              C,
              l,
              q
            );
          return;
        }
    }
    for (var A in a)
      C = a[A], a.hasOwnProperty(A) && C != null && !l.hasOwnProperty(A) && Le(e, t, A, null, l, C);
    for (Y in l)
      C = l[Y], q = a[Y], !l.hasOwnProperty(Y) || C === q || C == null && q == null || Le(e, t, Y, C, l, q);
  }
  function km(e) {
    switch (e) {
      case "css":
      case "script":
      case "font":
      case "img":
      case "image":
      case "input":
      case "link":
        return !0;
      default:
        return !1;
    }
  }
  function dx() {
    if (typeof performance.getEntriesByType == "function") {
      for (var e = 0, t = 0, a = performance.getEntriesByType("resource"), l = 0; l < a.length; l++) {
        var n = a[l], r = n.transferSize, p = n.initiatorType, g = n.duration;
        if (r && g && km(p)) {
          for (p = 0, g = n.responseEnd, l += 1; l < a.length; l++) {
            var S = a[l], M = S.startTime;
            if (M > g) break;
            var k = S.transferSize, Y = S.initiatorType;
            k && km(Y) && (S = S.responseEnd, p += k * (S < g ? 1 : (g - M) / (S - M)));
          }
          if (--l, t += 8 * (r + p) / (n.duration / 1e3), e++, 10 < e) break;
        }
      }
      if (0 < e) return t / e / 1e6;
    }
    return navigator.connection && (e = navigator.connection.downlink, typeof e == "number") ? e : 5;
  }
  var eo = null, to = null;
  function Ji(e) {
    return e.nodeType === 9 ? e : e.ownerDocument;
  }
  function Rm(e) {
    switch (e) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function Um(e, t) {
    if (e === 0)
      switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return e === 1 && t === "foreignObject" ? 0 : e;
  }
  function Hm(e, t, a, l) {
    return a = Ji(
      a
    ).createElement(e), a[gt] = l, a[Dt] = t, jt(a, e, t), ct(a), a;
  }
  function ao(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  var lo = null;
  function sx() {
    var e = window.event;
    return e && e.type === "popstate" ? e === lo ? !1 : (lo = e, !0) : (lo = null, !1);
  }
  var no = typeof setTimeout == "function" ? setTimeout : void 0, ux = typeof clearTimeout == "function" ? clearTimeout : void 0, Bm = typeof Promise == "function" ? Promise : void 0, Ym = typeof requestAnimationFrame == "function" ? requestAnimationFrame : no, ox = typeof queueMicrotask == "function" ? queueMicrotask : typeof Bm < "u" ? function(e) {
    return Bm.resolve(null).then(e).catch(cx);
  } : no;
  function cx(e) {
    setTimeout(function() {
      throw e;
    });
  }
  function yl(e) {
    return e === "head";
  }
  function Qm(e, t) {
    var a = t, l = 0;
    do {
      var n = a.nextSibling;
      if (e.removeChild(a), n && n.nodeType === 8)
        if (a = n.data, a === "/$" || a === "/&") {
          if (l === 0) {
            e.removeChild(n), $n(t);
            return;
          }
          l--;
        } else if (a === "$" || a === "$?" || a === "$~" || a === "$!" || a === "&")
          l++;
        else if (a === "html")
          fo(
            e.ownerDocument.documentElement
          );
        else if (a === "head") {
          a = e.ownerDocument.head, fo(a);
          for (var r = a.firstChild; r; ) {
            var p = r.nextSibling, g = r.nodeName;
            r[ci] || g === "SCRIPT" || g === "STYLE" || g === "LINK" && r.rel.toLowerCase() === "stylesheet" || a.removeChild(r), r = p;
          }
        } else
          a === "body" && fo(e.ownerDocument.body);
      a = n;
    } while (a);
    $n(t);
  }
  function Xm(e, t) {
    var a = e;
    e = 0;
    do {
      var l = a.nextSibling;
      if (a.nodeType === 1 ? t ? (a._stashedDisplay = a.style.display, a.style.display = "none") : (a.style.display = a._stashedDisplay || "", a.getAttribute("style") === "" && a.removeAttribute("style")) : a.nodeType === 3 && (t ? (a._stashedText = a.nodeValue, a.nodeValue = "") : a.nodeValue = a._stashedText || ""), l && l.nodeType === 8)
        if (a = l.data, a === "/$") {
          if (e === 0) break;
          e--;
        } else
          a !== "$" && a !== "$?" && a !== "$~" && a !== "$!" || e++;
      a = l;
    } while (a);
  }
  function Vm(e, t, a) {
    if (t = CSS.escape(t) !== t ? "r-" + btoa(t).replace(/=/g, "") : t, e.style.viewTransitionName = t, a != null && (e.style.viewTransitionClass = a), a = getComputedStyle(e), a.display === "inline") {
      if (t = e.getClientRects(), t.length === 1) var l = 1;
      else
        for (var n = l = 0; n < t.length; n++) {
          var r = t[n];
          0 < r.width && 0 < r.height && l++;
        }
      l === 1 && (e = e.style, e.display = t.length === 1 ? "inline-block" : "block", e.marginTop = "-" + a.paddingTop, e.marginBottom = "-" + a.paddingBottom);
    }
  }
  function Lm(e, t) {
    e = e.style, t = t.style;
    var a = t != null ? t.hasOwnProperty("viewTransitionName") ? t.viewTransitionName : t.hasOwnProperty("view-transition-name") ? t["view-transition-name"] : null : null;
    e.viewTransitionName = a == null || typeof a == "boolean" ? "" : ("" + a).trim(), a = t != null ? t.hasOwnProperty("viewTransitionClass") ? t.viewTransitionClass : t.hasOwnProperty("view-transition-class") ? t["view-transition-class"] : null : null, e.viewTransitionClass = a == null || typeof a == "boolean" ? "" : ("" + a).trim(), e.display === "inline-block" && (t == null ? e.display = e.margin = "" : (a = t.display, e.display = a == null || typeof a == "boolean" ? "" : a, a = t.margin, a != null ? e.margin = a : (a = t.hasOwnProperty("marginTop") ? t.marginTop : t["margin-top"], e.marginTop = a == null || typeof a == "boolean" ? "" : a, t = t.hasOwnProperty("marginBottom") ? t.marginBottom : t["margin-bottom"], e.marginBottom = t == null || typeof t == "boolean" ? "" : t)));
  }
  function px(e, t, a) {
    return a = a.ownerDocument.defaultView, {
      rect: e,
      abs: t.position === "absolute" || t.position === "fixed",
      clip: t.clipPath !== "none" || t.overflow !== "visible" || t.filter !== "none" || t.mask !== "none" || t.mask !== "none" || t.borderRadius !== "0px",
      view: 0 <= e.bottom && 0 <= e.right && e.top <= a.innerHeight && e.left <= a.innerWidth
    };
  }
  function io(e) {
    var t = e.getBoundingClientRect(), a = getComputedStyle(e);
    return px(t, a, e);
  }
  function fx(e) {
    return e.documentElement.clientHeight;
  }
  function mx(e) {
    this.addEventListener("load", e), this.addEventListener("error", e);
  }
  function hx(e, t, a, l, n, r, p, g, S) {
    var M = t.nodeType === 9 ? t : t.ownerDocument;
    try {
      var k = M.startViewTransition({
        update: function() {
          var C = M.defaultView, q = C.navigation && C.navigation.transition, F = M.fonts.status;
          l();
          var ne = [];
          if (F === "loaded" && (fx(M), M.fonts.status === "loading" && ne.push(M.fonts.ready)), F = ne.length, e !== null)
            for (var je = e.suspenseyImages, A = 0, T = 0; T < je.length; T++) {
              var D = je[T];
              if (!D.complete) {
                var B = D.getBoundingClientRect();
                if (0 < B.bottom && 0 < B.right && B.top < C.innerHeight && B.left < C.innerWidth) {
                  if (A += oh(D), A > Md) {
                    ne.length = F;
                    break;
                  }
                  D = new Promise(
                    mx.bind(D)
                  ), ne.push(D);
                }
              }
            }
          if (0 < ne.length)
            return C = Promise.race([
              Promise.all(ne),
              new Promise(function(ee) {
                return setTimeout(ee, 500);
              })
            ]).then(n, n), (q ? Promise.allSettled([q.finished, C]) : C).then(r, r);
          if (n(), q)
            return q.finished.then(
              r,
              r
            );
          r();
        },
        types: a
      });
      M.__reactViewTransition = k;
      var Y = [];
      return k.ready.then(
        function() {
          for (var C = M.documentElement.getAnimations({
            subtree: !0
          }), q = 0; q < C.length; q++) {
            var F = C[q], ne = F.effect, je = ne.pseudoElement;
            if (je != null && je.startsWith("::view-transition")) {
              Y.push(F), F = ne.getKeyframes();
              for (var A = je = void 0, T = !0, D = 0; D < F.length; D++) {
                var B = F[D], ee = B.width;
                if (je === void 0) je = ee;
                else if (je !== ee) {
                  T = !1;
                  break;
                }
                if (ee = B.height, A === void 0) A = ee;
                else if (A !== ee) {
                  T = !1;
                  break;
                }
                delete B.width, delete B.height, B.transform === "none" && delete B.transform;
              }
              T && je !== void 0 && A !== void 0 && (ne.setKeyframes(F), T = getComputedStyle(
                ne.target,
                ne.pseudoElement
              ), T.width !== je || T.height !== A) && (T = F[0], T.width = je, T.height = A, T = F[F.length - 1], T.width = je, T.height = A, ne.setKeyframes(F));
            }
          }
          p();
        },
        function(C) {
          M.__reactViewTransition === k && (M.__reactViewTransition = null);
          try {
            if (typeof C == "object" && C !== null)
              switch (C.name) {
                case "InvalidStateError":
                  (C.message === "View transition was skipped because document visibility state is hidden." || C.message === "Skipping view transition because document visibility state has become hidden." || C.message === "Skipping view transition because viewport size changed." || C.message === "Transition was aborted because of invalid state") && (C = null);
              }
            C !== null && S(C);
          } finally {
            l(), n(), p();
          }
        }
      ), k.finished.finally(function() {
        for (var C = 0; C < Y.length; C++)
          Y[C].cancel();
        M.__reactViewTransition === k && (M.__reactViewTransition = null), g();
      }), k;
    } catch {
      return l(), n(), p(), null;
    }
  }
  function en(e, t) {
    this._scope = document.documentElement, this._selector = "::view-transition-" + e + "(" + t + ")";
  }
  en.prototype.animate = function(e, t) {
    return t = typeof t == "number" ? { duration: t } : G({}, t), t.pseudoElement = this._selector, this._scope.animate(e, t);
  }, en.prototype.getAnimations = function() {
    for (var e = this._scope, t = this._selector, a = e.getAnimations({ subtree: !0 }), l = [], n = 0; n < a.length; n++) {
      var r = a[n].effect;
      r !== null && r.target === e && r.pseudoElement === t && l.push(a[n]);
    }
    return l;
  }, en.prototype.getComputedStyle = function() {
    return getComputedStyle(this._scope, this._selector);
  };
  function Gm(e) {
    return {
      name: e,
      group: new en("group", e),
      imagePair: new en("image-pair", e),
      old: new en("old", e),
      new: new en("new", e)
    };
  }
  function Pt(e) {
    this._fragmentFiber = e, this._observers = this._eventListeners = null;
  }
  Pt.prototype.addEventListener = function(e, t, a) {
    var l = null, n = null;
    if (!(a != null && typeof a != "boolean" && (l = a.signal || null, l !== null && l.aborted))) {
      this._eventListeners === null && (this._eventListeners = []);
      var r = this._eventListeners;
      if (Km(r, e, t, a) === -1) {
        var p = this, g = t;
        a != null && typeof a != "boolean" && a.once === !0 && (g = function(S) {
          p.removeEventListener(
            e,
            t,
            a
          ), typeof t == "function" ? t.call(this, S) : t.handleEvent(S);
        }), l !== null && (n = p.removeEventListener.bind(
          p,
          e,
          t,
          a
        ), l.addEventListener("abort", n, { once: !0 }), n = l.removeEventListener.bind(l, "abort", n)), l = Jn(a), r.push({
          type: e,
          listener: t,
          optionsOrUseCapture: a,
          attachedListener: g,
          cleanup: n
        }), b(
          this._fragmentFiber.child,
          !1,
          gx,
          e,
          g,
          l
        );
      }
      this._eventListeners = r;
    }
  };
  function gx(e, t, a, l) {
    return R(e).addEventListener(
      t,
      a,
      l
    ), !1;
  }
  Pt.prototype.removeEventListener = function(e, t, a) {
    var l = this._eventListeners;
    if (l !== null && (t = Km(
      l,
      e,
      t,
      a
    ), t !== -1)) {
      var n = l[t];
      a = n.attachedListener;
      var r = n.cleanup;
      n = Jn(n.optionsOrUseCapture), b(
        this._fragmentFiber.child,
        !1,
        bx,
        e,
        a,
        n
      ), l.splice(t, 1), r !== null && r();
    }
  };
  function bx(e, t, a, l) {
    return R(e).removeEventListener(
      t,
      a,
      l
    ), !1;
  }
  function Jn(e) {
    return e != null && typeof e != "boolean" && (e.once === !0 || e.signal instanceof AbortSignal) ? { capture: e.capture, passive: e.passive } : e;
  }
  function Zm(e) {
    return e == null ? "c=0" : typeof e == "boolean" ? "c=" + (e ? "1" : "0") : "c=" + (e.capture ? "1" : "0");
  }
  function Km(e, t, a, l) {
    if (e.length === 0) return -1;
    l = Zm(l);
    for (var n = 0; n < e.length; n++) {
      var r = e[n];
      if (r.type === t && r.listener === a && Zm(r.optionsOrUseCapture) === l)
        return n;
    }
    return -1;
  }
  Pt.prototype.dispatchEvent = function(e) {
    var t = y(
      this._fragmentFiber
    );
    if (t === null) return !0;
    t = R(t);
    var a = this._eventListeners;
    if (a !== null && 0 < a.length || !e.bubbles) {
      var l = t.nodeType === 9 ? t.createComment("") : document.createTextNode("");
      if (a)
        for (var n = 0; n < a.length; n++) {
          var r = a[n];
          l.addEventListener(
            r.type,
            r.attachedListener,
            Jn(r.optionsOrUseCapture)
          );
        }
      if (t.appendChild(l), e = l.dispatchEvent(e), a)
        for (n = 0; n < a.length; n++)
          r = a[n], l.removeEventListener(
            r.type,
            r.attachedListener,
            Jn(r.optionsOrUseCapture)
          );
      return t.removeChild(l), e;
    }
    return t.dispatchEvent(e);
  }, Pt.prototype.focus = function(e) {
    b(
      this._fragmentFiber.child,
      !0,
      Jm,
      e,
      void 0,
      void 0
    );
  };
  function Jm(e, t) {
    return e.tag === 6 ? !1 : (e = R(e), Ax(e, t));
  }
  Pt.prototype.focusLast = function(e) {
    var t = [];
    b(
      this._fragmentFiber.child,
      !0,
      ro,
      t,
      void 0,
      void 0
    );
    for (var a = t.length - 1; 0 <= a && !Jm(t[a], e); a--) ;
  };
  function ro(e, t) {
    return t.push(e), !1;
  }
  Pt.prototype.blur = function() {
    var e = y(
      this._fragmentFiber
    );
    e !== null && (e = R(e), e = Ji(e).activeElement, e !== null && b(
      this._fragmentFiber.child,
      !1,
      vx,
      e,
      void 0,
      void 0
    ));
  };
  function vx(e, t) {
    return e.tag === 6 ? !1 : (e = R(e), e === t || e.contains(t) ? (t.blur(), !0) : !1);
  }
  Pt.prototype.observeUsing = function(e) {
    this._observers === null && (this._observers = /* @__PURE__ */ new Set()), this._observers.add(e), b(
      this._fragmentFiber.child,
      !1,
      xx,
      e,
      void 0,
      void 0
    );
  };
  function xx(e, t) {
    return e.tag === 6 || (e = R(e), t.observe(e)), !1;
  }
  Pt.prototype.unobserveUsing = function(e) {
    var t = this._observers;
    if (t !== null && t.has(e)) {
      t.delete(e), b(
        this._fragmentFiber.child,
        !1,
        yx,
        e,
        void 0,
        void 0
      );
      for (var a = t = 0; a < ma.length; a++) {
        var l = ma[a];
        l.fragmentInstance === this && l.observer === e ? e.unobserve(l.instance) : ma[t++] = l;
      }
      ma.length = t;
    }
  };
  function yx(e, t) {
    return e.tag === 6 || (e = R(e), t.unobserve(e)), !1;
  }
  var ma = [], so = !1;
  function jx(e, t, a) {
    ma.push({
      fragmentInstance: e,
      observer: t,
      instance: a
    }), so || (so = !0, Mx(function() {
      so = !1;
      var l = ma;
      ma = [];
      for (var n = 0; n < l.length; n++) {
        var r = l[n];
        r.observer.unobserve(r.instance);
      }
    }));
  }
  Pt.prototype.getClientRects = function() {
    var e = [];
    return b(
      this._fragmentFiber.child,
      !1,
      zx,
      e,
      void 0,
      void 0
    ), e;
  };
  function zx(e, t) {
    if (e.tag === 6) {
      e = e.stateNode;
      var a = e.ownerDocument.createRange();
      a.selectNodeContents(e), t.push.apply(t, a.getClientRects());
    } else
      e = R(e), t.push.apply(t, e.getClientRects());
    return !1;
  }
  Pt.prototype.getRootNode = function(e) {
    var t = y(
      this._fragmentFiber
    );
    return t === null ? this : R(t).getRootNode(e);
  }, Pt.prototype.compareDocumentPosition = function(e) {
    var t = y(
      this._fragmentFiber
    );
    if (t === null) return Node.DOCUMENT_POSITION_DISCONNECTED;
    var a = [];
    b(
      this._fragmentFiber.child,
      !1,
      ro,
      a,
      void 0,
      void 0
    );
    var l = R(t);
    if (a.length === 0) {
      if (a = l, z(this._fragmentFiber)) {
        e: {
          for (t = this._fragmentFiber.return; t !== null; ) {
            if (t.tag === 4) {
              t = t.stateNode.containerInfo;
              break e;
            }
            if (t.tag === 3 || t.tag === 5 || t.tag === 27)
              break;
            t = t.return;
          }
          t = null;
        }
        t != null && (a = t);
      }
      t = this._fragmentFiber;
      var n = l = a.compareDocumentPosition(e);
      return a === e ? n = Node.DOCUMENT_POSITION_CONTAINS : l & Node.DOCUMENT_POSITION_CONTAINED_BY && (a = O(t)[1], a === null ? n = Node.DOCUMENT_POSITION_PRECEDING : (e = R(a).compareDocumentPosition(
        e
      ), n = e === 0 || e & Node.DOCUMENT_POSITION_FOLLOWING ? Node.DOCUMENT_POSITION_FOLLOWING : Node.DOCUMENT_POSITION_PRECEDING)), n |= Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
    }
    t = R(a[0]), n = R(a[a.length - 1]);
    var r = z(this._fragmentFiber) ? t.parentElement : l;
    if (r == null)
      return Node.DOCUMENT_POSITION_DISCONNECTED;
    l = r.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY, r = r.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_CONTAINED_BY;
    var p = t.compareDocumentPosition(e), g = n.compareDocumentPosition(e), S = p & Node.DOCUMENT_POSITION_CONTAINED_BY || g & Node.DOCUMENT_POSITION_CONTAINED_BY;
    return g = l && r && p & Node.DOCUMENT_POSITION_FOLLOWING && g & Node.DOCUMENT_POSITION_PRECEDING, t = l && t === e || r && n === e || S || g ? Node.DOCUMENT_POSITION_CONTAINED_BY : !l && t === e || !r && n === e ? Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC : p, t & Node.DOCUMENT_POSITION_DISCONNECTED || t & Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC || Sx(
      t,
      this._fragmentFiber,
      a[0],
      a[a.length - 1],
      e
    ) ? t : Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
  };
  function Sx(e, t, a, l, n) {
    var r = ql(n);
    if (e & Node.DOCUMENT_POSITION_CONTAINED_BY) {
      if (a = !!r)
        e: {
          for (; r !== null; ) {
            if (r.tag === 7 && (r === t || r.alternate === t)) {
              a = !0;
              break e;
            }
            r = r.return;
          }
          a = !1;
        }
      return a;
    }
    if (e & Node.DOCUMENT_POSITION_CONTAINS) {
      if (r === null)
        return r = n.ownerDocument, n === r || n === r.documentElement || n === r.body;
      e: {
        for (r = t, t = y(t); r !== null; ) {
          if (!(r.tag !== 5 && r.tag !== 3 && r.tag !== 27 || r !== t && r.alternate !== t)) {
            r = !0;
            break e;
          }
          r = r.return;
        }
        r = !1;
      }
      return r;
    }
    return e & Node.DOCUMENT_POSITION_PRECEDING ? ((t = !!r) && !(t = r === a) && (t = se(
      a,
      r,
      J
    ), t === null ? t = !1 : (b(
      t,
      !0,
      V,
      r,
      a
    ), r = U, U = null, t = r !== null)), t) : e & Node.DOCUMENT_POSITION_FOLLOWING ? ((t = !!r) && !(t = r === l) && (t = se(
      l,
      r,
      J
    ), t === null ? t = !1 : (b(
      t,
      !0,
      W,
      r,
      l
    ), r = U, H = U = null, t = r !== null)), t) : !1;
  }
  function Fm(e, t) {
    var a = e.ownerDocument.createRange();
    a.selectNodeContents(e), e = a.getBoundingClientRect(), window.scrollTo(
      window.scrollX + e.left,
      t ? window.scrollY + e.top : window.scrollY + e.bottom - window.innerHeight
    );
  }
  Pt.prototype.scrollIntoView = function(e) {
    if (typeof e == "object") throw Error(u(566));
    var t = [];
    b(
      this._fragmentFiber.child,
      !1,
      ro,
      t,
      void 0,
      void 0
    );
    var a = e !== !1;
    if (t.length === 0) {
      var l = O(
        this._fragmentFiber
      );
      if (l = a ? l[1] || l[0] || y(this._fragmentFiber) : l[0] || l[1], l === null) return;
      if (l.tag === 6) {
        e = R(l), Fm(e, a);
        return;
      }
      if (l = R(l), l.nodeType !== 9) {
        if (l.nodeType === 11) {
          a = "host" in l ? l.host : null, a !== null && a.scrollIntoView(e);
          return;
        }
        l.scrollIntoView(e);
      }
    }
    for (l = a ? t.length - 1 : 0; l !== (a ? -1 : t.length); ) {
      var n = t[l];
      n.tag === 6 ? (n = R(n), Fm(n, a)) : R(n).scrollIntoView(e), l += a ? -1 : 1;
    }
  };
  function wx(e, t) {
    return e = R(e), Wm(e, t), !1;
  }
  function Wm(e, t) {
    e.reactFragments == null && (e.reactFragments = /* @__PURE__ */ new Set()), e.reactFragments.add(t);
  }
  function Im(e, t) {
    var a = t._eventListeners;
    if (a !== null)
      for (var l = 0; l < a.length; l++) {
        var n = a[l];
        e.addEventListener(
          n.type,
          n.attachedListener,
          Jn(n.optionsOrUseCapture)
        );
      }
    e.nodeType !== 3 && (a = t._observers, a !== null && a.forEach(function(r) {
      for (var p = 0, g = 0; g < ma.length; g++) {
        var S = ma[g];
        (S.fragmentInstance !== t || S.observer !== r || S.instance !== e) && (ma[p++] = S);
      }
      ma.length = p, r.observe(e);
    }), Wm(e, t));
  }
  function Nx(e, t) {
    var a = t._eventListeners;
    if (a !== null)
      for (var l = 0; l < a.length; l++) {
        var n = a[l];
        e.removeEventListener(
          n.type,
          n.attachedListener,
          Jn(n.optionsOrUseCapture)
        );
      }
    e.nodeType !== 3 && (a = t._observers, a !== null && a.forEach(function(r) {
      typeof r.rootMargin == "string" ? jx(
        t,
        r,
        e
      ) : r.unobserve(e);
    }), e.reactFragments != null && e.reactFragments.delete(t));
  }
  function uo(e) {
    var t = e.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var a = t;
      switch (t = t.nextSibling, a.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          uo(a), vr(a);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (a.rel.toLowerCase() === "stylesheet") continue;
      }
      e.removeChild(a);
    }
  }
  function Tx(e, t, a, l) {
    for (; e.nodeType === 1; ) {
      var n = a;
      if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!l && (e.nodeName !== "INPUT" || e.type !== "hidden"))
          break;
      } else if (l) {
        if (!e[ci])
          switch (t) {
            case "meta":
              if (!e.hasAttribute("itemprop")) break;
              return e;
            case "link":
              if (r = e.getAttribute("rel"), r === "stylesheet" && e.hasAttribute("data-precedence"))
                break;
              if (r !== n.rel || e.getAttribute("href") !== (n.href == null || n.href === "" ? null : n.href) || e.getAttribute("crossorigin") !== (n.crossOrigin == null ? null : n.crossOrigin) || e.getAttribute("title") !== (n.title == null ? null : n.title))
                break;
              return e;
            case "style":
              if (e.hasAttribute("data-precedence")) break;
              return e;
            case "script":
              if (r = e.getAttribute("src"), (r !== (n.src == null ? null : n.src) || e.getAttribute("type") !== (n.type == null ? null : n.type) || e.getAttribute("crossorigin") !== (n.crossOrigin == null ? null : n.crossOrigin)) && r && e.hasAttribute("async") && !e.hasAttribute("itemprop"))
                break;
              return e;
            default:
              return e;
          }
      } else if (t === "input" && e.type === "hidden") {
        var r = n.name == null ? null : "" + n.name;
        if (n.type === "hidden" && e.getAttribute("name") === r)
          return e;
      } else return e;
      if (e = da(e.nextSibling), e === null) break;
    }
    return null;
  }
  function Ex(e, t, a) {
    if (t === "") return null;
    for (; e.nodeType !== 3; )
      if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !a || (e = da(e.nextSibling), e === null)) return null;
    return e;
  }
  function Pm(e, t) {
    for (; e.nodeType !== 8; )
      if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !t || (e = da(e.nextSibling), e === null)) return null;
    return e;
  }
  function oo(e) {
    return e.data === "$?" || e.data === "$~";
  }
  function co(e) {
    return e.data === "$!" || e.data === "$?" && e.ownerDocument.readyState !== "loading";
  }
  function Cx(e, t) {
    var a = e.ownerDocument;
    if (e.data === "$~") e._reactRetry = t;
    else if (e.data !== "$?" || a.readyState !== "loading")
      t();
    else {
      var l = function() {
        t(), a.removeEventListener("DOMContentLoaded", l);
      };
      a.addEventListener("DOMContentLoaded", l), e._reactRetry = l;
    }
  }
  function da(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (t = e.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F")
          break;
        if (t === "/$" || t === "/&") return null;
      }
    }
    return e;
  }
  var po = null;
  function _m(e) {
    e = e.nextSibling;
    for (var t = 0; e; ) {
      if (e.nodeType === 8) {
        var a = e.data;
        if (a === "/$" || a === "/&") {
          if (t === 0)
            return da(e.nextSibling);
          t--;
        } else
          a !== "$" && a !== "$!" && a !== "$?" && a !== "$~" && a !== "&" || t++;
      }
      e = e.nextSibling;
    }
    return null;
  }
  function $m(e) {
    e = e.previousSibling;
    for (var t = 0; e; ) {
      if (e.nodeType === 8) {
        var a = e.data;
        if (a === "$" || a === "$!" || a === "$?" || a === "$~" || a === "&") {
          if (t === 0) return e;
          t--;
        } else a !== "/$" && a !== "/&" || t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  function Ax(e, t) {
    function a() {
      l = !0;
    }
    if (e.ownerDocument.activeElement === e) return !0;
    var l = !1;
    try {
      e.ownerDocument.addEventListener("focus", a, !0), (e.focus || HTMLElement.prototype.focus).call(e, t);
    } finally {
      e.ownerDocument.removeEventListener("focus", a, !0);
    }
    return l;
  }
  function Mx(e) {
    Ym(function() {
      Ym(function(t) {
        return e(t);
      });
    });
  }
  function eh(e, t, a) {
    switch (t = Ji(a), e) {
      case "html":
        if (e = t.documentElement, !e) throw Error(u(452));
        return e;
      case "head":
        if (e = t.head, !e) throw Error(u(453));
        return e;
      case "body":
        if (e = t.body, !e) throw Error(u(454));
        return e;
      default:
        throw Error(u(451));
    }
  }
  function th(e, t, a) {
    for (var l in a) {
      var n = a[l];
      a.hasOwnProperty(l) && n != null && Le(e, t, l, null, ix, n);
    }
    a.dangerouslySetInnerHTML != null && (e.textContent = ""), e.onclick === ba && (e.onclick = null), vr(e);
  }
  function fo(e) {
    for (var t = e.attributes; t.length; )
      e.removeAttributeNode(t[0]);
    vr(e);
  }
  var sa = /* @__PURE__ */ new Map(), ah = /* @__PURE__ */ new Set();
  function Fi(e) {
    if (typeof e.getRootNode == "function") {
      var t = e.getRootNode();
      if (t.nodeType === 9 || t.nodeType === 11) return t;
    }
    return e.nodeType === 9 ? e : e.ownerDocument;
  }
  var Ka = oe.d;
  oe.d = {
    f: Ox,
    r: Dx,
    D: qx,
    C: kx,
    L: Rx,
    m: Ux,
    X: Bx,
    S: Hx,
    M: Yx
  };
  function Ox() {
    var e = Ka.f(), t = jd();
    return e || t;
  }
  function Dx(e) {
    var t = pn(e);
    t !== null && t.tag === 5 && t.type === "form" ? lf(t) : Ka.r(e);
  }
  var Fn = typeof document > "u" ? null : document;
  function lh(e, t, a) {
    var l = Fn;
    if (l && typeof t == "string" && t) {
      var n = ea(t);
      n = 'link[rel="' + e + '"][href="' + n + '"]', typeof a == "string" && (n += '[crossorigin="' + a + '"]'), ah.has(n) || (ah.add(n), e = { rel: e, crossOrigin: a, href: t }, l.querySelector(n) === null && (t = l.createElement("link"), jt(t, "link", e), ct(t), l.head.appendChild(t)));
    }
  }
  function qx(e) {
    Ka.D(e), lh("dns-prefetch", e, null);
  }
  function kx(e, t) {
    Ka.C(e, t), lh("preconnect", e, t);
  }
  function Rx(e, t, a) {
    Ka.L(e, t, a);
    var l = Fn;
    if (l && e && t) {
      var n = 'link[rel="preload"][as="' + ea(t) + '"]';
      t === "image" && a && a.imageSrcSet ? (n += '[imagesrcset="' + ea(
        a.imageSrcSet
      ) + '"]', typeof a.imageSizes == "string" && (n += '[imagesizes="' + ea(
        a.imageSizes
      ) + '"]')) : n += '[href="' + ea(e) + '"]';
      var r = n;
      switch (t) {
        case "style":
          r = Wn(e);
          break;
        case "script":
          r = In(e);
      }
      if (!(sa.has(r) || (e = G(
        {
          rel: "preload",
          href: t === "image" && a && a.imageSrcSet ? void 0 : e,
          as: t
        },
        a
      ), sa.set(r, e), l.querySelector(n) !== null || t === "style" && l.querySelector(Wi(r)) || t === "script" && l.querySelector(Ii(r))))) {
        var p = l.createElement("link");
        jt(p, "link", e), t === "style" && (p[br] = !0, p.onload = p.onerror = function() {
          hc(p);
        }), ct(p), l.head.appendChild(p);
      }
    }
  }
  function Ux(e, t) {
    Ka.m(e, t);
    var a = Fn;
    if (a && e) {
      var l = t && typeof t.as == "string" ? t.as : "script", n = 'link[rel="modulepreload"][as="' + ea(l) + '"][href="' + ea(e) + '"]', r = n;
      switch (l) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          r = In(e);
      }
      if (!sa.has(r) && (e = G({ rel: "modulepreload", href: e }, t), sa.set(r, e), a.querySelector(n) === null)) {
        switch (l) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (a.querySelector(Ii(r)))
              return;
        }
        l = a.createElement("link"), jt(l, "link", e), ct(l), a.head.appendChild(l);
      }
    }
  }
  function Hx(e, t, a) {
    Ka.S(e, t, a);
    var l = Fn;
    if (l && e) {
      var n = fn(l).hoistableStyles, r = Wn(e);
      t = t || "default";
      var p = n.get(r);
      if (!p) {
        var g = { loading: 0, preload: null };
        if (p = l.querySelector(
          Wi(r)
        ))
          g.loading = 5;
        else {
          e = G(
            { rel: "stylesheet", href: e, "data-precedence": t },
            a
          ), (a = sa.get(r)) && mo(e, a);
          var S = p = l.createElement("link");
          ct(S), jt(S, "link", e), S._p = new Promise(function(M, k) {
            S.onload = M, S.onerror = k;
          }), S.addEventListener("load", function() {
            g.loading |= 1;
          }), S.addEventListener("error", function() {
            g.loading |= 2;
          }), g.loading |= 4, Cd(p, t, l);
        }
        p = {
          type: "stylesheet",
          instance: p,
          count: 1,
          state: g
        }, n.set(r, p);
      }
    }
  }
  function Bx(e, t) {
    Ka.X(e, t);
    var a = Fn;
    if (a && e) {
      var l = fn(a).hoistableScripts, n = In(e), r = l.get(n);
      r || (r = a.querySelector(Ii(n)), r || (e = G({ src: e, async: !0 }, t), (t = sa.get(n)) && ho(e, t), r = a.createElement("script"), ct(r), jt(r, "link", e), a.head.appendChild(r)), r = {
        type: "script",
        instance: r,
        count: 1,
        state: null
      }, l.set(n, r));
    }
  }
  function Yx(e, t) {
    Ka.M(e, t);
    var a = Fn;
    if (a && e) {
      var l = fn(a).hoistableScripts, n = In(e), r = l.get(n);
      r || (r = a.querySelector(Ii(n)), r || (e = G({ src: e, async: !0, type: "module" }, t), (t = sa.get(n)) && ho(e, t), r = a.createElement("script"), ct(r), jt(r, "link", e), a.head.appendChild(r)), r = {
        type: "script",
        instance: r,
        count: 1,
        state: null
      }, l.set(n, r));
    }
  }
  function nh(e, t, a, l) {
    var n = (n = Ot.current) ? Fi(n) : null;
    if (!n) throw Error(u(446));
    switch (e) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof a.precedence == "string" && typeof a.href == "string" ? (a = Wn(a.href), t = fn(
          n
        ).hoistableStyles, l = t.get(a), l || (l = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, t.set(a, l)), l) : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
          e = Wn(a.href);
          var r = fn(
            n
          ).hoistableStyles, p = r.get(e);
          if (p || (n = n.ownerDocument || n, p = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: { loading: 0, preload: null }
          }, r.set(e, p), (r = n.querySelector(
            Wi(e)
          )) ? r._p || (p.instance = r, p.state.loading = 5) : (r = sa.get(e), r || (r = {
            rel: "preload",
            as: "style",
            href: a.href,
            crossOrigin: a.crossOrigin,
            integrity: a.integrity,
            media: a.media,
            hrefLang: a.hrefLang,
            referrerPolicy: a.referrerPolicy
          }, sa.set(e, r)), Qx(
            n,
            e,
            r,
            p.state
          ))), t && l === null)
            throw Error(u(528, ""));
          return p;
        }
        if (t && l !== null)
          throw Error(u(529, ""));
        return null;
      case "script":
        return t = a.async, a = a.src, typeof a == "string" && t && typeof t != "function" && typeof t != "symbol" ? (a = In(a), t = fn(
          n
        ).hoistableScripts, l = t.get(a), l || (l = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, t.set(a, l)), l) : { type: "void", instance: null, count: 0, state: null };
      default:
        throw Error(u(444, e));
    }
  }
  function Wn(e) {
    return 'href="' + ea(e) + '"';
  }
  function Wi(e) {
    return 'link[rel="stylesheet"][' + e + "]";
  }
  function ih(e) {
    return G({}, e, {
      "data-precedence": e.precedence,
      precedence: null
    });
  }
  function Qx(e, t, a, l) {
    if (t = e.querySelector(
      'link[rel="preload"][as="style"][' + t + "]"
    )) {
      if (t[br] !== !0) {
        l.loading = 1;
        return;
      }
    } else
      t = e.createElement("link"), t[br] = !0, t.onload = t.onerror = hc.bind(null, t), jt(t, "link", a), ct(t), e.head.appendChild(t);
    l.preload = t, t.addEventListener("load", function() {
      return l.loading |= 1;
    }), t.addEventListener("error", function() {
      return l.loading |= 2;
    });
  }
  function In(e) {
    return '[src="' + ea(e) + '"]';
  }
  function Ii(e) {
    return "script[async]" + e;
  }
  function rh(e, t, a) {
    if (t.count++, t.instance === null)
      switch (t.type) {
        case "style":
          var l = e.querySelector(
            'style[data-href~="' + ea(a.href) + '"]'
          );
          if (l)
            return t.instance = l, ct(l), l;
          var n = G({}, a, {
            "data-href": a.href,
            "data-precedence": a.precedence,
            href: null,
            precedence: null
          });
          return l = (e.ownerDocument || e).createElement(
            "style"
          ), ct(l), jt(l, "style", n), Cd(l, a.precedence, e), t.instance = l;
        case "stylesheet":
          n = Wn(a.href);
          var r = e.querySelector(
            Wi(n)
          );
          if (r)
            return t.state.loading |= 4, t.instance = r, ct(r), r;
          l = ih(a), (n = sa.get(n)) && mo(l, n), r = (e.ownerDocument || e).createElement("link"), ct(r);
          var p = r;
          return p._p = new Promise(function(g, S) {
            p.onload = g, p.onerror = S;
          }), jt(r, "link", l), t.state.loading |= 4, Cd(r, a.precedence, e), t.instance = r;
        case "script":
          return r = In(a.src), (n = e.querySelector(
            Ii(r)
          )) ? (t.instance = n, ct(n), n) : (l = a, (n = sa.get(r)) && (l = G({}, a), ho(l, n)), e = e.ownerDocument || e, n = e.createElement("script"), ct(n), jt(n, "link", l), e.head.appendChild(n), t.instance = n);
        case "void":
          return null;
        default:
          throw Error(u(443, t.type));
      }
    else
      t.type === "stylesheet" && (t.state.loading & 4) === 0 && (l = t.instance, t.state.loading |= 4, Cd(l, a.precedence, e));
    return t.instance;
  }
  function Cd(e, t, a) {
    for (var l = a.querySelectorAll(
      'link[rel="stylesheet"][data-precedence],style[data-precedence]'
    ), n = l.length ? l[l.length - 1] : null, r = n, p = 0; p < l.length; p++) {
      var g = l[p];
      if (g.dataset.precedence === t) r = g;
      else if (r !== n) break;
    }
    r ? r.parentNode.insertBefore(e, r.nextSibling) : (t = a.nodeType === 9 ? a.head : a, t.insertBefore(e, t.firstChild));
  }
  function mo(e, t) {
    e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.title == null && (e.title = t.title);
  }
  function ho(e, t) {
    e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.integrity == null && (e.integrity = t.integrity);
  }
  var Ad = null;
  function dh(e, t, a) {
    if (Ad === null) {
      var l = /* @__PURE__ */ new Map(), n = Ad = /* @__PURE__ */ new Map();
      n.set(a, l);
    } else
      n = Ad, l = n.get(a), l || (l = /* @__PURE__ */ new Map(), n.set(a, l));
    if (l.has(e)) return l;
    for (l.set(e, null), a = a.getElementsByTagName(e), n = 0; n < a.length; n++) {
      var r = a[n];
      if (!(r[ci] || r[gt] || e === "link" && r.getAttribute("rel") === "stylesheet") && r.namespaceURI !== "http://www.w3.org/2000/svg") {
        var p = r.getAttribute(t) || "";
        p = e + p;
        var g = l.get(p);
        g ? g.push(r) : l.set(p, [r]);
      }
    }
    return l;
  }
  function go(e, t, a) {
    e = e.ownerDocument || e, e.head.insertBefore(
      a,
      t === "title" ? e.querySelector("head > title") : null
    );
  }
  function Xx(e, t, a) {
    if (a === 1 || t.itemProp != null) return !1;
    switch (e) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "")
          break;
        return !0;
      case "link":
        if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError)
          break;
        switch (t.rel) {
          case "stylesheet":
            return e = t.disabled, typeof t.precedence == "string" && e == null;
          default:
            return !0;
        }
      case "script":
        if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string")
          return !0;
    }
    return !1;
  }
  function sh(e, t) {
    return e === "img" && t.src != null && t.src !== "" && t.onLoad == null && t.loading !== "lazy";
  }
  function uh(e) {
    return !(e.type === "stylesheet" && (e.state.loading & 3) === 0);
  }
  function oh(e) {
    return (e.width || 100) * (e.height || 100) * (typeof devicePixelRatio == "number" ? devicePixelRatio : 1) * 0.25;
  }
  function ch(e, t) {
    typeof t.decode == "function" && (e.imgCount++, t.complete || (e.imgBytes += oh(t), e.suspenseyImages.push(t)), e = Gx.bind(e), t.decode().then(e, e));
  }
  function Vx(e, t, a, l) {
    if (a.type === "stylesheet" && (typeof l.media != "string" || matchMedia(l.media).matches !== !1) && (a.state.loading & 4) === 0) {
      if (a.instance === null) {
        var n = Wn(l.href), r = t.querySelector(
          Wi(n)
        );
        if (r) {
          t = r._p, t !== null && typeof t == "object" && typeof t.then == "function" && (e.count++, e = Pi.bind(e), t.then(e, e)), a.state.loading |= 4, a.instance = r, ct(r);
          return;
        }
        r = t.ownerDocument || t, l = ih(l), (n = sa.get(n)) && mo(l, n), r = r.createElement("link"), ct(r);
        var p = r;
        p._p = new Promise(function(g, S) {
          p.onload = g, p.onerror = S;
        }), jt(r, "link", l), a.instance = r;
      }
      e.stylesheets === null && (e.stylesheets = /* @__PURE__ */ new Map()), e.stylesheets.set(a, t), (t = a.state.preload) && (a.state.loading & 3) === 0 && (e.count++, a = Pi.bind(e), t.addEventListener("load", a), t.addEventListener("error", a));
    }
  }
  var Md = 0;
  function Lx(e, t) {
    return e.stylesheets && e.count === 0 && Dd(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(a) {
      var l = setTimeout(function() {
        if (e.stylesheets && Dd(e, e.stylesheets), e.unsuspend) {
          var r = e.unsuspend;
          e.unsuspend = null, r();
        }
      }, 6e4 + t);
      0 < e.imgBytes && Md === 0 && (Md = 62500 * dx());
      var n = setTimeout(
        function() {
          if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && Dd(e, e.stylesheets), e.unsuspend)) {
            var r = e.unsuspend;
            e.unsuspend = null, r();
          }
        },
        (e.imgBytes > Md ? 50 : 800) + t
      );
      return e.unsuspend = a, function() {
        e.unsuspend = null, clearTimeout(l), clearTimeout(n);
      };
    } : null;
  }
  function ph(e) {
    if (e.count === 0 && (e.imgCount === 0 || !e.waitingForImages)) {
      if (e.stylesheets) Dd(e, e.stylesheets);
      else if (e.unsuspend) {
        var t = e.unsuspend;
        e.unsuspend = null, t();
      }
    }
  }
  function Pi() {
    this.count--, ph(this);
  }
  function Gx() {
    this.imgCount--, ph(this);
  }
  var Od = null;
  function Dd(e, t) {
    e.stylesheets = null, e.unsuspend !== null && (e.count++, Od = /* @__PURE__ */ new Map(), t.forEach(Zx, e), Od = null, Pi.call(e));
  }
  function Zx(e, t) {
    if (!(t.state.loading & 4)) {
      var a = Od.get(e);
      if (a) var l = a.get(null);
      else {
        a = /* @__PURE__ */ new Map(), Od.set(e, a);
        for (var n = e.querySelectorAll(
          "link[data-precedence],style[data-precedence]"
        ), r = 0; r < n.length; r++) {
          var p = n[r];
          (p.nodeName === "LINK" || p.getAttribute("media") !== "not all") && (a.set(p.dataset.precedence, p), l = p);
        }
        l && a.set(null, l);
      }
      n = t.instance, p = n.getAttribute("data-precedence"), r = a.get(p) || l, r === l && a.set(null, n), a.set(p, n), this.count++, l = Pi.bind(this), n.addEventListener("load", l), n.addEventListener("error", l), r ? r.parentNode.insertBefore(n, r.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(n, e.firstChild)), t.state.loading |= 4;
    }
  }
  var Pn = {
    $$typeof: Ee,
    Provider: null,
    Consumer: null,
    _currentValue: wt,
    _currentValue2: wt,
    _threadCount: 0
  };
  function Kx(e, t, a, l, n, r, p, g, S) {
    this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Wd(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Wd(0), this.hiddenUpdates = Wd(null), this.identifierPrefix = l, this.onUncaughtError = n, this.onCaughtError = r, this.onRecoverableError = p, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = S, this.transitionTypes = null, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function fh(e, t, a, l, n, r, p, g, S, M, k, Y) {
    return e = new Kx(
      e,
      t,
      a,
      p,
      S,
      M,
      k,
      Y,
      g
    ), t = 1, r === !0 && (t |= 24), r = qt(3, null, null, t), e.current = r, r.stateNode = e, t = Ms(), t.refCount++, e.pooledCache = t, t.refCount++, r.memoizedState = {
      element: l,
      isDehydrated: a,
      cache: t
    }, ks(r), e;
  }
  function mh(e) {
    return e ? (e = Sn, e) : Sn;
  }
  function hh(e, t, a, l, n, r) {
    n = mh(n), l.context === null ? l.context = n : l.pendingContext = n, l = sl(t), l.payload = { element: a }, r = r === void 0 ? null : r, r !== null && (l.callback = r), a = ul(e, l, t), a !== null && (Ht(a, e, t), Ci(a, e, t));
  }
  function gh(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
      var a = e.retryLane;
      e.retryLane = a !== 0 && a < t ? a : t;
    }
  }
  function bo(e, t) {
    gh(e, t), (e = e.alternate) && gh(e, t);
  }
  function bh(e) {
    if (e.tag === 13 || e.tag === 31) {
      var t = Hl(e, 67108864);
      t !== null && Ht(t, e, 67108864), bo(e, 67108864);
    }
  }
  function vh(e) {
    if (e.tag === 13 || e.tag === 31) {
      var t = It();
      t = Id(t);
      var a = Hl(e, t);
      a !== null && Ht(a, e, t), bo(e, t);
    }
  }
  var _n = !0;
  function Jx(e, t, a, l) {
    var n = le.T;
    le.T = null;
    var r = oe.p;
    try {
      oe.p = 2, vo(e, t, a, l);
    } finally {
      oe.p = r, le.T = n;
    }
  }
  function Fx(e, t, a, l) {
    var n = le.T;
    le.T = null;
    var r = oe.p;
    try {
      oe.p = 8, vo(e, t, a, l);
    } finally {
      oe.p = r, le.T = n;
    }
  }
  function vo(e, t, a, l) {
    if (_n) {
      var n = xo(l);
      if (n === null)
        _u(
          e,
          t,
          l,
          qd,
          a
        ), yh(e, l);
      else if (Ix(
        n,
        e,
        t,
        a,
        l
      ))
        l.stopPropagation();
      else if (yh(e, l), t & 4 && -1 < Wx.indexOf(e)) {
        for (; n !== null; ) {
          var r = pn(n);
          if (r !== null)
            switch (r.tag) {
              case 3:
                if (r = r.stateNode, r.current.memoizedState.isDehydrated) {
                  var p = Dl(r.pendingLanes);
                  if (p !== 0) {
                    var g = r;
                    for (g.pendingLanes |= 2, g.entangledLanes |= 2; p; ) {
                      var S = 1 << 31 - Lt(p);
                      g.entanglements[1] |= S, p &= ~S;
                    }
                    Ea(r), (Be & 6) === 0 && (vd = Xt() + 500, Gi(0));
                  }
                }
                break;
              case 31:
              case 13:
                g = Hl(r, 2), g !== null && Ht(g, r, 2), jd(), bo(r, 2);
            }
          if (r = xo(l), r === null && _u(
            e,
            t,
            l,
            qd,
            a
          ), r === n) break;
          n = r;
        }
        n !== null && l.stopPropagation();
      } else
        _u(
          e,
          t,
          l,
          null,
          a
        );
    }
  }
  function xo(e) {
    return e = ls(e), yo(e);
  }
  var qd = null;
  function yo(e) {
    if (qd = null, e = ql(e), e !== null) {
      var t = f(e);
      if (t === null) e = null;
      else {
        var a = t.tag;
        if (a === 13) {
          if (e = m(t), e !== null) return e;
          e = null;
        } else if (a === 31) {
          if (e = h(t), e !== null) return e;
          e = null;
        } else if (a === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          e = null;
        } else t !== e && (e = null);
      }
    }
    return qd = e, null;
  }
  function xh(e) {
    switch (e) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "fullscreenerror":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "resize":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (db()) {
          case lc:
            return 2;
          case nc:
            return 8;
          case pr:
          case sb:
            return 32;
          case ic:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var jo = !1, jl = null, zl = null, Sl = null, _i = /* @__PURE__ */ new Map(), $i = /* @__PURE__ */ new Map(), wl = [], Wx = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
    " "
  );
  function yh(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        jl = null;
        break;
      case "dragenter":
      case "dragleave":
        zl = null;
        break;
      case "mouseover":
      case "mouseout":
        Sl = null;
        break;
      case "pointerover":
      case "pointerout":
        _i.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        $i.delete(t.pointerId);
    }
  }
  function er(e, t, a, l, n, r) {
    return e === null || e.nativeEvent !== r ? (e = {
      blockedOn: t,
      domEventName: a,
      eventSystemFlags: l,
      nativeEvent: r,
      targetContainers: [n]
    }, t !== null && (t = pn(t), t !== null && bh(t)), e) : (e.eventSystemFlags |= l, t = e.targetContainers, n !== null && t.indexOf(n) === -1 && t.push(n), e);
  }
  function Ix(e, t, a, l, n) {
    switch (t) {
      case "focusin":
        return jl = er(
          jl,
          e,
          t,
          a,
          l,
          n
        ), !0;
      case "dragenter":
        return zl = er(
          zl,
          e,
          t,
          a,
          l,
          n
        ), !0;
      case "mouseover":
        return Sl = er(
          Sl,
          e,
          t,
          a,
          l,
          n
        ), !0;
      case "pointerover":
        var r = n.pointerId;
        return _i.set(
          r,
          er(
            _i.get(r) || null,
            e,
            t,
            a,
            l,
            n
          )
        ), !0;
      case "gotpointercapture":
        return r = n.pointerId, $i.set(
          r,
          er(
            $i.get(r) || null,
            e,
            t,
            a,
            l,
            n
          )
        ), !0;
    }
    return !1;
  }
  function jh(e) {
    var t = ql(e.target);
    if (t !== null) {
      var a = f(t);
      if (a !== null) {
        if (t = a.tag, t === 13) {
          if (t = m(a), t !== null) {
            e.blockedOn = t, pc(e.priority, function() {
              vh(a);
            });
            return;
          }
        } else if (t === 31) {
          if (t = h(a), t !== null) {
            e.blockedOn = t, pc(e.priority, function() {
              vh(a);
            });
            return;
          }
        } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function kd(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length; ) {
      var a = xo(e.nativeEvent);
      if (a === null) {
        a = e.nativeEvent;
        var l = new a.constructor(
          a.type,
          a
        );
        as = l, a.target.dispatchEvent(l), as = null;
      } else
        return t = pn(a), t !== null && bh(t), e.blockedOn = a, !1;
      t.shift();
    }
    return !0;
  }
  function zh(e, t, a) {
    kd(e) && a.delete(t);
  }
  function Px() {
    jo = !1, jl !== null && kd(jl) && (jl = null), zl !== null && kd(zl) && (zl = null), Sl !== null && kd(Sl) && (Sl = null), _i.forEach(zh), $i.forEach(zh);
  }
  function Rd(e, t) {
    e.blockedOn === t && (e.blockedOn = null, jo || (jo = !0, d.unstable_scheduleCallback(
      d.unstable_NormalPriority,
      Px
    )));
  }
  var Ud = null;
  function Sh(e) {
    Ud !== e && (Ud = e, d.unstable_scheduleCallback(
      d.unstable_NormalPriority,
      function() {
        Ud === e && (Ud = null);
        for (var t = 0; t < e.length; t += 3) {
          var a = e[t], l = e[t + 1], n = e[t + 2];
          if (typeof l != "function") {
            if (yo(l || a) === null)
              continue;
            break;
          }
          var r = pn(a);
          r !== null && (e.splice(t, 3), t -= 3, tu(
            r,
            {
              pending: !0,
              data: n,
              method: a.method,
              action: l
            },
            l,
            n
          ));
        }
      }
    ));
  }
  function $n(e) {
    function t(S) {
      return Rd(S, e);
    }
    jl !== null && Rd(jl, e), zl !== null && Rd(zl, e), Sl !== null && Rd(Sl, e), _i.forEach(t), $i.forEach(t);
    for (var a = 0; a < wl.length; a++) {
      var l = wl[a];
      l.blockedOn === e && (l.blockedOn = null);
    }
    for (; 0 < wl.length && (a = wl[0], a.blockedOn === null); )
      jh(a), a.blockedOn === null && wl.shift();
    if (a = (e.ownerDocument || e).$$reactFormReplay, a != null)
      for (l = 0; l < a.length; l += 3) {
        var n = a[l], r = a[l + 1], p = n[Dt] || null;
        if (typeof r == "function")
          p || Sh(a);
        else if (p) {
          var g = null;
          if (r && r.hasAttribute("formAction")) {
            if (n = r, p = r[Dt] || null)
              g = p.formAction;
            else if (yo(n) !== null) continue;
          } else g = p.action;
          typeof g == "function" ? a[l + 1] = g : (a.splice(l, 3), l -= 3), Sh(a);
        }
      }
  }
  function wh() {
    function e(r) {
      r.canIntercept && r.info === "react-transition" && r.intercept({
        handler: function() {
          return new Promise(function(p) {
            return n = p;
          });
        },
        focusReset: "manual",
        scroll: "manual"
      });
    }
    function t() {
      n !== null && (n(), n = null), l || setTimeout(a, 20);
    }
    function a() {
      if (!l && !navigation.transition) {
        var r = navigation.currentEntry;
        r && r.url != null && navigation.navigate(r.url, {
          state: r.getState(),
          info: "react-transition",
          history: "replace"
        });
      }
    }
    if (typeof navigation == "object") {
      var l = !1, n = null;
      return navigation.addEventListener("navigate", e), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(a, 100), function() {
        l = !0, navigation.removeEventListener("navigate", e), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), n !== null && (n(), n = null);
      };
    }
  }
  function zo(e) {
    this._internalRoot = e;
  }
  Hd.prototype.render = zo.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(u(409));
    var a = t.current, l = It();
    hh(a, l, e, t, null, null);
  }, Hd.prototype.unmount = zo.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
      this._internalRoot = null;
      var t = e.containerInfo;
      hh(e.current, 2, null, e, null, null), jd(), t[cn] = null;
    }
  };
  function Hd(e) {
    this._internalRoot = e;
  }
  Hd.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
      var t = cc();
      e = { blockedOn: null, target: e, priority: t };
      for (var a = 0; a < wl.length && t !== 0 && t < wl[a].priority; a++) ;
      wl.splice(a, 0, e), a === 0 && jh(e);
    }
  };
  var Nh = s.version;
  if (Nh !== "19.3.1")
    throw Error(
      u(
        527,
        Nh,
        "19.3.1"
      )
    );
  oe.findDOMNode = function(e) {
    var t = e._reactInternals;
    if (t === void 0)
      throw typeof e.render == "function" ? Error(u(188)) : (e = Object.keys(e).join(","), Error(u(268, e)));
    return e = j(t), e = e !== null ? x(e) : null, e = e === null ? null : e.stateNode, e;
  };
  var _x = {
    bundleType: 0,
    version: "19.3.1",
    rendererPackageName: "react-dom",
    currentDispatcherRef: le,
    reconcilerVersion: "19.3.1"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Bd = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Bd.isDisabled && Bd.supportsFiber)
      try {
        si = Bd.inject(
          _x
        ), Vt = Bd;
      } catch {
      }
  }
  return ar.createRoot = function(e, t) {
    if (!c(e)) throw Error(u(299));
    var a = !1, l = "", n = mf, r = hf, p = gf;
    return t != null && (t.unstable_strictMode === !0 && (a = !0), t.identifierPrefix !== void 0 && (l = t.identifierPrefix), t.onUncaughtError !== void 0 && (n = t.onUncaughtError), t.onCaughtError !== void 0 && (r = t.onCaughtError), t.onRecoverableError !== void 0 && (p = t.onRecoverableError)), t = fh(
      e,
      1,
      !1,
      null,
      null,
      a,
      l,
      null,
      n,
      r,
      p,
      wh
    ), e[cn] = t.current, Pu(e), new zo(t);
  }, ar.hydrateRoot = function(e, t, a) {
    if (!c(e)) throw Error(u(299));
    var l = !1, n = "", r = mf, p = hf, g = gf, S = null;
    return a != null && (a.unstable_strictMode === !0 && (l = !0), a.identifierPrefix !== void 0 && (n = a.identifierPrefix), a.onUncaughtError !== void 0 && (r = a.onUncaughtError), a.onCaughtError !== void 0 && (p = a.onCaughtError), a.onRecoverableError !== void 0 && (g = a.onRecoverableError), a.formState !== void 0 && (S = a.formState)), t = fh(
      e,
      1,
      !0,
      t,
      a ?? null,
      l,
      n,
      S,
      r,
      p,
      g,
      wh
    ), t.context = mh(null), a = t.current, l = It(), l = Id(l), n = sl(l), n.callback = null, ul(a, n, l), a = l, t.current.lanes = a, oi(t, a), Ea(t), e[cn] = t.current, Pu(e), new Hd(t);
  }, ar.version = "19.3.1", ar;
}
var Rh;
function c0() {
  if (Rh) return To.exports;
  Rh = 1;
  function d() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(d);
      } catch (s) {
        console.error(s);
      }
  }
  return d(), To.exports = o0(), To.exports;
}
var p0 = c0();
const Fh = {
  grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
  search: "M21 21l-5-5 M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0",
  plus: "M12 5v14 M5 12h14",
  minus: "M5 12h14",
  close: "M6 6l12 12 M6 18L18 6",
  check: "M5 12l4 4L19 6",
  chevronDown: "M6 9l6 6 6-6",
  chevronUp: "M6 15l6-6 6 6",
  chevronRight: "M9 6l6 6-6 6",
  chevronLeft: "M15 6l-6 6 6 6",
  arrowLeft: "M20 12H4 M10 6l-6 6 6 6",
  arrowRight: "M4 12h16 M14 6l6 6-6 6",
  cart: "M3 3h2l3 12h10l3-9H6 M9 20h.01 M18 20h.01",
  bag: "M5 7h14l1 14H4L5 7z M8 7V5a4 4 0 0 1 8 0v2",
  heart: "M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z",
  star: "m12 2 3.1 6.3L22 9.4l-5 4.9 1.2 6.9-6.2-3.3-6.2 3.3 1.2-6.9-5-4.9 6.9-1.1L12 2z",
  box: "m12 2 9 5v10l-9 5-9-5V7l9-5z M3 7l9 5 9-5 M12 12v10 M7 4.8l9 5",
  truck: "M3 5h12v12H3z M15 9h4l3 4v4h-7 M7 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4 M18 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4",
  shield: "M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6L12 2z M8 12l3 3 5-6",
  calendar: "M5 4h14a2 2 0 0 1 2 2v14H3V6a2 2 0 0 1 2-2z M7 2v5 M17 2v5 M3 10h18",
  clock: "M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0 M12 6v6l4 2",
  user: "M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M4 21v-2a8 6 0 0 1 16 0v2",
  users: "M15 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M2 21v-2a9 6 0 0 1 18 0v2 M18 3a4 4 0 0 1 0 8 M20 14a7 5 0 0 1 3 5",
  bell: "M18 8a6 6 0 0 0-12 0v8l-2 2h16l-2-2V8 M10 21h4",
  message: "M21 3H3v14h5l4 4 4-4h5V3z M7 8h10 M7 12h6",
  mail: "M3 5h18v14H3V5z M3 5l9 8 9-8",
  settings: "M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8 M9 2h6l1 4 4 1 2 5-3 3 1 4-5 3-3-3-4 1-3-5 3-3-1-4 4-1 1-4z",
  moon: "M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10",
  sun: "M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M12 1v3 M12 20v3 M1 12h3 M20 12h3 M4 4l2 2 M18 18l2 2 M4 20l2-2 M18 6l2-2",
  menu: "M4 6h16 M4 12h16 M4 18h16",
  more: "M5 12h.01 M12 12h.01 M19 12h.01",
  filter: "M3 4h18l-7 8v7l-4 2v-9L3 4z",
  sort: "M8 3v18 M4 7l4-4 4 4 M16 21V3 M12 17l4 4 4-4",
  download: "M12 3v12 M7 10l5 5 5-5 M4 17v4h16v-4",
  upload: "M12 16V3 M7 8l5-5 5 5 M4 17v4h16v-4",
  trash: "M3 6h18 M9 6V3h6v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7",
  edit: "m16 3 5 5L8 21H3v-5L16 3z M13 6l5 5",
  copy: "M8 8h13v13H8V8z M16 8V3H3v13h5",
  eye: "M2 12s3-7 10-7 10 7 10 7-3 7-10 7S2 12 2 12z M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  lock: "M5 10h14v11H5V10z M8 10V6a4 4 0 0 1 8 0v4",
  info: "M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0 M12 11v6 M12 7h.01",
  warning: "m12 3 10 18H2L12 3z M12 9v5 M12 17h.01",
  chart: "M3 3v18h18 M7 16v-5 M12 16V7 M17 16V4",
  code: "M8 5 2 12l6 7 M16 5l6 7-6 7 M14 3l-4 18",
  layers: "m12 2 10 6-10 6L2 8l10-6z M2 12l10 6 10-6 M2 16l10 6 10-6",
  sparkles: "m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5L12 2z",
  creditCard: "M3 4h18v16H3V4z M3 9h18 M7 15h4",
  tag: "M3 3h8l10 10-8 8L3 11V3z M7 7h.01",
  compare: "M8 3v18 M16 3v18 M4 7h8 M12 17h8",
  refresh: "M21 3v6h-6 M3 21v-6h6 M4 8a8 8 0 0 1 13-4l4 5 M20 16A8 8 0 0 1 7 20l-4-5",
  globe: "M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0 M2 12h20 M12 2c6 5 6 15 0 20-6-5-6-15 0-20",
  link: "m10 14 4-4 M8 16l-2 2a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0 M16 8l2-2a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"
};
function _({ name: d, size: s = 20, label: o, ...u }) {
  return w.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    role: o ? "img" : void 0,
    "aria-label": o,
    "aria-hidden": o ? void 0 : !0,
    ...u
  }, w.createElement("path", { d: Fh[d] }));
}
const f0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Icon: _,
  iconPaths: Fh
}, Symbol.toStringTag, { value: "Module" })), $t = (d) => String(d ?? "").replace(/[۰-۹]/g, (s) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(s))).replace(/[٠-٩]/g, (s) => String("٠١٢٣٤٥٦٧٨٩".indexOf(s))), Yo = (d) => $t(d).replace(/\d/g, (s) => "۰۱۲۳۴۵۶۷۸۹"[Number(s)]), m0 = (d) => d.normalize("NFKC").replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/[\u064B-\u065F\u0670ـ]/g, "").replace(/\s+/g, " ").trim(), Bt = (d) => $t(m0(d)).toLocaleLowerCase().replace(/[\s\u200c\u200d_-]/g, "");
function ke(d, s = {}, o = "fa-IR") {
  return new Intl.NumberFormat(o, s).format(d);
}
function Yt(d, s = "IRT", o = "fa-IR") {
  return s === "IRT" ? `${ke(d, {}, o)} ${o.startsWith("fa") ? "تومان" : "toman"}` : new Intl.NumberFormat(o, {
    style: "currency",
    currency: s,
    maximumFractionDigits: s === "IRR" ? 0 : 2
  }).format(d);
}
const Qd = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند"
], h0 = [
  "شنبه",
  "یکشنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنجشنبه",
  "جمعه"
], g0 = new Intl.DateTimeFormat("en-US-u-ca-persian", {
  year: "numeric",
  month: "numeric",
  day: "numeric",
  timeZone: "UTC"
}), Wh = (d) => {
  const s = Object.fromEntries(g0.formatToParts(d).map((o) => [o.type, o.value]));
  return { year: Number(s.year), month: Number(s.month), day: Number(s.day) };
};
function ha(d) {
  if (!Number.isFinite(d.getTime()))
    throw new RangeError("Invalid date");
  return Wh(new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())));
}
function nr(d, s, o) {
  if (![d, s, o].every(Number.isInteger) || d < 1200 || d > 1600 || s < 1 || s > 12 || o < 1 || o > 31)
    return null;
  const u = d * 1e4 + s * 100 + o;
  let c = Math.floor(Date.UTC(d + 621, 2, 15) / 864e5), f = Math.floor(Date.UTC(d + 622, 2, 24) / 864e5);
  for (; c <= f; ) {
    const m = Math.floor((c + f) / 2), h = new Date(m * 864e5), v = Wh(h), j = v.year * 1e4 + v.month * 100 + v.day;
    if (j === u)
      return new Date(h.getUTCFullYear(), h.getUTCMonth(), h.getUTCDate());
    j < u ? c = m + 1 : f = m - 1;
  }
  return null;
}
function b0(d, s) {
  if (s < 1 || s > 12 || !nr(d, s, 1))
    throw new RangeError("Invalid Jalali month");
  return s <= 6 ? 31 : s <= 11 || nr(d, 12, 30) ? 30 : 29;
}
function Uh(d) {
  const s = $t(d).trim().match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/);
  return s ? nr(+s[1], +s[2], +s[3]) : null;
}
function Tl(d, s = "numeric", o = "fa") {
  const u = ha(d), c = s === "long" ? `${u.day} ${Qd[u.month - 1]} ${u.year}` : `${u.year}/${String(u.month).padStart(2, "0")}/${String(u.day).padStart(2, "0")}`;
  return o === "fa" ? Yo(c) : c;
}
function Ja(d) {
  if (!Number.isFinite(d.getTime()))
    throw new RangeError("Invalid date");
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function Ao(d) {
  const s = d.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!s)
    return null;
  const o = new Date(+s[1], +s[2] - 1, +s[3]);
  return Ja(o) === d ? o : null;
}
const _t = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()), an = (d, s) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + s), lr = (d, s) => !!d && !!s && Ja(d) === Ja(s);
function ln(d, { min: s, max: o, isDateDisabled: u } = {}) {
  const c = _t(d).getTime();
  return Number.isFinite(c) && (!s || c >= _t(s).getTime()) && (!o || c <= _t(o).getTime()) && !(u != null && u(d));
}
function Hh(d, s, o = {}) {
  if (_t(d) > _t(s) || !ln(d, o) || !ln(s, o))
    return !1;
  if (o.isDateDisabled) {
    for (let u = _t(d); u <= s; u = an(u, 1))
      if (o.isDateDisabled(u))
        return !1;
  }
  return !0;
}
const Ih = (d) => $t(d).replace(/\D/g, "");
function Bh(d) {
  const s = $t(d).replace(/[\s-]/g, "");
  if (!/^\d{10}$/.test(s) || /^(\d)\1{9}$/.test(s))
    return !1;
  const o = [...s.slice(0, 9)].reduce((u, c, f) => u + Number(c) * (10 - f), 0) % 11;
  return Number(s[9]) === (o < 2 ? o : 11 - o);
}
function Yh(d) {
  const s = $t(d).replace(/[\s-]/g, "");
  return /^\d{16}$/.test(s) && !/^(\d)\1{15}$/.test(s) && [...s].reduce((o, u, c) => {
    let f = Number(u) * (c % 2 === 0 ? 2 : 1);
    return o + (f > 9 ? f - 9 : f);
  }, 0) % 10 === 0;
}
const v0 = (d) => Ih(d).slice(0, 16).replace(/(.{4})(?=.)/g, "$1 ");
function Qh(d) {
  const s = $t(d).replace(/\s/g, "").toUpperCase();
  return /^IR\d{24}$/.test(s) ? BigInt(s.slice(4) + "1827" + s.slice(2, 4)) % 97n === 1n : !1;
}
function Ph(d) {
  let s = $t(d).replace(/[\s()+-]/g, "");
  return s.startsWith("0098") ? s = "0" + s.slice(4) : s.startsWith("98") ? s = "0" + s.slice(2) : /^9\d{9}$/.test(s) && (s = "0" + s), s;
}
const Mo = (d) => /^09\d{9}$/.test(Ph(d)), Xh = (d) => /^[13-9]{5}\d{5}$/.test($t(d).replace(/[\s-]/g, "")) && !/^(\d)\1{9}$/.test(Ih(d)), x0 = [
  "آذربایجان شرقی",
  "آذربایجان غربی",
  "اردبیل",
  "اصفهان",
  "البرز",
  "ایلام",
  "بوشهر",
  "تهران",
  "چهارمحال و بختیاری",
  "خراسان جنوبی",
  "خراسان رضوی",
  "خراسان شمالی",
  "خوزستان",
  "زنجان",
  "سمنان",
  "سیستان و بلوچستان",
  "فارس",
  "قزوین",
  "قم",
  "کردستان",
  "کرمان",
  "کرمانشاه",
  "کهگیلویه و بویراحمد",
  "گلستان",
  "گیلان",
  "لرستان",
  "مازندران",
  "مرکزی",
  "هرمزگان",
  "همدان",
  "یزد"
], Vh = [
  "",
  "یک",
  "دو",
  "سه",
  "چهار",
  "پنج",
  "شش",
  "هفت",
  "هشت",
  "نه",
  "ده",
  "یازده",
  "دوازده",
  "سیزده",
  "چهارده",
  "پانزده",
  "شانزده",
  "هفده",
  "هجده",
  "نوزده"
], y0 = ["", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"], j0 = ["", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"];
function _h(d) {
  if (!Number.isSafeInteger(d))
    throw new RangeError("Expected a safe integer");
  if (d === 0)
    return "صفر";
  if (d < 0)
    return "منفی " + _h(-d);
  const s = (c) => [
    j0[Math.floor(c / 100)],
    c % 100 < 20 ? Vh[c % 100] : [y0[Math.floor(c % 100 / 10)], Vh[c % 10]].filter(Boolean).join(" و ")
  ].filter(Boolean).join(" و "), o = [];
  let u = 0;
  for (; d; ) {
    const c = d % 1e3;
    c && o.unshift([s(c), ["", "هزار", "میلیون", "میلیارد", "تریلیون", "کوادریلیون"][u]].filter(Boolean).join(" ")), d = Math.floor(d / 1e3), u++;
  }
  return o.join(" و ");
}
function z0(d, s = /* @__PURE__ */ new Date(), o = "fa-IR") {
  const u = (d.getTime() - s.getTime()) / 1e3;
  for (const [c, f] of [
    [31536e3, "year"],
    [2592e3, "month"],
    [86400, "day"],
    [3600, "hour"],
    [60, "minute"],
    [1, "second"]
  ])
    if (Math.abs(u) >= c || c === 1)
      return new Intl.RelativeTimeFormat(o, { numeric: "auto" }).format(Math.round(u / c), f);
  return "";
}
const ie = (...d) => d.filter(Boolean).join(" ");
function Wa(d, s, o) {
  const [u, c] = w.useState(s);
  return [
    d === void 0 ? u : d,
    w.useCallback((f) => {
      d === void 0 && c(f), o == null || o(f);
    }, [d, o])
  ];
}
function Qo(d) {
  const s = w.useRef(d);
  return w.useEffect(() => {
    s.current = d;
  }, [d]), s;
}
const Xo = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex="0"]';
function nn() {
  var s;
  let d = document.activeElement;
  for (; (s = d == null ? void 0 : d.shadowRoot) != null && s.activeElement; )
    d = d.shadowRoot.activeElement;
  return d;
}
function Vo(d, s) {
  return !!d && s.composedPath().some((o) => o instanceof Node && d.contains(o));
}
function S0(d, s) {
  for (; s; ) {
    if (s === d)
      return !0;
    s = s instanceof Element && s.assignedSlot ? s.assignedSlot : s instanceof ShadowRoot ? s.host : s.parentNode;
  }
  return !1;
}
function Oo(d, s) {
  const o = [], u = (c) => {
    c instanceof HTMLElement && c.matches(s) && o.push(c);
    const f = c instanceof HTMLSlotElement ? c.assignedElements({ flatten: !0 }) : c.shadowRoot ? Array.from(c.shadowRoot.children) : Array.from(c.children);
    for (const m of f.length ? f : Array.from(c.children))
      u(m);
  };
  for (const c of d.children)
    u(c);
  return o;
}
function $h(d) {
  if (!/^#[\da-f]{6}$/i.test(d))
    throw new TypeError("Brand must be a six digit hex color");
  return [
    parseInt(d.slice(1, 3), 16),
    parseInt(d.slice(3, 5), 16),
    parseInt(d.slice(5, 7), 16)
  ];
}
function ai(d, s) {
  const o = (f) => $h(f).map((m) => {
    const h = m / 255;
    return h <= 0.04045 ? h / 12.92 : ((h + 0.055) / 1.055) ** 2.4;
  }).reduce((m, h, v) => m + h * [0.2126, 0.7152, 0.0722][v], 0), [u, c] = [o(d), o(s)].sort((f, m) => m - f);
  return (u + 0.05) / (c + 0.05);
}
function Lo(d) {
  const s = $h(d), o = (u) => "#" + s.map((c) => Math.round(u >= 0 ? c + (255 - c) * u : c * (1 + u)).toString(16).padStart(2, "0")).join("");
  return Object.fromEntries([50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950].map((u, c) => [
    u,
    o([0.95, 0.9, 0.74, 0.54, 0.25, 0, -0.15, -0.3, -0.45, -0.6, -0.72][c])
  ]));
}
const eg = w.createContext({
  brand: "#6254df",
  radius: 16,
  density: "comfortable",
  fontFamily: "Vazirmatn, Tahoma, system-ui, sans-serif",
  locale: "fa-IR",
  dir: "rtl",
  digits: "fa",
  theme: "light",
  setTheme: () => {
  },
  resolvedTheme: "light"
});
function Go({ children: d, locale: s = "fa-IR", dir: o = s === "en-US" ? "ltr" : "rtl", digits: u = s === "fa-IR" ? "fa" : "latin", theme: c, defaultTheme: f = "light", onThemeChange: m, brand: h = "#6254df", radius: v = 16, fontFamily: j = "Vazirmatn, Tahoma, system-ui, sans-serif", density: x = "comfortable", storageKey: b, className: y }) {
  const [z, O] = w.useState(f), [E, R] = w.useState("light"), U = c ?? z;
  w.useEffect(() => {
    var G;
    const J = (G = window.matchMedia) == null ? void 0 : G.call(window, "(prefers-color-scheme: dark)");
    if (!J)
      return;
    const se = () => R(J.matches ? "dark" : "light");
    return se(), J.addEventListener("change", se), () => J.removeEventListener("change", se);
  }, []), w.useEffect(() => {
    if (!(!b || c !== void 0))
      try {
        const J = localStorage.getItem(b);
        (J === "light" || J === "dark" || J === "system") && O(J);
      } catch {
      }
  }, [b, c]);
  const H = (J) => {
    if (c === void 0 && O(J), m == null || m(J), b)
      try {
        localStorage.setItem(b, J);
      } catch {
      }
  }, V = U === "system" ? E : U, W = w.useMemo(() => {
    const J = Lo(h);
    return {
      "--pd-brand": h,
      "--pd-on-brand": ai(h, "#ffffff") >= ai(h, "#101725") ? "#ffffff" : "#101725",
      "--pd-font": j,
      "--pd-radius": `${Math.max(0, Math.min(40, v))}px`,
      ...Object.fromEntries(Object.entries(J).map(([se, G]) => [`--pd-brand-${se}`, G]))
    };
  }, [h, v, j]);
  return i.jsx(eg.Provider, { value: {
    locale: s,
    dir: o,
    digits: u,
    theme: U,
    setTheme: H,
    resolvedTheme: V,
    brand: h,
    radius: v,
    density: x,
    fontFamily: j
  }, children: i.jsx("div", { className: ["pd-root", y].filter(Boolean).join(" "), dir: o, lang: s, "data-pd-theme": V, "data-pd-density": x, style: W, children: d }) });
}
const be = () => w.useContext(eg), w0 = be;
function K(d, s) {
  return be().locale === "fa-IR" ? d : s;
}
const ue = w.forwardRef(function({ variant: s = "solid", size: o = "md", loading: u, startIcon: c, endIcon: f, fullWidth: m, className: h, disabled: v, children: j, onClick: x, type: b = "button", ...y }, z) {
  const O = K("در حال انجام", "Loading");
  return i.jsxs("button", { ref: z, type: b, className: ie("pd-button", `pd-button--${s}`, `pd-button--${o}`, m && "pd-full", h), disabled: v, "aria-disabled": v || u || void 0, "aria-busy": u || void 0, onClick: (E) => {
    if (u) {
      E.preventDefault();
      return;
    }
    x == null || x(E);
  }, ...y, children: [u ? i.jsx("span", { className: "pd-spinner", "aria-label": O }) : c, j, f] });
}), Ue = w.forwardRef(function({ icon: s, label: o, className: u, ...c }, f) {
  return i.jsx(ue, { ref: f, className: ie("pd-icon-button", u), "aria-label": o, ...c, children: i.jsx(_, { name: s }) });
});
function ii({ label: d, description: s, error: o, htmlFor: u, required: c, optional: f, className: m, children: h, ...v }) {
  const j = K("اختیاری", "Optional");
  return i.jsxs("div", { className: ie("pd-field", m), ...v, children: [d && i.jsxs("label", { className: "pd-label", htmlFor: u, children: [d, c && i.jsxs("span", { "aria-hidden": "true", className: "pd-required", children: [" ", "*"] }), f && i.jsx("small", { children: j })] }), h, s && i.jsx("div", { id: u ? `${u}-description` : void 0, className: "pd-description", children: s }), o && i.jsx("div", { id: u ? `${u}-error` : void 0, className: "pd-error", role: "alert", children: o })] });
}
const it = w.forwardRef(function({ label: s, description: o, error: u, startAdornment: c, endAdornment: f, id: m, className: h, wrapperClassName: v, required: j, disabled: x, "aria-describedby": b, ...y }, z) {
  const O = w.useId(), E = m ?? O;
  return i.jsx(ii, { htmlFor: E, label: s, description: o, error: u, required: j, className: v, children: i.jsxs("div", { className: ie("pd-input-wrap", !!u && "pd-invalid", x && "pd-disabled"), children: [c && i.jsx("span", { className: "pd-input-adornment", children: c }), i.jsx("input", { "data-pd-autofocus": y.autoFocus || void 0, ref: z, id: E, className: ie("pd-input", h), required: j, disabled: x, "aria-invalid": !!u || void 0, "aria-describedby": [b, o && `${E}-description`, u && `${E}-error`].filter(Boolean).join(" ") || void 0, ...y }), f && i.jsx("span", { className: "pd-input-adornment", children: f })] }) });
}), sr = w.forwardRef(function({ label: s, description: o, error: u, id: c, className: f, required: m, "aria-describedby": h, ...v }, j) {
  const x = w.useId(), b = c ?? x;
  return i.jsx(ii, { htmlFor: b, label: s, description: o, error: u, required: m, children: i.jsx("textarea", { ref: j, id: b, required: m, className: ie("pd-textarea", f), "aria-invalid": !!u || void 0, "aria-describedby": [h, o && `${b}-description`, u && `${b}-error`].filter(Boolean).join(" ") || void 0, ...v }) });
}), Aa = w.forwardRef(function({ label: s, description: o, error: u, options: c, placeholder: f, id: m, className: h, required: v, children: j, "aria-describedby": x, ...b }, y) {
  const z = w.useId(), O = m ?? z;
  return i.jsx(ii, { htmlFor: O, label: s, description: o, error: u, required: v, children: i.jsxs("div", { className: "pd-select-wrap", children: [i.jsxs("select", { ref: y, id: O, required: v, className: ie("pd-select", h), "aria-invalid": !!u || void 0, "aria-describedby": [x, o && `${O}-description`, u && `${O}-error`].filter(Boolean).join(" ") || void 0, ...b, children: [f && i.jsx("option", { value: "", disabled: !0, children: f }), c == null ? void 0 : c.map((E) => i.jsx("option", { value: E.value, disabled: E.disabled, children: E.label }, E.value)), j] }), i.jsx(_, { name: "chevronDown" })] }) });
}), rn = w.forwardRef(function({ label: s, description: o, error: u, indeterminate: c, id: f, className: m, ...h }, v) {
  const j = w.useId(), x = f ?? j;
  return i.jsxs("div", { className: "pd-field", children: [i.jsxs("label", { className: ie("pd-check", m), htmlFor: x, children: [i.jsx("input", { type: "checkbox", ref: (b) => {
    b && (b.indeterminate = !!c), typeof v == "function" ? v(b) : v && (v.current = b);
  }, id: x, "aria-invalid": !!u || void 0, "aria-describedby": [o && `${x}-description`, u && `${x}-error`].filter(Boolean).join(" ") || void 0, ...h }), i.jsxs("span", { children: [i.jsx("span", { children: s }), o && i.jsx("small", { id: `${x}-description`, children: o })] })] }), u && i.jsx("span", { className: "pd-error", id: `${x}-error`, role: "alert", children: u })] });
}), tg = w.forwardRef(function({ label: s, description: o, id: u, className: c, error: f, ...m }, h) {
  const v = w.useId(), j = u ?? v;
  return i.jsxs("div", { className: "pd-field", children: [i.jsxs("label", { className: ie("pd-switch", c), htmlFor: j, children: [i.jsx("input", { ref: h, type: "checkbox", role: "switch", id: j, "aria-invalid": !!f || void 0, "aria-describedby": o ? `${j}-description` : void 0, ...m }), i.jsx("span", { className: "pd-switch-track", "aria-hidden": "true" }), i.jsxs("span", { children: [s, o && i.jsx("small", { id: `${j}-description`, children: o })] })] }), f && i.jsx("span", { role: "alert", className: "pd-error", children: f })] });
});
function ag({ label: d, name: s, options: o, value: u, onChange: c, disabled: f }) {
  return i.jsxs("fieldset", { className: "pd-radio-group", disabled: f, children: [i.jsx("legend", { className: "pd-label", children: d }), o.map((m) => i.jsxs("label", { className: "pd-check", children: [i.jsx("input", { type: "radio", name: s, value: m.value, checked: u === m.value, onChange: () => c(m.value) }), i.jsxs("span", { children: [m.label, m.description && i.jsx("small", { children: m.description })] })] }, m.value))] });
}
function Ke({ tone: d = "neutral", dot: s, className: o, children: u, ...c }) {
  return i.jsxs("span", { className: ie("pd-badge", `pd-tone-${d}`, o), ...c, children: [s && i.jsx("i", { "aria-hidden": "true" }), u] });
}
function Ie({ className: d, ...s }) {
  return i.jsx("div", { className: ie("pd-card", d), ...s });
}
function N0({ className: d, ...s }) {
  return i.jsx("div", { className: ie("pd-card-header", d), ...s });
}
function T0({ className: d, ...s }) {
  return i.jsx("div", { className: ie("pd-card-body", d), ...s });
}
function E0({ className: d, ...s }) {
  return i.jsx("div", { className: ie("pd-card-footer", d), ...s });
}
function Vd({ tone: d = "info", title: s, children: o, onClose: u, className: c, ...f }) {
  const m = K("بستن", "Close");
  return i.jsxs("div", { role: d === "danger" ? "alert" : "status", className: ie("pd-alert", `pd-tone-${d}`, c), ...f, children: [i.jsx(_, { name: d === "success" ? "check" : d === "warning" ? "warning" : "info" }), i.jsxs("div", { children: [s && i.jsx("strong", { children: s }), o && i.jsx("div", { children: o })] }), u && i.jsx(Ue, { label: m, icon: "close", variant: "ghost", size: "sm", onClick: u })] });
}
function Ia({ name: d, src: s, size: o = "md", className: u }) {
  const [c, f] = w.useState(!1);
  return i.jsx("span", { className: ie("pd-avatar", `pd-avatar--${o}`, u), role: "img", "aria-label": d, children: s && !c ? i.jsx("img", { src: s, alt: "", onError: () => f(!0) }) : d.trim().split(/\s+/).slice(0, 2).map((m) => m[0]).join("") });
}
function C0({ names: d, max: s = 4 }) {
  return i.jsxs("div", { className: "pd-avatar-group", children: [d.slice(0, Math.max(1, s)).map((o, u) => i.jsx(Ia, { ...o }, u)), d.length > s && i.jsxs("span", { className: "pd-avatar pd-avatar--md", "aria-label": `${d.length - s} more`, children: ["+", d.length - s] })] });
}
function tn({ className: d, style: s, ...o }) {
  return i.jsx("span", { "aria-hidden": "true", className: ie("pd-skeleton", d), style: s, ...o });
}
function A0({ label: d }) {
  const s = K("در حال بارگذاری", "Loading");
  return i.jsx("span", { role: "status", "aria-label": d ?? s, className: "pd-spinner" });
}
function Pa({ value: d = 0, max: s = 100, label: o, className: u }) {
  const c = s > 0 ? s : 100, f = Math.max(0, Math.min(d, c));
  return i.jsx("div", { className: ie("pd-progress", u), role: "progressbar", "aria-label": o, "aria-valuenow": f, "aria-valuemin": 0, "aria-valuemax": c, children: i.jsx("span", { style: { width: `${f / c * 100}%` } }) });
}
const M0 = Pa;
function Cl({ title: d, description: s, icon: o = "box", action: u }) {
  return i.jsxs("div", { className: "pd-empty", children: [i.jsx("span", { className: "pd-empty-icon", children: i.jsx(_, { name: o, size: 28 }) }), i.jsx("strong", { children: d }), s && i.jsx("p", { children: s }), u] });
}
function O0({ label: d }) {
  return i.jsx("div", { className: "pd-divider", role: "separator", children: d && i.jsx("span", { children: d }) });
}
function D0({ children: d }) {
  return i.jsx("kbd", { className: "pd-kbd", children: d });
}
function q0({ children: d }) {
  return i.jsx("span", { className: "pd-sr-only", children: d });
}
function k0({ className: d, ...s }) {
  return i.jsx("div", { className: ie("pd-container", d), ...s });
}
function R0({ gap: d = 4, direction: s = "column", className: o, style: u, ...c }) {
  return i.jsx("div", { className: ie("pd-stack", o), style: { display: "flex", flexDirection: s, gap: `${d * 0.25}rem`, ...u }, ...c });
}
function U0({ min: d = 240, gap: s = 4, className: o, style: u, ...c }) {
  return i.jsx("div", { className: ie("pd-grid", o), style: {
    display: "grid",
    gridTemplateColumns: `repeat(auto-fit,minmax(min(100%,${d}px),1fr))`,
    gap: `${s * 0.25}rem`,
    ...u
  }, ...c });
}
const H0 = ({ className: d, ...s }) => i.jsx("div", { className: ie("pd-button-group", d), role: "group", ...s });
function dn({ open: d, onOpenChange: s, title: o, description: u, children: c, footer: f, size: m = "md", placement: h = "center", dismissible: v = !0, className: j }) {
  const x = w.useRef(null), b = w.useRef(null), y = w.useId(), z = Qo(s), O = K("بستن پنجره", "Close dialog");
  return w.useEffect(() => {
    var R, U;
    const E = x.current;
    E && (d && !E.open ? (b.current = nn(), E.showModal(), (R = Oo(E, "[data-pd-autofocus], [autofocus]")[0]) == null || R.focus()) : !d && E.open && (E.close(), (U = b.current) == null || U.focus()));
  }, [d]), w.useEffect(() => {
    const E = x.current;
    if (!E)
      return;
    const R = (U) => {
      if (U.key !== "Tab")
        return;
      const H = Oo(E, Xo).filter((J) => !J.closest("[hidden]") && J.getClientRects().length > 0), V = H[0], W = H.at(-1);
      if (!V) {
        U.preventDefault(), E.focus();
        return;
      }
      U.shiftKey && nn() === V ? (U.preventDefault(), W == null || W.focus()) : !U.shiftKey && nn() === W && (U.preventDefault(), V.focus());
    };
    return E.addEventListener("keydown", R), () => E.removeEventListener("keydown", R);
  }, []), i.jsxs("dialog", { ref: x, className: ie("pd-dialog", `pd-dialog--${m}`, `pd-dialog--${h}`, j), "aria-labelledby": `${y}-title`, "aria-describedby": u ? `${y}-desc` : void 0, onCancel: (E) => {
    E.preventDefault(), v && z.current(!1);
  }, onClose: () => z.current(!1), onClick: (E) => {
    if (!v || E.target !== x.current)
      return;
    const R = x.current.getBoundingClientRect();
    (E.clientX < R.left || E.clientX > R.right || E.clientY < R.top || E.clientY > R.bottom) && z.current(!1);
  }, children: [i.jsxs("div", { className: "pd-dialog-head", children: [i.jsxs("div", { children: [i.jsx("h2", { id: `${y}-title`, children: o }), u && i.jsx("p", { id: `${y}-desc`, children: u })] }), v && i.jsx(Ue, { label: O, icon: "close", variant: "ghost", size: "sm", onClick: () => s(!1) })] }), i.jsx("div", { className: "pd-dialog-body", children: c }), f && i.jsx("div", { className: "pd-dialog-footer", children: f })] });
}
function Ld(d) {
  return i.jsx(dn, { ...d, placement: d.placement ?? "end" });
}
function Gd({ trigger: d, children: s, label: o, open: u, onOpenChange: c, align: f = "start", className: m }) {
  const [h, v] = Wa(u, !1, c), [j, x] = w.useState({}), b = w.useRef(null), y = w.useRef(null), z = w.useRef(null), O = w.useId(), { dir: E } = be();
  return w.useEffect(() => {
    var H;
    if (!h)
      return;
    const R = () => {
      if (!b.current || !y.current)
        return;
      const V = b.current.getBoundingClientRect(), W = y.current.getBoundingClientRect();
      let J = f === "start" == (E === "ltr") ? V.left : V.right - W.width;
      J = Math.max(8, Math.min(J, window.innerWidth - W.width - 8));
      const se = V.bottom + W.height + 8 > window.innerHeight ? Math.max(8, V.top - W.height - 8) : V.bottom + 6;
      x({ left: J, top: se, maxHeight: Math.max(120, window.innerHeight - 16) });
    };
    R(), y.current && ((H = Oo(y.current, Xo)[0]) == null || H.focus());
    const U = (V) => {
      Vo(z.current, V) || v(!1);
    };
    return document.addEventListener("pointerdown", U), window.addEventListener("resize", R), window.addEventListener("scroll", R, !0), () => {
      document.removeEventListener("pointerdown", U), window.removeEventListener("resize", R), window.removeEventListener("scroll", R, !0);
    };
  }, [h, f, E]), i.jsxs("span", { ref: z, className: "pd-popover-anchor", children: [i.jsx("button", { ref: b, className: "pd-popover-trigger", type: "button", "aria-label": o, "aria-haspopup": "dialog", "aria-expanded": h, "aria-controls": h ? O : void 0, onClick: () => v(!h), children: d }), h && i.jsx("div", { id: O, role: "dialog", "aria-label": o, ref: y, className: ie("pd-popover", m), style: j, onKeyDown: (R) => {
    var U;
    R.key === "Escape" && (R.stopPropagation(), v(!1), (U = b.current) == null || U.focus());
  }, onBlur: (R) => {
    R.relatedTarget && !S0(z.current, R.relatedTarget) && v(!1);
  }, children: s })] });
}
function B0({ label: d, children: s }) {
  const o = w.useId(), [u, c] = w.useState(!1);
  return i.jsxs("span", { className: "pd-tooltip-wrap", tabIndex: 0, "aria-describedby": o, onFocus: () => c(!1), onMouseEnter: () => c(!1), onKeyDown: (f) => {
    f.key === "Escape" && (c(!0), f.stopPropagation());
  }, children: [s, i.jsx("span", { role: "tooltip", id: o, className: "pd-tooltip", hidden: u, children: d })] });
}
function lg({ trigger: d, label: s, items: o }) {
  const [u, c] = w.useState(!1);
  return i.jsx(Gd, { trigger: d, label: s, open: u, onOpenChange: c, children: i.jsx("div", { className: "pd-menu", role: "menu", "aria-label": s, onKeyDown: (f) => {
    var v;
    const m = Array.from(f.currentTarget.querySelectorAll("button:not(:disabled)")), h = m.indexOf(nn());
    ["ArrowDown", "ArrowUp", "Home", "End"].includes(f.key) && (f.preventDefault(), (v = m[f.key === "Home" ? 0 : f.key === "End" ? m.length - 1 : (h + (f.key === "ArrowDown" ? 1 : -1) + m.length) % m.length]) == null || v.focus());
  }, children: o.map((f) => i.jsxs("button", { type: "button", role: "menuitem", disabled: f.disabled, className: ie("pd-menu-item", f.danger && "pd-text-danger"), onClick: () => {
    f.onSelect(), c(!1);
  }, children: [f.icon, f.label] }, f.id)) }) });
}
const ng = w.createContext({
  toast: () => {
    throw new Error("Wrap your app in ToastProvider");
  },
  dismiss: () => {
  }
});
function Y0({ item: d, dismiss: s }) {
  const o = w.useRef(d.duration ?? 5e3), u = w.useRef(0), [c, f] = w.useState(!1), m = K("بستن اعلان", "Dismiss notification");
  return w.useEffect(() => {
    if (c || o.current === 1 / 0)
      return;
    u.current = Date.now();
    const h = setTimeout(s, Math.max(0, o.current));
    return () => {
      clearTimeout(h), o.current -= Date.now() - u.current;
    };
  }, [c, s]), i.jsxs("div", { className: ie("pd-toast", `pd-tone-${d.tone ?? "info"}`), onMouseEnter: () => f(!0), onMouseLeave: () => f(!1), onFocusCapture: () => f(!0), onBlurCapture: (h) => {
    h.currentTarget.contains(h.relatedTarget) || f(!1);
  }, children: [i.jsx(_, { name: d.tone === "success" ? "check" : d.tone === "danger" ? "warning" : "info" }), i.jsxs("div", { children: [i.jsx("strong", { children: d.title }), d.description && i.jsx("p", { children: d.description }), d.action && i.jsx(ue, { variant: "ghost", size: "sm", onClick: () => {
    d.action.onClick(), s();
  }, children: d.action.label })] }), i.jsx(Ue, { label: m, icon: "close", variant: "ghost", size: "sm", onClick: s })] });
}
function ig({ children: d, max: s = 5 }) {
  const [o, u] = w.useState([]), c = w.useRef(0), f = (h) => u((v) => v.filter((j) => j.id !== h)), m = (h) => {
    const v = ++c.current;
    return u((j) => [...j, { ...h, id: v }].slice(-s)), v;
  };
  return i.jsxs(ng.Provider, { value: { toast: m, dismiss: f }, children: [d, i.jsx("div", { className: "pd-toaster", "aria-live": "polite", "aria-relevant": "additions", children: i.jsx("div", { className: "pd-toast-list", children: o.map((h) => i.jsx(Y0, { item: h, dismiss: () => f(h.id) }, h.id)) }) })] });
}
const Q0 = () => w.useContext(ng);
function X0({ open: d, onOpenChange: s, title: o, description: u, onConfirm: c, danger: f, loading: m }) {
  const h = K({ cancel: "انصراف", confirm: "تأیید" }, { cancel: "Cancel", confirm: "Confirm" });
  return i.jsx(dn, { open: d, onOpenChange: s, title: o, footer: i.jsxs(i.Fragment, { children: [i.jsx(ue, { variant: "outline", onClick: () => s(!1), children: h.cancel }), i.jsx(ue, { variant: f ? "danger" : "solid", loading: m, onClick: () => void c(), children: h.confirm })] }), children: u });
}
function Zo({ value: d, onValueChange: s, defaultMonth: o, min: u, max: c, isDateDisabled: f, range: m, autoFocus: h, footer: v }) {
  const j = _t(/* @__PURE__ */ new Date()), x = d ?? o ?? j, [b, y] = w.useState(() => ha(x)), [z, O] = w.useState(x), E = w.useRef(null), R = w.useId(), { locale: U, digits: H, dir: V } = be(), W = K({ prev: "ماه قبل", next: "ماه بعد", month: "ماه", year: "سال" }, { prev: "Previous month", next: "Next month", month: "Month", year: "Year" }), J = nr(b.year, b.month, 1), se = b0(b.year, b.month), G = (J.getDay() + 1) % 7, X = an(J, -G), me = { min: u, max: c, isDateDisabled: f };
  w.useEffect(() => {
    d && (y(ha(d)), O(d));
  }, [d == null ? void 0 : d.getTime()]), w.useEffect(() => {
    var L, P;
    h && ((P = (L = E.current) == null ? void 0 : L.querySelector('button[tabindex="0"]')) == null || P.focus());
  }, [h]);
  const pe = (L) => {
    let P = b.year, re = b.month + L;
    re < 1 && (P--, re = 12), re > 12 && (P++, re = 1), P >= 1200 && P <= 1600 && y({ year: P, month: re, day: 1 });
  }, $ = an(J, se - 1), ce = b.year === 1200 && b.month === 1 || !!u && J <= _t(u), I = b.year === 1600 && b.month === 12 || !!c && $ >= _t(c), De = (L) => {
    const P = ha(L);
    P.year < 1200 || P.year > 1600 || (O(L), (P.year !== b.year || P.month !== b.month) && y(P), requestAnimationFrame(() => {
      var re, Ce;
      return (Ce = (re = E.current) == null ? void 0 : re.querySelector(`button[data-date="${Ja(L)}"]`)) == null ? void 0 : Ce.focus();
    }));
  }, Ee = ha(z).year === b.year && ha(z).month === b.month;
  return i.jsxs("div", { className: "pd-calendar", children: [i.jsxs("div", { className: "pd-calendar-head", children: [i.jsx(Ue, { label: W.prev, icon: V === "rtl" ? "chevronRight" : "chevronLeft", variant: "ghost", size: "sm", disabled: ce, onClick: () => pe(-1) }), i.jsxs("strong", { "aria-live": "polite", id: `${R}-title`, children: [Qd[b.month - 1], " ", ke(b.year, { useGrouping: !1 }, U)] }), i.jsx(Ue, { label: W.next, icon: V === "rtl" ? "chevronLeft" : "chevronRight", variant: "ghost", size: "sm", disabled: I, onClick: () => pe(1) })] }), i.jsxs("div", { className: "pd-calendar-selects", children: [i.jsx(Aa, { "aria-label": W.month, value: String(b.month), onChange: (L) => y((P) => ({ ...P, month: Number(L.target.value) })), options: Qd.map((L, P) => ({ label: L, value: String(P + 1) })) }), i.jsx(Aa, { "aria-label": W.year, value: String(b.year), onChange: (L) => y((P) => ({ ...P, year: Number(L.target.value) })), options: Array.from({
    length: Math.min(1600, c ? ha(c).year : b.year + 100) - Math.max(1200, u ? ha(u).year : b.year - 100) + 1
  }, (L, P) => {
    const re = Math.max(1200, u ? ha(u).year : b.year - 100) + P;
    return {
      label: ke(re, { useGrouping: !1 }, U),
      value: String(re)
    };
  }) })] }), i.jsxs("table", { ref: E, role: "grid", "aria-labelledby": `${R}-title`, children: [i.jsx("thead", { children: i.jsx("tr", { children: h0.map((L) => i.jsx("th", { scope: "col", abbr: L, children: L.slice(0, 1) }, L)) }) }), i.jsx("tbody", { children: Array.from({ length: Math.ceil((G + se) / 7) }, (L, P) => i.jsx("tr", { children: Array.from({ length: 7 }, (re, Ce) => {
    const he = an(X, P * 7 + Ce), ge = ha(he), We = ge.month !== b.month, St = !We && ln(he, me), N = lr(d, he), Q = (m == null ? void 0 : m.start) && (m == null ? void 0 : m.end) && he >= _t(m.start) && he <= _t(m.end);
    return i.jsx("td", { role: "gridcell", "aria-selected": N || lr(m == null ? void 0 : m.start, he) || lr(m == null ? void 0 : m.end, he), "data-range": Q || void 0, children: i.jsx("button", { type: "button", "data-date": Ja(he), "data-outside": We || void 0, "aria-label": Tl(he, "long", H), "aria-disabled": !St || void 0, "aria-current": lr(he, j) ? "date" : void 0, tabIndex: !We && (lr(he, z) || !Ee && ge.day === 1) ? 0 : -1, onFocus: () => O(he), onClick: () => St && (s == null ? void 0 : s(he)), onKeyDown: (te) => {
      const ae = {
        ArrowLeft: V === "rtl" ? 1 : -1,
        ArrowRight: V === "rtl" ? -1 : 1,
        ArrowUp: -7,
        ArrowDown: 7
      };
      ae[te.key] ? (te.preventDefault(), De(an(he, ae[te.key]))) : te.key === "Home" ? (te.preventDefault(), De(J)) : te.key === "End" && (te.preventDefault(), De($));
    }, children: H === "fa" ? ke(ge.day, {}, "fa-IR") : ge.day }) }, Ce);
  }) }, P)) })] }), v && i.jsx("div", { className: "pd-calendar-footer", children: v })] });
}
function V0({ value: d, defaultValue: s = null, onValueChange: o, min: u, max: c, isDateDisabled: f, label: m, name: h, disabled: v, readOnly: j, error: x, onBlur: b, ...y }) {
  const [z, O] = Wa(d, s, o), { digits: E } = be(), [R, U] = w.useState(z ? Tl(z, "numeric", E) : ""), [H, V] = w.useState(!1), [W, J] = w.useState(!1), se = w.useRef(null), G = K({
    open: "انتخاب تاریخ",
    today: "امروز",
    clear: "پاک کردن",
    invalid: "تاریخ نامعتبر یا خارج از محدوده است."
  }, {
    open: "Choose a date",
    today: "Today",
    clear: "Clear",
    invalid: "Invalid or unavailable date."
  }), X = { min: u, max: c, isDateDisabled: f };
  w.useEffect(() => {
    var $;
    U(z ? Tl(z, "numeric", E) : ""), V(!1), ($ = se.current) == null || $.setCustomValidity("");
  }, [z == null ? void 0 : z.getTime(), E]);
  const me = ($) => {
    var ce;
    return $ && !ln($, X) ? !1 : (O($), U($ ? Tl($, "numeric", E) : ""), V(!1), (ce = se.current) == null || ce.setCustomValidity(""), !0);
  }, pe = () => {
    var I;
    const $ = R.trim() ? Uh(R) : null, ce = !R.trim() || !!$ && ln($, X);
    return V(!ce), (I = se.current) == null || I.setCustomValidity(ce ? "" : G.invalid), ce && me($), ce;
  };
  return i.jsxs(i.Fragment, { children: [i.jsx(it, { ...y, ref: se, label: m, disabled: v, readOnly: j, dir: "ltr", value: R, placeholder: y.placeholder ?? "۱۴۰۵/۰۸/۱۰", error: x ?? (H ? G.invalid : void 0), onChange: ($) => {
    var I;
    U($.target.value);
    const ce = Uh($.target.value);
    (I = se.current) == null || I.setCustomValidity($.target.value.trim() && (!ce || !ln(ce, X)) ? G.invalid : "");
  }, onBlur: ($) => {
    pe(), b == null || b($);
  }, onKeyDown: ($) => {
    var ce;
    (ce = y.onKeyDown) == null || ce.call(y, $), $.key === "Enter" && !pe() && $.preventDefault();
  }, endAdornment: i.jsx(Ue, { icon: "calendar", label: G.open, size: "sm", variant: "ghost", disabled: v || j, onClick: () => J(!0) }) }), h && i.jsx("input", { type: "hidden", name: h, value: z ? Ja(z) : "", disabled: v }), i.jsx(dn, { open: W, onOpenChange: J, title: typeof m == "string" ? m : G.open, size: "sm", children: i.jsx(Zo, { value: z, ...X, autoFocus: !0, onValueChange: ($) => {
    me($) && J(!1);
  }, footer: i.jsxs(i.Fragment, { children: [i.jsx(ue, { variant: "ghost", size: "sm", disabled: !ln(/* @__PURE__ */ new Date(), X), onClick: () => {
    me(_t(/* @__PURE__ */ new Date())) && J(!1);
  }, children: G.today }), i.jsx(ue, { variant: "ghost", size: "sm", onClick: () => {
    me(null), J(!1);
  }, children: G.clear })] }) }) })] });
}
const rg = [
  { label: "۷ روز اخیر", range: (d) => ({ start: an(d, -6), end: d }) },
  { label: "۳۰ روز اخیر", range: (d) => ({ start: an(d, -29), end: d }) },
  {
    label: "این ماه",
    range: (d) => {
      const s = ha(d);
      return { start: nr(s.year, s.month, 1), end: d };
    }
  }
];
function L0({ label: d, value: s, onValueChange: o, min: u, max: c, isDateDisabled: f, presets: m = rg, disabled: h, name: v }) {
  const [j, x] = w.useState(!1), [b, y] = w.useState(s), z = K({
    placeholder: "انتخاب بازه",
    apply: "اعمال بازه",
    cancel: "انصراف",
    end: "تاریخ پایان را انتخاب کنید."
  }, {
    placeholder: "Select range",
    apply: "Apply range",
    cancel: "Cancel",
    end: "Choose the end date."
  }), O = { min: u, max: c, isDateDisabled: f }, E = !!b.start && !!b.end && Hh(b.start, b.end, O), { digits: R } = be(), U = _t(/* @__PURE__ */ new Date());
  return i.jsxs(i.Fragment, { children: [i.jsxs("div", { className: "pd-field", children: [i.jsx("span", { className: "pd-label", children: d }), i.jsx(ue, { variant: "outline", fullWidth: !0, disabled: h, startIcon: i.jsx(_, { name: "calendar" }), onClick: () => {
    y(s), x(!0);
  }, children: s.start && s.end ? `${Tl(s.start, "numeric", R)} — ${Tl(s.end, "numeric", R)}` : z.placeholder })] }), v && i.jsxs(i.Fragment, { children: [i.jsx("input", { type: "hidden", name: `${v}_start`, value: s.start ? Ja(s.start) : "", disabled: h }), i.jsx("input", { type: "hidden", name: `${v}_end`, value: s.end ? Ja(s.end) : "", disabled: h })] }), i.jsxs(dn, { open: j, onOpenChange: x, title: d, size: "sm", footer: i.jsxs(i.Fragment, { children: [i.jsx(ue, { variant: "outline", onClick: () => x(!1), children: z.cancel }), i.jsx(ue, { disabled: !E, onClick: () => {
    E && (o(b), x(!1));
  }, children: z.apply })] }), children: [i.jsx("div", { className: "pd-range-presets", children: m.map((H) => {
    const V = H.range(U);
    return i.jsx(ue, { size: "sm", variant: "soft", disabled: !Hh(V.start, V.end, O), onClick: () => y(V), children: H.label }, H.label);
  }) }), i.jsx(Zo, { value: b.end ?? b.start, range: b, ...O, autoFocus: !0, onValueChange: (H) => y(!b.start || b.end ? { start: H, end: null } : H < b.start ? { start: H, end: b.start } : { start: b.start, end: H }) }), i.jsx("p", { className: "pd-description", "aria-live": "polite", children: b.start && !b.end ? z.end : b.start && b.end ? `${Tl(b.start)} — ${Tl(b.end)}` : "" })] })] });
}
function G0({ label: d, value: s, onValueChange: o, minYear: u = 1300, maxYear: c = 1500 }) {
  const { locale: f } = be();
  return i.jsxs("fieldset", { className: "pd-month-picker", children: [i.jsx("legend", { className: "pd-label", children: d }), i.jsx(Aa, { "aria-label": f === "fa-IR" ? "سال" : "Year", value: String(s.year), onChange: (m) => o({ ...s, year: Number(m.target.value) }), options: Array.from({ length: Math.max(0, c - u + 1) }, (m, h) => ({
    value: String(u + h),
    label: ke(u + h, { useGrouping: !1 }, f)
  })) }), i.jsx("div", { children: Qd.map((m, h) => i.jsx(ue, { variant: s.month === h + 1 ? "solid" : "ghost", "aria-pressed": s.month === h + 1, onClick: () => o({ ...s, month: h + 1 }), children: m }, m)) })] });
}
function dg({ label: d, ...s }) {
  const [o, u] = w.useState(!1), c = K({ show: "نمایش رمز", hide: "پنهان کردن رمز" }, { show: "Show password", hide: "Hide password" });
  return i.jsx(it, { ...s, label: d, type: o ? "text" : "password", endAdornment: i.jsx(Ue, { label: o ? c.hide : c.show, icon: "eye", variant: "ghost", size: "sm", "aria-pressed": o, disabled: s.disabled, onClick: () => u((f) => !f) }) });
}
function Z0({ value: d }) {
  const s = K({ label: "قدرت رمز عبور", levels: ["وارد نشده", "ضعیف", "متوسط", "خوب", "قوی"] }, { label: "Password strength", levels: ["Empty", "Weak", "Fair", "Good", "Strong"] }), o = d ? +(d.length >= 8) + +(d.length >= 12) + Number(/[a-z]/.test(d) && /[A-Z]/.test(d)) + Number(/\d/.test(d) && /[^a-z\d]/i.test(d)) : 0;
  return i.jsxs("div", { className: "pd-password-strength", children: [i.jsx(Pa, { label: s.label, value: o, max: 4 }), i.jsx("small", { children: s.levels[d ? Math.max(1, o) : 0] })] });
}
function K0({ value: d, onValueChange: s, ...o }) {
  return i.jsx(it, { ...o, type: "time", value: $t(d), onChange: (u) => s(u.target.value) });
}
function Zd({ value: d, label: s, onError: o }) {
  const [u, c] = w.useState(!1), f = K({ copy: "کپی", done: "کپی شد" }, { copy: "Copy", done: "Copied" });
  return w.useEffect(() => {
    if (u) {
      const m = setTimeout(() => c(!1), 2e3);
      return () => clearTimeout(m);
    }
  }, [u]), i.jsx(ue, { variant: "outline", size: "sm", startIcon: i.jsx(_, { name: u ? "check" : "copy", size: 16 }), onClick: async () => {
    try {
      await navigator.clipboard.writeText(d), c(!0);
    } catch (m) {
      o == null || o(m);
    }
  }, children: i.jsx("span", { role: "status", children: u ? f.done : s ?? f.copy }) });
}
function J0({ label: d, value: s, change: o, description: u, icon: c, sparkline: f }) {
  const { locale: m } = be();
  return i.jsxs(Ie, { className: "pd-stat", children: [i.jsxs("div", { className: "pd-stat-label", children: [d, c && i.jsx("span", { children: c })] }), i.jsx("strong", { className: "pd-stat-value", children: s }), i.jsxs("div", { className: "pd-stat-foot", children: [o !== void 0 && i.jsxs("span", { className: ie("pd-stat-change", o >= 0 ? "pd-text-success" : "pd-text-danger"), children: [o > 0 ? "+" : "", ke(o, {}, m), "٪"] }), u && i.jsx("small", { children: u })] }), f] });
}
function F0({ date: d, refresh: s = 6e4 }) {
  const [o, u] = w.useState(null), { locale: c } = be();
  return w.useEffect(() => {
    u(/* @__PURE__ */ new Date());
    const f = setInterval(() => u(/* @__PURE__ */ new Date()), Math.max(1e3, s));
    return () => clearInterval(f);
  }, [s]), i.jsx("time", { dateTime: d.toISOString(), title: d.toLocaleString(c), children: o ? z0(d, o, c) : d.toLocaleDateString(c) });
}
function W0({ until: d, label: s, onComplete: o }) {
  const [u, c] = w.useState(null), { locale: f } = be();
  w.useEffect(() => {
    let h = !1;
    const v = () => {
      const x = Math.max(0, Math.ceil((d.getTime() - Date.now()) / 1e3));
      c(x), x === 0 && !h && (h = !0, o == null || o());
    };
    v();
    const j = setInterval(v, 1e3);
    return () => clearInterval(j);
  }, [d.getTime(), o]);
  const m = u === null ? [] : [
    Math.floor(u / 86400),
    Math.floor(u / 3600) % 24,
    Math.floor(u / 60) % 60,
    u % 60
  ];
  return i.jsx("span", { className: "pd-countdown", role: "timer", "aria-label": s, dir: "ltr", children: m.length ? m.map((h) => ke(h, { minimumIntegerDigits: 2, useGrouping: !1 }, f)).join(" : ") : "—" });
}
function I0({ value: d, onValueChange: s, label: o }) {
  const u = w.useId();
  return i.jsxs("div", { className: "pd-color-picker", children: [i.jsx("label", { className: "pd-label", htmlFor: u, children: o }), i.jsx("input", { id: u, type: "color", value: d, onChange: (c) => s(c.target.value) }), i.jsx("code", { children: d })] });
}
function P0({ items: d, label: s }) {
  const [o, u] = w.useState(0), { dir: c } = be(), f = K({ next: "مورد بعد", prev: "مورد قبل" }, { next: "Next slide", prev: "Previous slide" });
  return d.length ? i.jsxs("section", { className: "pd-carousel", "aria-label": s, "aria-roledescription": "carousel", children: [i.jsx("div", { "aria-live": "polite", children: d[o % d.length] }), i.jsxs("div", { className: "pd-carousel-controls", children: [i.jsx(Ue, { icon: c === "rtl" ? "chevronRight" : "chevronLeft", variant: "outline", size: "sm", label: f.prev, onClick: () => u((m) => (m - 1 + d.length) % d.length) }), i.jsxs("span", { children: [o + 1, " / ", d.length] }), i.jsx(Ue, { icon: c === "rtl" ? "chevronLeft" : "chevronRight", variant: "outline", size: "sm", label: f.next, onClick: () => u((m) => (m + 1) % d.length) })] })] }) : null;
}
function _0({ value: d, onSave: s, label: o }) {
  const [u, c] = w.useState(!1), [f, m] = w.useState(d), [h, v] = w.useState(!1), [j, x] = w.useState(""), b = K({ save: "ذخیره", cancel: "انصراف", edit: "ویرایش", error: "ذخیره انجام نشد." }, { save: "Save", cancel: "Cancel", edit: "Edit", error: "Could not save." });
  return u ? i.jsxs("form", { className: "pd-inline-edit", onSubmit: async (y) => {
    y.preventDefault(), v(!0), x("");
    try {
      await s(f), c(!1);
    } catch (z) {
      x(z instanceof Error ? z.message : b.error);
    } finally {
      v(!1);
    }
  }, children: [i.jsx(it, { autoFocus: !0, "aria-label": o, value: f, onChange: (y) => m(y.target.value), error: j || void 0 }), i.jsx(ue, { type: "submit", size: "sm", loading: h, children: b.save }), i.jsx(ue, { variant: "ghost", size: "sm", disabled: h, onClick: () => c(!1), children: b.cancel })] }) : i.jsx(ue, { variant: "ghost", endIcon: i.jsx(_, { name: "edit", size: 14 }), "aria-label": `${b.edit}: ${o}`, onClick: () => {
    m(d), c(!0);
  }, children: d || o });
}
function $0({ label: d, options: s, value: o, defaultValue: u = "", onValueChange: c, placeholder: f, disabled: m, loading: h, error: v, name: j, onSearchChange: x, filter: b = !0, clearable: y, required: z }) {
  const [O, E] = Wa(o, u, c), [R, U] = w.useState(""), [H, V] = w.useState(!1), [W, J] = w.useState(-1), se = w.useId(), G = w.useRef(null), X = w.useRef(null), me = K({ empty: "نتیجه‌ای پیدا نشد", loading: "در حال جست‌وجو", clear: "پاک کردن" }, { empty: "No results", loading: "Searching", clear: "Clear" }), pe = s.find((I) => I.value === O), $ = b ? s.filter((I) => Bt(I.label).includes(Bt(R))) : s;
  w.useEffect(() => {
    if (!H)
      return;
    const I = (De) => {
      Vo(G.current, De) || (V(!1), U(""));
    };
    return document.addEventListener("pointerdown", I), () => document.removeEventListener("pointerdown", I);
  }, [H]), w.useEffect(() => {
    J(-1);
  }, [R]);
  const ce = (I) => {
    var De;
    I.disabled || (E(I.value), V(!1), U(""), (De = X.current) == null || De.focus());
  };
  return i.jsxs("div", { ref: G, className: "pd-combobox", children: [i.jsx(it, { ref: X, label: d, error: v, role: "combobox", "aria-autocomplete": "list", "aria-expanded": H, "aria-controls": `${se}-list`, "aria-activedescendant": H && W >= 0 ? `${se}-${W}` : void 0, autoComplete: "off", disabled: m, required: z, placeholder: f, value: H ? R : (pe == null ? void 0 : pe.label) ?? "", startAdornment: i.jsx(_, { name: "search", size: 18 }), endAdornment: y && O ? i.jsx(Ue, { icon: "close", label: me.clear, variant: "ghost", size: "sm", disabled: m, onClick: () => {
    var I;
    E(""), U(""), (I = X.current) == null || I.focus();
  } }) : i.jsx(_, { name: "chevronDown", size: 16 }), onFocus: () => {
    V(!0), U("");
  }, onChange: (I) => {
    U(I.target.value), V(!0), x == null || x(I.target.value);
  }, onKeyDown: (I) => {
    if (I.key === "Escape")
      V(!1), U(""), I.stopPropagation();
    else if (I.key === "ArrowDown" || I.key === "ArrowUp") {
      I.preventDefault(), V(!0);
      const De = $.map((L, P) => L.disabled ? -1 : P).filter((L) => L >= 0), Ee = De.indexOf(W);
      J(De[(Ee + (I.key === "ArrowDown" ? 1 : -1) + De.length) % De.length] ?? -1);
    } else I.key === "Enter" && H && W >= 0 && (I.preventDefault(), ce($[W]));
  }, onBlur: (I) => {
    var De;
    (De = G.current) != null && De.contains(I.relatedTarget) || (V(!1), U(""));
  } }), j && i.jsx("input", { type: "hidden", name: j, value: O, disabled: m }), i.jsx("ul", { className: "pd-options", id: `${se}-list`, role: "listbox", "aria-label": d, hidden: !H, "aria-busy": h || void 0, children: h ? i.jsx("li", { role: "presentation", className: "pd-options-empty", children: me.loading }) : $.length ? $.map((I, De) => i.jsxs("li", { id: `${se}-${De}`, role: "option", "aria-selected": I.value === O, "aria-disabled": I.disabled || void 0, "data-active": W === De || void 0, onMouseDown: (Ee) => Ee.preventDefault(), onClick: () => ce(I), onPointerMove: () => !I.disabled && J(De), children: [i.jsxs("span", { children: [I.label, I.description && i.jsx("small", { children: I.description })] }), I.value === O && i.jsx(_, { name: "check", size: 16 })] }, I.value)) : i.jsx("li", { role: "presentation", className: "pd-options-empty", children: me.empty }) })] });
}
function e1({ label: d, options: s, value: o, onValueChange: u, max: c, disabled: f, name: m }) {
  const [h, v] = w.useState(""), j = K("جست‌وجو", "Search");
  return i.jsxs("fieldset", { className: "pd-multiselect", disabled: f, children: [i.jsx("legend", { className: "pd-label", children: d }), i.jsx(it, { "aria-label": j, placeholder: j, value: h, onChange: (x) => v(x.target.value), startAdornment: i.jsx(_, { name: "search" }) }), i.jsx("div", { className: "pd-multiselect-options", children: s.filter((x) => Bt(x.label).includes(Bt(h))).map((x) => i.jsx(rn, { label: x.label, checked: o.includes(x.value), disabled: x.disabled || !o.includes(x.value) && c !== void 0 && o.length >= c, onChange: () => u(o.includes(x.value) ? o.filter((b) => b !== x.value) : [...o, x.value]) }, x.value)) }), m && o.map((x) => i.jsx("input", { type: "hidden", name: m, value: x, disabled: f }, x))] });
}
function t1({ label: d, value: s, onValueChange: o, placeholder: u, max: c, disabled: f }) {
  const [m, h] = w.useState(""), v = K("حذف", "Remove"), j = () => {
    const x = m.trim();
    x && !s.includes(x) && (c === void 0 || s.length < c) && (o([...s, x]), h(""));
  };
  return i.jsx(ii, { label: d, children: i.jsxs("div", { className: "pd-tag-input", children: [s.map((x) => i.jsxs("span", { className: "pd-tag", children: [x, i.jsx("button", { type: "button", disabled: f, "aria-label": `${v} ${x}`, onClick: () => o(s.filter((b) => b !== x)), children: i.jsx(_, { name: "close", size: 14 }) })] }, x)), i.jsx("input", { "aria-label": d, value: m, disabled: f || c !== void 0 && s.length >= c, placeholder: u, onChange: (x) => h(x.target.value), onKeyDown: (x) => {
    x.key === "Enter" || x.key === "," ? (x.preventDefault(), j()) : x.key === "Backspace" && !m && o(s.slice(0, -1));
  }, onBlur: j })] }) });
}
function Ko({ label: d, value: s, onValueChange: o, min: u = -1 / 0, max: c = 1 / 0, step: f = 1, name: m, disabled: h }) {
  const v = K({ minus: "کاهش", plus: "افزایش" }, { minus: "Decrease", plus: "Increase" }), j = (x) => {
    Number.isFinite(x) && o(Math.min(c, Math.max(u, x)));
  };
  return i.jsx(it, { label: d, type: "number", name: m, value: s, min: Number.isFinite(u) ? u : void 0, max: Number.isFinite(c) ? c : void 0, step: f, disabled: h, onChange: (x) => j(x.target.valueAsNumber), startAdornment: i.jsx(Ue, { icon: "minus", label: `${v.minus} ${d}`, variant: "ghost", size: "sm", disabled: h || s <= u, onClick: () => j(s - f) }), endAdornment: i.jsx(Ue, { icon: "plus", label: `${v.plus} ${d}`, variant: "ghost", size: "sm", disabled: h || s >= c, onClick: () => j(s + f) }) });
}
function a1({ label: d, value: s, onValueChange: o, min: u = 0, max: c = 100, step: f = 1, disabled: m, name: h }) {
  const v = w.useId(), { locale: j } = be();
  return i.jsx(ii, { htmlFor: v, label: i.jsxs(i.Fragment, { children: [d, i.jsx("span", { className: "pd-field-value", children: ke(s, {}, j) })] }), children: i.jsx("input", { id: v, className: "pd-slider", type: "range", value: s, min: u, max: c, step: f, disabled: m, name: h, onChange: (x) => o(x.target.valueAsNumber) }) });
}
function ri({ value: d, max: s = 5, onValueChange: o, label: u, readonly: c = !1 }) {
  const f = w.useId();
  return c ? i.jsxs("span", { className: "pd-rating", role: "img", "aria-label": `${u}: ${d} / ${s}`, children: [i.jsx(_, { name: "star", fill: "currentColor", size: 16 }), i.jsx("span", { children: d.toFixed(1) })] }) : i.jsxs("fieldset", { className: "pd-rating-input", children: [i.jsx("legend", { className: "pd-label", children: u }), Array.from({ length: s }, (m, h) => i.jsxs("label", { "data-selected": d >= h + 1 || void 0, children: [i.jsx("input", { type: "radio", name: f, "aria-label": `${h + 1} / ${s}`, value: h + 1, checked: d === h + 1, onChange: () => o == null ? void 0 : o(h + 1) }), i.jsx(_, { name: "star", fill: d >= h + 1 ? "currentColor" : "none" })] }, h))] });
}
function l1({ label: d, options: s, value: o, onValueChange: u, multiple: c = !0 }) {
  return i.jsx("div", { className: "pd-chip-group", role: "group", "aria-label": d, children: s.map((f) => i.jsx(ue, { variant: o.includes(f.value) ? "soft" : "outline", size: "sm", "aria-pressed": o.includes(f.value), disabled: f.disabled, onClick: () => u(o.includes(f.value) ? o.filter((m) => m !== f.value) : c ? [...o, f.value] : [f.value]), children: f.label }, f.value)) });
}
function n1({ label: d, value: s, onValueChange: o, length: u = 6, name: c, disabled: f, autoFocus: m, onComplete: h }) {
  const { digits: v } = be();
  return i.jsx(it, { label: d, name: c, disabled: f, autoFocus: m, dir: "ltr", autoComplete: "one-time-code", inputMode: "numeric", maxLength: u, className: "pd-otp", value: v === "fa" ? Yo(s) : s, onChange: (j) => {
    const x = $t(j.target.value).replace(/\D/g, "").slice(0, u);
    o(x), x.length === u && (h == null || h(x));
  } });
}
function di({ kind: d, value: s, defaultValue: o = "", onValueChange: u, name: c, disabled: f, error: m, onBlur: h, ...v }) {
  const [j, x] = Wa(s, o), [b, y] = w.useState(!1), { digits: z } = be(), O = K({
    mobile: "شماره موبایل معتبر نیست.",
    nationalId: "کد ملی معتبر نیست.",
    card: "شماره کارت معتبر نیست.",
    iban: "شماره شبا معتبر نیست.",
    postalCode: "کد پستی معتبر نیست."
  }, {
    mobile: "Invalid mobile number.",
    nationalId: "Invalid national ID.",
    card: "Invalid card number.",
    iban: "Invalid IBAN.",
    postalCode: "Invalid postal code."
  }), E = {
    mobile: Mo,
    nationalId: Bh,
    card: Yh,
    iban: Qh,
    postalCode: Xh
  }[d](j);
  let R = d === "card" ? v0(j) : j;
  return z === "fa" && d !== "iban" && (R = Yo(R)), i.jsxs(i.Fragment, { children: [i.jsx(it, { ...v, disabled: f, error: m ?? (b && j && !E ? O[d] : void 0), inputMode: d === "iban" ? "text" : "numeric", dir: "ltr", autoComplete: d === "mobile" ? "tel-national" : d === "card" ? "cc-number" : "off", value: R, onChange: (U) => {
    let H = $t(U.target.value);
    H = d === "iban" ? H.replace(/[^a-z\d]/gi, "").toUpperCase().slice(0, 26) : d === "mobile" ? Ph(H).slice(0, 11) : H.replace(/\D/g, "").slice(0, d === "card" ? 16 : 10), x(H), u == null || u(H, {
      mobile: Mo,
      nationalId: Bh,
      card: Yh,
      iban: Qh,
      postalCode: Xh
    }[d](H));
  }, onBlur: (U) => {
    y(!0), h == null || h(U);
  } }), c && i.jsx("input", { type: "hidden", name: c, value: j, disabled: f })] });
}
const sg = (d) => i.jsx(di, { kind: "mobile", ...d }), i1 = (d) => i.jsx(di, { kind: "nationalId", ...d }), r1 = (d) => i.jsx(di, { kind: "card", ...d }), d1 = (d) => i.jsx(di, { kind: "iban", ...d }), s1 = (d) => i.jsx(di, { kind: "postalCode", ...d });
function u1(d) {
  return i.jsx(Aa, { options: x0.map((s) => ({ label: s, value: s })), ...d });
}
function o1({ value: d, onValueChange: s, label: o, name: u, disabled: c, ...f }) {
  const { locale: m } = be();
  return i.jsxs(i.Fragment, { children: [i.jsx(it, { ...f, label: o, disabled: c, inputMode: "numeric", dir: "ltr", value: ke(d, {}, m), description: m === "fa-IR" ? `${_h(d)} تومان` : Yt(d, "IRT", m), onChange: (h) => {
    const v = Number($t(h.target.value).replace(/[^\d]/g, ""));
    Number.isSafeInteger(v) && s(v);
  } }), u && i.jsx("input", { type: "hidden", name: u, value: d, disabled: c })] });
}
function c1({ open: d, onOpenChange: s, items: o, title: u }) {
  const [c, f] = w.useState(""), [m, h] = w.useState(0), v = K("جست‌وجو و فرمان‌ها", "Search and commands"), j = K("نتیجه‌ای پیدا نشد", "No results"), x = w.useId(), b = o.filter((y) => Bt(y.label + " " + (y.description ?? "")).includes(Bt(c)));
  return w.useEffect(() => {
    d && (f(""), h(0));
  }, [d]), i.jsxs(dn, { open: d, onOpenChange: s, title: u ?? v, children: [i.jsx(it, { autoFocus: !0, "aria-label": u ?? v, role: "combobox", "aria-expanded": "true", "aria-controls": `${x}-list`, "aria-activedescendant": b[m] ? `${x}-${m}` : void 0, value: c, onChange: (y) => {
    f(y.target.value), h(0);
  }, startAdornment: i.jsx(_, { name: "search" }), onKeyDown: (y) => {
    (y.key === "ArrowDown" || y.key === "ArrowUp") && (y.preventDefault(), h((z) => Math.max(0, Math.min(b.length - 1, z + (y.key === "ArrowDown" ? 1 : -1))))), y.key === "Enter" && b[m] && (y.preventDefault(), b[m].onSelect(), s(!1));
  } }), i.jsx("ul", { className: "pd-command-list", role: "listbox", id: `${x}-list`, "aria-label": u ?? v, children: b.map((y, z) => i.jsxs("li", { id: `${x}-${z}`, role: "option", "aria-selected": z === m, onMouseDown: (O) => O.preventDefault(), onClick: () => {
    y.onSelect(), s(!1);
  }, children: [y.icon, i.jsxs("span", { children: [y.label, y.description && i.jsx("small", { children: y.description })] })] }, y.id)) }), !b.length && i.jsx("p", { children: j })] });
}
function ir({ code: d, language: s = "text", filename: o, showLineNumbers: u = !1, maxHeight: c = 420, className: f }) {
  return i.jsxs("figure", { className: ie("pd-code-block", f), children: [i.jsxs("figcaption", { children: [i.jsx("span", { children: o ?? s }), i.jsx(Zd, { value: d })] }), i.jsx("pre", { dir: "ltr", tabIndex: 0, style: { maxHeight: c }, "aria-label": o ?? `${s} code`, children: i.jsx("code", { children: u ? d.split(`
`).map((m, h) => i.jsxs("span", { className: "pd-code-line", children: [i.jsx("span", { "aria-hidden": "true", children: h + 1 }), m || " "] }, h)) : d }) })] });
}
function Jo({ name: d, size: s, url: o, type: u, onRemove: c, onDownload: f, progress: m, error: h }) {
  const v = K({ download: "دانلود", remove: "حذف فایل" }, { download: "Download", remove: "Remove attachment" });
  return i.jsxs("div", { className: "pd-attachment", children: [i.jsx("span", { children: i.jsx(_, { name: "box" }) }), i.jsxs("div", { children: [i.jsx("strong", { children: d }), i.jsx("small", { children: [u, s].filter(Boolean).join(" · ") }), m !== void 0 && i.jsx(Pa, { label: d, value: m }), " ", h && i.jsx("small", { className: "pd-error", role: "alert", children: h })] }), o ? i.jsx("a", { className: "pd-attachment-download", href: o, download: !0, "aria-label": `${v.download} ${d}`, children: i.jsx(_, { name: "download", size: 16 }) }) : f && i.jsx(Ue, { icon: "download", label: `${v.download} ${d}`, variant: "ghost", size: "sm", onClick: f }), " ", c && i.jsx(Ue, { icon: "close", label: `${v.remove} ${d}`, variant: "ghost", size: "sm", onClick: c })] });
}
function ug({ children: d, sender: s, avatar: o, role: u = "assistant", time: c, status: f, actions: m, streaming: h, className: v }) {
  const j = K({
    pending: "در حال ارسال",
    sent: "ارسال شده",
    read: "خوانده شده",
    error: "ارسال نشد",
    streaming: "در حال دریافت پاسخ"
  }, {
    pending: "Sending",
    sent: "Sent",
    read: "Read",
    error: "Not sent",
    streaming: "Receiving response"
  });
  return i.jsxs("article", { className: ie("pd-bubble", `pd-bubble--${u}`, v), "aria-label": s, "aria-busy": h || void 0, children: [s && i.jsx(Ia, { name: s, src: o, size: "sm" }), i.jsxs("div", { className: "pd-bubble-body", children: [s && i.jsx("strong", { className: "pd-bubble-sender", children: s }), i.jsxs("div", { className: "pd-bubble-content", children: [d, h && i.jsx("span", { className: "pd-stream-cursor", role: "status", "aria-label": j.streaming })] }), (c || f) && i.jsxs("footer", { children: [c, f && i.jsx("span", { role: "img", "aria-label": j[f], children: i.jsx(_, { name: f === "error" ? "warning" : f === "pending" ? "clock" : "check", size: 12 }) })] }), m && i.jsx("div", { className: "pd-bubble-actions", children: m })] })] });
}
function og({ children: d, label: s, height: o = 440, className: u, ...c }) {
  const f = w.useRef(null), m = w.useRef(null), [h, v] = w.useState(!0), j = w.useRef(!0), x = K("رفتن به آخر گفتگو", "Scroll to latest message"), b = () => {
    const y = f.current;
    y && (y.scrollTo({ top: y.scrollHeight, behavior: "auto" }), j.current = !0, v(!0));
  };
  return w.useEffect(() => {
    j.current && b();
  }, [d]), w.useEffect(() => {
    if (typeof ResizeObserver > "u" || !m.current)
      return;
    const y = new ResizeObserver(() => {
      j.current && b();
    });
    return y.observe(m.current), () => y.disconnect();
  }, []), i.jsxs("div", { className: ie("pd-message-scroll-wrap", u), children: [i.jsx("div", { ...c, ref: f, role: "log", "aria-label": s, "aria-live": "polite", "aria-relevant": "additions text", className: "pd-message-scroller", style: { height: o }, onScroll: (y) => {
    var E;
    const z = y.currentTarget, O = z.scrollHeight - z.clientHeight - z.scrollTop < 48;
    j.current = O, v(O), (E = c.onScroll) == null || E.call(c, y);
  }, children: i.jsx("div", { ref: m, children: d }) }), !h && i.jsx(Ue, { className: "pd-scroll-latest", icon: "chevronDown", label: x, variant: "outline", onClick: b })] });
}
function cg({ items: d, label: s }) {
  const { locale: o } = be(), u = K({ pending: "در صف", running: "در حال اجرا", success: "موفق", error: "خطا" }, { pending: "Pending", running: "Running", success: "Success", error: "Error" });
  return i.jsx("ol", { className: "pd-trace", "aria-label": s, children: d.map((c) => i.jsxs("li", { "data-status": c.status, children: [i.jsx("span", { className: "pd-trace-status", children: i.jsx(_, { name: c.status === "success" ? "check" : c.status === "error" ? "warning" : c.status === "running" ? "refresh" : "clock", size: 16 }) }), i.jsxs("div", { children: [c.details ? i.jsxs("details", { children: [i.jsxs("summary", { children: [c.title, i.jsx(Ke, { tone: c.status === "error" ? "danger" : c.status === "success" ? "success" : "neutral", children: u[c.status] })] }), c.details] }) : i.jsx("strong", { children: c.title }), c.description && i.jsx("p", { children: c.description })] }), c.duration !== void 0 && i.jsxs("small", { children: [ke(c.duration, { maximumFractionDigits: 1 }, o), " ms"] })] }, c.id)) });
}
function p1({ questions: d, onComplete: s, defaultAnswers: o = {}, label: u }) {
  var H;
  const [c, f] = w.useState(o), [m, h] = w.useState(0), [v, j] = w.useState(!1), [x, b] = w.useState(""), y = w.useId(), z = d[m], O = K({
    next: "ادامه",
    back: "قبلی",
    submit: "ثبت پاسخ‌ها",
    required: "لطفاً پاسخ دهید.",
    error: "ثبت پاسخ انجام نشد."
  }, {
    next: "Continue",
    back: "Back",
    submit: "Submit answers",
    required: "An answer is required.",
    error: "Could not submit answers."
  }), E = z ? c[z.id] : void 0, R = !(z != null && z.required) || (Array.isArray(E) ? E.length > 0 : typeof E == "string" ? E.trim().length > 0 : !!E);
  if (!z)
    return null;
  const U = (V) => {
    f((W) => ({ ...W, [z.id]: V })), b("");
  };
  return i.jsxs("form", { className: "pd-questionnaire", "aria-label": u, onSubmit: async (V) => {
    if (V.preventDefault(), !v) {
      if (!R) {
        b(O.required);
        return;
      }
      if (m < d.length - 1) {
        h((W) => W + 1);
        return;
      }
      j(!0), b("");
      try {
        await s(c);
      } catch (W) {
        b(W instanceof Error ? W.message : O.error);
      } finally {
        j(!1);
      }
    }
  }, children: [i.jsx(Pa, { label: u, value: m + 1, max: d.length }), i.jsxs("div", { children: [i.jsxs("small", { children: [m + 1, " / ", d.length] }), i.jsx("h3", { id: `${y}-question`, children: z.title }), z.description && i.jsx("p", { children: z.description })] }), z.type === "text" ? i.jsx(it, { "aria-labelledby": `${y}-question`, value: String(E ?? ""), onChange: (V) => U(V.target.value) }) : z.type === "rating" ? i.jsx(ri, { label: z.title, value: Number(E ?? 0), onValueChange: U }) : i.jsx("fieldset", { "aria-labelledby": `${y}-question`, children: (H = z.options) == null ? void 0 : H.map((V) => z.type === "multiple" ? i.jsx(rn, { label: V.label, checked: Array.isArray(E) && E.includes(V.value), onChange: () => U(Array.isArray(E) ? E.includes(V.value) ? E.filter((W) => W !== V.value) : [...E, V.value] : [V.value]) }, V.value) : i.jsxs("label", { className: "pd-check", children: [i.jsx("input", { type: "radio", name: z.id, value: V.value, checked: E === V.value, onChange: () => U(V.value) }), V.label] }, V.value)) }), x && i.jsx("div", { role: "alert", className: "pd-error", children: x }), i.jsxs("div", { className: "pd-form-actions", children: [i.jsx(ue, { variant: "outline", disabled: m === 0 || v, onClick: () => {
    h((V) => V - 1), b("");
  }, children: O.back }), i.jsx(ue, { type: "submit", loading: v, children: m === d.length - 1 ? O.submit : O.next })] })] });
}
const f1 = w.forwardRef(function({ className: s, ...o }, u) {
  return i.jsx("label", { ref: u, className: ie("pd-label", s), ...o });
});
function m1({ ratio: d = 16 / 9, className: s, style: o, ...u }) {
  return i.jsx("div", { className: ie("pd-aspect-ratio", s), style: { aspectRatio: Number.isFinite(d) && d > 0 ? d : 16 / 9, ...o }, ...u });
}
function h1({ orientation: d = "horizontal", decorative: s = !1, className: o, ...u }) {
  return i.jsx("div", { className: ie("pd-separator", `pd-separator--${d}`, o), role: s ? "none" : "separator", "aria-orientation": s ? void 0 : d, ...u });
}
function g1({ label: d, height: s = 280, orientation: o = "vertical", className: u, style: c, ...f }) {
  return i.jsx("div", { className: ie("pd-scroll-area", u), role: "region", "aria-label": d, tabIndex: 0, style: {
    maxHeight: s,
    overflowX: o === "vertical" ? "hidden" : "auto",
    overflowY: o === "horizontal" ? "hidden" : "auto",
    ...c
  }, ...f });
}
function rr({ title: d, children: s, open: o, defaultOpen: u = !1, onOpenChange: c, disabled: f, className: m }) {
  const [h, v] = Wa(o, u, c), j = w.useId();
  return i.jsxs("div", { className: ie("pd-collapsible", m), children: [i.jsxs("button", { type: "button", disabled: f, "aria-expanded": h, "aria-controls": `${j}-panel`, id: `${j}-trigger`, onClick: () => v(!h), children: [d, i.jsx(_, { name: "chevronDown", size: 16 })] }), i.jsx("div", { id: `${j}-panel`, "aria-labelledby": `${j}-trigger`, hidden: !h, children: s })] });
}
function b1({ dir: d, children: s }) {
  const o = be();
  return i.jsx(Go, { ...o, dir: d, onThemeChange: o.setTheme, children: s });
}
function pg({ pressed: d, defaultPressed: s = !1, onPressedChange: o, onClick: u, children: c, ...f }) {
  const [m, h] = Wa(d, s, o);
  return i.jsx(ue, { variant: m ? "soft" : "outline", ...f, "aria-pressed": m, onClick: (v) => {
    u == null || u(v), v.defaultPrevented || h(!m);
  }, children: c });
}
function v1({ label: d, items: s, value: o, defaultValue: u = [], onValueChange: c, multiple: f = !1, disabled: m }) {
  const [h, v] = Wa(o, u, c), { dir: j } = be(), x = s.findIndex((b) => !b.disabled);
  return i.jsx("div", { role: "group", "aria-label": d, className: "pd-toggle-group", children: s.map((b, y) => i.jsx(pg, { disabled: m || b.disabled, pressed: h.includes(b.value), tabIndex: h[0] === b.value || !h.length && y === x ? 0 : -1, onPressedChange: (z) => v(z ? f ? [...h, b.value] : [b.value] : h.filter((O) => O !== b.value)), onKeyDown: (z) => {
    var U;
    const O = Array.from(z.currentTarget.parentElement.querySelectorAll("button:not(:disabled)")), E = O.indexOf(z.currentTarget);
    let R;
    if (z.key === "Home")
      R = 0;
    else if (z.key === "End")
      R = O.length - 1;
    else if (z.key === "ArrowRight" || z.key === "ArrowLeft")
      R = (E + (z.key === "ArrowRight" ? 1 : -1) * (j === "rtl" ? -1 : 1) + O.length) % O.length;
    else
      return;
    z.preventDefault(), (U = O[R]) == null || U.focus();
  }, children: b.label }, b.value)) });
}
function x1({ variant: d = "p", as: s, className: o, ...u }) {
  const c = s ?? (["lead", "muted"].includes(d) ? "p" : d);
  return w.createElement(c, {
    className: ie("pd-typography", `pd-typography--${d}`, o),
    ...u
  });
}
function y1({ children: d, tone: s = "brand", className: o, ...u }) {
  return i.jsx("mark", { className: ie("pd-marker", `pd-tone-${s}`, o), ...u, children: d });
}
function j1({ leading: d, title: s, description: o, trailing: u, children: c, onClick: f, href: m, className: h }) {
  const v = i.jsxs(i.Fragment, { children: [d && i.jsx("span", { className: "pd-item-leading", children: d }), i.jsxs("span", { className: "pd-item-copy", children: [i.jsx("strong", { children: s }), o && i.jsx("small", { children: o }), c] }), u && i.jsx("span", { className: "pd-item-trailing", children: u })] });
  return m ? i.jsx("a", { className: ie("pd-item", h), href: m, children: v }) : f ? i.jsx("button", { type: "button", className: ie("pd-item", h), onClick: f, children: v }) : i.jsx("div", { className: ie("pd-item", h), children: v });
}
function z1({ label: d, children: s, className: o, ...u }) {
  return i.jsx("div", { role: "group", "aria-label": d, className: ie("pd-item-group", o), ...u, children: s });
}
const S1 = w.forwardRef(function({ className: s, ...o }, u) {
  return i.jsx("div", { ref: u, className: ie("pd-input-group", s), ...o });
});
function w1({ position: d = "start", className: s, ...o }) {
  return i.jsx("div", { className: ie("pd-input-group-addon", `pd-input-group-addon--${d}`, s), ...o });
}
const N1 = w.forwardRef(function(s, o) {
  return i.jsx(it, { ref: o, ...s });
});
function T1({ className: d, ...s }) {
  return i.jsx("div", { className: "pd-simple-table-wrap", children: i.jsx("table", { className: ie("pd-table", d), ...s }) });
}
const E1 = w.forwardRef(function(s, o) {
  return i.jsx("thead", { ref: o, ...s });
}), C1 = w.forwardRef(function(s, o) {
  return i.jsx("tbody", { ref: o, ...s });
}), A1 = w.forwardRef(function(s, o) {
  return i.jsx("tr", { ref: o, ...s });
}), M1 = w.forwardRef(function(s, o) {
  return i.jsx("th", { ref: o, scope: "col", ...s });
}), O1 = w.forwardRef(function(s, o) {
  return i.jsx("td", { ref: o, ...s });
}), D1 = w.forwardRef(function(s, o) {
  return i.jsx("caption", { ref: o, ...s });
});
function fg({ items: d, value: s, defaultValue: o, onValueChange: u, label: c, variant: f = "underline" }) {
  var b;
  const [m, h] = Wa(s, o ?? ((b = d.find((y) => !y.disabled)) == null ? void 0 : b.value) ?? "", u), v = w.useId(), { dir: j } = be(), x = w.useRef([]);
  return i.jsxs("div", { className: ie("pd-tabs", `pd-tabs--${f}`), children: [i.jsx("div", { className: "pd-tab-list", role: "tablist", "aria-label": c, children: d.map((y, z) => i.jsxs("button", { ref: (O) => {
    x.current[z] = O;
  }, type: "button", id: `${v}-${z}-tab`, role: "tab", disabled: y.disabled, "aria-selected": m === y.value, "aria-controls": `${v}-${z}-panel`, tabIndex: m === y.value ? 0 : -1, onClick: () => h(y.value), onKeyDown: (O) => {
    var U;
    let E = z;
    const R = (O.key === "ArrowRight" ? 1 : -1) * (j === "rtl" ? -1 : 1);
    if (O.key === "Home")
      E = d.findIndex((H) => !H.disabled);
    else if (O.key === "End")
      E = d.length - 1 - [...d].reverse().findIndex((H) => !H.disabled);
    else if (O.key === "ArrowLeft" || O.key === "ArrowRight")
      do
        E = (E + R + d.length) % d.length;
      while (d[E].disabled && E !== z);
    else
      return;
    O.preventDefault(), d[E].disabled || (h(d[E].value), (U = x.current[E]) == null || U.focus());
  }, children: [y.label, y.count !== void 0 && i.jsx(Ke, { children: y.count })] }, y.value)) }), d.map((y, z) => i.jsx("div", { className: "pd-tab-panel", role: "tabpanel", id: `${v}-${z}-panel`, "aria-labelledby": `${v}-${z}-tab`, hidden: m !== y.value, tabIndex: 0, children: y.content }, y.value))] });
}
function q1({ label: d, options: s, value: o, onChange: u }) {
  const c = w.useId();
  return i.jsx("div", { className: "pd-segmented", role: "radiogroup", "aria-label": d, children: s.map((f) => i.jsxs("label", { children: [i.jsx("input", { type: "radio", name: c, value: f.value, checked: o === f.value, onChange: () => u(f.value) }), i.jsx("span", { children: f.label })] }, f.value)) });
}
function k1({ items: d, multiple: s = !1 }) {
  const [o, u] = w.useState([]), c = w.useId();
  return i.jsx("div", { className: "pd-accordion", children: d.map((f, m) => i.jsxs("div", { children: [i.jsx("h3", { children: i.jsxs("button", { type: "button", "aria-expanded": o.includes(f.id), "aria-controls": `${c}-${m}-panel`, id: `${c}-${m}-trigger`, onClick: () => u((h) => h.includes(f.id) ? h.filter((v) => v !== f.id) : s ? [...h, f.id] : [f.id]), children: [f.title, i.jsx(_, { name: "chevronDown" })] }) }), i.jsx("div", { id: `${c}-${m}-panel`, role: "region", "aria-labelledby": `${c}-${m}-trigger`, hidden: !o.includes(f.id), children: f.content })] }, f.id)) });
}
function R1({ items: d, label: s }) {
  const o = K("مسیر صفحه", "Breadcrumb");
  return i.jsx("nav", { className: "pd-breadcrumb", "aria-label": s ?? o, children: i.jsx("ol", { children: d.map((u, c) => i.jsxs("li", { children: [u.href && c < d.length - 1 ? i.jsx("a", { href: u.href, children: u.label }) : i.jsx("span", { "aria-current": c === d.length - 1 ? "page" : void 0, children: u.label }), c < d.length - 1 && i.jsx(_, { name: "chevronLeft", size: 14 })] }, c)) }) });
}
function mg(d, s) {
  if (s <= 7)
    return Array.from({ length: Math.max(0, s) }, (f, m) => m + 1);
  const u = [...new Set([1, s, d - 1, d, d + 1].filter((f) => f >= 1 && f <= s))].sort((f, m) => f - m), c = [];
  return u.forEach((f, m) => {
    m && f - u[m - 1] > 1 && c.push("ellipsis"), c.push(f);
  }), c;
}
function hg({ page: d, total: s, pageSize: o = 10, onPageChange: u, label: c }) {
  const f = Math.max(1, Math.ceil(s / Math.max(1, o))), m = Math.min(f, Math.max(1, d)), { locale: h, dir: v } = be(), j = K({ nav: "صفحه‌بندی", next: "صفحهٔ بعد", prev: "صفحهٔ قبل", page: "صفحه" }, { nav: "Pagination", next: "Next page", prev: "Previous page", page: "Page" });
  return i.jsxs("nav", { className: "pd-pagination", "aria-label": c ?? j.nav, children: [i.jsx(Ue, { label: j.prev, icon: v === "rtl" ? "chevronRight" : "chevronLeft", variant: "outline", size: "sm", disabled: m === 1, onClick: () => u(m - 1) }), mg(m, f).map((x, b) => x === "ellipsis" ? i.jsx("span", { children: "…" }, `e${b}`) : i.jsx(ue, { variant: x === m ? "solid" : "ghost", size: "sm", "aria-label": `${j.page} ${x}`, "aria-current": x === m ? "page" : void 0, onClick: () => u(x), children: ke(x, {}, h) }, x)), i.jsx(Ue, { label: j.next, icon: v === "rtl" ? "chevronLeft" : "chevronRight", variant: "outline", size: "sm", disabled: m === f, onClick: () => u(m + 1) })] });
}
function dr({ items: d, active: s, onSelect: o, label: u, collapsed: c = !1 }) {
  return i.jsx("nav", { className: ie("pd-side-nav", c && "pd-side-nav--collapsed"), "aria-label": u, children: i.jsx("ul", { children: d.map((f) => i.jsxs("li", { children: [f.href ? i.jsxs("a", { href: f.href, "aria-current": s === f.id ? "page" : void 0, title: c ? f.label : void 0, onClick: () => o == null ? void 0 : o(f.id), children: [f.icon && i.jsx(_, { name: f.icon }), i.jsx("span", { children: f.label }), f.count !== void 0 && i.jsx(Ke, { children: f.count })] }) : i.jsxs("button", { type: "button", "aria-current": s === f.id ? "page" : void 0, "aria-label": c ? f.label : void 0, onClick: () => o == null ? void 0 : o(f.id), children: [f.icon && i.jsx(_, { name: f.icon }), i.jsx("span", { children: f.label }), f.count !== void 0 && i.jsx(Ke, { children: f.count })] }), f.children && !c && i.jsx(dr, { items: f.children, active: s, onSelect: o, label: f.label })] }, f.id)) }) });
}
function Fo({ steps: d, current: s }) {
  const { locale: o } = be();
  return i.jsx("ol", { className: "pd-stepper", children: d.map((u, c) => i.jsxs("li", { "data-state": c < s ? "done" : c === s ? "current" : "upcoming", "aria-current": c === s ? "step" : void 0, children: [i.jsx("span", { className: "pd-step-number", children: c < s ? i.jsx(_, { name: "check", size: 16 }) : ke(c + 1, {}, o) }), i.jsxs("span", { children: [i.jsx("strong", { children: u.label }), u.description && i.jsx("small", { children: u.description })] })] }, c)) });
}
function gg({ items: d }) {
  return i.jsx("ol", { className: "pd-timeline", children: d.map((s) => i.jsxs("li", { children: [i.jsx("span", { className: "pd-timeline-dot", children: s.icon ?? i.jsx(_, { name: "check", size: 14 }) }), i.jsxs("div", { children: [i.jsx("strong", { children: s.title }), s.description && i.jsx("p", { children: s.description }), s.date && i.jsx("small", { children: s.date })] })] }, s.id)) });
}
function bg({ items: d, label: s, onSelect: o }) {
  return i.jsx("div", { className: "pd-tree", "aria-label": s, children: d.map((u) => u.children ? i.jsxs("details", { children: [i.jsx("summary", { children: u.label }), i.jsx(bg, { items: u.children, label: u.label, onSelect: o })] }, u.id) : i.jsx(ue, { variant: "ghost", size: "sm", onClick: () => o == null ? void 0 : o(u.id), children: u.label }, u.id)) });
}
function Yd(d, s) {
  const o = d.map((f) => f.defaultSize ?? 100 / d.length), u = (s == null ? void 0 : s.length) === d.length && s.every((f) => Number.isFinite(f) && f > 0) ? s : o, c = u.reduce((f, m) => f + m, 0) || 1;
  return u.map((f) => f / c * 100);
}
function Do(d, s, o, u) {
  const c = d[o] + d[o + 1], f = Math.max(s[o].minSize ?? 10, c - (s[o + 1].maxSize ?? 90)), m = Math.min(s[o].maxSize ?? 90, c - (s[o + 1].minSize ?? 10));
  if (f > m)
    return d;
  const h = Math.max(f, Math.min(m, u)), v = [...d];
  return v[o] = h, v[o + 1] = c - h, v;
}
function vg({ panels: d, orientation: s = "horizontal", onLayoutChange: o, storageKey: u, className: c, label: f, style: m }) {
  const [h, v] = w.useState(() => Yd(d)), j = w.useRef(null), x = w.useRef(null), b = Qo(o), { dir: y } = be(), z = K("تغییر اندازهٔ پنل", "Resize panel");
  w.useEffect(() => {
    if (v(Yd(d)), u)
      try {
        const E = JSON.parse(localStorage.getItem(u) ?? "null");
        Array.isArray(E) && v(Yd(d, E));
      } catch {
      }
  }, [d.map((E) => E.id).join("|"), u]);
  const O = (E) => {
    var R;
    if (v(E), (R = b.current) == null || R.call(b, E), u)
      try {
        localStorage.setItem(u, JSON.stringify(E));
      } catch {
      }
  };
  return w.useEffect(() => {
    const E = (U) => {
      const H = x.current;
      if (!H || !j.current)
        return;
      const V = s === "horizontal" ? j.current.clientWidth : j.current.clientHeight;
      if (!V)
        return;
      const W = ((s === "horizontal" ? U.clientX : U.clientY) - H.point) / V * 100 * (s === "horizontal" && y === "rtl" ? -1 : 1);
      O(Do(H.sizes, d, H.index, H.sizes[H.index] + W));
    }, R = () => {
      x.current = null;
    };
    return window.addEventListener("pointermove", E), window.addEventListener("pointerup", R), window.addEventListener("pointercancel", R), () => {
      window.removeEventListener("pointermove", E), window.removeEventListener("pointerup", R), window.removeEventListener("pointercancel", R);
    };
  }, [s, y, d, u]), i.jsx("div", { ref: j, className: ie("pd-resizable", `pd-resizable--${s}`, c), style: m, role: "group", "aria-label": f, children: d.map((E, R) => i.jsxs("div", { className: "pd-resizable-section", style: { flexGrow: h[R] ?? 1, flexBasis: 0 }, children: [i.jsx("div", { id: E.id, className: "pd-resizable-panel", children: E.content }), R < d.length - 1 && i.jsx("div", { role: "separator", tabIndex: 0, className: "pd-resizable-handle", "aria-label": `${z} ${R + 1}`, "aria-orientation": s === "horizontal" ? "vertical" : "horizontal", "aria-controls": E.id, "aria-valuenow": Math.round(h[R] ?? 0), "aria-valuemin": E.minSize ?? 10, "aria-valuemax": E.maxSize ?? 90, onPointerDown: (U) => {
    U.preventDefault(), U.currentTarget.focus(), x.current = {
      index: R,
      point: s === "horizontal" ? U.clientX : U.clientY,
      sizes: [...h]
    };
  }, onKeyDown: (U) => {
    const H = s === "horizontal", V = U.shiftKey ? 10 : 2, W = H ? y === "rtl" ? "ArrowLeft" : "ArrowRight" : "ArrowDown", J = H ? y === "rtl" ? "ArrowRight" : "ArrowLeft" : "ArrowUp";
    let se;
    if (U.key === W)
      se = h[R] + V;
    else if (U.key === J)
      se = h[R] - V;
    else if (U.key === "Home")
      se = E.minSize ?? 10;
    else if (U.key === "End")
      se = E.maxSize ?? 90;
    else
      return;
    U.preventDefault(), O(Do(h, d, R, se));
  }, children: i.jsx("span", {}) })] }, E.id)) });
}
function U1({ label: d, items: s, active: o, onSelect: u, brand: c, footer: f, collapsed: m, defaultCollapsed: h = !1, onCollapsedChange: v, mobileOpen: j = !1, onMobileOpenChange: x, className: b }) {
  const [y, z] = Wa(m, h, v), O = K({ collapse: "جمع کردن منو", expand: "باز کردن منو" }, { collapse: "Collapse sidebar", expand: "Expand sidebar" }), E = i.jsxs(i.Fragment, { children: [i.jsxs("div", { className: "pd-sidebar-brand", children: [c, i.jsx(Ue, { icon: y ? "chevronLeft" : "chevronRight", variant: "ghost", size: "sm", label: y ? O.expand : O.collapse, onClick: () => z(!y) })] }), i.jsx(dr, { label: d, items: s, active: o, collapsed: y, onSelect: (R) => {
    u == null || u(R), x == null || x(!1);
  } }), f && i.jsx("div", { className: "pd-sidebar-footer", children: f })] });
  return i.jsxs(i.Fragment, { children: [i.jsx("aside", { className: ie("pd-sidebar", y && "pd-sidebar--collapsed", b), "aria-label": d, children: E }), i.jsx(Ld, { open: j, onOpenChange: (R) => x == null ? void 0 : x(R), title: d, placement: "start", size: "sm", children: i.jsx(dr, { label: d, items: s, active: o, onSelect: (R) => {
    u == null || u(R), x == null || x(!1);
  } }) })] });
}
function H1({ onClick: d, label: s }) {
  const o = K("باز کردن منو", "Open sidebar");
  return i.jsx(Ue, { icon: "menu", label: s ?? o, variant: "ghost", onClick: d });
}
function B1(d) {
  return i.jsx(vg, { ...d });
}
function Y1({ label: d, children: s, items: o, className: u }) {
  const [c, f] = w.useState(null), m = w.useRef(null), h = w.useRef(null), v = w.useId(), j = K("برای باز کردن منو راست‌کلیک کنید یا Shift+F10 را بزنید.", "Right click or press Shift+F10 to open the menu."), { dir: x } = be(), b = (y = !1) => {
    var z;
    f(null), y && ((z = h.current) == null || z.focus());
  };
  return w.useEffect(() => {
    var H;
    if (!c || !m.current)
      return;
    const y = m.current, z = y.getBoundingClientRect(), O = Math.max(8, Math.min(c.x, window.innerWidth - z.width - 8)), E = Math.max(8, Math.min(c.y, window.innerHeight - z.height - 8));
    if (O !== c.x || E !== c.y) {
      f({ x: O, y: E });
      return;
    }
    (H = y.querySelector(Xo)) == null || H.focus();
    const R = (V) => {
      Vo(y, V) || b();
    }, U = () => b();
    return document.addEventListener("pointerdown", R), window.addEventListener("resize", U), () => {
      document.removeEventListener("pointerdown", R), window.removeEventListener("resize", U);
    };
  }, [c == null ? void 0 : c.x, c == null ? void 0 : c.y]), w.useEffect(() => {
    const y = h.current;
    if (!y)
      return;
    const z = (E) => {
      E.preventDefault(), f({ x: E.clientX, y: E.clientY });
    }, O = (E) => {
      if (E.key === "ContextMenu" || E.shiftKey && E.key === "F10") {
        E.preventDefault();
        const R = y.getBoundingClientRect();
        f({ x: x === "rtl" ? R.right - 230 : R.left, y: R.top + 20 });
      }
    };
    return y.addEventListener("contextmenu", z), y.addEventListener("keydown", O), () => {
      y.removeEventListener("contextmenu", z), y.removeEventListener("keydown", O);
    };
  }, [x]), i.jsxs("div", { ref: h, className: ie("pd-context-area", u), tabIndex: 0, "aria-describedby": `${v}-hint`, children: [s, i.jsx("span", { className: "pd-sr-only", id: `${v}-hint`, children: j }), c && i.jsx("div", { ref: m, className: "pd-context-menu", role: "menu", "aria-label": d, style: { left: c.x, top: c.y }, onKeyDown: (y) => {
    var E;
    const z = Array.from(y.currentTarget.querySelectorAll("button:not(:disabled)")), O = z.indexOf(nn());
    y.key === "Escape" || y.key === "Tab" ? (y.key === "Escape" && y.preventDefault(), y.stopPropagation(), b(!0)) : ["ArrowUp", "ArrowDown", "Home", "End"].includes(y.key) && (y.preventDefault(), (E = z[y.key === "Home" ? 0 : y.key === "End" ? z.length - 1 : (O + (y.key === "ArrowDown" ? 1 : -1) + z.length) % z.length]) == null || E.focus());
  }, children: o.map((y) => i.jsxs("button", { type: "button", role: "menuitem", disabled: y.disabled, className: ie("pd-menu-item", y.danger && "pd-text-danger"), onClick: () => {
    y.onSelect(), b(!0);
  }, children: [y.icon, y.label] }, y.id)) })] });
}
function Q1({ menus: d, label: s }) {
  const { dir: o } = be();
  return i.jsx("div", { className: "pd-menubar", role: "group", "aria-label": s, onKeyDown: (u) => {
    var m;
    if (u.key !== "ArrowLeft" && u.key !== "ArrowRight")
      return;
    const c = Array.from(u.currentTarget.querySelectorAll(".pd-popover-trigger")), f = c.indexOf(nn());
    f < 0 || (u.preventDefault(), (m = c[(f + (u.key === "ArrowRight" ? 1 : -1) * (o === "rtl" ? -1 : 1) + c.length) % c.length]) == null || m.focus());
  }, children: d.map((u) => i.jsx(X1, { menu: u }, u.id)) });
}
function X1({ menu: d }) {
  const [s, o] = w.useState(!1);
  return i.jsx(Gd, { label: d.label, open: s, onOpenChange: o, trigger: i.jsx("span", { className: "pd-menubar-trigger", children: d.label }), children: i.jsx("div", { className: "pd-menu", role: "menu", "aria-label": d.label, onKeyDown: (u) => {
    var m;
    if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(u.key))
      return;
    u.preventDefault();
    const c = Array.from(u.currentTarget.querySelectorAll("button:not(:disabled)")), f = c.indexOf(nn());
    (m = c[u.key === "Home" ? 0 : u.key === "End" ? c.length - 1 : (f + (u.key === "ArrowDown" ? 1 : -1) + c.length) % c.length]) == null || m.focus();
  }, children: d.items.map((u) => i.jsxs("button", { type: "button", role: "menuitem", disabled: u.disabled, className: ie("pd-menu-item", u.danger && "pd-text-danger"), onClick: () => {
    u.onSelect(), o(!1);
  }, children: [u.icon, u.label] }, u.id)) }) });
}
function V1({ items: d, label: s, active: o }) {
  return i.jsx("nav", { className: "pd-navigation-menu", "aria-label": s, children: i.jsx("ul", { children: d.map((u) => i.jsx("li", { children: u.children ? i.jsxs("details", { children: [i.jsxs("summary", { children: [u.label, i.jsx(_, { name: "chevronDown", size: 14 })] }), i.jsx("ul", { children: u.children.map((c) => i.jsx("li", { children: i.jsxs("a", { href: c.href ?? "#", "aria-current": o === c.id ? "page" : void 0, children: [i.jsx("strong", { children: c.label }), c.description && i.jsx("small", { children: c.description })] }) }, c.id)) })] }) : i.jsx("a", { href: u.href ?? "#", "aria-current": o === u.id ? "page" : void 0, children: u.label }) }, u.id)) }) });
}
function L1({ trigger: d, title: s, children: o, delay: u = 180 }) {
  const [c, f] = w.useState(!1), m = w.useRef(void 0), h = w.useId();
  return w.useEffect(() => () => clearTimeout(m.current), []), i.jsxs("span", { className: "pd-hover-card", onMouseEnter: () => {
    clearTimeout(m.current), m.current = setTimeout(() => f(!0), u);
  }, onMouseLeave: () => {
    clearTimeout(m.current), f(!1);
  }, onFocus: () => f(!0), onBlur: (v) => {
    v.currentTarget.contains(v.relatedTarget) || f(!1);
  }, onKeyDown: (v) => {
    v.key === "Escape" && (f(!1), v.stopPropagation());
  }, children: [i.jsx("button", { type: "button", className: "pd-hover-trigger", "aria-expanded": c, "aria-controls": h, onClick: () => f((v) => !v), children: d }), i.jsx("span", { id: h, role: "region", "aria-label": s, className: "pd-hover-panel", hidden: !c, children: o })] });
}
function qo(d, s = "fa-IR") {
  const o = s.startsWith("fa") ? ["بایت", "کیلوبایت", "مگابایت", "گیگابایت"] : ["B", "KB", "MB", "GB"];
  let u = d, c = 0;
  for (; u >= 1024 && c < 3; )
    u /= 1024, c++;
  return `${ke(u, { maximumFractionDigits: c ? 1 : 0 }, s)} ${o[c]}`;
}
function xg(d, s) {
  return !s || s.split(",").some((o) => {
    const u = o.trim().toLowerCase();
    return u.startsWith(".") ? d.name.toLowerCase().endsWith(u) : u.endsWith("/*") ? d.type.toLowerCase().startsWith(u.slice(0, -1)) : d.type.toLowerCase() === u;
  });
}
function G1({ label: d, uploader: s, accept: o, multiple: u = !0, maxSize: c = 10 * 1024 * 1024, maxFiles: f = 10, concurrency: m = 3, disabled: h, onItemsChange: v }) {
  const [j, x] = w.useState([]), [b, y] = w.useState(!1), [z, O] = w.useState(""), E = w.useRef(null), R = w.useRef(/* @__PURE__ */ new Map()), U = w.useRef(!0), H = w.useRef(0), V = w.useId(), { locale: W } = be(), J = K({
    drop: "فایل را اینجا رها کنید",
    browse: "انتخاب فایل",
    hint: "یا برای انتخاب کلیک کنید",
    cancel: "لغو آپلود",
    retry: "تلاش مجدد",
    remove: "حذف فایل",
    size: "حجم فایل بیش از حد مجاز است.",
    type: "نوع فایل پذیرفته نیست.",
    count: "تعداد فایل‌ها بیش از حد مجاز است.",
    queued: "در صف",
    uploading: "در حال بارگذاری",
    done: "آماده",
    error: "خطا",
    canceled: "لغو شد",
    failed: "بارگذاری ناموفق بود."
  }, {
    drop: "Drop files here",
    browse: "Choose files",
    hint: "or click to browse",
    cancel: "Cancel upload",
    retry: "Retry",
    remove: "Remove file",
    size: "File is too large.",
    type: "File type is not accepted.",
    count: "Too many files.",
    queued: "Queued",
    uploading: "Uploading",
    done: "Ready",
    error: "Error",
    canceled: "Canceled",
    failed: "Upload failed."
  }), se = Qo(v);
  w.useEffect(() => (U.current = !0, () => {
    U.current = !1, R.current.forEach((X) => X.abort()), R.current.clear();
  }), []), w.useEffect(() => {
    var X;
    (X = se.current) == null || X.call(se, j);
  }, [j]), w.useEffect(() => {
    if (!s)
      return;
    const X = Math.max(1, m) - R.current.size;
    for (const me of j.filter((pe) => pe.status === "queued" && !R.current.has(pe.id)).slice(0, X)) {
      const pe = new AbortController();
      R.current.set(me.id, pe), x(($) => $.map((ce) => ce.id === me.id ? { ...ce, status: "uploading", progress: 0 } : ce)), Promise.resolve().then(() => s(me.file, {
        signal: pe.signal,
        onProgress: ($) => {
          U.current && !pe.signal.aborted && x((ce) => ce.map((I) => I.id === me.id ? { ...I, progress: Math.max(0, Math.min(100, $)) } : I));
        }
      })).then(($) => {
        U.current && !pe.signal.aborted && x((ce) => ce.map((I) => I.id === me.id ? { ...I, status: "done", progress: 100, url: $ == null ? void 0 : $.url } : I));
      }).catch(($) => {
        U.current && !pe.signal.aborted && x((ce) => ce.map((I) => I.id === me.id ? { ...I, status: "error", error: $ instanceof Error ? $.message : J.failed } : I));
      }).finally(() => {
        R.current.delete(me.id), U.current && x(($) => [...$]);
      });
    }
  }, [j, s, m]);
  const G = (X) => {
    if (h)
      return;
    const me = Array.from(X).slice(0, u ? void 0 : 1), pe = [], $ = u ? j.length : 0;
    let ce = "";
    for (const I of me) {
      if ($ + pe.length >= f) {
        ce = J.count;
        break;
      }
      if (!xg(I, o)) {
        ce = J.type;
        continue;
      }
      if (I.size > c) {
        ce = J.size;
        continue;
      }
      pe.push({
        id: `${V}-${++H.current}`,
        file: I,
        status: s ? "queued" : "done",
        progress: s ? 0 : 100
      });
    }
    u || R.current.forEach((I) => I.abort()), x((I) => u ? [...I, ...pe] : pe), O(ce);
  };
  return i.jsxs("div", { className: "pd-upload", children: [i.jsx("span", { className: "pd-label", id: `${V}-label`, children: d }), i.jsxs("div", { className: "pd-dropzone", "data-dragging": b || void 0, "data-disabled": h || void 0, onDragOver: (X) => {
    X.preventDefault(), h || y(!0);
  }, onDragLeave: (X) => {
    X.currentTarget.contains(X.relatedTarget) || y(!1);
  }, onDrop: (X) => {
    X.preventDefault(), y(!1), G(X.dataTransfer.files);
  }, children: [i.jsx("span", { className: "pd-upload-icon", children: i.jsx(_, { name: "upload", size: 26 }) }), i.jsx("strong", { children: J.drop }), i.jsx("span", { children: J.hint }), i.jsxs("small", { children: [o ?? "*", " · ", qo(c, W)] }), i.jsx(ue, { variant: "outline", size: "sm", disabled: h, onClick: () => {
    var X;
    return (X = E.current) == null ? void 0 : X.click();
  }, children: J.browse }), i.jsx("input", { ref: E, type: "file", className: "pd-sr-only", tabIndex: -1, "aria-labelledby": `${V}-label`, accept: o, multiple: u, disabled: h, onChange: (X) => {
    X.target.files && G(X.target.files), X.target.value = "";
  } })] }), i.jsx("div", { role: "status", className: "pd-error", children: z }), i.jsx("ul", { className: "pd-upload-list", children: j.map((X) => i.jsxs("li", { children: [i.jsx("span", { className: "pd-file-icon", children: i.jsx(_, { name: "box" }) }), i.jsxs("div", { children: [i.jsx("strong", { children: X.file.name }), i.jsxs("small", { children: [qo(X.file.size, W), " · ", J[X.status]] }), X.status === "uploading" && i.jsx(Pa, { label: X.file.name, value: X.progress }), " ", X.error && i.jsx("span", { className: "pd-error", role: "alert", children: X.error })] }), X.status === "error" || X.status === "canceled" ? i.jsx(Ue, { icon: "refresh", label: `${J.retry} ${X.file.name}`, variant: "ghost", size: "sm", onClick: () => x((me) => me.map((pe) => pe.id === X.id ? { ...pe, status: "queued", error: void 0 } : pe)) }) : null, X.status === "uploading" ? i.jsx(Ue, { icon: "close", label: `${J.cancel} ${X.file.name}`, variant: "ghost", size: "sm", onClick: () => {
    var me;
    (me = R.current.get(X.id)) == null || me.abort(), x((pe) => pe.map(($) => $.id === X.id ? { ...$, status: "canceled" } : $));
  } }) : i.jsx(Ue, { icon: "trash", label: `${J.remove} ${X.file.name}`, variant: "ghost", size: "sm", onClick: () => x((me) => me.filter((pe) => pe.id !== X.id)) })] }, X.id)) })] });
}
function Z1(d, { chunkSize: s = 5 * 1024 * 1024, retries: o = 2 } = {}) {
  if (!Number.isSafeInteger(s) || s <= 0)
    throw new RangeError("chunkSize must be positive");
  const u = /* @__PURE__ */ new WeakMap();
  return async (c, { signal: f, onProgress: m }) => {
    f.throwIfAborted();
    let h = u.get(c);
    h || (h = { id: await d.begin(c, f), done: /* @__PURE__ */ new Set() }, u.set(c, h));
    const v = Math.max(1, Math.ceil(c.size / s));
    for (let x = 0; x < v; x++) {
      if (f.throwIfAborted(), !h.done.has(x)) {
        let b = 0;
        for (; ; )
          try {
            await d.uploadPart(h.id, x, c.slice(x * s, (x + 1) * s), f);
            break;
          } catch (y) {
            if (f.throwIfAborted(), b++ >= o)
              throw y;
          }
        h.done.add(x);
      }
      m(Math.round(h.done.size / v * 99));
    }
    f.throwIfAborted();
    const j = await d.complete(h.id, c, f);
    return u.delete(c), m(100), j;
  };
}
const K1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Accordion: k1,
  Alert: Vd,
  AspectRatio: m1,
  Attachment: Jo,
  Avatar: Ia,
  AvatarGroup: C0,
  Badge: Ke,
  Breadcrumb: R1,
  Button: ue,
  ButtonGroup: H0,
  Calendar: Zo,
  Card: Ie,
  CardBody: T0,
  CardFooter: E0,
  CardHeader: N0,
  CardNumberInput: r1,
  Carousel: P0,
  Checkbox: rn,
  ChipGroup: l1,
  CodeBlock: ir,
  Collapsible: rr,
  ColorPicker: I0,
  Combobox: $0,
  CommandPalette: c1,
  ConfirmDialog: X0,
  Container: k0,
  ContextMenu: Y1,
  CopyButton: Zd,
  Countdown: W0,
  DatePicker: V0,
  DateRangePicker: L0,
  Dialog: dn,
  DirectionProvider: b1,
  Divider: O0,
  Drawer: Ld,
  DropdownMenu: lg,
  EmptyState: Cl,
  Field: ii,
  FileUpload: G1,
  Grid: U0,
  HoverCard: L1,
  IbanInput: d1,
  IconButton: Ue,
  InlineEdit: _0,
  Input: it,
  InputGroup: S1,
  InputGroupAddon: w1,
  InputGroupInput: N1,
  Item: j1,
  ItemGroup: z1,
  Kbd: D0,
  Label: f1,
  Marker: y1,
  Menubar: Q1,
  MessageBubble: ug,
  MessageScroller: og,
  Meter: M0,
  MobileInput: sg,
  MonthPicker: G0,
  MultiSelect: e1,
  NationalIdInput: i1,
  NavigationMenu: V1,
  NumberInput: Ko,
  OtpInput: n1,
  Pagination: hg,
  PasswordInput: dg,
  PasswordStrength: Z0,
  PersianInput: di,
  Popover: Gd,
  PostalCodeInput: s1,
  PriceInput: o1,
  PrimeProvider: Go,
  Progress: Pa,
  ProvinceSelect: u1,
  Questionnaire: p1,
  RadioGroup: ag,
  Rating: ri,
  RelativeTime: F0,
  ResizablePanelGroup: vg,
  ScrollArea: g1,
  SegmentedControl: q1,
  Select: Aa,
  Separator: h1,
  SideNav: dr,
  Sidebar: U1,
  SidebarTrigger: H1,
  Skeleton: tn,
  Slider: a1,
  Spinner: A0,
  Splitter: B1,
  Stack: R0,
  StatCard: J0,
  Stepper: Fo,
  Switch: tg,
  Table: T1,
  TableBody: C1,
  TableCaption: D1,
  TableCell: O1,
  TableHead: M1,
  TableHeader: E1,
  TableRow: A1,
  Tabs: fg,
  TagInput: t1,
  Textarea: sr,
  TimeInput: K0,
  Timeline: gg,
  ToastProvider: ig,
  Toggle: pg,
  ToggleGroup: v1,
  Tooltip: B0,
  Trace: cg,
  TreeView: bg,
  Typography: x1,
  VisuallyHidden: q0,
  acceptsFile: xg,
  createChunkedUploader: Z1,
  cx: ie,
  defaultRangePresets: rg,
  formatBytes: qo,
  normalizePanelSizes: Yd,
  pageRange: mg,
  resizePanelPair: Do,
  useLabels: K,
  usePrime: be,
  useTheme: w0,
  useToast: Q0
}, Symbol.toStringTag, { value: "Module" })), yg = (d, s) => JSON.stringify([d, s ?? null]);
function li(d, s) {
  const o = (s == null ? void 0 : s.stock) ?? d.stock;
  return Number.isFinite(o) ? Math.max(0, Math.floor(o)) : 0;
}
function Wo(d) {
  var s;
  return ((s = d.variant) == null ? void 0 : s.price) ?? d.product.price;
}
function jg(d, s) {
  var h;
  if (s.type === "clear")
    return [];
  if (s.type === "remove")
    return d.filter((v) => v.key !== s.key);
  if (s.type === "quantity")
    return Number.isFinite(s.quantity) ? d.map((v) => v.key === s.key ? {
      ...v,
      quantity: Math.max(0, Math.min(li(v.product, v.variant), Math.floor(s.quantity)))
    } : v).filter((v) => v.quantity > 0) : d;
  const o = li(s.product, s.variant), u = s.quantity ?? 1;
  if (!Number.isFinite(u) || Math.floor(u) <= 0 || o === 0)
    return d;
  const c = yg(s.product.id, (h = s.variant) == null ? void 0 : h.id), f = d.find((v) => v.key === c), m = Math.min(o, ((f == null ? void 0 : f.quantity) ?? 0) + Math.floor(u));
  return f ? d.map((v) => v.key === c ? { ...v, product: s.product, variant: s.variant, quantity: m } : v) : [...d, { key: c, product: s.product, variant: s.variant, quantity: m }];
}
function Io(d, { shipping: s = 0, discount: o = 0, tax: u = 0 } = {}) {
  const c = d.reduce((v, j) => v + Wo(j) * j.quantity, 0), f = Math.max(0, Math.min(c, Number.isFinite(o) ? o : 0)), m = Math.max(0, Number.isFinite(s) ? s : 0), h = Math.max(0, Number.isFinite(u) ? u : 0);
  return {
    subtotal: c,
    discount: f,
    shipping: m,
    tax: h,
    total: c - f + m + h,
    count: d.reduce((v, j) => v + j.quantity, 0)
  };
}
const zg = w.createContext(null);
function Sg({ children: d, initialItems: s = [], onItemsChange: o }) {
  const [u, c] = w.useState(s), f = w.useRef(o);
  w.useEffect(() => {
    f.current = o;
  }, [o]);
  const m = (v) => c((j) => jg(j, v));
  w.useEffect(() => {
    var v;
    (v = f.current) == null || v.call(f, u);
  }, [u]);
  const h = Io(u);
  return i.jsx(zg.Provider, { value: {
    items: u,
    count: h.count,
    subtotal: h.subtotal,
    add: (v, j = 1, x) => m({ type: "add", product: v, quantity: j, variant: x }),
    setQuantity: (v, j) => m({ type: "quantity", key: v, quantity: j }),
    remove: (v) => m({ type: "remove", key: v }),
    clear: () => m({ type: "clear" })
  }, children: d });
}
function Po() {
  const d = w.useContext(zg);
  if (!d)
    throw new Error("Wrap your store in CartProvider");
  return d;
}
const wg = w.createContext(null);
function Ng({ children: d, initialIds: s = [], onChange: o }) {
  const [u, c] = w.useState(s), f = w.useRef(o);
  w.useEffect(() => {
    f.current = o;
  }, [o]);
  const m = (h) => c((v) => v.includes(h) ? v.filter((j) => j !== h) : [...v, h]);
  return w.useEffect(() => {
    var h;
    (h = f.current) == null || h.call(f, u);
  }, [u]), i.jsx(wg.Provider, { value: { ids: u, toggle: m, has: (h) => u.includes(h) }, children: d });
}
function Tg() {
  const d = w.useContext(wg);
  if (!d)
    throw new Error("Wrap your store in WishlistProvider");
  return d;
}
const Eg = w.createContext(null);
function Cg({ children: d, max: s = 4 }) {
  const [o, u] = w.useState([]), c = w.useRef(o);
  return i.jsx(Eg.Provider, { value: {
    ids: o,
    max: s,
    toggle: (f) => c.current.includes(f) ? (c.current = c.current.filter((m) => m !== f), u(c.current), !0) : c.current.length >= s ? !1 : (c.current = [...c.current, f], u(c.current), !0),
    clear: () => {
      c.current = [], u([]);
    }
  }, children: d });
}
function Ag() {
  const d = w.useContext(Eg);
  if (!d)
    throw new Error("Wrap your store in CompareProvider");
  return d;
}
function El({ src: d, alt: s, className: o }) {
  const [u, c] = w.useState(!1);
  return w.useEffect(() => c(!1), [d]), i.jsx("div", { className: ie("pd-product-image", o), children: d && !u ? i.jsx("img", { src: d, alt: s, loading: "lazy", decoding: "async", onError: () => c(!0) }) : i.jsx("span", { role: "img", "aria-label": s, children: i.jsx(_, { name: "box", size: 64 }) }) });
}
function ur({ value: d, original: s, currency: o = "IRT", size: u = "md" }) {
  const { locale: c } = be(), f = K({ previous: "قیمت قبل", current: "قیمت" }, { previous: "Previous price", current: "Price" });
  return i.jsxs("div", { className: ie("pd-price", `pd-price--${u}`), children: [s !== void 0 && s > d && i.jsx("del", { "aria-label": f.previous, children: Yt(s, o, c) }), i.jsx("strong", { "aria-label": f.current, children: Yt(d, o, c) })] });
}
function Mg({ price: d, originalPrice: s }) {
  const { locale: o } = be(), u = Math.max(0, Math.min(100, Math.round((1 - d / s) * 100))), c = K("تخفیف", "off");
  return s > d && s > 0 ? i.jsxs(Ke, { tone: "danger", children: [ke(u, {}, o), "٪ ", c] }) : null;
}
function _o({ stock: d, lowStock: s = 5 }) {
  const { locale: o } = be(), u = K({ out: "ناموجود", low: "عدد باقی مانده", in: "موجود در انبار" }, { out: "Out of stock", low: "left in stock", in: "In stock" });
  return i.jsxs("span", { className: ie("pd-stock", d <= 0 ? "pd-text-danger" : d <= s ? "pd-text-warning" : "pd-text-success"), children: [i.jsx("i", {}), d <= 0 ? u.out : d <= s ? `${ke(d, {}, o)} ${u.low}` : u.in] });
}
function $o({ variants: d, value: s, onValueChange: o, label: u, disabled: c }) {
  const f = w.useId();
  return i.jsx("div", { className: "pd-swatches", role: "radiogroup", "aria-label": u, children: d.map((m) => i.jsxs("label", { title: m.label, "data-selected": s === m.id || void 0, "data-disabled": m.stock === 0 || void 0, children: [i.jsx("input", { type: "radio", name: f, value: m.id, checked: s === m.id, "aria-label": m.label, disabled: c || m.stock === 0, onChange: () => o(m.id) }), i.jsx("span", { style: { background: m.color ?? "var(--pd-muted)" }, children: !m.color && m.label })] }, m.id)) });
}
function ec({ product: d, layout: s = "default", onAddToCart: o, onQuickView: u, onWishlistChange: c, wishlisted: f, onCompareChange: m, compared: h, className: v }) {
  var se, G, X, me, pe, $, ce, I, De;
  const [j, x] = w.useState(((G = (se = d.variants) == null ? void 0 : se.find((Ee) => Ee.stock !== 0)) == null ? void 0 : G.id) ?? ""), [b, y] = w.useState(!1), [z, O] = w.useState(""), E = (X = d.variants) == null ? void 0 : X.find((Ee) => Ee.id === j), R = (E == null ? void 0 : E.price) ?? d.price, U = li(d, E), H = K({
    add: "افزودن به سبد",
    view: "مشاهدهٔ محصول",
    out: "ناموجود",
    wishlist: "علاقه‌مندی",
    compare: "مقایسه",
    quick: "نمایش سریع",
    color: "انتخاب رنگ",
    shipping: "ارسال رایگان",
    rating: "امتیاز محصول",
    error: "افزودن به سبد انجام نشد."
  }, {
    add: "Add to cart",
    view: "View product",
    out: "Out of stock",
    wishlist: "Wishlist",
    compare: "Compare",
    quick: "Quick view",
    color: "Choose color",
    shipping: "Free shipping",
    rating: "Product rating",
    error: "Could not add to cart."
  }), { locale: V } = be(), W = async () => {
    if (!(!o || !U || b)) {
      y(!0), O("");
      try {
        await o(d, 1, E);
      } catch (Ee) {
        O(Ee instanceof Error ? Ee.message : H.error);
      } finally {
        y(!1);
      }
    }
  }, J = w.useId();
  return i.jsxs("article", { className: ie("pd-product-card", `pd-product-card--${s}`, U === 0 && "pd-product-card--sold-out", v), "aria-labelledby": J, children: [i.jsxs("div", { className: "pd-product-media", children: [d.href ? i.jsx("a", { href: d.href, tabIndex: -1, "aria-hidden": "true", children: i.jsx(El, { src: d.image ?? ((pe = (me = d.images) == null ? void 0 : me[0]) == null ? void 0 : pe.src), alt: "" }) }) : i.jsx(El, { src: d.image ?? ((ce = ($ = d.images) == null ? void 0 : $[0]) == null ? void 0 : ce.src), alt: d.title }), i.jsxs("div", { className: "pd-product-badges", children: [d.originalPrice && i.jsx(Mg, { price: R, originalPrice: d.originalPrice }), " ", (I = d.badges) == null ? void 0 : I.map((Ee) => i.jsx(Ke, { tone: "brand", children: Ee }, Ee))] }), i.jsxs("div", { className: "pd-product-tools", children: [c && i.jsx(Ue, { label: `${H.wishlist}: ${d.title}`, icon: "heart", variant: "ghost", size: "sm", "aria-pressed": !!f, className: f ? "pd-wishlisted" : void 0, onClick: () => c(d) }), " ", m && i.jsx(Ue, { label: `${H.compare}: ${d.title}`, icon: "compare", variant: "ghost", size: "sm", "aria-pressed": !!h, onClick: () => m(d) })] }), u && i.jsxs("button", { type: "button", className: "pd-product-quick", onClick: () => u(d), children: [i.jsx(_, { name: "eye", size: 16 }), H.quick] })] }), i.jsxs("div", { className: "pd-product-info", children: [i.jsxs("div", { className: "pd-product-overline", children: [i.jsx("span", { children: d.brand ?? d.category }), d.rating !== void 0 && i.jsx(ri, { label: H.rating, value: d.rating, readonly: !0 })] }), i.jsx("h3", { id: J, children: d.href ? i.jsx("a", { href: d.href, children: d.title }) : d.title }), d.subtitle && i.jsx("p", { className: "pd-product-subtitle", children: d.subtitle }), s === "featured" && d.description && i.jsx("p", { className: "pd-product-description", children: d.description }), i.jsxs("div", { className: "pd-product-meta", children: [!!((De = d.variants) != null && De.length) && i.jsx($o, { variants: d.variants, value: j, onValueChange: x, label: H.color }), " ", d.reviewCount !== void 0 && i.jsxs("small", { children: [ke(d.reviewCount, {}, V), " ", V === "fa-IR" ? "دیدگاه" : "reviews"] })] }), i.jsxs("div", { className: "pd-product-stock-line", children: [i.jsx(_o, { stock: U }), d.freeShipping && i.jsxs("span", { className: "pd-free-shipping", children: [i.jsx(_, { name: "truck", size: 14 }), H.shipping] })] }), i.jsxs("div", { className: "pd-product-bottom", children: [i.jsx(ur, { value: R, original: d.originalPrice, currency: d.currency, size: s === "featured" ? "lg" : "md" }), o ? i.jsx(ue, { "aria-label": `${H.add}: ${d.title}`, size: s === "compact" ? "sm" : "md", variant: s === "featured" ? "solid" : "soft", disabled: U === 0, loading: b, startIcon: i.jsx(_, { name: "cart", size: 18 }), onClick: () => void W(), children: U === 0 ? H.out : H.add }) : d.href ? i.jsxs("a", { className: "pd-product-link", href: d.href, children: [H.view, i.jsx(_, { name: "arrowLeft", size: 16 })] }) : null] }), z && i.jsx("p", { className: "pd-error", role: "alert", children: z })] })] });
}
function Og({ layout: d = "default" }) {
  return i.jsxs("div", { className: ie("pd-product-card", `pd-product-card--${d}`), "aria-hidden": "true", children: [i.jsx(tn, { className: "pd-product-skeleton-image" }), i.jsxs("div", { className: "pd-product-info", children: [i.jsx(tn, { style: { width: "35%" } }), i.jsx(tn, { style: { width: "90%", height: 22 } }), i.jsx(tn, { style: { width: "65%" } }), i.jsx(tn, { style: { height: 40, marginTop: 18 } })] })] });
}
function J1({ products: d, loading: s = !1, columns: o = 3, ...u }) {
  const c = K("محصولی پیدا نشد", "No products found");
  return !s && !d.length ? i.jsx(Cl, { title: c, icon: "bag" }) : i.jsx("div", { className: ie("pd-product-grid", `pd-product-grid--${o}`), children: s ? Array.from({ length: o }, (f, m) => i.jsx(Og, { layout: u.layout }, m)) : d.map((f) => i.jsx(ec, { product: f, ...u }, f.id)) });
}
function Dg({ images: d, title: s }) {
  var f, m;
  const [o, u] = w.useState(0), c = K("تصویر محصول", "Product image");
  return i.jsxs("div", { className: "pd-product-gallery", children: [i.jsx(El, { src: (f = d[o]) == null ? void 0 : f.src, alt: ((m = d[o]) == null ? void 0 : m.alt) ?? s }), d.length > 1 && i.jsx("div", { className: "pd-gallery-thumbnails", children: d.map((h, v) => i.jsx("button", { type: "button", "aria-label": `${c} ${v + 1}`, "aria-pressed": o === v, onClick: () => u(v), children: i.jsx("img", { src: h.src, alt: "" }) }, v)) })] });
}
function F1({ product: d, open: s, onOpenChange: o, onAddToCart: u }) {
  const c = K("مشاهدهٔ محصول", "Product details");
  return i.jsx(dn, { open: s && !!d, onOpenChange: o, title: (d == null ? void 0 : d.title) ?? c, size: "lg", children: d && i.jsx(ec, { product: d, layout: "horizontal", onAddToCart: u }) });
}
function W1({ title: d, count: s, image: o, icon: u = "bag", href: c, onClick: f }) {
  const { locale: m } = be(), h = K("محصول", "products"), v = i.jsxs(i.Fragment, { children: [i.jsx("span", { className: "pd-category-art", children: o ? i.jsx("img", { src: o, alt: "" }) : i.jsx(_, { name: u, size: 32 }) }), i.jsx("strong", { children: d }), s !== void 0 && i.jsxs("small", { children: [ke(s, {}, m), " ", h] })] });
  return c ? i.jsx("a", { className: "pd-category-card", href: c, children: v }) : i.jsx("button", { type: "button", className: "pd-category-card", onClick: f, children: v });
}
function I1({ eyebrow: d, title: s, description: o, action: u, image: c, tone: f = "brand" }) {
  return i.jsxs("section", { className: ie("pd-promo-card", `pd-promo-card--${f}`), children: [i.jsxs("div", { children: [d && i.jsx("span", { children: d }), i.jsx("h3", { children: s }), o && i.jsx("p", { children: o }), u] }), c && i.jsx("img", { src: c, alt: "" })] });
}
function P1({ name: d, logo: s, description: o, href: u }) {
  const c = i.jsxs(i.Fragment, { children: [s ? i.jsx("img", { src: s, alt: "" }) : i.jsx(_, { name: "shield", size: 32 }), i.jsx("strong", { children: d }), o && i.jsx("small", { children: o })] });
  return u ? i.jsx("a", { className: "pd-brand-card", href: u, children: c }) : i.jsx(Ie, { className: "pd-brand-card", children: c });
}
function _1({ name: d, avatar: s, rating: o, date: u, children: c, verified: f }) {
  const m = K({ verified: "خریدار محصول", rating: "امتیاز خریدار" }, { verified: "Verified buyer", rating: "Customer rating" });
  return i.jsxs(Ie, { className: "pd-review-card", children: [i.jsxs("div", { children: [s, i.jsx("strong", { children: d }), f && i.jsx(Ke, { tone: "success", children: m.verified }), i.jsx(ri, { value: o, label: m.rating, readonly: !0 })] }), i.jsx("p", { children: c }), u && i.jsx("small", { children: u })] });
}
function qg({ item: d, onQuantityChange: s, onRemove: o }) {
  const u = K({ remove: "حذف از سبد", quantity: "تعداد" }, { remove: "Remove from cart", quantity: "Quantity" });
  return i.jsxs("article", { className: "pd-cart-line", children: [i.jsx(El, { src: d.product.image, alt: d.product.title }), i.jsxs("div", { className: "pd-cart-line-info", children: [i.jsx("strong", { children: d.product.title }), d.variant && i.jsx("small", { children: d.variant.label }), i.jsx(ur, { value: Wo(d), currency: d.product.currency, size: "sm" }), i.jsx(Ko, { label: `${u.quantity}: ${d.product.title}`, value: d.quantity, min: 1, max: li(d.product, d.variant), onValueChange: s })] }), i.jsx(Ue, { label: `${u.remove}: ${d.product.title}`, icon: "trash", variant: "ghost", size: "sm", onClick: o })] });
}
function kg({ items: d, shipping: s = 0, discount: o = 0, tax: u = 0, currency: c = "IRT", onCheckout: f, loading: m, footer: h }) {
  const v = Io(d, { shipping: s, discount: o, tax: u }), { locale: j } = be(), x = K({
    title: "خلاصهٔ سفارش",
    subtotal: "مبلغ کالاها",
    shipping: "هزینهٔ ارسال",
    discount: "تخفیف",
    tax: "مالیات",
    total: "مبلغ قابل پرداخت",
    checkout: "ادامهٔ خرید",
    free: "رایگان",
    secure: "پرداخت امن و رمزگذاری‌شده"
  }, {
    title: "Order summary",
    subtotal: "Subtotal",
    shipping: "Shipping",
    discount: "Discount",
    tax: "Tax",
    total: "Total",
    checkout: "Continue to checkout",
    free: "Free",
    secure: "Secure checkout"
  }), [b, y] = w.useState(!1), [z, O] = w.useState("");
  return i.jsxs(Ie, { className: "pd-cart-summary", children: [i.jsx("h3", { children: x.title }), i.jsxs("dl", { children: [i.jsxs("div", { children: [i.jsx("dt", { children: x.subtotal }), i.jsx("dd", { children: Yt(v.subtotal, c, j) })] }), i.jsxs("div", { children: [i.jsx("dt", { children: x.shipping }), i.jsx("dd", { children: v.shipping ? Yt(v.shipping, c, j) : x.free })] }), v.discount > 0 && i.jsxs("div", { className: "pd-text-success", children: [i.jsx("dt", { children: x.discount }), i.jsxs("dd", { children: ["−", Yt(v.discount, c, j)] })] }), v.tax > 0 && i.jsxs("div", { children: [i.jsx("dt", { children: x.tax }), i.jsx("dd", { children: Yt(v.tax, c, j) })] }), i.jsxs("div", { className: "pd-summary-total", children: [i.jsx("dt", { children: x.total }), i.jsx("dd", { children: Yt(v.total, c, j) })] })] }), h, f && i.jsx(ue, { fullWidth: !0, disabled: !d.length, loading: m || b, endIcon: i.jsx(_, { name: "arrowLeft", size: 18 }), onClick: async () => {
    y(!0), O("");
    try {
      await f();
    } catch (E) {
      O(E instanceof Error ? E.message : "Checkout failed");
    } finally {
      y(!1);
    }
  }, children: x.checkout }), z && i.jsx("p", { role: "alert", className: "pd-error", children: z }), i.jsxs("small", { className: "pd-checkout-secure", children: [i.jsx(_, { name: "lock", size: 14 }), x.secure] })] });
}
function $1({ onApply: d, appliedCode: s, onRemove: o }) {
  const [u, c] = w.useState(""), [f, m] = w.useState(!1), [h, v] = w.useState(""), j = K({ placeholder: "کد تخفیف", apply: "اعمال", remove: "حذف کد", error: "کد تخفیف معتبر نیست." }, {
    placeholder: "Coupon code",
    apply: "Apply",
    remove: "Remove code",
    error: "Invalid coupon."
  });
  return s ? i.jsxs("div", { className: "pd-coupon-applied", children: [i.jsx(Ke, { tone: "success", children: s }), o && i.jsx(Ue, { label: j.remove, icon: "close", variant: "ghost", size: "sm", onClick: o })] }) : i.jsxs("form", { className: "pd-coupon", onSubmit: async (x) => {
    if (x.preventDefault(), !(!u.trim() || f)) {
      m(!0), v("");
      try {
        await d(u.trim());
      } catch (b) {
        v(b instanceof Error ? b.message : j.error);
      } finally {
        m(!1);
      }
    }
  }, children: [i.jsx(it, { "aria-label": j.placeholder, placeholder: j.placeholder, value: u, onChange: (x) => c(x.target.value), error: h || void 0 }), i.jsx(ue, { type: "submit", variant: "outline", disabled: !u.trim(), loading: f, children: j.apply })] });
}
function Rg({ subtotal: d, threshold: s }) {
  const { locale: o } = be(), u = K({ achieved: "ارسال سفارش شما رایگان است!", more: "تا ارسال رایگان" }, { achieved: "Your order ships for free!", more: "away from free shipping" }), c = Math.max(0, s - d);
  return i.jsxs("div", { className: "pd-shipping-progress", children: [i.jsxs("span", { children: [i.jsx(_, { name: "truck", size: 18 }), c ? `${Yt(c, "IRT", o)} ${u.more}` : u.achieved] }), i.jsx(Pa, { label: u.more, value: Math.min(d, s), max: Math.max(1, s) })] });
}
function ey({ open: d, onOpenChange: s, onCheckout: o, shippingThreshold: u = 2e6 }) {
  const c = Po(), f = K({
    title: "سبد خرید شما",
    empty: "سبد خرید خالی است",
    description: "محصولات دلخواهتان را به سبد اضافه کنید."
  }, {
    title: "Your shopping bag",
    empty: "Your bag is empty",
    description: "Add something you love."
  }), { locale: m } = be();
  return i.jsx(Ld, { open: d, onOpenChange: s, title: `${f.title} (${ke(c.count, {}, m)})`, size: "md", children: c.items.length ? i.jsxs(i.Fragment, { children: [i.jsx(Rg, { subtotal: c.subtotal, threshold: u }), i.jsx("div", { className: "pd-cart-lines", children: c.items.map((h) => i.jsx(qg, { item: h, onQuantityChange: (v) => c.setQuantity(h.key, v), onRemove: () => c.remove(h.key) }, h.key)) }), i.jsx(kg, { items: c.items, onCheckout: o })] }) : i.jsx(Cl, { title: f.empty, description: f.description, icon: "bag" }) });
}
function ty({ name: d, phone: s, address: o, postalCode: u, selected: c, onSelect: f, onEdit: m }) {
  const h = K({ choose: "انتخاب نشانی", edit: "ویرایش", postal: "کد پستی" }, { choose: "Select address", edit: "Edit", postal: "Postal code" });
  return i.jsxs(Ie, { className: `pd-address-card${c ? " pd-address-selected" : ""}`, children: [i.jsxs("div", { children: [i.jsx("strong", { children: d }), c && i.jsx(Ke, { tone: "brand", children: i.jsx(_, { name: "check", size: 14 }) })] }), i.jsx("p", { children: o }), i.jsx("small", { dir: "ltr", children: s }), u && i.jsxs("small", { children: [h.postal, ": ", u] }), i.jsxs("div", { children: [f && i.jsx(ue, { variant: c ? "soft" : "outline", size: "sm", "aria-pressed": !!c, onClick: f, children: h.choose }), m && i.jsx(ue, { variant: "ghost", size: "sm", onClick: m, children: h.edit })] })] });
}
function ay({ options: d, value: s, onValueChange: o, currency: u = "IRT" }) {
  const { locale: c } = be(), f = K("روش ارسال", "Shipping method");
  return i.jsx(ag, { label: f, name: "shipping-method", value: s, onChange: o, options: d.map((m) => ({
    value: m.id,
    label: `${m.label} · ${Yt(m.price, u, c)}`,
    description: m.description
  })) });
}
function ly({ current: d }) {
  const s = K(["سبد خرید", "نشانی و ارسال", "پرداخت", "تکمیل سفارش"], ["Shopping bag", "Delivery", "Payment", "Confirmation"]);
  return i.jsx(Fo, { current: d, steps: s.map((o) => ({ label: o })) });
}
function ny({ number: d, date: s, status: o, items: u, total: c, currency: f = "IRT", onDetails: m }) {
  const { locale: h } = be(), v = K({
    order: "سفارش",
    details: "جزئیات سفارش",
    pending: "در انتظار پرداخت",
    processing: "در حال پردازش",
    shipped: "ارسال شده",
    delivered: "تحویل داده شده",
    canceled: "لغو شده"
  }, {
    order: "Order",
    details: "Order details",
    pending: "Pending payment",
    processing: "Processing",
    shipped: "Shipped",
    delivered: "Delivered",
    canceled: "Canceled"
  });
  return i.jsxs(Ie, { className: "pd-order-card", children: [i.jsxs("header", { children: [i.jsxs("div", { children: [i.jsxs("strong", { children: [v.order, " #", d] }), i.jsx("small", { children: s })] }), i.jsx(Ke, { tone: o === "delivered" ? "success" : o === "canceled" ? "danger" : o === "pending" ? "warning" : "info", children: v[o] })] }), i.jsx("div", { className: "pd-order-products", children: u.map((j, x) => i.jsxs("div", { children: [i.jsx(El, { src: j.image, alt: j.title }), i.jsxs("span", { children: [j.title, i.jsxs("small", { children: ["×", ke(j.quantity, {}, h)] })] })] }, x)) }), i.jsxs("footer", { children: [i.jsx("strong", { children: Yt(c, f, h) }), m && i.jsx(ue, { variant: "outline", size: "sm", onClick: m, children: v.details })] })] });
}
function iy({ steps: d }) {
  return i.jsx(gg, { items: d });
}
function ry({ products: d, onRemove: s }) {
  const { locale: o } = be(), u = K({ title: "مقایسهٔ محصولات", price: "قیمت", stock: "موجودی", remove: "حذف از مقایسه" }, {
    title: "Compare products",
    price: "Price",
    stock: "Stock",
    remove: "Remove from comparison"
  }), c = [...new Set(d.flatMap((f) => Object.keys(f.specifications ?? {})))];
  return i.jsx("div", { className: "pd-compare-scroll", tabIndex: 0, "aria-label": u.title, children: i.jsxs("table", { className: "pd-table pd-compare-table", children: [i.jsx("caption", { children: u.title }), i.jsx("thead", { children: i.jsxs("tr", { children: [i.jsx("th", { scope: "col", children: u.title }), d.map((f) => i.jsxs("th", { scope: "col", children: [i.jsx(El, { src: f.image, alt: "" }), i.jsx("strong", { children: f.title }), s && i.jsx(Ue, { label: `${u.remove}: ${f.title}`, icon: "close", variant: "ghost", size: "sm", onClick: () => s(f.id) })] }, f.id))] }) }), i.jsxs("tbody", { children: [i.jsxs("tr", { children: [i.jsx("th", { scope: "row", children: u.price }), d.map((f) => i.jsx("td", { children: Yt(f.price, f.currency, o) }, f.id))] }), i.jsxs("tr", { children: [i.jsx("th", { scope: "row", children: u.stock }), d.map((f) => i.jsx("td", { children: ke(f.stock, {}, o) }, f.id))] }), c.map((f) => i.jsxs("tr", { children: [i.jsx("th", { scope: "row", children: f }), d.map((m) => {
    var h;
    return i.jsx("td", { children: ((h = m.specifications) == null ? void 0 : h[f]) ?? "—" }, m.id);
  })] }, f))] })] }) });
}
function dy({ product: d, onAddToCart: s, description: o, shippingInfo: u }) {
  var E, R, U;
  const [c, f] = w.useState(((R = (E = d.variants) == null ? void 0 : E.find((H) => H.stock !== 0)) == null ? void 0 : R.id) ?? ""), [m, h] = w.useState(1), [v, j] = w.useState(!1), [x, b] = w.useState(""), y = (U = d.variants) == null ? void 0 : U.find((H) => H.id === c), z = li(d, y), O = K({
    add: "افزودن به سبد خرید",
    quantity: "تعداد",
    variant: "انتخاب مدل",
    description: "توضیحات",
    specs: "مشخصات",
    shipping: "ارسال"
  }, {
    add: "Add to shopping bag",
    quantity: "Quantity",
    variant: "Choose variant",
    description: "Description",
    specs: "Specifications",
    shipping: "Delivery"
  });
  return i.jsxs("section", { className: "pd-product-detail", children: [i.jsx(Dg, { title: d.title, images: d.images ?? (d.image ? [{ src: d.image, alt: d.title }] : []) }), i.jsxs("div", { children: [i.jsx("small", { children: d.brand }), i.jsx("h2", { children: d.title }), d.rating !== void 0 && i.jsx(ri, { label: d.title, value: d.rating, readonly: !0 }), i.jsx("p", { children: d.description }), i.jsx(ur, { value: (y == null ? void 0 : y.price) ?? d.price, original: d.originalPrice, currency: d.currency, size: "lg" }), i.jsx(_o, { stock: z }), d.variants && i.jsx($o, { label: O.variant, variants: d.variants, value: c, onValueChange: (H) => {
    f(H), h(1);
  } }), i.jsx(Ko, { label: O.quantity, value: m, onValueChange: h, min: 1, max: Math.max(1, z), disabled: !z }), i.jsx(ue, { fullWidth: !0, disabled: !z, loading: v, startIcon: i.jsx(_, { name: "cart" }), onClick: async () => {
    j(!0), b("");
    try {
      await s(d, m, y);
    } catch (H) {
      b(H instanceof Error ? H.message : "Could not add product");
    } finally {
      j(!1);
    }
  }, children: O.add }), x && i.jsx("div", { role: "alert", className: "pd-error", children: x })] }), i.jsx("div", { className: "pd-product-detail-tabs", children: i.jsx(fg, { label: d.title, items: [
    {
      value: "description",
      label: O.description,
      content: o ?? d.description
    },
    {
      value: "specs",
      label: O.specs,
      content: i.jsx("dl", { className: "pd-specification-list", children: Object.entries(d.specifications ?? {}).map(([H, V]) => i.jsxs("div", { children: [i.jsx("dt", { children: H }), i.jsx("dd", { children: V })] }, H)) })
    },
    { value: "shipping", label: O.shipping, content: u ?? "—" }
  ] }) })] });
}
function sy({ title: d, products: s, price: o, onAddBundle: u }) {
  var b, y;
  const [c, f] = w.useState(!1), [m, h] = w.useState(""), v = s.reduce((z, O) => z + O.price, 0), j = K({ add: "افزودن بسته به سبد", saving: "صرفه‌جویی" }, { add: "Add bundle to cart", saving: "You save" }), { locale: x } = be();
  return i.jsxs(Ie, { className: "pd-bundle-card", children: [i.jsx("h3", { children: d }), i.jsx("div", { className: "pd-bundle-products", children: s.map((z, O) => i.jsxs("div", { children: [O > 0 && i.jsx(_, { name: "plus", size: 16 }), i.jsx(El, { src: z.image, alt: z.title }), i.jsx("small", { children: z.title })] }, z.id)) }), i.jsx(ur, { value: o, original: v, currency: (b = s[0]) == null ? void 0 : b.currency }), o < v && i.jsxs(Ke, { tone: "success", children: [j.saving, ": ", Yt(v - o, (y = s[0]) == null ? void 0 : y.currency, x)] }), i.jsx(ue, { fullWidth: !0, disabled: !s.length || s.some((z) => z.stock <= 0), loading: c, onClick: async () => {
    f(!0), h("");
    try {
      await u(s);
    } catch (z) {
      h(z instanceof Error ? z.message : "Could not add bundle");
    } finally {
      f(!1);
    }
  }, children: j.add }), m && i.jsx("p", { className: "pd-error", role: "alert", children: m })] });
}
function uy({ name: d, logo: s, rating: o, description: u, verified: c, action: f }) {
  const m = K("فروشندهٔ تأیید شده", "Verified seller");
  return i.jsxs(Ie, { className: "pd-seller-card", children: [i.jsx(Ia, { name: d, src: s, size: "lg" }), i.jsxs("div", { children: [i.jsx("strong", { children: d }), c && i.jsxs(Ke, { tone: "success", children: [i.jsx(_, { name: "shield", size: 13 }), m] }), u && i.jsx("p", { children: u }), o !== void 0 && i.jsx(ri, { label: d, value: o, readonly: !0 })] }), f] });
}
function oy({ code: d, title: s, description: o, expires: u }) {
  return i.jsxs(Ie, { className: "pd-coupon-card", children: [i.jsx("span", { children: i.jsx(_, { name: "tag", size: 26 }) }), i.jsxs("div", { children: [i.jsx("strong", { children: s }), o && i.jsx("p", { children: o }), u && i.jsx("small", { children: u })] }), i.jsxs("div", { children: [i.jsx("code", { children: d }), i.jsx(Zd, { value: d })] })] });
}
const cy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AddressCard: ty,
  BrandCard: P1,
  BundleCard: sy,
  CartLineItem: qg,
  CartProvider: Sg,
  CartSummary: kg,
  CategoryCard: W1,
  CheckoutStepper: ly,
  ColorSwatches: $o,
  CompareProvider: Cg,
  CompareTable: ry,
  CouponCard: oy,
  CouponInput: $1,
  DiscountBadge: Mg,
  FreeShippingProgress: Rg,
  MiniCart: ey,
  OrderCard: ny,
  OrderTracking: iy,
  Price: ur,
  ProductCard: ec,
  ProductCardSkeleton: Og,
  ProductDetail: dy,
  ProductGallery: Dg,
  ProductGrid: J1,
  ProductImage: El,
  PromoCard: I1,
  QuickView: F1,
  ReviewCard: _1,
  SellerCard: uy,
  ShippingMethodPicker: ay,
  StockBadge: _o,
  WishlistProvider: Ng,
  calculateCart: Io,
  cartKey: yg,
  cartReducer: jg,
  itemPrice: Wo,
  itemStock: li,
  useCart: Po,
  useCompare: Ag,
  useWishlist: Tg
}, Symbol.toStringTag, { value: "Module" })), Ca = ["var(--pd-brand)", "#1caa88", "#eaad53", "#6497f5", "#d372be", "#8996ab"], Fa = (d) => Number.isFinite(d) ? d : 0;
function or({ title: d, data: s, children: o }) {
  const u = w.useId(), c = K({ empty: "داده‌ای برای نمایش نیست", value: "مقدار" }, { empty: "No chart data", value: "Value" }), { locale: f } = be();
  return i.jsxs("figure", { className: "pd-chart", "aria-labelledby": u, children: [i.jsx("figcaption", { id: u, children: d }), s.length ? o : i.jsx(Cl, { title: c.empty, icon: "chart" }), i.jsxs("table", { className: "pd-sr-only", children: [i.jsx("caption", { children: d }), i.jsx("thead", { children: i.jsxs("tr", { children: [i.jsx("th", { scope: "col", children: d }), i.jsx("th", { scope: "col", children: c.value })] }) }), i.jsx("tbody", { children: s.map((m, h) => i.jsxs("tr", { children: [i.jsx("th", { scope: "row", children: m.label }), i.jsx("td", { children: ke(Fa(m.value), {}, f) })] }, h)) })] })] });
}
function py({ title: d, data: s }) {
  const { locale: o, dir: u } = be(), c = s.map((b) => Fa(b.value)), f = Math.min(0, ...c), m = Math.max(0, ...c), h = m - f || 1, v = (b) => 180 - (b - f) / h * 150, j = v(0), x = 520 / Math.max(1, s.length);
  return i.jsx(or, { title: d, data: s, children: i.jsxs("svg", { viewBox: "0 0 600 230", className: "pd-chart-svg", role: "img", "aria-label": d, children: [Array.from({ length: 5 }, (b, y) => {
    const z = f + h * y / 4;
    return i.jsxs("g", { children: [i.jsx("line", { x1: 52, x2: 580, y1: v(z), y2: v(z), stroke: "var(--pd-border)" }), i.jsx("text", { x: 44, y: v(z) + 4, textAnchor: "end", children: ke(Math.round(z), {}, o) })] }, y);
  }), s.map((b, y) => {
    const z = Fa(b.value), O = u === "rtl" ? s.length - 1 - y : y, E = 58 + O * x;
    return i.jsxs("g", { children: [i.jsx("rect", { x: E, y: Math.min(j, v(z)), width: Math.max(1, x * 0.6), height: Math.max(1, Math.abs(v(z) - j)), rx: 4, fill: Ca[y % Ca.length], children: i.jsxs("title", { children: [b.label, ": ", ke(z, {}, o)] }) }), i.jsx("text", { x: E + x * 0.3, y: 210, textAnchor: "middle", children: b.label })] }, y);
  })] }) });
}
function fy({ title: d, data: s, area: o = !0 }) {
  const u = w.useId(), { dir: c, locale: f } = be(), m = s.map((z) => Fa(z.value)), h = Math.min(0, ...m), v = Math.max(0, ...m), j = v - h || 1, x = (z, O) => [
    c === "rtl" ? 570 - O / Math.max(1, s.length - 1) * 520 : 50 + O / Math.max(1, s.length - 1) * 520,
    180 - (Fa(z) - h) / j * 150
  ], b = s.map((z, O) => x(z.value, O)), y = b.map((z, O) => `${O ? "L" : "M"}${z[0]},${z[1]}`).join(" ");
  return i.jsx(or, { title: d, data: s, children: i.jsxs("svg", { viewBox: "0 0 600 230", className: "pd-chart-svg", role: "img", "aria-label": d, children: [i.jsx("defs", { children: i.jsxs("linearGradient", { id: u, x1: "0", y1: "0", x2: "0", y2: "1", children: [i.jsx("stop", { stopColor: "var(--pd-brand)", stopOpacity: ".22" }), i.jsx("stop", { offset: "1", stopColor: "var(--pd-brand)", stopOpacity: "0" })] }) }), [0, 1, 2, 3].map((z) => i.jsx("line", { x1: 50, x2: 570, y1: 30 + z * 50, y2: 30 + z * 50, stroke: "var(--pd-border)" }, z)), !!b.length && o && i.jsx("path", { d: `${y} L${b.at(-1)[0]},180 L${b[0][0]},180 Z`, fill: `url(#${u})` }), i.jsx("path", { d: y, stroke: "var(--pd-brand)", strokeWidth: 3, fill: "none", strokeLinejoin: "round", strokeLinecap: "round" }), b.map(([z, O], E) => i.jsxs("g", { children: [i.jsx("circle", { cx: z, cy: O, r: 4, fill: "var(--pd-surface)", stroke: "var(--pd-brand)", strokeWidth: 2, children: i.jsxs("title", { children: [s[E].label, ": ", ke(s[E].value, {}, f)] }) }), i.jsx("text", { x: z, y: 210, textAnchor: "middle", children: s[E].label })] }, E))] }) });
}
function my({ title: d, data: s }) {
  const o = s.map((m) => ({ ...m, value: Math.max(0, Fa(m.value)) })), u = o.reduce((m, h) => m + h.value, 0), { locale: c } = be();
  let f = 0;
  return i.jsx(or, { title: d, data: o, children: i.jsxs("div", { className: "pd-pie-layout", children: [i.jsxs("svg", { viewBox: "0 0 160 160", width: "180", role: "img", "aria-label": d, children: [i.jsx("circle", { cx: 80, cy: 80, r: 57, fill: "none", stroke: "var(--pd-muted)", strokeWidth: 20 }), o.map((m, h) => {
    const v = u ? m.value / u * 100 : 0, j = f;
    return f += v, i.jsx("circle", { cx: 80, cy: 80, r: 57, fill: "none", stroke: Ca[h % Ca.length], strokeWidth: 20, pathLength: 100, strokeDasharray: `${v} ${100 - v}`, strokeDashoffset: -j, transform: "rotate(-90 80 80)", children: i.jsxs("title", { children: [m.label, ": ", ke(v, { maximumFractionDigits: 1 }, c), "%"] }) }, h);
  }), i.jsx("text", { x: 80, y: 85, textAnchor: "middle", className: "pd-pie-total", children: ke(u, {}, c) })] }), i.jsx("ul", { className: "pd-chart-legend", children: o.map((m, h) => i.jsxs("li", { children: [i.jsx("i", { style: { background: Ca[h % Ca.length] } }), i.jsx("span", { children: m.label }), i.jsxs("strong", { children: [ke(u ? m.value / u * 100 : 0, { maximumFractionDigits: 1 }, c), "٪"] })] }, h)) })] }) });
}
function hy({ values: d, label: s }) {
  const o = d.map(Fa), u = Math.min(...o), c = Math.max(...o), f = c - u || 1, m = o.map((h, v) => `${v / Math.max(1, o.length - 1) * 100},${28 - (h - u) / f * 24}`).join(" ");
  return i.jsx("svg", { viewBox: "0 0 100 32", className: "pd-sparkline", role: s ? "img" : void 0, "aria-label": s, "aria-hidden": s ? void 0 : !0, children: i.jsx("polyline", { points: m, fill: "none", stroke: "currentColor", strokeWidth: 2, vectorEffect: "non-scaling-stroke", strokeLinejoin: "round" }) });
}
function gy({ title: d, data: s }) {
  const o = Math.max(1, ...s.map((c) => Fa(c.value))), { locale: u } = be();
  return i.jsx(or, { title: d, data: s, children: i.jsx("ol", { className: "pd-bar-list", children: s.map((c, f) => i.jsxs("li", { children: [i.jsx("span", { style: { width: `${Math.max(0, c.value) / o * 100}%` } }), i.jsx("span", { children: c.label }), i.jsx("strong", { children: ke(c.value, {}, u) })] }, f)) }) });
}
function by({ title: d, data: s }) {
  const o = s.reduce((c, f) => c + Math.max(0, Fa(f.value)), 0) || 1, { locale: u } = be();
  return i.jsxs(or, { title: d, data: s, children: [i.jsx("div", { className: "pd-proportion", children: s.map((c, f) => i.jsx("span", { style: { flex: Math.max(0, c.value), background: Ca[f % Ca.length] }, title: `${c.label}: ${ke(c.value / o * 100, { maximumFractionDigits: 1 }, u)}%` }, f)) }), i.jsx("ul", { className: "pd-chart-legend", children: s.map((c, f) => i.jsxs("li", { children: [i.jsx("i", { style: { background: Ca[f % Ca.length] } }), c.label, i.jsxs("strong", { children: [ke(c.value / o * 100, { maximumFractionDigits: 1 }, u), "٪"] })] }, f)) })] });
}
const Ug = {
  page: 1,
  pageSize: 10,
  sort: null,
  search: "",
  filters: [],
  hiddenColumns: [],
  columnOrder: []
}, ti = (d, s) => s.accessor ? s.accessor(d) : d[s.id];
function Hg(d, s, o, u = "fa-IR") {
  let c = d.filter((f) => o.search && !s.some((m) => Bt(String(ti(f, m) ?? "")).includes(Bt(o.search))) ? !1 : o.filters.every((m) => {
    const h = s.find((b) => b.id === m.id);
    if (!h)
      return !0;
    const v = ti(f, h);
    if (m.operator === "contains")
      return Bt(String(v ?? "")).includes(Bt(String(m.value)));
    if (m.operator === "eq")
      return Bt(String(v ?? "")) === Bt(String(m.value));
    const j = Number(v), x = Number(m.value);
    return !Number.isFinite(j) || !Number.isFinite(x) ? !1 : m.operator === "gt" ? j > x : m.operator === "gte" ? j >= x : m.operator === "lt" ? j < x : j <= x;
  }));
  if (o.sort) {
    const f = s.find((m) => m.id === o.sort.id);
    if (f) {
      const m = o.sort.direction === "asc" ? 1 : -1;
      c = [...c].sort((h, v) => {
        const j = ti(h, f), x = ti(v, f);
        return m * (typeof j == "number" && typeof x == "number" ? j - x : String(j ?? "").localeCompare(String(x ?? ""), u, { numeric: !0 }));
      });
    }
  }
  return c;
}
function Bg(d, s) {
  const o = (u) => {
    let c = String(u ?? "");
    return /^[\s]*[=+@-]/.test(c) && (c = "'" + c), '"' + c.replace(/"/g, '""') + '"';
  };
  return "\uFEFF" + [
    s.map((u) => o(u.header)).join(","),
    ...d.map((u) => s.map((c) => o(ti(u, c))).join(","))
  ].join(`\r
`);
}
function vy({ rows: d, columns: s, getRowId: o, caption: u, description: c, state: f, defaultState: m, onStateChange: h, serverSide: v, rowCount: j, loading: x, selectable: b, selected: y, onSelectedChange: z, bulkActions: O, rowActions: E, renderExpanded: R, onRowClick: U, empty: H, toolbar: V, exportable: W = !0, onExport: J, virtualized: se = !1, height: G = 480, rowHeight: X = 56, className: me }) {
  const [pe, $] = w.useState({ ...Ug, ...m }), [ce, I] = w.useState([]), [De, Ee] = w.useState({}), [L, P] = w.useState([]), [re, Ce] = w.useState(0), he = w.useRef(null), ge = { ...pe, ...f }, We = y ?? ce, { locale: St } = be(), N = K({
    search: "جست‌وجو در جدول",
    columns: "ستون‌ها",
    export: "خروجی CSV",
    selectAll: "انتخاب ردیف‌های این صفحه",
    selectRow: "انتخاب ردیف",
    empty: "داده‌ای پیدا نشد",
    emptyText: "عبارت جست‌وجو یا فیلترها را تغییر دهید.",
    rows: "ردیف",
    selected: "انتخاب شده",
    pageSize: "تعداد در صفحه",
    actions: "عملیات",
    expand: "جزئیات ردیف",
    resize: "تغییر عرض ستون",
    move: "جابه‌جایی ستون",
    filter: "فیلتر",
    clear: "حذف فیلترها",
    loading: "در حال بارگذاری"
  }, {
    search: "Search table",
    columns: "Columns",
    export: "Export CSV",
    selectAll: "Select page rows",
    selectRow: "Select row",
    empty: "No records found",
    emptyText: "Try a different search or filter.",
    rows: "rows",
    selected: "selected",
    pageSize: "Rows per page",
    actions: "Actions",
    expand: "Expand row",
    resize: "Resize column",
    move: "Move column",
    filter: "Filter",
    clear: "Clear filters",
    loading: "Loading"
  }), Q = (Z) => {
    const qe = { ...ge, ...Z };
    $(qe), h == null || h(qe);
  }, te = (Z) => {
    y === void 0 && I(Z), z == null || z(Z);
  }, ae = w.useMemo(() => v ? d : Hg(d, s, ge, St), [
    d,
    s,
    ge.search,
    JSON.stringify(ge.filters),
    JSON.stringify(ge.sort),
    v,
    St
  ]), we = v ? j ?? d.length : ae.length, Ae = Math.max(1, Math.min(ge.page, Math.max(1, Math.ceil(we / ge.pageSize)))), ze = v ? ae : ae.slice((Ae - 1) * ge.pageSize, Ae * ge.pageSize), le = [...s].sort((Z, qe) => {
    const ve = ge.columnOrder.indexOf(Z.id), Pe = ge.columnOrder.indexOf(qe.id);
    return (ve < 0 ? s.indexOf(Z) + s.length : ve) - (Pe < 0 ? s.indexOf(qe) + s.length : Pe);
  }), oe = le.filter((Z) => !ge.hiddenColumns.includes(Z.id)), wt = ze.map(o), Al = wt.length > 0 && wt.every((Z) => We.includes(Z)), _a = !Al && wt.some((Z) => We.includes(Z)), Nt = se && !R, $e = Nt ? Math.min(Math.max(0, ze.length - 1), Math.max(0, Math.floor(Math.max(0, re - 56) / X) - 5)) : 0, Ye = Nt ? Math.min(ze.length, $e + Math.ceil(G / X) + 10) : ze.length, Qt = ze.slice($e, Ye), Ml = (b ? 1 : 0) + (R ? 1 : 0) + (E ? 1 : 0), Ot = oe.length + Ml;
  w.useEffect(() => {
    var Z;
    Ce(0), (Z = he.current) == null || Z.scrollTo({ top: 0 });
  }, [ge.page, ge.pageSize, ge.search, JSON.stringify(ge.filters)]);
  const Ol = (Z) => {
    const qe = De[Z.id] ?? Z.width ?? 160, ve = oe.filter((Oa) => Oa.pin === Z.pin), Pe = ve.indexOf(Z), ht = ve.slice(Z.pin === "start" ? 0 : Pe + 1, Z.pin === "start" ? Pe : void 0).reduce((Oa, on) => Oa + (De[on.id] ?? on.width ?? 160), 0);
    return {
      width: qe,
      minWidth: Z.minWidth ?? 100,
      ...Z.pin ? {
        position: "sticky",
        zIndex: 2,
        background: "var(--pd-surface)",
        [Z.pin === "start" ? "insetInlineStart" : "insetInlineEnd"]: ht + (Z.pin === "start" ? ((b ? 1 : 0) + (R ? 1 : 0)) * 44 : 0)
      } : {}
    };
  }, un = () => {
    if (J) {
      J(ae);
      return;
    }
    const Z = new Blob([Bg(ae, oe)], { type: "text/csv;charset=utf-8" }), qe = URL.createObjectURL(Z), ve = document.createElement("a");
    ve.href = qe, ve.download = "primedesign-export.csv", ve.click(), setTimeout(() => URL.revokeObjectURL(qe), 1e3);
  }, Ma = (Z, qe) => {
    const ve = le.map((Oa) => Oa.id), Pe = ve.indexOf(Z), ht = Pe + qe;
    ht < 0 || ht >= ve.length || ([ve[Pe], ve[ht]] = [ve[ht], ve[Pe]], Q({ columnOrder: ve }));
  };
  return i.jsxs("section", { className: ie("pd-data-table", me), children: [i.jsxs("div", { className: "pd-table-title", children: [i.jsxs("div", { children: [i.jsx("h3", { children: u }), c && i.jsx("p", { children: c })] }), i.jsxs(Ke, { children: [ke(we, {}, St), " ", N.rows] })] }), i.jsxs("div", { className: "pd-table-toolbar", children: [i.jsx(it, { "aria-label": N.search, placeholder: N.search, startAdornment: i.jsx(_, { name: "search", size: 18 }), value: ge.search, onChange: (Z) => Q({ search: Z.target.value, page: 1 }) }), i.jsxs("div", { children: [V, i.jsxs("details", { className: "pd-column-picker", children: [i.jsxs("summary", { children: [i.jsx(_, { name: "filter", size: 16 }), N.columns] }), i.jsx("div", { children: le.map((Z, qe) => i.jsxs("div", { children: [i.jsx(rn, { label: Z.header, checked: !ge.hiddenColumns.includes(Z.id), disabled: oe.length === 1 && !ge.hiddenColumns.includes(Z.id), onChange: () => Q({
    hiddenColumns: ge.hiddenColumns.includes(Z.id) ? ge.hiddenColumns.filter((ve) => ve !== Z.id) : [...ge.hiddenColumns, Z.id]
  }) }), i.jsx(Ue, { icon: "chevronUp", label: `${N.move} ${Z.header}`, variant: "ghost", size: "sm", disabled: qe === 0, onClick: () => Ma(Z.id, -1) }), i.jsx(Ue, { icon: "chevronDown", label: `${N.move} ${Z.header}`, variant: "ghost", size: "sm", disabled: qe === le.length - 1, onClick: () => Ma(Z.id, 1) })] }, Z.id)) })] }), W && i.jsx(ue, { variant: "outline", size: "sm", startIcon: i.jsx(_, { name: "download", size: 16 }), disabled: x || !ae.length, onClick: un, children: N.export })] })] }), s.some((Z) => Z.filterable) && i.jsxs("div", { className: "pd-table-filters", children: [s.filter((Z) => Z.filterable).map((Z) => {
    var qe;
    return i.jsx(it, { "aria-label": `${N.filter} ${Z.header}`, placeholder: `${N.filter}: ${Z.header}`, value: String(((qe = ge.filters.find((ve) => ve.id === Z.id)) == null ? void 0 : qe.value) ?? ""), onChange: (ve) => Q({
      page: 1,
      filters: [
        ...ge.filters.filter((Pe) => Pe.id !== Z.id),
        ...ve.target.value ? [{ id: Z.id, operator: "contains", value: ve.target.value }] : []
      ]
    }) }, Z.id);
  }), !!ge.filters.length && i.jsx(ue, { variant: "ghost", size: "sm", onClick: () => Q({ filters: [], page: 1 }), children: N.clear })] }), !!We.length && i.jsxs("div", { className: "pd-table-bulk", children: [i.jsxs("strong", { children: [ke(We.length, {}, St), " ", N.selected] }), O == null ? void 0 : O(We)] }), i.jsx("div", { ref: he, className: "pd-table-scroll", style: { maxHeight: G }, tabIndex: 0, "aria-label": u, onScroll: (Z) => Ce(Z.currentTarget.scrollTop), children: i.jsxs("table", { className: "pd-table", "aria-busy": x || void 0, "aria-rowcount": we + 1, children: [i.jsx("caption", { className: "pd-sr-only", children: u }), i.jsx("thead", { children: i.jsxs("tr", { children: [b && i.jsx("th", { scope: "col", className: "pd-table-check", children: i.jsx(rn, { label: i.jsx("span", { className: "pd-sr-only", children: N.selectAll }), checked: Al, indeterminate: _a, disabled: x || !wt.length, onChange: () => te(Al ? We.filter((Z) => !wt.includes(Z)) : [.../* @__PURE__ */ new Set([...We, ...wt])]) }) }), R && i.jsx("th", { scope: "col", children: i.jsx("span", { className: "pd-sr-only", children: N.expand }) }), oe.map((Z) => {
    var qe;
    return i.jsxs("th", { scope: "col", style: Ol(Z), "aria-sort": Z.sortable ? ((qe = ge.sort) == null ? void 0 : qe.id) === Z.id ? ge.sort.direction === "asc" ? "ascending" : "descending" : "none" : void 0, children: [i.jsx("span", { children: Z.sortable ? i.jsxs("button", { type: "button", className: "pd-table-sort", onClick: () => {
      var ve;
      return Q({
        sort: {
          id: Z.id,
          direction: ((ve = ge.sort) == null ? void 0 : ve.id) === Z.id && ge.sort.direction === "asc" ? "desc" : "asc"
        },
        page: 1
      });
    }, children: [Z.header, i.jsx(_, { name: "sort", size: 14 })] }) : Z.header }), i.jsx("input", { type: "range", className: "pd-column-resize", "aria-label": `${N.resize} ${Z.header}`, min: Z.minWidth ?? 100, max: 600, value: De[Z.id] ?? Z.width ?? 160, onChange: (ve) => Ee((Pe) => ({ ...Pe, [Z.id]: ve.target.valueAsNumber })) })] }, Z.id);
  }), E && i.jsx("th", { scope: "col", children: N.actions })] }) }), i.jsx("tbody", { children: x ? Array.from({ length: 5 }, (Z, qe) => i.jsx("tr", { children: Array.from({ length: Ot }, (ve, Pe) => i.jsx("td", { children: i.jsx(tn, {}) }, Pe)) }, qe)) : Qt.length ? i.jsxs(i.Fragment, { children: [Nt && $e > 0 && i.jsx("tr", { "aria-hidden": "true", children: i.jsx("td", { colSpan: Ot, style: { height: $e * X, padding: 0, border: 0 } }) }), Qt.map((Z, qe) => {
    const ve = o(Z);
    return i.jsx(xy, { row: Z, id: ve, columns: oe, columnStyle: Ol, rowIndex: $e + qe + 2, selected: We.includes(ve), selectable: b, onSelect: () => te(We.includes(ve) ? We.filter((Pe) => Pe !== ve) : [...We, ve]), selectLabel: `${N.selectRow} ${ve}`, expanded: L.includes(ve), onExpand: () => P((Pe) => Pe.includes(ve) ? Pe.filter((ht) => ht !== ve) : [...Pe, ve]), expandLabel: N.expand, renderExpanded: R, rowActions: E, onRowClick: U, rowHeight: Nt ? X : void 0, colspan: Ot }, ve);
  }), Nt && Ye < ze.length && i.jsx("tr", { "aria-hidden": "true", children: i.jsx("td", { colSpan: Ot, style: { height: (ze.length - Ye) * X, padding: 0, border: 0 } }) })] }) : i.jsx("tr", { children: i.jsx("td", { colSpan: Ot, children: H ?? i.jsx(Cl, { title: N.empty, description: N.emptyText, icon: "search" }) }) }) })] }) }), x && i.jsx("span", { className: "pd-sr-only", role: "status", children: N.loading }), i.jsxs("div", { className: "pd-table-footer", children: [i.jsx(Aa, { "aria-label": N.pageSize, value: String(ge.pageSize), onChange: (Z) => Q({ pageSize: Number(Z.target.value), page: 1 }), options: [.../* @__PURE__ */ new Set([10, 25, 50, 100, ge.pageSize])].sort((Z, qe) => Z - qe).map((Z) => ({ value: String(Z), label: `${ke(Z, {}, St)} ${N.rows}` })) }), i.jsx(hg, { page: Ae, total: we, pageSize: ge.pageSize, onPageChange: (Z) => {
    var qe;
    Q({ page: Z }), (qe = he.current) == null || qe.scrollTo({ top: 0 });
  } })] })] });
}
function xy({ row: d, id: s, columns: o, columnStyle: u, rowIndex: c, selected: f, selectable: m, onSelect: h, selectLabel: v, expanded: j, onExpand: x, expandLabel: b, renderExpanded: y, rowActions: z, onRowClick: O, rowHeight: E, colspan: R }) {
  return i.jsxs(i.Fragment, { children: [i.jsxs("tr", { "aria-rowindex": c, "data-selected": f || void 0, style: { height: E }, onClick: (U) => {
    U.target.closest("button,a,input,select,label,textarea") || O == null || O(d);
  }, children: [m && i.jsx("td", { className: "pd-table-check", children: i.jsx(rn, { label: i.jsx("span", { className: "pd-sr-only", children: v }), checked: f, onChange: h }) }), y && i.jsx("td", { children: i.jsx(Ue, { icon: j ? "chevronUp" : "chevronDown", label: `${b} ${s}`, variant: "ghost", size: "sm", "aria-expanded": j, onClick: x }) }), o.map((U) => i.jsx("td", { style: {
    ...u(U),
    ...E ? { height: E, paddingBlock: 0 } : {}
  }, className: U.numeric ? "pd-table-numeric" : void 0, children: U.render ? U.render(d) : String(ti(d, U) ?? "") }, U.id)), z && i.jsx("td", { children: z(d) })] }), y && j && i.jsx("tr", { children: i.jsx("td", { colSpan: R, className: "pd-table-expanded", children: y(d) }) })] });
}
const yy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  BarChart: py,
  BarList: gy,
  DataTable: vy,
  LineChart: fy,
  PieChart: my,
  ProportionBar: by,
  Sparkline: hy,
  defaultTableState: Ug,
  getTableRows: Hg,
  toCSV: Bg
}, Symbol.toStringTag, { value: "Module" })), Yg = (d) => {
  const s = d.replace(/\[(\d+)\]/g, ".$1").split(".");
  if (s.some((o) => ["__proto__", "prototype", "constructor"].includes(o) || !o))
    throw new Error("Invalid field path");
  return s;
};
function sn(d, s) {
  return Yg(s).reduce((o, u) => o == null ? void 0 : o[u], d);
}
function Qg(d, s, o) {
  const u = Yg(s), c = (f, m) => {
    const h = u[m], v = Array.isArray(f) ? [...f] : { ...f ?? {} };
    return v[h] = m === u.length - 1 ? o : c((f == null ? void 0 : f[h]) ?? (/^\d+$/.test(u[m + 1]) ? [] : {}), m + 1), v;
  };
  return c(d, 0);
}
function Xg({ defaultValues: d, validate: s }) {
  const o = w.useRef(d), [u, c] = w.useState(d), [f, m] = w.useState({}), [h, v] = w.useState({}), [j, x] = w.useState(!1), [b, y] = w.useState(!1), z = w.useRef(!1), O = w.useRef(0), E = JSON.stringify(u) !== JSON.stringify(o.current), R = async () => {
    const U = ++O.current, H = await (s == null ? void 0 : s(u)) ?? {};
    return U === O.current && m(H), H;
  };
  return {
    values: u,
    errors: f,
    touched: h,
    dirty: E,
    submitting: j,
    submitted: b,
    setValue: (U, H) => {
      c((V) => Qg(V, U, H)), m((V) => {
        const W = { ...V };
        return delete W[U], W;
      });
    },
    setTouched: (U) => v((H) => ({ ...H, [U]: !0 })),
    setErrors: m,
    reset: (U = o.current) => {
      o.current = U, c(U), m({}), v({}), y(!1);
    },
    validate: R,
    submit: async (U) => {
      if (!z.current) {
        z.current = !0, x(!0), y(!0);
        try {
          const H = await R();
          Object.keys(H).length || await U(u);
        } finally {
          z.current = !1, x(!1);
        }
      }
    }
  };
}
const Vg = w.createContext(null);
function Lg() {
  const d = w.useContext(Vg);
  if (!d)
    throw new Error("Form fields must be inside Form");
  return d;
}
function tc({ form: d, onSubmit: s, children: o, ...u }) {
  return i.jsx(Vg.Provider, { value: d, children: i.jsxs("form", { ...u, onSubmit: (c) => {
    c.preventDefault(), d.submit(s).catch((f) => d.setErrors({
      ...d.errors,
      _form: f instanceof Error ? f.message : "Submission failed"
    }));
  }, children: [o, d.errors._form && i.jsx("div", { className: "pd-error", role: "alert", children: d.errors._form })] }) });
}
function Gg({ name: d, children: s }) {
  const o = Lg();
  return i.jsx(i.Fragment, { children: s({
    name: d,
    value: sn(o.values, d),
    onChange: (u) => o.setValue(d, u),
    onBlur: () => o.setTouched(d),
    error: o.touched[d] || o.submitted ? o.errors[d] : void 0
  }) });
}
const ei = {
  required: (d = "این فیلد الزامی است.") => (s) => s == null || s === "" || s === !1 || Array.isArray(s) && !s.length ? d : void 0,
  minLength: (d, s = `حداقل ${d} نویسه وارد کنید.`) => (o) => String(o ?? "").length < d ? s : void 0,
  maxLength: (d, s = `حداکثر ${d} نویسه مجاز است.`) => (o) => String(o ?? "").length > d ? s : void 0,
  email: (d = "ایمیل معتبر نیست.") => (s) => !s || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s)) ? void 0 : d,
  mobile: (d = "موبایل معتبر نیست.") => (s) => !s || Mo(String(s)) ? void 0 : d,
  range: (d, s, o = "مقدار خارج از محدوده است.") => (u) => Number.isFinite(Number(u)) && Number(u) >= d && Number(u) <= s ? void 0 : o,
  matches: (d, s = "مقادیر یکسان نیستند.") => (o, u) => o === sn(u, d) ? void 0 : s
};
function Zg(d) {
  return (s) => {
    const o = {};
    for (const [u, c] of Object.entries(d))
      for (const f of c) {
        const m = f(sn(s, u), s);
        if (m) {
          o[u] = m;
          break;
        }
      }
    return o;
  };
}
function jy({ form: d, name: s }) {
  const o = sn(d.values, s) ?? [], u = w.useRef(0), [c, f] = w.useState(() => o.map(() => `field-${++u.current}`));
  return w.useEffect(() => {
    c.length !== o.length && f((m) => o.map((h, v) => m[v] ?? `field-${++u.current}`));
  }, [o.length, c.length]), {
    fields: o.map((m, h) => ({
      id: c[h] ?? `field-pending-${h}`,
      value: m,
      index: h
    })),
    append: (m) => {
      d.setValue(s, [...o, m]), f((h) => [...h, `field-${++u.current}`]);
    },
    remove: (m) => {
      d.setValue(s, o.filter((h, v) => v !== m)), f((h) => h.filter((v, j) => j !== m));
    },
    move: (m, h) => {
      if (m < 0 || h < 0 || m >= o.length || h >= o.length)
        return;
      const v = (j) => {
        const x = [...j];
        return x.splice(h, 0, x.splice(m, 1)[0]), x;
      };
      d.setValue(s, v(o)), f(v);
    },
    update: (m, h) => d.setValue(`${s}.${m}`, h)
  };
}
function zy({ form: d, storageKey: s, fields: o }) {
  const [u, c] = w.useState(!1), f = o.join("|");
  return w.useEffect(() => {
    try {
      const m = localStorage.getItem(s);
      if (m) {
        const h = JSON.parse(m);
        for (const v of o)
          /password|secret|token|card|iban/i.test(v) || Object.prototype.hasOwnProperty.call(h, v) && d.setValue(v, h[v]);
      }
    } catch {
    }
    c(!0);
  }, [s, f]), w.useEffect(() => {
    if (!(!u || !d.dirty))
      try {
        const m = Object.fromEntries(o.filter((h) => !/password|secret|token|card|iban/i.test(h)).map((h) => [h, sn(d.values, h)]));
        localStorage.setItem(s, JSON.stringify(m));
      } catch {
      }
  }, [d.values, u, s, f]), {
    clearDraft: () => {
      try {
        localStorage.removeItem(s);
      } catch {
      }
    },
    ready: u
  };
}
function Sy({ form: d, steps: s, onSubmit: o }) {
  var v;
  const [u, c] = w.useState(0), [f, m] = w.useState(!1), h = K({ back: "مرحلهٔ قبل", next: "مرحلهٔ بعد", submit: "ثبت نهایی" }, { back: "Back", next: "Continue", submit: "Submit" });
  return i.jsxs(tc, { form: d, onSubmit: o, className: "pd-form-wizard", children: [i.jsx(Fo, { steps: s.map((j) => ({ label: j.title })), current: u }), (v = s[u]) == null ? void 0 : v.content, i.jsxs("div", { className: "pd-form-actions", children: [i.jsx(ue, { variant: "outline", disabled: u === 0 || d.submitting || f, onClick: () => c((j) => j - 1), children: h.back }), u === s.length - 1 ? i.jsx(ue, { type: "submit", loading: d.submitting, children: h.submit }) : i.jsx(ue, { loading: f, onClick: async () => {
    m(!0);
    try {
      s[u].fields.forEach(d.setTouched);
      const j = await d.validate();
      s[u].fields.some((x) => j[x]) || c((x) => x + 1);
    } finally {
      m(!1);
    }
  }, children: h.next })] })] });
}
function Kg({ fields: d, defaultValues: s, onSubmit: o, submitLabel: u }) {
  const c = K("ذخیرهٔ اطلاعات", "Save changes"), f = Xg({
    defaultValues: s,
    validate: (m) => {
      const h = d.filter((v) => !v.visible || v.visible(m));
      return Zg(Object.fromEntries(h.map((v) => [v.name, v.rules ?? []])))(m);
    }
  });
  return i.jsxs(tc, { form: f, onSubmit: o, className: "pd-schema-form", children: [d.filter((m) => !m.visible || m.visible(f.values)).map((m) => i.jsx(Gg, { name: m.name, children: (h) => {
    const v = {
      label: m.label,
      name: m.name,
      description: m.description,
      error: h.error,
      onBlur: h.onBlur,
      placeholder: m.placeholder
    };
    return m.type === "checkbox" ? i.jsx(rn, { ...v, checked: !!h.value, onChange: (j) => h.onChange(j.target.checked) }) : m.type === "textarea" ? i.jsx(sr, { ...v, value: String(h.value ?? ""), onChange: (j) => h.onChange(j.target.value) }) : m.type === "select" ? i.jsx(Aa, { ...v, options: m.options, value: String(h.value ?? ""), onChange: (j) => h.onChange(j.target.value) }) : m.type === "mobile" ? i.jsx(sg, { ...v, value: String(h.value ?? ""), onValueChange: (j) => h.onChange(j) }) : i.jsx(it, { ...v, type: m.type, value: String(h.value ?? ""), onChange: (j) => h.onChange(m.type === "number" ? j.target.valueAsNumber : j.target.value) });
  } }, m.name)), i.jsx(ue, { type: "submit", loading: f.submitting, children: u ?? c })] });
}
const wy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Form: tc,
  FormField: Gg,
  FormWizard: Sy,
  SchemaForm: Kg,
  getFieldValue: sn,
  setFieldValue: Qg,
  useFieldArray: jy,
  useForm: Xg,
  useFormContext: Lg,
  useFormDraft: zy,
  validateFields: Zg,
  validators: ei
}, Symbol.toStringTag, { value: "Module" }));
function Ny({ logo: d, sidebar: s, header: o, children: u, className: c }) {
  const [f, m] = w.useState(!1), h = K({ menu: "باز کردن منو", navigation: "منوی اصلی" }, { menu: "Open menu", navigation: "Main navigation" });
  return i.jsxs("div", { className: ie("pd-app-shell", c), children: [i.jsxs("aside", { className: "pd-app-sidebar", children: [i.jsx("div", { className: "pd-app-logo", children: d }), s] }), i.jsxs("div", { className: "pd-app-content", children: [i.jsxs("header", { className: "pd-app-header", children: [i.jsx(Ue, { icon: "menu", label: h.menu, variant: "ghost", className: "pd-mobile-menu", onClick: () => m(!0) }), o] }), i.jsx("main", { children: u })] }), i.jsx(Ld, { open: f, onOpenChange: m, title: h.navigation, placement: "start", size: "sm", children: i.jsx("div", { onClick: (v) => {
    v.target.closest("a,button") && m(!1);
  }, children: s }) })] });
}
function Ty({ eyebrow: d, title: s, description: o, actions: u, breadcrumb: c }) {
  return i.jsxs("div", { className: "pd-page-header", children: [c, i.jsxs("div", { children: [i.jsxs("div", { children: [d && i.jsx("span", { className: "pd-eyebrow", children: d }), i.jsx("h1", { children: s }), o && i.jsx("p", { children: o })] }), u && i.jsx("div", { className: "pd-page-actions", children: u })] })] });
}
function Ey({ name: d, email: s, avatar: o, items: u }) {
  return i.jsx(lg, { label: d, trigger: i.jsxs("span", { className: "pd-user-trigger", children: [i.jsx(Ia, { name: d, src: o, size: "sm" }), i.jsxs("span", { children: [i.jsx("strong", { children: d }), s && i.jsx("small", { children: s })] }), i.jsx(_, { name: "chevronDown", size: 16 })] }), items: u });
}
function Cy({ tickets: d, selected: s, onSelect: o }) {
  const u = K({
    open: "باز",
    pending: "در انتظار پاسخ",
    closed: "بسته",
    empty: "تیکتی وجود ندارد",
    high: "فوری"
  }, {
    open: "Open",
    pending: "Awaiting reply",
    closed: "Closed",
    empty: "No tickets",
    high: "Urgent"
  });
  return i.jsx("div", { className: "pd-ticket-list", children: d.length ? d.map((c) => i.jsxs("button", { type: "button", className: "pd-ticket", "data-active": s === c.id || void 0, onClick: () => o(c.id), children: [i.jsxs("div", { children: [i.jsxs("span", { className: "pd-ticket-id", children: ["#", c.id] }), i.jsx(Ke, { tone: c.status === "open" ? "brand" : c.status === "pending" ? "warning" : "neutral", children: u[c.status] }), c.priority === "high" && i.jsx(Ke, { tone: "danger", children: u.high })] }), i.jsx("strong", { children: c.title }), c.preview && i.jsx("p", { children: c.preview }), i.jsxs("footer", { children: [i.jsx("span", { children: c.customer ?? c.date }), c.unread ? i.jsx(Ke, { tone: "brand", children: c.unread }) : i.jsx("small", { children: c.date })] })] }, c.id)) : i.jsx(Cl, { title: u.empty, icon: "message" }) });
}
function Ay({ title: d, messages: s, onSend: o, subtitle: u, actions: c, sending: f }) {
  const [m, h] = w.useState(""), [v, j] = w.useState(!1), [x, b] = w.useState(""), y = K({
    message: "متن پیام",
    placeholder: "پیامتان را بنویسید…",
    send: "ارسال پیام",
    error: "پیام ارسال نشد.",
    read: "خوانده شده",
    sent: "ارسال شده"
  }, {
    message: "Message",
    placeholder: "Write a message…",
    send: "Send message",
    error: "Could not send message.",
    read: "Read",
    sent: "Sent"
  });
  return i.jsxs("section", { className: "pd-conversation", children: [i.jsxs("header", { children: [i.jsxs("div", { children: [i.jsx("strong", { children: d }), u && i.jsx("small", { children: u })] }), c] }), i.jsx("ol", { className: "pd-message-list", "aria-label": d, "aria-live": "polite", "aria-relevant": "additions", children: s.map((z) => i.jsxs("li", { className: ie("pd-message", z.own && "pd-message--own"), children: [i.jsx(Ia, { name: z.sender, src: z.avatar, size: "sm" }), i.jsxs("div", { children: [i.jsx("strong", { children: z.sender }), i.jsx("p", { children: z.text }), i.jsxs("small", { children: [z.time, " ", z.status && i.jsx("span", { role: "img", "aria-label": y[z.status], children: i.jsx(_, { name: "check", size: 12 }) })] })] })] }, z.id)) }), i.jsxs("form", { className: "pd-message-composer", onSubmit: async (z) => {
    if (z.preventDefault(), !(!m.trim() || v)) {
      j(!0), b("");
      try {
        await o(m.trim()), h("");
      } catch (O) {
        b(O instanceof Error ? O.message : y.error);
      } finally {
        j(!1);
      }
    }
  }, children: [i.jsx(sr, { "aria-label": y.message, placeholder: y.placeholder, value: m, rows: 2, onChange: (z) => h(z.target.value) }), i.jsx(ue, { type: "submit", loading: v || f, disabled: !m.trim(), startIcon: i.jsx(_, { name: "arrowLeft" }), children: y.send }), x && i.jsx("p", { role: "alert", className: "pd-error", children: x })] })] });
}
function My({ list: d, conversation: s, showConversation: o = !1, onBack: u }) {
  const c = K("بازگشت به گفتگوها", "Back to conversations");
  return i.jsxs("div", { className: ie("pd-inbox", o && "pd-inbox--selected"), children: [i.jsx("aside", { children: d }), i.jsxs("div", { children: [u && i.jsx(ue, { className: "pd-inbox-back", variant: "ghost", startIcon: i.jsx(_, { name: "arrowRight" }), onClick: u, children: c }), s] })] });
}
function Oy({ items: d, onRead: s, onReadAll: o }) {
  const u = K({ title: "اعلان‌ها", all: "خواندن همه", empty: "اعلان جدیدی ندارید" }, { title: "Notifications", all: "Mark all as read", empty: "You are all caught up" });
  return i.jsxs(Ie, { className: "pd-notification-center", children: [i.jsxs("header", { children: [i.jsx("h3", { children: u.title }), o && i.jsx(ue, { variant: "ghost", size: "sm", onClick: o, children: u.all })] }), d.length ? i.jsx("ul", { children: d.map((c) => i.jsx("li", { "data-unread": !c.read || void 0, children: i.jsxs("button", { type: "button", onClick: () => s(c.id), children: [i.jsx("span", { children: i.jsx(_, { name: "bell" }) }), i.jsxs("div", { children: [i.jsx("strong", { children: c.title }), c.description && i.jsx("p", { children: c.description }), i.jsx("small", { children: c.date })] }), !c.read && i.jsx("i", { "aria-label": u.title })] }) }, c.id)) }) : i.jsx(Cl, { title: u.empty, icon: "bell" })] });
}
function Dy({ title: d, description: s, price: o, currency: u = "IRT", period: c, features: f, highlighted: m, action: h }) {
  const { locale: v } = be(), j = K("پیشنهاد ما", "Recommended");
  return i.jsxs(Ie, { className: ie("pd-pricing-card", m && "pd-pricing-card--featured"), children: [m && i.jsx(Ke, { tone: "brand", children: j }), i.jsx("h3", { children: d }), s && i.jsx("p", { children: s }), i.jsxs("div", { className: "pd-plan-price", children: [i.jsx("strong", { children: Yt(o, u, v) }), c && i.jsxs("small", { children: [" / ", c] })] }), i.jsx("ul", { children: f.map((x, b) => i.jsxs("li", { "data-included": x.included, children: [i.jsx(_, { name: x.included ? "check" : "close", size: 18 }), x.label] }, b)) }), h] });
}
function qy({ title: d, description: s, onSubmit: o, logo: u, footer: c }) {
  const [f, m] = w.useState(""), [h, v] = w.useState(""), [j, x] = w.useState(!1), [b, y] = w.useState(""), z = K({ email: "ایمیل", password: "رمز عبور", submit: "ورود به حساب", error: "ورود انجام نشد." }, { email: "Email", password: "Password", submit: "Sign in", error: "Sign in failed." });
  return i.jsxs(Ie, { className: "pd-auth-card", children: [u, i.jsx("h2", { children: d }), s && i.jsx("p", { children: s }), i.jsxs("form", { onSubmit: async (O) => {
    O.preventDefault(), x(!0), y("");
    try {
      await o({ email: f, password: h });
    } catch (E) {
      y(E instanceof Error ? E.message : z.error);
    } finally {
      x(!1);
    }
  }, children: [i.jsx(it, { label: z.email, type: "email", autoComplete: "username", required: !0, value: f, onChange: (O) => m(O.target.value) }), i.jsx(dg, { label: z.password, autoComplete: "current-password", required: !0, value: h, onChange: (O) => v(O.target.value) }), b && i.jsx("div", { role: "alert", className: "pd-error", children: b }), i.jsx(ue, { type: "submit", loading: j, fullWidth: !0, children: z.submit })] }), c] });
}
function ky({ name: d, size: s, type: o, onDownload: u, onRemove: c }) {
  const f = K({ download: "دانلود", remove: "حذف" }, { download: "Download", remove: "Remove" });
  return i.jsxs(Ie, { className: "pd-file-card", children: [i.jsx("span", { children: i.jsx(_, { name: "box", size: 28 }) }), i.jsx("strong", { children: d }), i.jsxs("small", { children: [o, " · ", s] }), i.jsxs("div", { children: [u && i.jsx(Ue, { label: `${f.download} ${d}`, icon: "download", variant: "outline", size: "sm", onClick: u }), " ", c && i.jsx(Ue, { label: `${f.remove} ${d}`, icon: "trash", variant: "ghost", size: "sm", onClick: c })] })] });
}
function Ry({ items: d, active: s, onSelect: o }) {
  const u = K("ناوبری داشبورد", "Dashboard navigation");
  return i.jsx(dr, { items: d, active: s, onSelect: o, label: u });
}
function Uy({ columns: d, onMove: s, label: o }) {
  const [u, c] = w.useState(""), [f, m] = w.useState(null), h = K({ move: "انتقال به ستون", empty: "کاری در این ستون نیست" }, { move: "Move to column", empty: "No tasks in this column" }), v = async (j, x, b) => {
    if (!(x === b || f)) {
      m(j), c("");
      try {
        await s(j, x, b);
      } catch (y) {
        c(y instanceof Error ? y.message : "Move failed");
      } finally {
        m(null);
      }
    }
  };
  return i.jsxs("section", { "aria-label": o, className: "pd-kanban", children: [i.jsx("div", { children: d.map((j) => i.jsxs("section", { "aria-label": j.title, onDragOver: (x) => x.preventDefault(), onDrop: (x) => {
    var b;
    x.preventDefault();
    try {
      const y = JSON.parse(x.dataTransfer.getData("application/primedesign-task"));
      (b = d.find((z) => z.id === y.from)) != null && b.items.some((z) => z.id === y.id) && v(y.id, y.from, j.id);
    } catch {
    }
  }, children: [i.jsxs("header", { children: [i.jsx("h3", { children: j.title }), i.jsx(Ke, { children: j.items.length })] }), j.items.length ? j.items.map((x) => {
    var b;
    return i.jsxs(Ie, { className: "pd-kanban-card", draggable: !f, onDragStart: (y) => y.dataTransfer.setData("application/primedesign-task", JSON.stringify({ id: x.id, from: j.id })), children: [i.jsxs("div", { children: [(b = x.tags) == null ? void 0 : b.map((y) => i.jsx(Ke, { tone: "brand", children: y }, y)), x.priority === "high" && i.jsx(Ke, { tone: "danger", children: "!" })] }), i.jsx("strong", { children: x.title }), x.description && i.jsx("p", { children: x.description }), i.jsxs("footer", { children: [x.assignee && i.jsx(Ia, { name: x.assignee, size: "sm" }), i.jsx(Aa, { "aria-label": `${h.move}: ${x.title}`, disabled: !!f, value: j.id, onChange: (y) => void v(x.id, j.id, y.target.value), options: d.map((y) => ({ label: y.title, value: y.id })) })] })] }, x.id);
  }) : i.jsx(Cl, { title: h.empty, icon: "check" })] }, j.id)) }), u && i.jsx("p", { className: "pd-error", role: "alert", children: u })] });
}
function Hy({ members: d, roles: s, onRoleChange: o, onInvite: u }) {
  const [c, f] = w.useState(""), m = K({ search: "جست‌وجوی اعضا", invite: "دعوت عضو", role: "نقش" }, { search: "Search members", invite: "Invite member", role: "Role" });
  return i.jsxs(Ie, { className: "pd-team-members", children: [i.jsxs("header", { children: [i.jsx(it, { "aria-label": m.search, placeholder: m.search, value: c, onChange: (h) => f(h.target.value) }), u && i.jsxs(ue, { size: "sm", onClick: u, children: [i.jsx(_, { name: "plus", size: 15 }), m.invite] })] }), i.jsx("ul", { children: d.filter((h) => Bt(h.name + " " + h.email).includes(Bt(c))).map((h) => i.jsxs("li", { children: [i.jsx(Ia, { name: h.name, src: h.avatar }), i.jsxs("div", { children: [i.jsx("strong", { children: h.name }), i.jsx("small", { children: h.email })] }), h.status && i.jsx(Ke, { tone: "success", children: h.status }), i.jsx(Aa, { "aria-label": `${m.role}: ${h.name}`, value: h.role, disabled: !o, onChange: (v) => o == null ? void 0 : o(h.id, v.target.value), options: s })] }, h.id)) })] });
}
function By({ items: d, onValueChange: s, label: o }) {
  return i.jsxs(Ie, { className: "pd-notification-preferences", children: [i.jsx("h3", { children: o }), d.map((u) => i.jsx(tg, { label: u.title, description: u.description, checked: u.enabled, onChange: (c) => s(u.id, c.target.checked) }, u.id))] });
}
function Yy({ title: d, description: s, initialValues: o, onSave: u, children: c }) {
  const [f, m] = w.useState(o), [h, v] = w.useState(!1), [j, x] = w.useState(""), [b, y] = w.useState(!1), z = K({ name: "نام", description: "توضیحات", save: "ذخیرهٔ تغییرات", saved: "ذخیره شد" }, { name: "Name", description: "Description", save: "Save changes", saved: "Saved" });
  return i.jsxs(Ie, { className: "pd-settings-panel", children: [i.jsxs("header", { children: [i.jsx("h3", { children: d }), s && i.jsx("p", { children: s })] }), i.jsxs("form", { onSubmit: async (O) => {
    O.preventDefault(), v(!0), x(""), y(!1);
    try {
      await u(f), y(!0);
    } catch (E) {
      x(E instanceof Error ? E.message : "Save failed");
    } finally {
      v(!1);
    }
  }, children: [i.jsx(it, { label: z.name, value: f.name, required: !0, onChange: (O) => {
    m((E) => ({ ...E, name: O.target.value })), y(!1);
  } }), i.jsx(sr, { label: z.description, value: f.description, onChange: (O) => {
    m((E) => ({ ...E, description: O.target.value })), y(!1);
  } }), c, j && i.jsx("p", { className: "pd-error", role: "alert", children: j }), i.jsxs("footer", { children: [i.jsx("span", { role: "status", children: b ? z.saved : "" }), i.jsx(ue, { type: "submit", loading: h, children: z.save })] })] })] });
}
const Qy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AppShell: Ny,
  AuthCard: qy,
  ConversationView: Ay,
  DashboardNav: Ry,
  FileCard: ky,
  InboxLayout: My,
  KanbanBoard: Uy,
  NotificationCenter: Oy,
  NotificationPreferences: By,
  PageHeader: Ty,
  PricingCard: Dy,
  SettingsPanel: Yy,
  TeamMembers: Hy,
  TicketList: Cy,
  UserMenu: Ey
}, Symbol.toStringTag, { value: "Module" }));
function cr({ status: d }) {
  const s = K({
    pending: "در صف",
    running: "در حال اجرا",
    success: "انجام شد",
    error: "خطا",
    canceled: "لغو شد"
  }, {
    pending: "Queued",
    running: "Running",
    success: "Completed",
    error: "Error",
    canceled: "Canceled"
  });
  return i.jsx(Ke, { tone: d === "success" ? "success" : d === "error" ? "danger" : d === "running" ? "brand" : "neutral", dot: !0, children: s[d] });
}
function Lh(d) {
  try {
    return JSON.stringify(d, null, 2) ?? "";
  } catch {
    return String(d);
  }
}
function Jg({ sources: d, label: s }) {
  const o = K("منابع پاسخ", "Response sources");
  return i.jsxs("section", { className: "pd-ai-sources", "aria-label": s ?? o, children: [i.jsxs("strong", { children: [i.jsx(_, { name: "link", size: 15 }), s ?? o] }), i.jsx("ol", { children: d.map((u, c) => i.jsx("li", { children: i.jsxs("a", { href: u.url, target: "_blank", rel: "noopener noreferrer", children: [i.jsx("span", { children: c + 1 }), i.jsxs("div", { children: [i.jsx("strong", { children: u.title }), u.description && i.jsx("small", { children: u.description })] }), i.jsx(_, { name: "arrowLeft", size: 14 })] }) }, u.id)) })] });
}
function Xy({ source: d, index: s }) {
  return i.jsx(Gd, { label: d.title, trigger: i.jsx("sup", { className: "pd-ai-citation", children: s }), children: i.jsxs("div", { className: "pd-ai-source-preview", children: [i.jsx("strong", { children: d.title }), d.description && i.jsx("p", { children: d.description }), i.jsx("a", { href: d.url, target: "_blank", rel: "noopener noreferrer", children: d.url })] }) });
}
function Fg({ message: d, streaming: s, onFeedback: o }) {
  var c, f;
  const u = K({ assistant: "دستیار", user: "شما", good: "پاسخ مفید بود", bad: "پاسخ نیاز به اصلاح دارد" }, {
    assistant: "Assistant",
    user: "You",
    good: "Helpful response",
    bad: "Response needs improvement"
  });
  return i.jsxs(ug, { role: d.role, sender: d.name ?? (d.role === "user" ? u.user : u.assistant), time: d.time, streaming: s, actions: d.role === "assistant" ? i.jsxs(i.Fragment, { children: [i.jsx(Zd, { value: d.content }), o && i.jsxs(i.Fragment, { children: [i.jsx(ue, { variant: "ghost", size: "sm", "aria-label": u.good, onClick: () => o(!0), children: i.jsx(_, { name: "check", size: 14 }) }), i.jsx(ue, { variant: "ghost", size: "sm", "aria-label": u.bad, onClick: () => o(!1), children: i.jsx(_, { name: "warning", size: 14 }) })] })] }) : void 0, children: [i.jsx("div", { className: "pd-ai-message-text", children: d.content }), (c = d.attachments) == null ? void 0 : c.map((m, h) => i.jsx(Jo, { ...m }, h)), !!((f = d.sources) != null && f.length) && i.jsx(Jg, { sources: d.sources })] });
}
function Wg({ models: d, value: s, onValueChange: o, label: u, disabled: c }) {
  const f = K("مدل پاسخ‌گو", "Response model");
  return i.jsx(Aa, { "aria-label": u ?? f, value: s, onChange: (m) => o(m.target.value), disabled: c, options: d.map((m) => ({ label: m.name, value: m.id, disabled: m.disabled })) });
}
function Ig({ onSubmit: d, onStop: s, status: o = "ready", placeholder: u, models: c, model: f, onModelChange: m, allowAttachments: h = !1, maxFiles: v = 4, maxFileSize: j = 10 * 1024 * 1024, disabled: x }) {
  const [b, y] = w.useState(""), [z, O] = w.useState([]), [E, R] = w.useState(!1), [U, H] = w.useState(""), V = w.useRef(null), W = K({
    placeholder: "پیام خود را بنویسید…",
    send: "ارسال پیام",
    stop: "توقف پاسخ",
    attach: "پیوست فایل",
    error: "ارسال پیام انجام نشد.",
    size: "فایل بیش از حد مجاز است.",
    count: "تعداد فایل‌ها بیش از حد مجاز است."
  }, {
    placeholder: "Write a message…",
    send: "Send message",
    stop: "Stop response",
    attach: "Attach files",
    error: "Could not send message.",
    size: "File is too large.",
    count: "Too many files."
  }), J = E || o === "submitted" || o === "streaming", se = async () => {
    if (!(J || x || !b.trim() && !z.length)) {
      R(!0), H("");
      try {
        await d({ text: b.trim(), files: z, model: f }), y(""), O([]);
      } catch (G) {
        H(G instanceof Error ? G.message : W.error);
      } finally {
        R(!1);
      }
    }
  };
  return i.jsxs("form", { className: "pd-ai-prompt", onSubmit: (G) => {
    G.preventDefault(), se();
  }, children: [i.jsx(sr, { "aria-label": W.placeholder, placeholder: u ?? W.placeholder, rows: 3, value: b, disabled: x || J, onChange: (G) => y(G.target.value), onKeyDown: (G) => {
    G.key === "Enter" && !G.shiftKey && !G.nativeEvent.isComposing && (G.preventDefault(), se());
  } }), !!z.length && i.jsx("div", { className: "pd-ai-files", children: z.map((G, X) => i.jsx(Jo, { name: G.name, onRemove: () => O((me) => me.filter((pe, $) => $ !== X)) }, `${G.name}-${X}`)) }), i.jsxs("div", { className: "pd-ai-prompt-toolbar", children: [i.jsxs("div", { children: [h && i.jsxs(i.Fragment, { children: [i.jsx(ue, { variant: "ghost", size: "sm", "aria-label": W.attach, disabled: x || J, onClick: () => {
    var G;
    return (G = V.current) == null ? void 0 : G.click();
  }, children: i.jsx(_, { name: "plus", size: 18 }) }), i.jsx("input", { ref: V, className: "pd-sr-only", type: "file", multiple: !0, tabIndex: -1, "aria-label": W.attach, onChange: (G) => {
    const X = Array.from(G.target.files ?? []);
    z.length + X.length > v ? H(W.count) : X.some((me) => me.size > j) ? H(W.size) : (O((me) => [...me, ...X]), H("")), G.target.value = "";
  } })] }), c && f && i.jsx(Wg, { models: c, value: f, onValueChange: (G) => m == null ? void 0 : m(G), disabled: J })] }), J && s ? i.jsxs(ue, { variant: "outline", size: "sm", onClick: s, "aria-label": W.stop, children: [i.jsx(_, { name: "close", size: 16 }), W.stop] }) : i.jsxs(ue, { type: "submit", size: "sm", loading: E, disabled: x || J || !b.trim() && !z.length, "aria-label": W.send, children: [i.jsx(_, { name: "arrowLeft", size: 16 }), W.send] })] }), U && i.jsx("div", { className: "pd-error", role: "alert", children: U })] });
}
function Pg({ items: d, onSelect: s, label: o }) {
  const u = K("پیشنهادهای گفتگو", "Conversation suggestions");
  return i.jsx("div", { className: "pd-ai-suggestions", role: "group", "aria-label": o ?? u, children: d.map((c) => i.jsxs(ue, { size: "sm", variant: "outline", onClick: () => s(c), children: [c, i.jsx(_, { name: "plus", size: 13 })] }, c)) });
}
function Vy({ messages: d, title: s, description: o, error: u, suggestions: c, onSuggestion: f, height: m = 440, onRegenerate: h, ...v }) {
  var x;
  const j = K({ title: "دستیار هوشمند", empty: "از کجا شروع کنیم؟", retry: "تولید دوبارهٔ پاسخ" }, { title: "AI assistant", empty: "Where should we start?", retry: "Regenerate response" });
  return i.jsxs(Ie, { className: "pd-ai-chat", children: [i.jsxs("header", { children: [i.jsx("span", { children: i.jsx(_, { name: "sparkles" }) }), i.jsxs("div", { children: [i.jsx("strong", { children: s ?? j.title }), o && i.jsx("small", { children: o })] }), v.models && v.model && i.jsx(Ke, { tone: "brand", children: (x = v.models.find((b) => b.id === v.model)) == null ? void 0 : x.name })] }), i.jsx(og, { label: s ?? j.title, height: m, children: d.length ? d.map((b, y) => i.jsx(Fg, { message: b, streaming: v.status === "streaming" && y === d.length - 1 && b.role === "assistant" }, b.id)) : i.jsxs("div", { className: "pd-ai-welcome", children: [i.jsx(_, { name: "sparkles", size: 34 }), i.jsx("h3", { children: j.empty }), c && i.jsx(Pg, { items: c, onSelect: (b) => f == null ? void 0 : f(b) })] }) }), u && i.jsx(Vd, { tone: "danger", children: u }), h && d.some((b) => b.role === "assistant") && i.jsxs(ue, { className: "pd-ai-regenerate", variant: "ghost", size: "sm", disabled: v.status === "streaming", onClick: h, children: [i.jsx(_, { name: "refresh", size: 14 }), j.retry] }), i.jsx(Ig, { ...v })] });
}
function Ly({ summary: d, children: s, open: o, defaultOpen: u = !1, onOpenChange: c }) {
  return i.jsx(rr, { title: i.jsxs("span", { children: [i.jsx(_, { name: "sparkles", size: 15 }), " ", d] }), open: o, defaultOpen: u, onOpenChange: c, children: s });
}
function Gy({ steps: d, label: s }) {
  return i.jsx(rr, { title: s, children: i.jsx(cg, { items: d, label: s }) });
}
function Zy({ name: d, status: s, input: o, output: u, error: c, duration: f }) {
  const m = K({ input: "ورودی ابزار", output: "خروجی ابزار" }, { input: "Tool input", output: "Tool output" });
  return i.jsxs(Ie, { className: "pd-ai-tool", children: [i.jsxs("header", { children: [i.jsx(_, { name: "code", size: 18 }), i.jsx("strong", { children: d }), i.jsx(cr, { status: s }), f !== void 0 && i.jsxs("small", { children: [f, " ms"] })] }), o !== void 0 && i.jsx(rr, { title: m.input, children: i.jsx(ir, { code: Lh(o), language: "json" }) }), u !== void 0 && i.jsx(rr, { title: m.output, defaultOpen: s === "success", children: i.jsx(ir, { code: Lh(u), language: "json" }) }), c && i.jsx(Vd, { tone: "danger", children: c })] });
}
function Ky({ title: d, description: s, onApprove: o, onReject: u, status: c = "pending", loading: f }) {
  const [m, h] = w.useState(!1), [v, j] = w.useState(""), x = K({ approve: "اجازه می‌دهم", reject: "رد درخواست", approved: "تأیید شده", rejected: "رد شده" }, { approve: "Approve", reject: "Reject", approved: "Approved", rejected: "Rejected" }), b = async (y) => {
    h(!0), j("");
    try {
      await y();
    } catch (z) {
      j(z instanceof Error ? z.message : "Action failed");
    } finally {
      h(!1);
    }
  };
  return i.jsxs(Ie, { className: "pd-ai-confirmation", children: [i.jsx("strong", { children: d }), s && i.jsx("p", { children: s }), c === "pending" ? i.jsxs("div", { children: [i.jsx(ue, { size: "sm", loading: f || m, onClick: () => void b(o), children: x.approve }), i.jsx(ue, { size: "sm", variant: "outline", disabled: m || f, onClick: () => void b(u), children: x.reject })] }) : i.jsx(Ke, { tone: c === "approved" ? "success" : "danger", children: x[c] }), v && i.jsx("div", { role: "alert", className: "pd-error", children: v })] });
}
function Jy({ title: d, description: s, onRestore: o, disabled: u }) {
  const [c, f] = w.useState(!1), [m, h] = w.useState(""), v = K("بازگشت به این نقطه", "Restore checkpoint");
  return i.jsxs("div", { className: "pd-ai-checkpoint", children: [i.jsx(_, { name: "clock", size: 17 }), i.jsxs("div", { children: [i.jsx("strong", { children: d }), s && i.jsx("small", { children: s }), m && i.jsx("small", { role: "alert", className: "pd-error", children: m })] }), i.jsx(ue, { size: "sm", variant: "outline", disabled: u, loading: c, onClick: async () => {
    f(!0), h("");
    try {
      await o();
    } catch (j) {
      h(j instanceof Error ? j.message : "Restore failed");
    } finally {
      f(!1);
    }
  }, children: v })] });
}
function Fy({ used: d, limit: s, label: o, details: u }) {
  const { locale: c } = be(), f = K("مصرف زمینهٔ مدل", "Model context usage");
  return i.jsxs("div", { className: "pd-ai-context", children: [i.jsxs("div", { children: [i.jsx("strong", { children: o ?? f }), i.jsxs("small", { children: [ke(d, {}, c), " / ", ke(s, {}, c)] })] }), i.jsx(Pa, { label: o ?? f, value: d, max: s }), u] });
}
function Wy({ title: d, items: s }) {
  return i.jsxs(Ie, { className: "pd-ai-plan", children: [i.jsx("h3", { children: d }), i.jsx("ol", { children: s.map((o, u) => i.jsxs("li", { children: [i.jsx("span", { children: u + 1 }), i.jsxs("div", { children: [i.jsx("strong", { children: o.title }), o.description && i.jsx("small", { children: o.description })] }), i.jsx(cr, { status: o.status })] }, o.id)) })] });
}
function Iy({ title: d, status: s, description: o, progress: u, actions: c }) {
  return i.jsxs(Ie, { className: "pd-ai-task", children: [i.jsxs("header", { children: [i.jsx("strong", { children: d }), i.jsx(cr, { status: s })] }), o && i.jsx("p", { children: o }), u !== void 0 && i.jsx(Pa, { label: d, value: u }), " ", c] });
}
function Py({ items: d, onCancel: s, onRetry: o, label: u }) {
  const c = K({ cancel: "لغو", retry: "تلاش مجدد" }, { cancel: "Cancel", retry: "Retry" });
  return i.jsxs("section", { className: "pd-ai-queue", "aria-label": u, children: [i.jsx("h3", { children: u }), i.jsx("ul", { children: d.map((f) => i.jsxs("li", { children: [i.jsx("strong", { children: f.title }), i.jsx(cr, { status: f.status }), s && (f.status === "pending" || f.status === "running") && i.jsx(ue, { size: "sm", variant: "ghost", onClick: () => s(f.id), children: c.cancel }), o && f.status === "error" && i.jsx(ue, { size: "sm", variant: "outline", onClick: () => o(f.id), children: c.retry })] }, f.id)) })] });
}
function _y({ output: d, title: s = "Terminal", running: o = !1 }) {
  return i.jsxs("div", { className: "pd-ai-terminal", children: [i.jsx(ir, { code: d, filename: s, language: "text" }), o && i.jsx(Ke, { tone: "brand", dot: !0, children: "Running" })] });
}
function $y({ message: d, stack: s }) {
  return i.jsxs("div", { className: "pd-ai-stack", children: [i.jsx(Vd, { title: d, tone: "danger" }), i.jsx(ir, { code: s, language: "text", filename: "Stack trace" })] });
}
function ej({ items: d, label: s }) {
  const o = K({ passed: "موفق", failed: "ناموفق", skipped: "رد شده" }, { passed: "Passed", failed: "Failed", skipped: "Skipped" });
  return i.jsxs(Ie, { className: "pd-ai-tests", children: [i.jsx("h3", { children: s }), i.jsx("div", { children: ["passed", "failed", "skipped"].map((u) => i.jsxs(Ke, { tone: u === "passed" ? "success" : u === "failed" ? "danger" : "neutral", children: [o[u], ": ", d.filter((c) => c.status === u).length] }, u)) }), i.jsx("ul", { children: d.map((u) => i.jsxs("li", { children: [i.jsx(_, { name: u.status === "passed" ? "check" : u.status === "failed" ? "warning" : "minus", size: 16 }), i.jsx("strong", { children: u.name }), i.jsxs("small", { children: [u.duration ?? "—", " ms"] }), u.error && i.jsx("pre", { children: u.error })] }, u.id)) })] });
}
function _g({ items: d, label: s, onSelect: o, selected: u }) {
  return i.jsx("div", { className: "pd-ai-file-tree", role: "group", "aria-label": s, children: d.map((c) => c.type === "directory" ? i.jsxs("details", { open: !0, children: [i.jsxs("summary", { children: [i.jsx(_, { name: "box", size: 15 }), c.name] }), i.jsx(_g, { items: c.children ?? [], label: c.name, onSelect: o, selected: u })] }, c.id) : i.jsxs("button", { type: "button", "aria-pressed": u === c.id, onClick: () => o == null ? void 0 : o(c.id), children: [i.jsx(_, { name: "code", size: 14 }), c.name] }, c.id)) });
}
function tj({ name: d, description: s, status: o, children: u }) {
  return i.jsxs(Ie, { className: "pd-ai-subagent", children: [i.jsxs("header", { children: [i.jsx(Ia, { name: d }), i.jsxs("div", { children: [i.jsx("strong", { children: d }), s && i.jsx("small", { children: s })] }), i.jsx(cr, { status: o })] }), u] });
}
async function aj({ url: d, body: s, signal: o, onDelta: u, headers: c, credentials: f = "same-origin", protocol: m = "sse", extractDelta: h, maxEventBytes: v = 1024 * 1024 }) {
  const j = await fetch(d, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...c },
    credentials: f,
    body: JSON.stringify(s),
    signal: o
  });
  if (!j.ok)
    throw new Error(`Request failed (${j.status})`);
  if (!j.body)
    throw new Error("Streaming response is unavailable");
  const x = j.body.getReader(), b = new TextDecoder();
  let y = "", z = !1;
  const O = (R) => {
    const U = R.trim();
    if (!U)
      return;
    if (U === "[DONE]") {
      z = !0;
      return;
    }
    const H = JSON.parse(U);
    if (H && typeof H == "object" && "error" in H)
      throw new Error(String(H.error));
    const V = h ? h(H) : H && typeof H == "object" && "delta" in H ? String(H.delta ?? "") : void 0;
    V && u(V);
  }, E = () => {
    const R = m === "sse" ? /\r?\n\r?\n/ : /\r?\n/;
    let U;
    for (; U = R.exec(y); ) {
      const H = y.slice(0, U.index);
      if (new TextEncoder().encode(H).length > v)
        throw new Error("Stream event exceeds size limit");
      if (y = y.slice(U.index + U[0].length), m === "sse") {
        const V = H.split(/\r?\n/).filter((W) => W.startsWith("data:")).map((W) => W.slice(5).replace(/^ /, "")).join(`
`);
        V && O(V);
      } else
        O(H);
      if (z)
        break;
    }
  };
  try {
    for (; !z; ) {
      o.throwIfAborted();
      const R = await x.read();
      if (R.done) {
        y += b.decode(), y.trim() && (m === "sse" ? y += `

` : y += `
`, E());
        break;
      }
      if (y += b.decode(R.value, { stream: !0 }), E(), new TextEncoder().encode(y).length > v)
        throw new Error("Stream event exceeds size limit");
    }
  } finally {
    await x.cancel().catch(() => {
    }), x.releaseLock();
  }
}
const lj = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AIMessage: Fg,
  ChainOfThought: Gy,
  Chat: Vy,
  Checkpoint: Jy,
  Confirmation: Ky,
  ContextUsage: Fy,
  FileTree: _g,
  InlineCitation: Xy,
  ModelSelector: Wg,
  Plan: Wy,
  PromptInput: Ig,
  Queue: Py,
  Reasoning: Ly,
  Sources: Jg,
  StackTrace: $y,
  SubagentCard: tj,
  Suggestions: Pg,
  TaskCard: Iy,
  Terminal: _y,
  TestResults: ej,
  ToolCall: Zy,
  streamCompletion: aj
}, Symbol.toStringTag, { value: "Module" })), $g = '@font-face{font-family:Vazirmatn;src:url(data:font/woff2;base64,d09GMgABAAAAAbIwABQAAAADsWQAAbG6ACEAxQAAAAAAAAAAAAAAAAAAAAAAAAAAGotDG4HRKhy4Tj9IVkFSmmsGYD9TVEFUgRonLgCPdi9sEQgKhLs0g/EGMIaqVgE2AiQDqVQLlGwABCAFjlgH6CoMB1tqgJMJ/2vI3kewLtUdrlE6B2xbaQKgyLkFSYBcMnzaEHEVvaFjDAM2BQOy/EOOkNf25oJKb1Yuztr9dNbs////////FyaL8Dd/doHZz10OEgQkfIIaLNba9rV9oNEDmZGldrWgNlHbepPR24AufVu9PcEy0+sO2fWtX4vYofWC1VEr96hxOJR9h+fj82Y0EXHS+sNZuVydSnVfK9O496eJN/RHHFGtEARJDmk8m23DxpJDDiyl2EucHK/tEpHVKJK+Ew6nvXW8EdZRzBRziHTDPcb3QQTilaLAdibuxLc1rIcpR/Ew7Ke1PeMEC+UGihuF0d1Ewk2hw11+oDeRWeRzoC34XTxO4t3bZ0oXZkq5gz8kDV9qLnFc7pDbD/e1lsu7LHeIxHxXc3nTRSVVUn8VFXfUEOe4MmKRuQTl/LgokT57vNGlHzEgAl18IbtETRERqK/gJgbHlmJ7xzAoR91BOQl7UUmNoEou/LNqxP4d/SgiAjGKuCJm6cVRDiJiyPzAozRkW2iccSRqHSMEJxSXToZJGjE4Ivhwp8g1zCm2Tx8PZLfBkzT1l3pdyV3+XoqvTr9rSfRHCkPAOhNOGHoxE/+9NnQErTSVFC2E07a0xf58rlsnI067iDOY+KGYbboSM5g4K52haQTl/Esr16syXmByIzfnpcyL/da+HkjeqE4UfzhywYNcmxhcfFv69Fe9UulnN/wVl2sMt1S8UxsX4/atziYOhDEIN2EU9yImwlCVtLJRSbikmeWnLza1vtUi/q1wZmaKaQWHQyqt+/8DHV6+EAr7f5rpsQqnUCv1XFlbtcdANORuXxnDElGipCelXfs2tplHHBFdrzqf8Qsl0bKKTEnVBj4fAj8RgXd0xK/tZ3ffvgvqgONABERApPKAI0MB4RMqQosnYf8DwWrCJhQLsRAklNMmxC6sQmwslLjhcab+k8wyy5IssNCSJTOd7QPKYZCapCn9ZcS5823d74DaYWGYdoAdFjBlTNcAN5dLcpgcDk9z1r/RKGZFUqOmK9brAL27ryKZTEIMjwAxmYgJIZhWgCqVtW53vV0fnpaufzLiu57dZHezkaZpPTWoJ60DxfT/w0+QU+3MLH6OeDnloEhb/KDgLdCrSapJdzeyaqMQ/e8Xn1V1u9+b+TS7YTYajw8LReB0ZITRC0Pgtk7LpmPWdsxsqamlWG4UFQe4YKuIgIAyFAVBcA1AVBRUXCNLcSa2NLMx5pe1/+v79q8GeLv93easwxnrncwzklnGqaNCKDQo0S+roYwZWeOMQ5zM1fydkYwyDxWNaeyzzzlzvCGcaicHmzRtU6Kte1h/Tx1148LgefBEOEd54nE7KkIAm5hkZBlkSydZYJFtmWCE39YzfBhPfNbzXfELs7Cw+PXmMAqb77C4KOa4wmLYyBW/sLAZY34s5mcOoxlGccVFcc0VxnEZAPRPjP3rnhsiYWNNImxYRkgSOvN0iCW31YDja0Rd+394N+v/MGJCTdAWimiMBAkSKAGCBy0EvE7b1+k8Mf+6IvJm3871WZWR7qyIhbHB1lqaAf/8T7/fvj31lWk1v7T+/gdhcSi6kTm5mZm1UE21JjESC8ZhLIHn8fDfk3uT/M6hY1KtIGPSwIIUtDiW10tW4hK8l5uDKhWxuVhd4MuhLpVatsIAku4BQ+Q0bN+wdZk6DQBkeCjwEMytAwWLqJE5xsY2trFg3SxYNNuIwRiMHpFSNgj4oo2iqKjvXqz4SL/a+vA7QbGF2sm91HYUDLMBygd6oVAmrNt9i8RAEBYlPAmoshlt3xGCAJ4Y29fFwxxxQDF/x+5FBPHAsfetggY+gY1+Loo3HBU1Jg8koihSRzKxPKhq76OzM733vpShRKAAE4FiQBmQZBc3ASECbmpmQAyIwu01gsn3v2uqusBT5brsKW337VmdkTxN0hkZHeAC/8B75d9kzTqFPA/kP/jHM0m3AJyFkP9b63tvFXc1DOzsB2JF7P+JMLER8qvMm0SoGBVlwgphcebtYENxV9f/71zfxYSCDgpZUSYY0sbcNFtuuUW33Vbj4WzXbzvtDyn7DI/wiAo6Wafu+b+JW1JVFDoopHOlLYRNqzdOz7w5SOd/zn/ttyPOJ3pAGMACB26gvYHmUqBJ34A0GbMzoyYUCzc5oQelmauq6oPsdWQ4MGekBWxZc0nQwpJ99v/8+zxbAWqaLXrCyX2+SwXgzPP8FbrYbazRmglVCTTZJHsldu0DshMvHUG2LVlKXijyz5jpUF5wLV0LT4eop/efW/1XJWhVEqD7fZO1yUrEryDtSJphnJYkdxPO38GZXY+aI1+gssnk7f/f7rSCkpIQEoKyCI3HKIzjcuw/3WHeFZT4s4ASklW+vgdrbpROIzRSNgmJEpahTk1eTl6mKES4bMneprR7Si9C4QTCI/NVWAUMEXMLD8fGYMJYUkyWZAsGWzHU6GqRMQYgzc2KCZWVJ83KITxCw/P9L51NEWave2tc1rtM1KRSFP8gZKkSbwD67/c6/efJqLgYE+FjZaPtv7R+qEVWoZI+HrDdBhVLa4pBlipRMYbBonAgnEBphHPt/zfVz3YeQYigtLsWNkXKleQUW2pDqpzS6WN6uHfevJl5GAAESAjEkBQFSvwi+QNIKiRr582bGQ4CocQfpOVPChtCpPiTpA0p9Q4xF5UrF6XLf1SpdEhF6aJ00bjtXfS9efh+2s/e4/Lkl+v+c4nb9Q56Lj30HkepGoeTCEUopakdjEMyHq2wCsnfm65K/2u3DbMGWAdzDrZOV+IsBBkr4Iw3Qdb6X61Wq8UgzDgYWAHjYJwGxsGsUau7tSAJdgbEWM0a1jin0azRaJ1gnTtjjEtvow033PiC6ILQuujqoovyS8NLrUmSi5ILsuOhXPZJw/W7uH3OjG97KHGNViUnOYv5Mx/hK7NfRv4/VcsWw5l/NyCA9wDx9A68SMpBkp2LTtI6V5dKV24qcAbDATgcBQalER8VNmpzpDZxpY10yt2WW18lXQihvNLu3Lku3Zvnf+5ZlhPS2m1xWJNfRAaLj8ErUbCYirABB64NYYL7n6pli//fcY4gHQhCnOGOVxci6ayucVXrKMkrCYLiZi4uw4kXl06xu6J06fKa0iF3bg3/n7OfbXM/26vJRTVCuS6KHPawLuMZj0N9EJK/L9Wq638AISVV6mhQ1er6KDOR1LiXbZNj7qzi2NussWOPHXt2yYRQTCRJVRKUVEmw1JUCyyRBqfojKVUnQPU0SZQ0KqmdTDtprKRxVWNqpXbmJSRqPih1TxJq1UBcxzHG3dqaMd5c1133tnvdw2mPe9zrHo09HK8bC/jh9JXmx3EA6ZhsLILOQi1k+vfuvp0vOUt2xlq0Sw5ygtwQ1LACmGJY+Acup9d/t38D9QpD2gvjPMDuqLFILd9a/uyvLQOhudKVOhknmdkNd0PmUdsvluaw2ECXpxFO4f+r+rpeAIQk81O2iRP6wOXs9pZh/P8/Z2I60zktdpcFS25l0slUSgXoSriK6UoVt7S6KqVOiSdn9jBlmP23tAL/zo9n9dxIq/oGLKWEYQgl1Dpfurv8r/1G1TvvSexce9EMMog0YqQRIyIiUjGdyTL/cmdznNZ8e2WVw72c++GkrTFCCLGIYViGzfHV3h9fQXRq3UB0FQY7L/tuX/33TgLz1Xf2ot4WmlCIiIiIBBEJ4swOFWDbf1UzQLzY327kBdAI4TC++HNQXjrQHY1YtRQobeH2/Lqv+5E16wmKdlt7rZ3rYBiXMhghjRFiCOEZHjEif77FclX0xPQ1gkQIYyQDG2J0jcz7U6uVI1L6Pe/EM5d4bGyKBAgEqHQEmPu7QzatQeZ0wv/EUzEIUnnqlGfJcUlDxgtasgU1rRD43gNBpq5ZiZr2AovEcppL3IrSoT++nMT9RBA0eH7Q41i+CRgvICr+r6QBs5UHxKG6C9OUHpAkX9DJ3Z5nGWkmSLkyTVfQhdTGPFXLSguAtd1i1T4ftdarj6r2jtnW7ZTpMNFd1KnH0v2GMm+tPP0xO2crYTHX2gQW11Ha7+Po0LMTSu10vkCcERlTUvcWarG1/LGt4seuykZNz9850O9xNz7zIWH0pE+ipk+NJpSJ8hwqJGYZS7PX0Cdx4T/yImKOxbF4My3J4DAhaYYJzXtG1svkZaD8DFaYT8zLuGml6S9vSo2K5tLexIvDZoCqAFiLEdth9aEyxvStAZXEf9veV2oBAtgPE8BxAC4H3BfwaCBuCMRrAfF/IPgjfAIAZ/EB6wAEvODtT38n1iAcGZsoV6vWl9AGAArQL98dIrGxPo4pI8uFKqt6wQtiy2h3+4MRg0HBUb8BAgIBsydYUpVuAAbQQ3oEftH3SPmK3MoUOb0+sJ5cT62n12fX5zTilXHNLDWrld/m2ObZ5t8W0hbWFt4Ga0O0oduwbbg2chu9LbuN1cZvE2gCNAmdV7riujHdhb3hfRn94f1x/ch+XH96f3Y//2DsMHr0udZSa63drw3ThmsjtDHaWG2cFqGN1yZosVqcFj+eO5E5aTnlOsWYeToj3RCzBA6NFFXaIQnAEKFwK3NqeibzT92+jkZYiYpV64neKS88YoLx4iSkpFVUdaIw4grKKuSpcyQYaZGzb2WtAbyyCgIGDgJeUGDBgYeAPKpoQRecHuP496YWDiyYCEcvwwnSmjAJesmRp8YgQ6ywyuH9w3aUWSHtba5Fjd8BBQkRKU68BGmSbTrODGEi5POpLFy6XENHHHncsAnPOgw90A+rxiWTc1AeGJwXicLwYXF4AomfQhMUFhWXlJJWUdWAUsg73ecZOeQRLlK0BPkVViag8EY4CmlMR5IZzFyZii6h/KVVsvJ1oCf4gZZa7lgXxz3UYsttcJOfCSkqSVJVEmDg+ODgEZDQCBIjSYo0efZy13f+73TxXW2+r+oWc8JUDTKMEQ1neKMYzQRNyuTNxxyKtTFGEln8Pn4p81wGk0wq+q+coYk29IncB/mRCbljjMJKqRXzMfOdFmfmd/iVWB3KjEXyBidJR7R/GobwUXOJDKQuZoBOHkIAgQDoe+PR8vyXT/TyvnmZeyv8tBLmZYwEeNlVjI0UX9nCoJ8h6HfRnCBzwhSYWOBqgZcFhq+7QfHdRn6GIYHAIICHP0QdCA/UB5MHnoPhxyYeo94afov6SPcJ9ZN//+Q/P3n9J+/+TP5V7FcP/entf/zhX6Cehey6BGHAYAC11cgRxtKjFbYfrVMOAlggSS/keb+mZ8Hwpp/I8uBw88+3BfC71i5Uwe92tlsHPwwA3QYgYOFtih8wFK4TzdM48G/+304TvG6/t12HgJML88eNmACMd0mhrDvVmst3i2xVAANyyOPXeako9EsTZVRQRQ2gwMa0ITAcFOC2fIjrp0EJaN/397px6WtEL2KSVC7Jzo+d11wQnMnOVH+u/5if4+dHM26kSYoJ3djmHCc58FDmZy4a4JAw+BDwEyBImBgJUmTIUaBEhRYaAgQLE26c/8SZIMEkKdJkyDRVtlwzzDKHTL4C8yywiIDQIAmZISPGKKhM0tIzMrOiuYREJaRl5RV95gu7fe1/9jngkCOOOeGk084acV7CmAlpOQUlqtRpYWBLiEFcpIRUkbqYXikZWXlF/SqqBg0bNW7StB3mW2aRVU5YNov9iggZOnL8hElKjzpCQ622cWC4YPiLJkCqAwX46lSR4DDWdurlgAZPGoHixxQ4WnQzfD9+mDRxWpnjuAs4wtG+hLrykBf1KrlKpNdLI5k6Ih/zZFJ1V34fnuLtabTU4Q/apy00CjUV0LA1XgagOcy60QCjlv2FFFFOvUiyBRlm3HQL1OCiZ8pC0GgTrBPKNLxWjqjyGJf8KCcHqSzVlnGmdX3SCXAYv0Dc6hrx4PfRe6shAMUDDgEJBQOLgIgfmQBqs5NvFBvllq+6kCAvtaKRUTemGrp2vIGRSVpGXkHRp8bnxi7jS2NPY6/sKDOs/BZ/yikpOXkFRUqUW/Z/a5NYRRYqVmKkUUYbY7JpZttim1E588oqFlRWRYYsDZKwAgMJg8GQMDSMAyYcYqEYSqEcKqEax+NEqIdGaIV2GMaZsArruBZBERGxERfkSA5KpAY1srIqX+arfJNvsybrsj7fZ0M2Z0u2Z0d2Jj27sic/Z29+zW/5PX/kz/yVAzmYQzmcU7mRMzmbc3k1rw12AENuyA+FoTiU0SkqW3E35dwEKmoP94NmC8Frg3UcgcjByc3Dxy8gqENYVJcevfpMtczy8ff7B/jjWM3h5UpHHcc86RRdBs46x5QVa9fqbT96hzMXruMDRc2L9EWoMOEiRIoSLSaTziRL81aNWnWOAhwCARQMHBIKGgfhUUrhkCMJnmpaVHc27vbkoUc8ePLizYdvPjnPMKYj8CZOW1i8Y0mISSGf2kUq3j7X0BYfO5wv3frPJw38y9Be6ctvu/xhfhk0bNS4SVNm6pzMLli0ZNmq9brpfLdj95LDAQoPcYZHApJVyvlHjjwFiqH8EBDDrkj6vkluX6ULHRIcRE4efkFhXXpNtXw1519KE4o4rZgsJQop+CrrqPIUKYVKKxH+DbW0pbY73c6+66zpxtAtYmcOlrwLlCcUdVFxV+VKlZ1RASGU53ByURqlCUVcUtYfyheKlEKllQhpoZa21HaX2lk3/NGt2Fkfw5o1qzZtYmNjb2EXZQI7iJlbYFhdJ9+SxR/VtRhhF6EQOHDhxR+40jazMb9+NzY2Nja2EzY2NjY2NjY29vPZzNUejw64vW23d+DMhSsvvkKFCRchUpRoMZKleatGrbpFJs7AwfmgRnGwyHkqrqkkylSoOu6EM/lkn2FIWMzC2efO95sffhk1bjJmFujxtp+8w5kLV158hQoTLkKkKNFiJEvzVo3aqCuBQ5HzRFgklD73zQ+/jBo3GTOTOBUBUwxUiUIKvspCKE+RUqh02o63nX0XrW7g71bTndvw2ULUvxhYPTJCsAQCCgYJjYNw1TMt+gwQnWaTFPoMv6wvifa1/J8f4zhoRIeJqckHwIpPpmtRi6CQsIiouFr8uNMnXO9hM+biWnlYMkWAGqFnAGOlIQZyDlAqJRFBbdoyh+iRLMESCCgYJDQOwkEpHTQcUy8Fa+9XHfwZ2llg2pdiZm6eb2lNndkOaf3gd4btlKRXk+eXgyBXlGtIYLNx3P28a4Yb8/tfhBJNsWnPVLOEwFkSdd/F2oevjvVAdMZWV+OuSbcygudCQiJw5uIfsDJzSz7GzHNFg2xF/Rp5O3PNr2Xr+ChtrfgT2U8wB8j1cpjj0nA8by9m5r5KtN3zvvKKN3ry0H/eeXEp0yb/t3l/LjjbErn/QK7ZA+UDl5k0SqQQQq05HAG/roBmI4Je1hCAhb+L2XQh8LzWBldqetPcMNYZ3eJlWm5/t7TIeesseORWxlyuamPFWT4Tx9V+2/LCwWp5qcrFAX9pxta8Hi8/j8dQKAKga3FXVrDyX4IJiP5maf1iNSufhra8J2zrza7WhbHg6Nw6swLZouKEMjuxOtpaq7Rf6mUzgvpfl3X1+LmSNxgQVfM0u8ktbGaQ3dbBbWCkzHjWbNjUBmYqgyvd+/WOtWJcoHu17uuyYyAS7+b1rW85l4/HMZ4VV11nutjcreCv0vzKppcxz2jJqpe6xjUAWMO1t0veyuglraebV7e6pdxLwQ8T1WUselVRuSVKg5hXHTyReLqX3KSbJhp19pxoWBATP2GTBeIVCBlxs+c9S4iAj54Rt2M5tpbEdcpUGSiI4Dm1tCfg5bu0/EG6dFIVD+kNuk88bdX/7R1+rvfP+1avSrApCifMy1Sa/bNq90YNBDV+WAEI/rg3Nls7uv+obevO3nWe/Jd982j/WrerBR8d7X7mRfHjJ7o4IlL2qdCm927mBou01J7xt26q+VRt8HzYlvZ345trzqW2ey/5Y+ewBDvxcZ921d4nM5sva9Go8PhaLeeWo1NJWuWm00FiRqUMtNZEWivLjtwrw1ceue5E3yr/Ps6aM2/Bsm2GGm6scSaaZIqpkkyXbGYT2pQliSPJ7fLGJlObzJiuWhuHgrGYIX4yEy2sOJWn6rzoQ1SjVt071ii7DQ64ZHssDp9oM1rCHr4bNSUjwr/thjey0Y0B8+j3MGTXU6nBg+FTQxlGZasGI+BEA4wmJ1pgRJzogBnGyXAw+pwYghnJiTEYE05MwYzmxBxNmJsYNwluUtxkuMmBcGHHFYQbOxIQ7ux4gPHkxIsBX5QAlGCUMJRwlHEo/6HEoSSgpECkUqEYm1Js1uGwQSc/xGGTTu7Qwo/w+LEWfoLHz7VwJx53aeFuPO7Rwi/weADESTWcAdGqhjaQdiIdIGeJdIKcI3Ie5AKRSyCXiVwBuUrkDshdIvf4OQ/ymcQXUS6R+CbKFRK9oszi+ItjAIdieiNUD4MYXMSlhJSoIlXqugnFWpvgExVYMZVKBS/fIofdu6xsZWUrK1tZ2cqTTdZcsweP4jUlTUqb/py1gFHuFPwNFWy4SOPEmthxPMLp8we0GzLaf2VioC9bClNFCj36VmBqXWDqTEDVFgi9D4R6Hgn2/wNEOxanXlUMyFgOGQExxRQHc4kiWtuCyfqBsxooa/UIFhUrNsWLHyDxCLk8QLZjbemNPXA8N6j7i0HbB0OtlwfUKwLslQH3qoC5OEAuCYjXhnbfHmpdHjrit+FAHAqM2BegqA1oHAycqA+caAgt8feAxpGAhjygcTRAcSy0xn8DI06G9ngk1EZb4KI9hOKJwMbZehw+WJ8jhOOZ4IlngzOeCyguByquFK4eT18jkHE9MHGjcPME3DpBt0+oHxJgPAo4ugKMxwHH64DjXeCiO3DxMwjxK7Dxu/AnGvqi2X8JbHIDBsUGSxl/ASt5VdqCmr8tN4YLmD4k3uhmFypYKjf2vWyW2BnZGdkZ2RnZGdkZ2Rm3HYe4DhirfjbzgLGFGTsw9sw4gHFkxgmMMzMejHiykwkzBZepMFm4ZMPk4JILMw2XYj18Rw8PgDmJySkwZ8C0YtIG0Y6hA+Ishk6IcxjOQ1zYPy76+ngZDFcgrmK4AXEL4g7EXQwPoLCHvyvCLRzcpsMMB3fpsMDBfTpgHOzo4OBgTwcPCycqRErofqCP4G0Wl5BbwCXqlnAJvAMC4LEHVrCEH4xgiUAKgiUIqQiWOGRGsIQiSwIejdzkTlHAA1K9FeoxCgxMUlqhnqLAgCWla9RzHNCQuV7ggAzO9RIHZHyuVzggQ3S9xr8goxSNdrvdLwaeENTDdUABaXaBgArS+Q2pxBS6sdqQGnTN0WzdOksRhivMC8Mw3IwJAWQaYMwWINBi6OmasUwB4RaGgWF+MRer4LAXhYMeyxgO8ZkdF+p8BX1/PmAXBK4LA/K8gD3/Yiyo8IlkHAi8GV6tAiJwo15PwLwh1HljUYtnnG6O+ygg9EIgkIbjFKEuThe10J05c/vcfr8NhUZtGrcbgnZDxIIQAmoinvSA4mmA8SygeB5gvAgoXgYYrwKK14GINwHF2wME83rPgcTzEvsDgYyPNX0+sq9H9T1KfkSlYq4a4QlHddAH+YOHF70+DDjfFj5h+ViOPQygFzAh+CgSi51Z/deGYHtt6XQgUEaIryGk76LgReodbpW3zlocgQfyueb6DgKus+FLPL31l5F/uRuH2Bt307x0mTnW4/DTNDfMD8fI0UKniJRr+jGK/Mbd7h3e5tPgI+QP3vY5scc1QKqxIKTP4co1IoslZeLIm1i0x35fcf2CA6/1s2c9stgeZ3+jyrkH3B9WRg9YSbYdZCXxix+4aGCcx2AK6huUCdPCLm7sMY3efoY8UgXW+QcbTBF/yOmHGRGSZZT3Ka/43As5XuarKnCz3dYHc7vtzr4kdx8i0n3tHqxJvS/kuNcvrdUF2t9qpNynGqsy2/OOlFwTxzaaXS1+8YOe1eOTXun/9DGvm/DjPpTwCy6V01/2lZxfAV3k1yJ9K9K3pe76OYyyM8BcNDNLW/tplK39/AEx8gv/4pfyrcWvlFiypbDqsaKA8qz7/02mn4qzq+2DHVcGqrtiRmq8ag5qsbE85ZXs0jYEcACgjL90DICTgLZ97kZmXPv1AP6k/ba+l3+NV8mPYnYs5sSzDvv9wE/BBgdc1KHwgyM4pST7gjKnyPb8eSu0DgIIVSO+rugfZb08PeUgRun/3DbYCBHE6IVMz6U6hRSiWy6YXU5lNRVmJJVcCo0pSctU90570OJNVY1VMsz/IQLgQcsHeEpfAwYYYcK3r2VLa8gKsAJ/oH60GwkkTtCOCN1dkMPpQT+SSC5HgQmKVN9tiPEgi2eZxuxTODolOZTttg/zx3Qxj31MJrgL2uzvNM5Rw3Ly2MBLZpvDv9jC318CC9nP4Ul2UqJRvKS9lmlZmwx8EJWcSFqyY9+sdV6nYK6T8lNsRsp/pqzyDO/wkdVe5XO+UX+uuMNPwsgcz8pZ4UGH03fZWutOGzQJ68O1/wMTavpR6p70alP3w1MeXsrwT1iQEGzyt7FM06mm7+XSn6fXlBb4wV+MreHtQgitJmZfVV4K0M2PYR+kOoUqyj740qr6RXFKEs0x/i0NJX2H8QupplwxFJSCb6vMjwD92/YRn9IJlZrrOvp6IosndF6VNDboUfrO05BLsWME+UFuHL9QfoYtKBW4jDaHcOAHvQ25AOYhZSgzlBwwBL7Qj5A29BmkCe0JcUCAgFBGGOhZaAHAKtQb0Ah1AWRhuZkCBgYkQXm5YmlAPAgDpTJi+saCFKA/JvNXWhRQLZ2RtPFk5qLJxzcvSUl5IhE7b84GAcJgfzhmpeEECFjkMYLePG2UmSAooVRryBHyk1e3P8N+fgT5SzRr1AXYV9Oy3T9iYFKApcw5PwisAT7O214Czvw2oiBnMU0Ms/Hp/nSqc7TvxiIWHiKlhYc/05JW4u6+epfAt6Mjxl6dZ0ogdpUx5jMn1BgcxiIKReQBpVQLX3wOuR7S5bFPt51bhBfZHaL+s320cZ49r9lQ5SaU3DsTueXrQMD9h0kSTfFlh50Wh3kgTM0MNKQBPEPgxNvsIJF8GtD/mtBPNGxVgy8rwFGBForJYlKsFFCYg1BBqDffHFyjW/P9pnkQdQS08NH2frg0MKeeS1+3g+aHorPE1uFWPawJikyc68HUTfOJwYUh4sPzeeds5ZbFo7kDKAmz1ihue8htmclKqlbeRghYFkRXxCAmHTwtsB3mDjGfTnwBZbNhSzg7TgNTuRH5Wuanq8mRBT2sLbLS4GkUoZBKQ+Rw/VeL/IgYDtHi1rTsPyCNCW6cupJzmF2ow+Oh2X4q0CzSxCUj2Q0wqjs+N7sKqa6kQpAPRK7pnlwpNv8PwN1wN3S80fWrIrVRESwNXXA2hvmQFnQCuROgM5jB0RpWrSslJgOjLfKmKVf11Anzub7JA47Hu8CIe0vu28mpsBYU7w7ATmG/5iM4HZyA3xa7/6STCV55bf0l7hfEDfefci+A8QPQJcTTbdp7/mtn4H/pUkDmDtVu9nFQ8OVH/Bil/QNUXAiJgBsSDrkr3ffTfT/djek+TUJ9VDAQPATEx0/bUFQ1CM215Xl7BFS4Hr9RJZkRSu9Qbj1V3/iFDMDpc8sLsQoUbF2IQsP07mHRgYGryFH/qWcsJ7Y7Q8uJumb2ahiDdrJweuKS1nXnzyQnF1p4iSWXWnoL8y3QeiKGR/R/0CRKIqbJmDmrH0QvuNAu8AmJySupMPxgxTmCB8+zXu+97nnnW2zxLc7TZpmQWMKr5+RSZpOUAbGMmRiLKeprw7ilMYCZ+P7C5st0e1Co5/DoRRbd0rzzL9g+UAGi9nZaWNwLKHj12Nm0ac40DQtrTbmIddosJ+aBhBgQ1DcKR4ANgWDh3oDPYkAOaSX+fjrILw6xi90ahDUAJD+++hkRWVSXjGDT5PRs1YKZ4CzZTE5WCNNRzYzFaH4qMT1EVZA/XFpRzSZKeDe+sowoT2EySKlduDTkhQVkAr5o5MNArsmZsvJEO2MTCQuyDUZ6aB1FhUm5NdEwl7fBy+eAz0gaEMpm+LZVEeUREyaJkwuhJYUQiI/GqmtumFXmm3+BBVsvFMPKItPOEe1wwRCgN/X5c0u2PlQuT50CUAocmAaz2fx5kqaEtrmgf2l2WJ58BV1VeBBJXK0Fy1YahgQl35VUviStCD9byTVzUe0tQbPimpnQejdxb+KTy3Z2oL+RzdL+kfxlOpmDAcEJMXZmeX9/3WuwJr2b8uib0yTD082bSZtpFgwTb/GB6N7K4JREGX6eUni1+WcvqVZPYKawCGD6/fN3EvI65Bo6KEd10zeCzngGl+L0D5YaO+5hp3n3th5moPl3dmDXEiVwaCRRAUmjyf8T2Xai6Y7/J3mu0Gd7nuxOPSP5G3HHwM/jPauY/DVGPGCQZRBgEVMVcQa9cAn+dzhvTrhtcsf4ev0mCBK6UA4n8zAO63AeaQAzvtnOHxc4f1lmzREHXXwLlYYXYbRHfiZW+v46q+feU67mvDmmiwXwADKADWRDHcb98Xpd8lJEu79dl5Y71DpbdQNBzFt8j13WAAAXwE9fMVu5ktkfXP7ttwd8rupu3ufM2MNT90vhcYT4btHnTQVU6FCLUmjrEFoJRS8maACLOGI3406QERsAwACuDeUfs9qqv1S1XJv1qAxlLNOzhABD5r+9/c/vkXorHYizFF3RnuXix36Vhb32iZ+UeOp9sE/f5rtzf8Z79IyNtbBcN4Isb/b+9uvwjsl7wiJuKB9+LLO7kKY+0bwWdndLW96K5eRYa1p7A13xJTBM8ICAsPNA9FQZZYx3DWAZWhjHEu0rGgiPSo9MMHAWArRhGEpM4DnUuNnbxk1GrLCc9Eg6gIcZthbEcNGCrnSHV7kTO7ea1RXmrGtgDJNIYy4Z0FgOAjNhLhPGMsmiVPMen9MkLOggD8VkYs2s0TGxVKcrkmjGAbG/b6DWqrTSa0cQohtnh7E4gDUcaMUN/Zxne0jqpjnfp4ANNd18t1h29ZQ1wgPvxRyfSULcEopudFySAplwopuX0pQDDwTjwkjNT1srmIyMZke/TxryQG+y2yRlqJPbxxnDykRl3bTN6EjG0hZmeR6Nab4tAMHrsl5LXorONGWZW77CqIjRT8F+l/LpO7N29yClzpkOwIZ8VZ0wXeoqVNyPcJHal+qGtIiFQt6SUh9OAvjZVzVDobMCLVuFLtRb2bIq9ATcruAXJwGVr3smtU9qyke+MWzkSlfDlGL+s8AthdUWen1QA62JmPCNroFOnWi6pCrXXE2LA2uDC1Ek74omPy8NoDjuHL6POFeb/D7OXSwg3EoiJbWG4L4SGwjI3ttj/wdghCZhb9QaTsBSf87XlM31Ua502sKclq3bsnMHSo0gz44h5+WC/bJjyage84ALXx199FkNa5XsyVqgnA6vNfjj++vEda9kOZ168mkus6BIpB+5Vr4JA3tV2ytt0j4W2uqe2R9vhJ/ETZd/POfC32LP95oCNHPKLn0Ue4q97nH01zROwSyeHux6lTVA6PsCknAjSRF3/mG+rGJxr2wgPXthJwGzkMjS/qEAC8Ym8qlveAeiKnT5v4Vhu/xQT1GBmS5fwXwuUUuERYaAmIlmUp7p28EsXdbCZQqjAKOGVKCCalNnUK7YU65TQmHZ7XqWX8wlWUQ52k0JbvzmxEx8sj6aqKAFmsCE2RNloZechoXN9vyz14IZIy32juhfW7Xkfq2Q30z/0QDEcjB7Jxf7DoeAO582Ss07HF5LU+rSxs2ShPrkYD7zkJNkasGONfUqN6JM9V1BET54AfVvUT3iw0WNm2oTsG/KotOnrUrXPXLyX4za85asi+Ghxjzj/rnuUpL9kShbDRU/wZbot3ALptHmvkSOHIkXpZpcLl/+Fj/l9ZNHYxyLuWGOGzxWgYm4VP3yQ66rR4Xr2tVUiAgHlNNXKtcAIKKdlPOTXhNVRKD9wmflkzDIUGBDVQe7JmauFUCiSkARozymIurTWDuiomQNy1hKVGRyr9a3OqLasIbJzlUGjVbBBGr4dVNXtH7WlZkUjc8c6IWNoHtX9Il0xAlfpc5t22APMaAgudb6byITHAGSq0KfmEylpdpxjgEj95Tpf9rGl0ukVz6k1B5KihsTfSiKd3VT3NgRdK8VvFYjNQVImCjbQ12EZKPhSwaeCYEwSSANXU7pLE/15tE0IcYLF++qpPzfDuuLIk43sJpVl18obyTQkRXqNeRhW2tURQMpGqKNrKslYYOjzUswalVPzxoypkBOPLZ788uqSSH8x7eotE94lEz7SVJVYzLXKfZlkawKQYOvmJ1Jol5Igx5ix+WsE4cWh7OKtQpNVZrC4MsFqbRsokvO7aNQ3eNsYEe4d0aMnqvFZA2L8QAjVUbivw2TU6PC+buyx2xlFLtWZrPg9gisMEGX6d2NYM4piYSYrl0izP+gioQORm4A90VUU2ifElzlDu5zWpgvtvzJjKlWqA+BGR2uYUFRb2uDiEoxFxQQ5MtyzlE2eyLuQ4umC3aLug2ldcKnfSXlCAqEmw2BgKmf4Sop6kYZKaNC9VpZq/ziMxEa+FDuidDlEjn1SU3L6SqWyk4U0cLp3JYyG2nX8jCNuyk3DBT4aVm09LbplCLypNyIIIxykU/AYtelBFt2VYNNLxlZe94TiA2hlyXlr0pXOUBXJuylBAXBDppmET6YayJ3K/4Fm9xipFdH/CRdToRaTBjJHVmzObGTLlS+6yJTr/OUPTcVNaxYdWm1kifXqRoe1OOkwYXNaX2Q8tYw5aRWf5JerfIziJiRbESUkU6sRIU1V2sPwMZwJeVl2fVtCWn4VqR6qhPPSaik7FiB9BrmkH0/Tpq/hsEp+3VcME+D7R6ws2a00Cfcd39CG1409hDzcR0tmDWW8sUbwin48uQWAkva1zYHEPR/+pbkFHCrzDcWe4AfLrl87JPlHujuiQ9uBFEGnQ5Evo6oe61Eg1+7x4v1Zwd35feHn/o1xYP+6DHP+JsXveoN7/nIF/Y46Lgz4iblVUNb6AnW5JeTU5/SbBVyc5ySuFgHNcWQgyVZtF+8Xyy8Itwrwb4ba/HZ359vq9MzDxMkDjYYchXm9jOApOfmcaoDPfpzF+pNvHdyC+lJeFrU04+Lbr8YxHnElBY3whoe/F1rIWrFwQ8DXefPmV6mH+l95qqQaYMw0tvd8mcJKAZIEeC53osKtCwODkSzAyOxE/a9GXsR4QWr1O8qCbh9Q5DORq9wZPo3jRA9q16K2/VhMThgkuDu9g0Fh56dFJxt+WA8nU8taATcpynvGvKdXKTBE4zSyWhwLHoVezdyl9M9/GplOvwFcq37z/sZI8R9nuuLeGqz5P33T461XLoShjEI+hGu+esZ8E8aqrQYCb+6GTRGw8YvqcwjhpRXZh1Ddb7vDOv9W7b8Rf0c9NIG+3K28u+vrOr8V7nIZU75+lndyz/ssS/hMk9wdR/9Zb/lz/NfM77zsd/M7kuut1271ZoyH90i6ygv4f0ym9ms5ja/O3uwp1qTL/2A4l0rhnz5d6H5zBtwpwO7wVv+yGv5JFBBQzHYqEELBjGFdeigxw5Bqx8ZygQWspS8ZS11uRRRyhL2yveglZKr1PMNv8kSdBBBPooSqhTlqlhs3vN7cF+ADUM1uvSDqXol15y0ekmx0xhoIJeDhu2Pk51ixhcdfcyxxlnNY5njmu/Eu+Rej3kd8FnrLycmPEkpNk/ihJ+/IstUrhdq+PGAXO0zUYNOJpjzYs7wp2V6RzETo56b8wbGWb/kcjl1GctarnHldySr2s199D0ImehorWWyKX4piTq9eBEiQY46MSSRQR4lVNFAGz0MASxzC5s9cJSt33VzJVydWqQdKruWXedcqmvPhbugS3IRdA9Yyv7PPtQ+ATqlNCBCzhw69LzBJAt+q4dDjAOtHhNXV95PIpUWdEcGYx1/HT0cwx2TnE210OfNq0J3e7iqvOnn06Zk4P8wEQ6Co+A0WkZhToQXYbqjzGr02Tly+nPyciI7pRzzzl7dtVHpf+JazPyc5btzhmKRX4SAuCGhCFp6S9tQUeWdq7b6vpnxYH131/92p1ZdC6Lqs/TFw8454jyrxffr048/IXmn18mNA3XWgf3luk9u9QtQ5vFd/ckDdLAPhD//7kRPEz0PkCg8/+zCzW+Fsqy8Vzh5su6bxfKbK/bSR3uAg90snd3ckYEnRfzXtdP8AMc4xttlnwzDCFZ6mxbOxJ12DrxmXr5P5Jsm7BfGtu2GW4045Za3TZ/n+EeDJqJn+rjPv2JeiU9/ufr4rh/X3M3PQWn8vy2c+CXvnLnn9i+kbWOlibr+fLH16YGc/3G54YnK7rsZqG9gB30OF8RHYhN6F2aKN2wpZfXpZdhLz0GneFJsoEdgmrjf22R2bv+40i1r5eBQnullMb8nNu1F+Gt/MrplFv8lVP/EbfKuGbsmEEoD16e0f5KflzNLDzPF06PybL0rb0fd2WG18ecjzvIx/7yPBcWM57zP4tyLHqEbVXOVXtaFipJ1zCZSpCG2pfb9PRDHkR9YNK/wpWpakcd+hJPHhg+x2dV9lkv30LSQLVZorS6ExdLpfvvg40BLYYsG6oLyN/3XCPhr/wMqKFl0wEF3pxbwllwgFX3vgxON72V9f1QgvF3G/u06oGm5SvAPNGDu3K6RdtFIl6igvq5rYN5pJ19wYLHm5PV9a7jaF8mpq+VTj1tmd2hZOA/cha/X5dIT+Gp7lY7l9yiItmth5CgpUMgkDfxb48DyqXJz8/BlFMRc8HMoq+W2e/fdrrJNj+deKbfXIS9bX7cCYFnMuXYAPPPF0oT0tDAttHoqY/6EW+Xad30OvhFEiBfD1RVfDGdELDWnCZPbbwzDxauRJt/j9fFtUDBIByXF+Zf6ova4FZtv6feLqeFTDN9LC1T+cFqp9yRgGiJ3+NhkoaWuUDXvR+eWefzltBSe9oOVmL3taN3ciZOA1DhD7Rtu4RRx2Qvo5Z2lyDqwVrLZG8sesVKKXjO9vBcuxjes2ykUKfVL3rJa+7xXvpRmaY2e+mxfYeAvdx593Zf7C0mJpxPs9k6yQgJd8BetU5oMbCI7v8AwMMHIRu5WeLLfA5tN4Hb/GJYc2+/hnHhXYrk3AxEwZs5rVL8GC8OzObLH338JrOPddEIAP4MV3VqZNiBgs39Q8dy/w96/AKt5zjBZlOJiuXDTcOXApP1WNuyjD4kJW6VH3uQTfXzeeKNc+KG8fwUAHDP+YvmbH3AitOEWgD0wiTbRJhZmVNvUrOU4M3ucNkM+Apat4WSnffChj9hi6hS+wbwbv+cNF+FJ62i1AXN2vJXIZYYveZ+YjgCuizT6VJ6/33H+Wsq24u6dkXReUyyn139GkVl4utzZ2LvisQreHBHalf41wwURK25HySglcnG8KZdYTiHc/QVdPq8CFk+60SuOiG0j9rsZnWs/4qaJYD9uT+xYekYbOvzarwGrECVj97GUiP3389tEkBqTDuBmbbwWC+1LE7Ktxtt0o0CFUdca1x6Eg3ZyZkJyPgs0giE4gs1yp5sWqESpms8Xv/qAwTcSLurcgw8ftt7Uyp0tOA0lt3QdGTdAOqP2QakYHYzqmO4DMWtYtyfv7ccdgW2nSP1R25G/bLt0XDrabdu79CwIHWx7uva8gD0/z3C2WHaMnhlPRssN98l7XxK27dHLc/Zp+USWx533cAtSI1SL/fEdYOE6uf8VlvM2NLIvVTRVlw3Q8WaycHcE8ytybrNr9RoRilOm6Obl/vxCrA+49dye+0gz9iWV4oUrv4Sqpz22epPtO3fRBll5zwn2C9zUQZZixy19gGVWvat6YNsLW6xqurarb0cYd148Wvh4YL1mmJajZCeQJhKCxeUD28oBRLkjFzwBHkLLHd7TCr5hfqd5SbEAhbXlOZXMMs126ae3jzM1OfQnL3Y34pC+OOa+ccQcP6kpnf2t0tu//PL7vQ+dpozN/ur2sd/2PvcByWYxINlfKmh5CFam56ByPLPKaF6CuTKZJbJ8iNUyp/LR71nOfs+PW1Dorg5Cnh+4fuaVU0/5333TBiJsvpz67LxoIZyyzv0rtmD8opUg53Fdek6uwU8MZd0nh00fhgOYfc99VOMCo60l+Bb2GmXs++6KpQAdqOi0+aOG4CtMc3ovsnLmGw5j+enkz34Uc3zkncm09DcttPOYcZ7L+sbeXkHnzXpBdXHaeQsYf9mY+SJ+lSvntMv6QLLpFIXja7EtxGduqu3y1XTSpp90Y6715cPR2rnl4DlV6UR9uklZxXWGbkLrbK8ChA5GL8LIFKCWqM+1Vfhg5iX5D5LHcofqYolLgroBdivXshAMjv5suMTqtByDE5c7mY5Fb0NRny1/3iFlf0yeW4ZAzj1CvFF0tZn97MNYa7xHnrkn5nHgFtyJO1YSjes0YBFWmfO+iTMwLbvsS3MLCDPeIduXmaLSArpaMq/xBz1Fhtmd8ck5UHKHTFgEOCd/xpQ/P9touFyccvAI5NS1Kty+jL1mFy02rS9qOkk0A/rJpum9mokfDaeJ6AtVRcWT56vXYnwh1pxxQFylug3bFkQ/bMQeV2z3/7F8Q+NZ94xJyxpb02A+Trp22D5d/0+H5nDxMtfFHBBLfuqt55OijFSrrdu+pOA6j/C5aV+NBvSa99coYiXGXH63HeqYW3S4AKAvednuchSmNh+uATyjNNdzDTZ8aG1kjMXJKNTGb/gXVj0Ywzt5KgFXzu3adzqQ00yd8P6VyP7xnkv9T/h0QbPMvUjPdWC4a7xzQkOoM+udtqzVycxP89/40Z8Y1QXPD2XL9w3V6sDANVyBDtZx6OYEFh0HrB1wbaY2FV5cc3MPELimyyNuQN5KdHe9PNJHzeKaQtazEeDj0NDT4B8S1uPXtzVOQCijGDhb3M27A8U3nSceKE6y1Pt3EqlQzym5vyVc6Ty46TLGyL2r4hGl/bL0MbKzfYoVJYqugmYaSWNZ4X9XPbBcOGpdNj0cpyFY6DunOZmM1bZ1aP7FPMP0zt7ZjGVoZ3p1+z7O5Mls1PwGSP0/RPGLfV0sMWY5r+7q7LwLDSY5IuSToYIrcLamnkEbUOc0r5nnTT0gmKMqz4K4w0btX+hmGBTXiZ1d9dQV0ydOp8Fy1KZbgpWKdxD+Q6s3XuiJsvmCNlFVDDStnCQfZfssJ7Zf8S28a/RRs+I2V1rvkIJk7Sphmii6oYqrAv/PiaMz90CCgcLPQ/jP8vzMvFGF9Mo7kCk0Ib3pxZ+3LWrUXIMfs+LTAAfw0FZh5W1ZbhktQjc7YqJH5c+H+RtKVL8J9X/g7aN/KwfIUaFViAgxJkqRKccs+RZYRmaMmo6Fk19UWtFue0HrX1fP9k346vcP8zp5twWqtDewvWaCbdvWN2p/VL9+dgBHb51ptzeDUExT0va9P1BlA3zRvTnPvRPf9i32yyE9J3zLPD153W1zZvhOezWU7zqE9r+hyw68TbKxT5xqa1//bIY/0qG1h65Vn8RtOk/gS5N++s9QPp/BIR//qxDp/+drwMfn3Xs47lKEx+FiXPxwHfriuN6g8jS48FBCJVHYNEzlXVK6nY2Arvkboh8j7Uif1RA4nkYTws1sI9+MaywyDnqrLA0XleBMvgmzvYJSsM5Xz8kG91jRqulzoxmhPFwmDpsiGJpwe7RMEq7EKEXqXpCR0RGLTJM7x/J41HIl3/840T9OzFixIxttvER+nHRSWYsDvEy3efyAlu5oaAL1Z9zy8vTqnFo3+FY9zdsA/rx/wrvB0F+8WA1M3J9xCjC/GxtYIbz18kcej9aGkPCHXocnJOKE43AyzlT5vwnBqRDYLy03h6C8vlPlzb9ZCyG/MedbhTBbGhxNIfyWFhQ6ROp3PLiqtbHWEWK+rxTCi55ygzAD6eJQuqKifHYQItH+QIC7qSo6JKpuDBGV4ptGqIlX47FcjpG2luowFa1KI1jb+DtkYcIXx4yib+Pz4/76Lbz/Xon0d7bwYf2HzA+yDw0fNlY5tbEv2av09e9VXz7itUv2nWsER9DzOwyBzxNnCcnW8rbD+0+STnLIO8Ck9say4w5INR1Ba/9/Fc1eGp/ef/T0xavF5dX1ze3d/cOT86tbUdGbnf7AtIE3htEUEZaX1VxiUCKxVD48OqFUT+kMJovN4Q7HkplcoTQcTxerjSBBTL3QK73RO33QJyHNtZQlV75C6ECDhQDJqiVARhTxkDJSQxriktL65BSUlA2oGTJizIQpM3bKt9JSXzppzTwODF582CgJElXEU5XxD73BTd0HzNtgaWVYajRX1QiXlq7O5fH8rJdy04nTt4jIf3LpfEhRk6dBQjfabYFYOpvYrVidSJWAKmYUC9YUqlbCO1jtn2qaT6WafaVrrCXv0q22fTIcOnXp1qNXn0FDho0YNSZuwpRpiXlUKH3nGztkcYXhU47z8kzjixUrVa5SS+tKKlkfKj1GzLLKjhUnbgUVVlxGmSu+zPruXPVc+RVWnEHsbYyDQ9gFRQnVYfMPzQsNj4SCRp2/IKHGihQt1njJ9nDyiIhLeYGOJUYs4iMVJNAjEQR7VAqk6ExFaPoxk6tCcvlNEvoPKSn64dLZSaEJcyljL0Y/6VmF6MqXCIhdYCShVM7zltGBCPCRivakNZhUS0lGJu+lMkL5NrBCb1ni8s5dKIslMjdA64HBucXLpRGMLhg0fGIgAJuUdR0I3QpYdwKK+ztAMFSST9a3MsabGMubD+sbDg+hQBxJX1aBMKNwwP3jdYiXOaCaV1zRHoYUEthqghnm2+K/AF7AwmLVi8wF4tzoDo8EiuiEeVyNW3EvfCI/rsdAMIIVRylImTyXAVmctXkkr+dEMkuyTOp6+VQ+K3CBKkJoBAJEsIAlOc+BVIgWsI6eXpDa6QN2euXA3gIEAwcsCRBM7AFWIQgGmy37KoLS4CX+03efYFKZSJ8dCMAXeItl+m0epnoOn5+U46AXfxpuTHnhL44m7r+6Pln+zqJ/Lgt/IBH4DAfBZIeLEAnS9mSABfCeHUGLr4aPUE2HIX4ruTQX4hhwxuqipHeOaSLvOzHkT15bvvd0ggPzuhwe0vs/O1I4DU6yczBQ++jxr1CjT9jVuCUIzRvBOqeRpgwLNpdHIS4/byzbD2NQGx3LXTOELznamKKqJSpsFa4e4Zz2ky8zYGOR9lhyVn1G1m3ik9SCy3lxcExu5aUSkL46Qnvd+MPrJFXM57fsJ0Y/3Pd6kpDsiLf+4uMJ5FVeHzFz8nZ7mzcevJVSG3neUayhgwpEbJ00eWWgYbf1sVQ1/+M0T5nc0NlsWavtuJ3kwYLcliQPP2mVad+ss46lBe/uxwpALjDFHyzfFhNJZ9spF6+nu65dWJrxbme70HBZ8ewScczU0iU9cNhXzn3m32cGmXVUY/eE0+YdcMxJ5+XUpQf7WL/Rj1IZrwrryDf/qC32GBUfiTVdU/NBj6VExdZFj3130M7hkRWbD/aGMoDAvDfJSq4p8ZncC2S/b5FYuHWOBVGOmpH4hHvpWVS1BUQV9vgKsC64i+rRWzMHPO58GOjaVaFYTNStFSG0PVRSFbzepDt2pKMuOMCyp7ovsV1i1vU2z3NhgE1rjLXc1+5axMHFFBE+2r7ib02d8dcpkqSielu33bDSx0OOgpBInRMDC5THkJRUWifVI0ceEKR5EewMrF/bSlptma98444FHFR0uKjrmUSdB4hblwTdwayw2Odu2lVbkaWUue6li5oPP3lNeqXD2/XBHeHXTxW5YaPGqUwyMnPwCYlNzoCZIv/rKLFy8gqKSiC26oEcgayoQT9ATRlCCY8ZEUJsORKlhosoO4o8BYqqAFOqLHQ0BGT00IUIK1y0+KKDFQEFFzF8qZGlRYomA1WOvBAlkGTI8iDiJ5vc1DHndJPn6l9gwRknMD/juMvNObmLhRaun3CJysSTDwYiRYZMWXLkylcIqhgCGm4KCq20Mjk/AhxSgnjfk2HhERClSEWSjoyCK3c+Stxc6H98v6X97KJl4xYQkTDDzs0vLC4lOwyNI1KVtZi+tWsIhygxtuIrkiw9PDgUbJgYIKiYYYOCiRKXS7KiYMqWRaAzW1wyx91palqOeiLLUTMsQB+0b64BYQmfsRFXriRplSuBhKksOt95QNUwzbypixSTfYP6XwW6TDT5OrI+CJccn7sy4SrCpCyDlx/lTDqK3CInURchnqg9o4MRVhDRutbm5jKHLp9XWmtEXyaCwfpA5VOo3b0woXSo37LAiSCyKeQvGNFT80ScfYZ7w9E1ff4wHbzs6w1eIFd54tEPh9kgoLkbzNwPZB6EMA/3mS5v+1jQGzykrin3Rku0uFyK0Dhd9V9rNghze46ehMDEwVeQcyU1xq2FnpWdi+dYVBUQwlxfpSfEocmST5B9RdWVnYqWhY2T+zDKBxYeHITYkYWhvviM/O4/MwBvJa2QJLwryV5Vpp0KXJxHNHIHDUVcBNRk5TKhaSJe2dC57gO145CZLCDh994hL3QfUuXhoxdUaNBiqqdI70PmFxAWEZdQZmFj5+Lm4xcSbngz1XplLbpZXLPFymOqfU0tRhGMHU9O6zAgHTkmyrvwIMw5FG+hogsWBoYp09TMduJ8LqvRYhQSNFho1NKaqcKIgL/6gsc4ApFM1aCfc+M2YRPj9UiERmWWtVF8daAq2AriDDZprdJSgJkFIqUJDRJ5c6qRJifvTBEjRQY+wH2HzgHvni2k02YK8bDkHjfyhq+tlhQkA4mABzJWHR8kX4I344Mf9+Cj9512x+x9FzunYDXESU13TKpyknZKeXv7/xkn4rizbXWF1lW+54iNnl59DS66pu21Tm1RjBrVfATxAxK43/bf4yhHTpLyHUt+aVw3feBxOjo5aIfgyJDI0MjwyMiLjOb+ScbCyxRWDHwSwPImvN93DX7lCr921R/vYBEEtQwLqQhFKUZxC9TOYpFztvdigtu/FhPSloPH+YUvDcclf+f+8WJlykBIqfuiDD3llcTG2NwJ8NKQnFifjdkaK5t101wUq2P5I6+uQpK5PjbKleZcjheNA8nr1CyzveJe//Rv9/mfBzx0FPtE6CCRl7zsVf/wL//xX/d70Iq+uFgVa6I41sXa2BCboiLKY0tUoQeicL7plJUuzrLFigvuC7uOB1Oj7kHiAnCSM1wS1x0cOsRacfd0e+AdkggJtgwcbaeBbzxy8Q2e44H282qV00Jg/f2OPCP9/3pH6pvp31M/2OjO+aPtTTu1/EWF3KI/P1hWfLXkt48CpYdKf/Pox8eDZ4HK3zi78/x3V+gl79Vv3tx4v/fqJdqp6g+mP6/tr+t7uORx5vtff57VcK75lz46Px5q/801tHzbEx+8Z/uTDx0eObz38P7Ddxx+4P2HKI8tjqfaM/S9lPWOp+58mnorLUSN3iNoDKZaxdrMPTOnNiuLuHzXLffah/aue8kOOc4p/89RiFJeugGnkGoGM8Y5dtG5yfW07mMJpbaxPbpfn/jE9Qbxw9vMLJ9Xs7ksm1WytazPvvUMv7R5DH/XIL9A+002zVKuc8WLWhPtwcZNmWSHk8uuSQvj07Iv5nUrgYDBwZ+3FUKRlIqCj+mYT/a0/JH26EXbbFvrxrujXVAnGz7orC5rrtu6oSfoTD3PDDOcXe2EjvFWr/uCr/qd4XJAAhukOB63xNbx/iiPWnpY8dwaiP8UJolBLHc0Ansielr3tMMZ3Nm+s1DutXMr3MkndiWJ9nkK15s8nyMmCIDBuSoviTNy/xU++duBI9qEtkF4FmyPqCe7a/ukF7ghmEtvF4tBQCCQt0kgAkEAdA+XrOOfyVQVvORuvIkpa7/chUEPS3Ma+eHBoL1fwSNCNSH4b/wj+Ut+yb9PutwT1fgjr56typ9O7z0P3qPWP9D8xeDfqP8lz/4Qav4IBv4jM/+T6Tto8m5yPpiqZ9B11Xf8sZqhv8Hz1mXzwVN7pAOxJF/fOgC0PoBNeMTQRjJpFQ0jD4R02DtaEBwvnobVcsOZ6Y66eZw9n7vtNOZBBsMLXkiYWAs4+jJYuMjAi0Tzf15ttn7ZgLrykaiE/ZUx0p4eUGxm05u91mrxB3wYteqrmzgJ9M97f3pV1c5VaOjh0P9/9UjhYPBppkxzfxWdtY8X/zX//mEKS96vyEkw3V24dPKnsuvXN3VSPFqoti50mamstZfP8WWZ/kGy6VyVgfjFdyvyebT83r+bxEyWrz/bavaf5PgaAqjw6LMWYIJaBrBWK756Nfiu+P6+AMzWtdvf++CaXdQp0WRmJwYbb6seX25hVzakd7w9/6HE46KJv2WIEIb09H2n+uN1wRXk4beJSKGeDg/g82ZhXCkkbboonH7E2OIm1ot7OtFkry4gG4ptYpk+TVk+gOfQA7vcun7m4mTM+sre6U9lB5Ob/i0jAPwc8vrnL+cpscID+Ad94MxuHZNyraMBFl1ub9u2U3HMQJUWsLeIAJF3PpDP3Qoyx0ZR5FpPeh0gl2r6OESZNBWzqZUGLpCOQyRVuR+2XHVMMvFl+EO7pojh0cL0fHZ21aXpxp+8rT/om2IUdc2eD/7lsj2oxA9t76e1HUbiOWDuGg7mEA4iol/E1d0aUlaE4kHnu+jDhslsCGQy43gxu4bIbnUBnVRJMU/vfAE5Ir8JVpWsf7GuJM5td+V6S63vcABg3jmy/bDGYrJ0HHUwz1IMMuriICT+FQzun2J0xsXGa3C8UDCZ5Vzv/+zPILEwPvUmO2cr9bUTlDMQgPy2o0vl84y6wuE3YZvBolYHLxMoUk7whJfcB+ImVN0Un+fMbgrHBrIXOD+N2skRp8dP65WvmjFMgp2y+6072R+vW/UD+HjPColgAgisETGQ2AFEz4bjItCOB+6zPBasu40PDCeEeYeTc/P26E2Nb3RxIWbqzvEIZsCglFB+c3xDE30N2DwMoiueZRHkxIlty99H7v8a1HQB4IE76+n9sb/SLHXtIRMsw+fbm7qxomb6vtoS3Wz//RdUstfhNaZr+lftMpApnqeZx+1x9Gz+k0JZ+0YCWQp5SctiOIczCfYNvu8JyCnaN3x1Nz34WOtBE3PyLW7V/oN/Yn+3+gRRQvbWdhGktt/A2NUIyGEPIKfpW9Vhg6X5Hmrd3sv4CTmRw2O6HbFc92T9I10nZqbWUx5MWphMv3scCSTfPLqPHuDsnj5KuEG9ou8evGBDazacnI8fJx49cqGwhuqFwtklfl4ZIX5AQgIS2aybVyi5YvEqy1nDK5J9QpZYhbqCV5yYsErQXSCGgZ4jrR86GPw6JlVH7G2uvti3mdu14a+70DvfICCHhSlsT9n/DZArf2MPA8hjd57NcI8lwt9+zJjPmnmbOdgh+9TJAFHTxEJ2seBPwRmL9JzFvZOcfdkSQJ5y7QPYq32eBz9oORu/Fr73X8pdiV5+AwuHyNEqwkSZZiHp0oaM3JdrAi6uT2T1oRZF6z4cDfTzmgmPv2YOn7pmnhiuXyDLzHc2r62Ij11Z+sU7xgWXvvjV5m7LOVaAGf4jHRwib0N2gSG2baIryv+Y6qdXAGZshrMAsMyCxMpNt0SaK7LxruXb1LF6ckakBTwqSWq2XEqGsqZkZdO5qLiWrmU96zYNkhqnoDZFw8zGJyAmLW+GS0BUhqBRL0FHTgaCZpdTzrjkihs8oB/DWS5swQLCE5cqVWR1NNGXYY5c2rvshuGhT3zbrmNj5YvSt4BYeA8aJiKUdNDHKGPMMcI4UywAHv7WmmlYP44ibVnKhmVYNpgGAsAyUX5R9K7i9nb9fJDQDQOrwXpuFBaOPWnStJz28/bVsZOczITi1Ivgh9k2u2fvmZv7Qayc7L4FET7SN4WMKUII16SEYldZR/+VqS6b3PJXXpC5nHSpka2hC+9IIgMBlbTT2w+g5SQ3GYPBPAfmimCr74eX+mjyIpuExviyfUX60xDvm8PTAdyPm32zYUD7FZ35Ml88mtmkm4bXP/23QTGSjDgj2ogyIowEAPlnGg0sMJ4Z1CkA6b6RZqQCSDod1dlfSj6dy6sbjAoj7xv6qK4OQOg/pdSXeWA/+PTtb20fe/DbH7/677c/tf3J7Y0nB072HT968+z9rwG43+zDgwACwMOQY9uPXr93+h5y9GUA+ajFh08DsEY29yWz1aceSw/a4/mj7FFKHz7rEfuIeUQ9woDphGvsenKtYjkAY5X273KR66tE8//znccw7nI4LIyfmnEP8ps8ANIjbpXgxjOceIo48aSQ/YCS1XnON+kXnP/nv+nQT+jEwvi3Mmj5JXVais8tvv4Xjk984p32saXFpyiMv+OLeMuG7OkXha+iMkWX9PO22JFbVLRrsvNGF9rT4LplwZNDO2BRFwq2zA19pyCf+D8bknct+OSzs2cZL17Syp0IkQiR3PUWk8WJKMdpdU5EP0ikKh5ejrUlE1xsy/eTsnaTKDEi/aQnvRvS7N3m9gLlyczcB2T0y7w958+y78ZS9PVC2+Pcl1keHwybEyfnDI4FNUxBETDgwBq+Pdjubpn/ssAif+Coqo+UHfFFEgfqh7/YEhrFtG97lqI71oHBbnqPpYaNqoea+nT0Qfsv+KwHJpECC4uCUV6WHYhRVtnr1MZ1gVQ7ynKBURc22oWT9savADtdh6s+iUSfIq5ariVmXCX8dnX8OAl/3QR/2XghFZLbJP/SHD/sJLJ+cX/f+HXnebCfKIWQ32X+2B8e7Z9xnmyQ5xvh2YZ5oVH+3iwvx+at1tnRmorckJylDUPbAHx2Q3BqcHi82zm6u/jf7uTk7uejPczZPcjpPdDBovi46/i6j2u5Pq14NgPdq9kymvEsjamu7AqqGzBofCOmN2Zyo57kqw0iDp6JsYbgyJPXtsX9polX0N70ONVTzqvvjpqigtEDQFaOTzgvOxMQEUyI+0/KRMX1J/kEHgfMYx/Hq+RuVZ9r/lALTskgGRb5GWiALR7W5qumSBk0/r8d9BxEhKzDhTQ/LkfirEJFdpnfgTPrU6zazRVWsjGm7J4xTrIvs9mcv7W+NeuiBeaba95Ij+iIcPcPzRlBL+YXTtEUT4mLyK2cKofUzEbWs+FYek+01NNIM20KFcWUUMb9kYWJZdBwsblGSwoywOxYF49IC2FAOg0oI/hMZNFhylMM/4ip+DrmfCDmS+y1fQHPvECt8AJKHf/FLNwOyLcDzr4HbvUnOPADgJ2PwnxmOP6KrsewnWgwaPbqdCtDUEt4xYN99hlDmBsS9ScaCNOiHlsfdqsh/z42A61DTmLGhjm4GkWafQx4FEIIEs4yKNTJ11OCYZKaY0h5753QnAhJ4iDaFKp8D0aQMpKGlJHIJq+wZt3cxACbgcxFxo5MP3KKLNo8tDBqVNg3wUYFjs4sbFHkYK3xkBlzGAx/ooA2D5zHhwGyPp3QExPHzREvBkVkBP5R54afp7wRiegiGSeIYNYC4/02lxJkybnUxqsJa94SR8hs5eETlKCCcyCEE0njHgAWfgMRxankAI0Tq4wCKQwHcYuhVOo7vXA2ovxiYseFvOFZZAveJ7CGpA7pm1ySLdIJ3iQRJJ/JamKZFIFysmrPZPJbLs8rSY3zUEiZ0IK3hFeGKzATEuJDxwjlhITZSxw12XPmogzTd/3lTXnZF+159nXwEeQwFdzKgAoXe1RI8eKDUd0IUWcvoLqxTlyErC4n9kCY+LzkOCkYgGRG7MhAw93j73nxjSSVwXc0SiZXapde5OCCIOUzFzLotRg4ffuxkTR221MlFqoC3Mg540chh5WIrQ2kunlSt3s5neBrGKaGz6LhLzvszcZvqNerDjxDYJ+b7kEzRYR/tc6ce22a4CU67KladtdUngjAwXBsDFYOwWRZY+ScezzSbkHvDjNNHnqCA6YN0zXhbvDamda8erHHMN5QNzutpj0VYqyog6QikhpWYWoY6t2wU/f108cOR7y7B5lJ+XpufFXDij5JLNhN6uCxv0ie5dO6xmcEM7BDUWWnse0lvDgWdwpGSrXnzmOWuwDT9MagKsp/Mm6tQ9ND2G5Wy00CKFDJl/P+zlswvVj8bQXuc4Ckmm50otJ/eKVE/2EP2KY8PklyX7YOmAoxYSp79eJ+Ydc46GfuukJI1Y4/t4XO2vG+xldFXa8qj5oi8pXpqh2+U1ZSmD+TuURR/rlCZNQYRlfXTZl97XG3O6DZ7/F2ZkQfvynwuJbUBLOr6XTej52sPDQUyXQ+DoOpsq4IPQe98DNQpperlUrcTBYzuPf6K2Vt+57FftCNdX35AW4FMBYcRIax0Dgm37559H4Sgk4RIc82B9fvyn3B2E8D4rSvhztvorzoh3LUw8Obb9G3s3Q9mVW+4APHouPuSI8Fhr9HiWy0i+Pn+rw3eU7Pd56S5yq3U9sfLQJhlkY0f8638soabzOsjidJlLS6VsAJD77/QiUI2AM/HZbK6UD/6XjBD9uZuj3ngvWacS0iqoLsjpPLHuCXuYDNfh6HTvviVNi77PhDO6REZhxjL83i5RmUe0FuLnt8Oz5t74v2f+HzZ2s39m5XttULl+835em4X5w20utVB+z6tbJxp+WLc8HYUBxxDm+ukfRnRvvW2hEbMVWQ2hI85Cp1o4uv7aXftLKP3mlMQIbDSOltpiDf0foyeB9UukNKFwxCHbZZD02SiLEWwB3kl04axZc1WY/tYrkLaFOFLGoH/zAEVfBwX4tCig7WMoiZaoGDbdgiA5m0lhd9GnD+UL4CEretE5fp8tAXCbCJTZT68gXOHeX2mHZIcUIyn0ORxGDwCUenZNwG7f5igLFTtm9LKcoaO+N5BJDbVYhQp+mUt5uChj1itN24TCyaKIGIR0qdTsBG6PbOYVJVfuok+qUDjYGQs9YzlC0z1gRvqDQt1P+RzXnyUBZyRIGpKAylFkqU7zMZym5A6o+s6X51pygGGKFokw7BlWX5brAfckhGhyIUYijUJmX68D2gGY9SlOUd6QxDamKzb6XqcfIlRJ0hXNvpwsi4fDQymk3s4VHxxFJLLMAPuPPrsqy3KHqhBtauJWs4saxRuUUm/3cxcWpgWT8x4Df4L3m17aCxjjFA44GE1mh4TStBSSlK80SNsHLickXTxy1juxIyKwIioCOZtsYVOjI1naFsAc+LgQjDdHcWxlpimzw7spyJm1TimMzTHKc59TdkvIPxhZqqtMIlHR49MnCUCwgz+d21H67Si6aP8IBNIKt9Tkm9YHjVOAcUPe0Eb26h5F+9k9b8DNlGjbj7Oy6lKM1yJzQuzgxAptk0xo4OR4VZluPFjzZJItxZ56RiZIwcNJhep6M05pQp6paJy70wTjuSstuWgOD8HEUfmSDhqhdJ3HozcHpZTwBlPT/SIQxlHDCelw+e4znswI4ieGoQN+XXTZwZEnDfbd0EoM/CTTWpPa7octvpbCa7j800aZplOAYF2xbtJVg+waYh2i7dDusiKmmOo6ktdGFM5dwMcjK8wFmDoKaugMm+AzT2sirAsdE1vZbDRBynof7XlTomzzfWRaNV8dnPirlW5QgNlCX+exNimJvpwirdhAu+8KGUopxWp3HAkj9GHDqEFOlH94bI62LJmqPIDzAo1JX62DjYdcihoDqhjpZnCpSgm4MxfqFBy7Nj4CEQWN7BBoXOL4aznFGopvQkZjQKKBdWqTJlnJosn089LftZgVv1pDMrmKhrWbQaqmxBoFCVUiGUmm3/SZScYqKFDBTKPpqLlEsq02zxfJNWzVNrlan7372NGrzNChKUjPwStYWmUGtxmDUOlonOpj8+R02TrlaPhcPt/5qx2ypcizS7rtwgUXAHscrgnaGqeEC2PJfxZbbI16+h6KkE8uVEoDIvj0GXpopFNlCOZgpekhM8kAkg2RXUb6PBh7cVIS3xZ6Y0MDNT5qqqQHk8yVdsWKMpRLAhN4HqTQSpxcUmH5K+jplrvTsAGCSxyKnUsjnwB/rVQ2YjnHz+Xh2W99JedlMviHfB8TC1KqSeU1Jx5DfR/StvNmrjejNBLZ6cUtw0mg9L8k0rHWH57fdoL+ivzOnZMhercqYkykVThQ8HwDRP9PHRqy6Mw0j77a85hXhfHRrdGUm7R/r4pnP4okmYMCvbmgWbWJoVfgV4b1sEqdRvSOJozCgAreFGHNpxWzICE0Rkk0FNqPYHkoLbEfXg9wiD7nkw3ZgxM9GLzkF0Qhf9gnkcErjGHOW6PsfB65TmdIKS09YX8MAFWx01pTPtTS6BUjMUqYzMX32MZUzlz/MAIWksskNdtMZQKIGZFoSV6aYwFoxf+Z67CjFwdbZD+rP10NoG0R7V8h4QaAsj/RjqGIjcgSoGRIzKNd7RbaszxwyTWDEMUcmKTIfU+dgYQdeYfp9CoXSgG0KlZWQbHZ1f6pgDeWwAyAxDeAAVjOiODZDvgI5jRCXRr+MSybJ4qUTzQvaZTCE+hbTqvR6/CibXCpgfpTZ82xY4MYo97mpgKDWy/x7Yv4Y1XKLrxM2HKFsOIuR+AYMGxRbjvxawbGDIrmRVXgMIqRw2uqEmJYSdMmIEqo2BtzxW/EHnUQ7VuNscQetbS1PrYh72TPvgGcYqE0awNjV3R3oXFqyc/YFQTzb92lkmiu+9Poupudur61Wb0Wohm1IwgW8J6sZStuW1UnFk0iNnlODhaTJ8tBA3CKZLgfNlXGJoh2F2ZvbxddWYf9sGPWip6Rx4xZvyM2pJ7qTe/xObyhQy3A9G1G+unY9INrvKIKPOAW5VccERR696YM/+Z58hUGb4t2cJmXOc1tYXwXiFLhfnTYH83Zu/+nbVljOUbYOnWiyKforSJlB5HmiyBo/S9PqRDaFb8v7x569eoF93nfIQR2euEtdsBXlJcKBjBqidS0dJdK7TR5jDqxG2VunrfYrZOX2nsESNSL+M2YghBG1dNmv/gM4U1awlUNiaiSMhQUmKShoDu3cJawr9Yp0aqH0JtYjrIEK8nJKTsQQlBTHYWWvXVCNSSM3OROiesEc8QM2xi1zWbFqnxcvHnMpUrsqFNhgNbnuutbNxBz3lNR59VisP97LPwJJrjQxoxmK5IDt1jXOGlboqwBUAaWHt4XI8Igc76dTiC9lmtGE9KdYakL7v9AaI0KwX+F6zBobgTY2PQePR5ABm1FW26VSr+GTKWY/7OGZmpy7MY2GpVFk0eqY/t7PzykNrAS44GBNDeHmTa+CgH6hXCY88CMJMgLNW4UzsmTlTBUjduzLdYjHflKRbqxQ358nAjKXV9S4bRQmeSBUjSxCiI2NKazEaKrMY/LHPOKRWTfp13fBVrSGwygnGhjLqiZnY1cJckDw+OSmWVTCTv0xXpFnJOI7dyZyiWoY4jQTHeKt+jjXI8NTFcl92RJ7Tws2N2Fk8yf6JLh/ollzJafkiCUpz6QcjxCLyarGGg/0GM4bjE6EVSkwLg5aCZnJzX4GOpeWqSeTxl8VdlEZpf5rsDK4zGUp/fTdVk6KkyNkBHkAIeLbn0vD5nohXfaFyW4jXaFzqLFCX9TTMnnRggZxlG14MG5LW1kRKDtm02+roUW148VCIxGrYFHqoRXZjJcQ9zVKmCbxRA1Gw7qHboW7ixXkJj8feIGZmBNVLi8YxDX4dIPCS5FFk/ZTC13sB9sUFr+6tB8osE1r2OEVcWqOCWbXtomOT5YBrscKabKcoPVNoezr0+Taaw8idHz6m0TB/d3YTADOrt114Bw7dXNzliUjuloUtAQN8Lizf1bjbBZuPUCQb3TdRjQBgOBhz/wt0heAVJ05gLMfFG7Iy/KJUBDCVKqjhRFUZQ0QN25UdR2zIpC3iittJ8VPLP5Kg9NzbXN41IatMtxtHuLMzIwNA82hCMsYLGviEObfXLES6JmoyONztYRjTvw/QgAZnEPkcKRYA4rHpGfWW1QBcRmufoV+Yc8wO/MyePHChOyoXnY8QkMnjVz/vofPUcgYYvq2StDFOz3ELw57ZvHD8T2YGEX6dAnWQy7GwnznU4cMfZvzU6AfHhaHg7u1HbtXRT7HUo63n9DyCcYPSmZ4H5+F5aniYazgQGxLzUKHcXtVpcDUYm78bCMGdxfISssgGSMn5K06hdWsOh0Ke82KGsQj4Qw52+ZC/LpSW72EBigeTCQrMI6FEwF7VsKj4B2D3INn5yhJ7f6KarKyx8P61eaBA1MC7V7D0LEBqSQ8gTHHf5RXNwthFKluU5FKFE0tAFtk0LmZro7J1RV670O3LiZSwYn4wvQ48RXuWyYVJvSbNGap4Tjh/6hvxbufiai7R5YF9E560NZVqqHt7Jzo1uE5lbqmgh1F/VocxkOa/uFiiCc8uz3L+4YWueVsynBKnJyug678AihUL8WI3dhk79R0BPKqS8hyWIc8yqpWQ9Z9rg75C8sXb3Q98Ir9wcst6OHk4jPuDE9WbxPke0adGR6MgZSuB24wXu2CTtRJTvf5doRE+RwlwEIfUGOrVFtpbTGymPmBSv9GIKfr6CTn6Bry0N7mpoTqyaPvOv8t/3d02bQvj8jnqlv+l/nyrlrNvlv4KFKo9/IQ82z8rv/3QxKb6JxY+2d8uD6cBTczq7iYSHgeZQ1LIoOkdxaJhYcXgpggiSUaQIrYn9kdJpYP0bv9dOuTS6JlwFtRflznfUTiOp1/FyziQ4jthpi1goTL21Ic1En7UpWqHBDkcPXBAmjLHenil0vGhExKdkwI+tgz2qdCfqX0o631mR3No5oXcfHUu0+AvZobdNKUqLTdgWbbiIU6cxl/TznbgMtXFqYnZV31wWsxS5h4rHIlirEWTB629TTjODlsF+0Mi27WtxnHsy5iv2d7IKw2WY3wEI81sfwHTut/RlQJsZmPsEtxyKDTF6Zx1OjkNEhwTq/+DqxiBbVWcQb0nczis6C0RYmcQimJe3XoLRvYe7xyVyKPVS30cdJ9PjjbWrtB9fNXaZd+24rBXvdg880mHw+ufyKY6Iz4Xw92W3QoQXkatsrjFp+cSU38ttiOJczhmYEVNG6QsOr3ND+Pq2OptqlPprirkSdlGsTmMb8MGNCm13W3tbH4ksu4y3vtikEYjxS+SQcqTkatUlLjta8pUlFr6+jPh4r8PocKzEDBidzzLvUBNKbrYl+XzAcviVz4vn73hfVP4ylvlyceqq5OK9F4eTwzfx90RYmzb8yxzyLztxwnbIGAwOrSbGS49V8nWXhinYAISPdBXXsB8u2i0o8PXOqrBWDz/f4K0hQ8nQ7n/gDIMJk2uy3QrZ1y2/hDwQvluIEPr/o6XwUC5x4PRievf1nne1ioXfP63gmSc2WJ1tlx1yuM9pcP9CX8pFYaWylRQecDZAtUTTSQ01I9Ca/dvoGvufKaXzCpSGzb9XxasFuP6Kb4rYlph5bT3bU9ipA4vm3Fcgh7G2SbDq1SVWDEhp6SszvRhuFSd+HkEeI0ERrNy107A5E2hQ1CgHZmxLX9nnXINUVqQ+PzSYhNDC/SSmjvD0cSd3LAtCwwOTtzA2sahJh6aHhB7uo+n2+5iqJi9h8LxbtN4nORwoDJpIJudfzQJYrIuWaQRdT415pPjsjNyHa6/5m1Yr5cD8R/kNR7mKt7o+w8gNUszr57KzPWNsaeYDRZmiSF4PTa3aNfOYtm4OXcz8mBff8dMDYgKG9bilp33SimwYEdK/AoMvjA8O6Elo//EBlN7cZR7oP4YmyBEmHuEJH95GvLK81v6ekaERjK2WvJ8AZrR65pwuT3dqPRrYA0+V26tby90pHShLZ8eHQsyCBNBr6Md2e6/6/aof42DegcYrDnVZkjsTVK/y+kngItmzuzZfTvcDs/dtNjuTxIts2Bjp21Otpn9oVacVx+pP77u6RrGfsruDKnCAlen5QPOoTVkDL0H3ueYJnd6FvZwg4G+9hPXQoq4/t0WpqFHL9ToiR6nKfKxtpVKssXTiXLBjMVYShfjj+/fqqTZuu/afsN2GjXHqtUtoyGtOEAu5ip1q2bp6PeKDCxlpKgJNc2wK63yD5NaCZmY0i1/0+b8urAkeKjtOWkJKKRs3ajEMhpEs4HxEjdcsiXhJQ/tL00kHOkKrLkGoYZWmAjv1KyiPQFHkmCH0U/ASYS+jmd1UkMy6heWpD689KMUPC8JO7X/Uvxjyj3N4m7f6Avd8agZHSsm49b4WDIYLKA3RaeBKLlCnL+dDVvhdkOR1+GSQYbNzzygLzQhX/R09GFokefvRZu2mJqC9bhGt4yTLJeBtsvZ5JbkMxoPcxXZ/LZDns5vv+OgbFhEfSI0QpgPsj65xW9HbYvrIDjWB1CP18Vx0WGIJLb9tigjkmfAYysbSjFnwLny/MqG03eSc2mvqm9QnbiN6imhQ77k/inhpJ3//Sx3q2dQ0+xOysS29/BeHRptdgK02G3ol3Jn8BO9cak+4sNPT9c6V0oma35KH1Af8Unz3qriZ6g1FM+94BefANe3gW0ZfRdZpuBak5eOatcht9oZ8+uHbE+CTloZfMahq+eEts8PwCKm87e1qa5W0qejxZ74eaFPeRz9wfh+a8BX6R0eEI1efyS+UcsNswWs6lyTI/Esm73031iSy00XJv0DciRDwb8qKnPIz7GDwK7esTeIWokx+yB508Ed3eod9EZqOq4JvSPgRIwIHvyA63KBVFGP34HWcdqWHXPNILgYGFK9UDqHHnaPrW4U1aFV65CXAUub0XQgbOlALlcYplKLIZklcwt2Ydku1pXHka3LYng5ZGSErMo0zwNjQOO4NWKgTnFNuXhQEgrqJJDwkWXLefuyRmKEe9FyFWd117sJx9RaYg0vrhvOHIB2Pi9nbrB2MhDsRCnmkb2Yzt5kSnzJSheWByI2bAkT4YfLzfbPA7dPJikR36e+1Nvwm8W2bGXuEOhiE9uxaE28ogBoL13h31HEcoy8DQvlougi3wVhZ9R7AQWlxQWvBc8bTEdK/9MGlEcvPLwlJDL4WQCdj9iezIe/yOcPlMSGvxCMKtFlaF9WE/5ipODeZ/WyMiqQqW7RfhmSjCxJManYEPPb9RtsH3F7W2qdsYh8efj+FZDwWmk3Jv7gc+W61VsOHEfTiRF79ssolNgfaNZ+8fFz/OybtQBgy+QKQhZJMCXhbI2Az3xUnpc9XFQuFwRZH0gQ5mHj3iWan1568Mnd3lZ1ajQ+BWOwBHGmCoLcTsobbPkiUoTaeUrcE2/niulx0PHKDjT7tcLhZbOUvOk7a0altOowM3VbcGadzHf5xK+eGJQsd14aU0x86wiwrJJfZu1o11eULmUe1kSCXkPntB/qiyL520pduW4TkzbyaMVH03CedN+FnTzcvBFohQdkm8HcebC/s+uEVHdxucG7/OOpTLwn44bBdk52YBXxVkvZvNX2Uh/aqIiLdCLZEVnYCN2RIMf8RpLg1Od34/hsaY0eWIS/wQM6sjjzB2QsoCss3Jlc5s3BFnwR8TfN8HKaHho9D2NwGdVzunxKbAvl65BsFwjj4cLoWhQ4NgOHDjJyjQE38MRsCIFwGt5aUSDGnu2WiVbFgDUpbLYgNNp6XD4gdZi+YKHQVx8Y51OfDVsxroVPtU0mzBjx2A4JyhyzASIr6zgy52n9JgymuFMscwK4fHC7PXgR6LglGE4kmESGSAN9maGlkwsyvwqwc6oAuh5JpHEIq9isiN3pjlWBTqqmVIHU9ZaLMBYG6XLT1OYiRfrADikiwyHBAtG+M7mYojTvr10VwHucU8TTuQ3zEahr2WFnD8eKkBNrdA+bg1aV/sZfsk8Lu6Lo2oVLc3/p30p3QpGZTm6L9lNa8UaI1trbTV8itn9b+2RT+552MGrp3Yab745v/SINspyWbuj5YNgu2DotvTOimlQB37hjtg0jWi2tA4LqxB8rKl781lin+UivuN/7bp+5sCTm7FNjJn5Vr81w7Ik3pZ0ED82vCiVLFiNy6e4SXUsCRUo8dYA/dYvGmy3Q1J1ywd4HHn2b3chpj/ZZafNWOXSOvh4lBOWrHqv0+jYsu904q4PfY581x1OdYaoeqUCy7e6m/U03LJUflLuevd94F2c7HNl61jVnS27NuSZsU+o5/VLpjH6jFLTvnTzE7HmEz//jnCC7oh12e14b8VPgWyoQjSmEvViaL7X1UXt08Yr9OPr2OVuvJVbUVJCVX02XbwEGgXlAaY9/+/tiLwZb141lGEb3TzLawquaa/MRvq3dAfb4kJb8CuoqRTq8lXBpxV2IMqfp1WylBxKRGBEy7/GXVUrT4ht1b3hUjhSWviLMOJ/QvJHbmZqIotPzP4IioxyiviQuqDCi/8UA8C26OmdcJb7/tnB0+P9KitslxSWp24qByb6lgsIHxvI5q+Zm7VDRiAT1urVBHvuuv6aoQBEdqQAu7M7ZtSyvsUvk5qYn5fyv/W4Dgq/Pxdb6s+msibU5TSbc0CI5TYaHaYWU3KDxKhJdKRYBLXe9tt1tV4upv3egB2jvzgnqYO2wk7b9XXtuJt/s8nDp3+itBZQGPowE3q8Hzeiig8T48YJgcYK2FyvYNL+p/2d88rfnpIHa70d1QsulUp0UROF7WD4oVIlUwM5pm93itjPO5BX+pl+1+JfuBuJgR85Kc5tmuwacyjZXbQqps1yT2b2lUSozt5RaLNHiHLYOjgUEpGg0yzT6uYKoPJ6cZo0U/uG9/WchRPKn6glM/+avLY3SS6+ag5oVr9T1atADubR+Qr7/Cv5ah5+l9hBoAzin2OlWpZcmx7lXemaYU1s1K8f/1ezYhP8yN6MsP5v1B4NOU1BmAwFGvoJ288v6/MvZ3pwHqTJVFjF8eEptk/S+kdogCGUSZErBgvONUprqtMBg6N4SonSyoaFxlc3e80ZtL0MNjCsixuMIj1bRKo879XQrWjvLhAIBHpKnIYc/K/WZsVkWHSK+iX/HXxEJevPhpyr1/yoqCsiJecWi0yRbgNR59Oq92LrEo23YVTe1RT+LepeXrwuhMc4PE3VgU2NWtol/8x02+2nvse/7Zo+8M2NesWxwI230a5KNj5wYqdOuZQb9wf/95aMeCPfVnGTPHnl7bfsHWfvHdiAMZaefMeZAhbaqGFRGq0H4jdtWA7lpV2A9Y+Y9rd4P2PcrvAx6jw38xik8byaZN4yxLJLGsCoOSeL/6OUOUj7MioUUsT0PVRCmaAP+aXGzcmr05L7alj9Kyn/Qro7m/VjiOhtPExh9xpnvDwWk+n2MjXIidKIwqShhqoVAE7K9Wr/bWAf8/vykXH0PnZEnndASK0pOZsZEkUdp9D+c78Q70+JNcKeetQv6Xs3P423w6Q3C1LSK+IqE6txTL7ta89MHxlE5Pt4k0LnMX2Op2cpuo0xUmGsPPPRr1F1qR72zfAXHCcY3yuVJWrD27DwiLztX3PwWzPtUJSqgXSajVVqWIvhRajc/tHKOU5e7eCWjvPwqNveofL66UcyD5wdCJWDDZcglSHZ1+0gCizcbSVfzZqkFWAommz4GZ9YdtxifYvPKL+q5jf7Lxk2LHNW2JSIQ4ZDTFewyZJeUsV/vHwnsdqP9AH1wuydisGIO6++0sXI4eud9TYv+6ORmdwiGbEeB75xGc0+jT+b12YCrVqXKYeFjB6OXdYrgs6KAnTDN/QwW5ypPie5jA15X2tGtt3q2nu455mRj1m+b0vbpTeT73IiDvnCRxxUfYKOXjGzgbttA2jZiYymtcHCUajb9Xd8Q+kVaKNXVg9AlHhEOPJCz9VWn4dyzL54Z3mm/xwuWi4NwifIQGs9v3husi+LCcbOyqhPw7NNLFtpqNn1faEHjETBOSY0pp3bdIpFUw8C7l2e4Cf+DCuCWsFFRejnXTqsVl+Ly5VfJ2b/pTs+dEUY1K6BUfDssRxTUvckQ3T+541GfQh7Onj+5cXojzZ0qhQBbv0+2L6cGFhgcHBhllmrmBmfk2lN3hURfskBZMObllL37k1sTd837ElJDNrohVVDTGaiZ7gQZcP8NDguwaxH7YA4uTv3pRnH8yhZbfUrLZrv9MawoMikutpgXV7mu6wIQOj4dejIExvWswA3VQQwGxw6tGlRCHuAeNEJWDh4aWzlYBznhTTiF/zBaIMobK0j5cJgwmvpxvCCvcKQA+xEEjlOCtaJ/l6SWplcVRf/SjLWS/2akppYXFYX/Ta+eWxY9pSBQSApC7FRpaGnckXoCqXXoFjCH3o1WGgaj24PWNhrHeveno08r9igwZwbS2TGNxoFc7cErGoyiK38+SzbSuo/VGP5ospnapu6fd29HqavKmrQmC0mEb6rnZd5sCmUiSHCbnUqEcqUY7U7eGHfJypnl7mz4aipe15EZPsdOHbt5siIWFwDlhz6a9EAOMRgc75frHF+RpS1I3SDt49j/ROJTfyenDXWzm8HK6mIk32zLkWxfjK3NQgYbSumGk4WlpyM+ijnHa6x/dlT0/1OUbH2cUwj7WHJ6vJBmJA0yYlyOrnVddE5aWNLEan7XAA97amEDZ0BB4LAVBOgA03ks4FhedrxVl8dwAMdt9jvPd5zJ+/iyprfvZU3eR6Ujn/Q8u7kPRzcS2Fs1e/ddMXhacUq1XDWvAlG3f/fvj5D734nIfzng52/NZ5TTW592a7/4BEqkMk0ZuyY8UIyMCiypiWOjHK1P0jf2LbFzzxXV5i4uZQDHKbgaXiXgYBIFxVWbvugoN+VnCBm9dFZG55kkoBd4jO04kEe3/fLBwNxs3AdtPPvAmZA/hbmQ76cCu2HxBbzkjgxLr2s4M3ZL6e8PgJ+pfd77nMQ7JUuP623iUDer7uq1JVGrYNCCqMIm1YDdx0+i8akN50BmpSFYVS49eOvNkeGk0FIJBrW+bkKveXui14uAIZq7uRV/boz93bHiFNj+twbjZ8Zi+1pmoqtc5K432dxONlsw/oSi7H0hzDvHmUNCC6UwJqXsQGBt6AGuSRmVZ3tk901+eh+bJxpdIraQT+1rzyb0MueifOuqoRLbMGfNPpgbaHps99gF8/t6UvptjmMpFakEunwBUVx7JoXWmTqLFnPKRPyU8F3E0H6fzNQBm/EUfHVKapZ0EV6GOrizGoOoxM1CdiEUe2qTyPG+bcQI0CB4xrCrwvWi0H9GZB+Qnp/gNZdMKYhflbeaCF8vzfQVj+4b3i0T09wWHblvOY43779CuNoJMR0DVuYDTry86tvJ7cD0hVQ6Iw1X31Kn1uxTPPdBvPj+NB2gGsvgVhGn/R4z+2SBgIRwAdoDmgMYwzH7u9lh+3uGYxkbwDcpOqnHe/UbPql/pX51n1LXmUQ58OrTzt3vVdz/01PS+IFR/Ylx/+R9TnxDU3g6WYXwRX0O0LGUzhqWCsevoQtLrqDzxksNjxgmncsq8FL2NOYXgQDJHwtzgNKmzUyirulXtVz9p6VcdpPMfaZbmF8UxqgaoVT2PCV/BMR/0xdLkSenU5srMljBO4Yajes01qhIy9lOnRGCI860L/eGH/Zo062b1+2mtEqrr1rxxptej5R2fVoQbu9rP+6NPmJu8aPWutoip2DSMJFmTJoOvVi9zkobt7RkbLE0v85AW22m1Jo1/HA9WmN+2gkxAS5CTEryinZ9M11oKlxjKTXkurkWiuOOSEM9qyPiXWbeqYmNHaUmIcEH4gpjWLt3fwON5BX8rluBBxev3XmylOHjeBSEeD8CgknplnHr8cfVQarIx66zLrOPlJG1QYC3q5H/QPDgoQ1pu+28bf89Djx5nDVwbfwXe9j/Sd1WpHfiFzHX5qIN6OrUaB5o/HorfBYd87b7TNnmK9t724GXqUqFUXlZiFDDVvkB9yNmPIFqtwrYaXW7Upo57DCqGykasRpDq58jlPAmYzM6+T/2mvNLYuafmmTi1+oVHe0YTiNHUzIpiUXhcIqttIp2wOnC1e5HNfYmYuowIysnnwJO3YN5p6drnUDQ8en/HGc8uJHeIKCySljRR8wI9Yq5eLH2/tzJL4kltQbJ/nsrUFhedRptbxPUTIfwooipnTmk6WDxoWltY/vS4UdP63qeVXO/aFTb8z9flUvAg4cGv8kct2baiNE9XjgBK6YEj9B31rO1Cio3TwEzo2+OS4HM7wZmusSNvgeeoG2KmI3Ce3gsblzqodmZ3U90Yf48ixuaaRzU9bPc9mDw4u2A6tl2v+VdaBLcz2BNQKFzYkOJjVGJO+IhT7x6WCX1F1gcTFsPIovekhBfHR/m0ViFHba9E+7FsJgLEnmU1t6wlIR2uEgWeYbf35j4HZtQ2VwZGfcgLktxg8bW5eNiaqr5YC56/PKQMCOtNNF/4wnp9vB8bDgnODAQvpOAsmqqxm/6JNaiiV5ORkxMriyImFIDi+KF7SlA06OE29+l555aB6vHZZUez824VjGYB78RFt+ydigq7BZi5CLekSQ6g3M7C04xSiFBMj2M8veHE1yEjIKQ9+PkBb4MYYLzqY/Y7bKQoOgQt4+ycL6Mc5HT9A4PqFxJlKm1NbV3qw9NYOi6CKodcsGaj8qFWZazVFKb/K1u5w0YBevvnlndj/aAyfngAqhTvsOS3jkPTG6zXd8BgdzVzWAKckhBJiaXQqNDdqsxZXA1ndCpR7PpUxCJqMoIWGAq0h0dbc4FEZ3nLHahS2d2Za1Pzl6NV2pEzO3B3DEucJixmdwAbi76Ds87cZGoVuEYNcUnTDr2uDbscTWACRia7JIRjYwDzyzPxvyQuDhce3PD6+oIe/XnVWNRroevf2nciZp0XXBic3be24H/N/3leNda61WXF2Ae63lIj+vhGcOdgZ/YXDwwFBUKKUrCiJvXmxjhuw4dG6KmiZl7764tNhkV/9JNUhgF/l2qtIt4N7qAT4o7DbjdcAJC1Uyu1/oiCyHtad+PppRXHRGSX5locCYd5FfTwsrKY1WpP3SNVgzc+QI6LSzDjSff6Vr8xPe7mUSAwKYX0HzOgVUhzuG7tK4QwBJXANui/EUcjC4/4Mxuc9RdK7iaHtc9QpQJ2Gli5lVa4HRL9Zrv5s6czc4tVYHTtCvMNAlbIBshxnWTrxRgjgF0vteZPebUUh0wTbvKJIlZbOkoJq49/WoB+oTBSktnTpuT7krBFXKcZhQjZbFIEuYVWkCwpQoYTr1RZQN0Q7bqJGDJAJ5FqOYBS55XsQC6AZg43W3idTRW13Q28pr8QnTIuBA0sDTSbdD1f2vcgsiGXZM82QQiMzvJVe3JIhKYWcCwJDjbm2eGa5cTA3pPpnN7bjVSvyqUFdSvt+e7xcczGNrl2bTlwSR6VmAkR8L1OkvYbsGclXCAQN+vpqWmoc41/5lx/jRbA1Sxk2pCVDJBzVGuyFQTxr/ksAeeXxkOXF86287aru39Fz9rk6GrKDOw9wRzu1S0wUt/A8+ra1qUg42DqrVfTDB1P32jRfvw0RJQ0mAlx2cFaD9UYrEXkCFU2D87MInW8jkQ9yE2NmwqYn/32AZzbOciAOeGPNJvRw6d+D4TuTmVQu0AxOdJ9ZrxNnXH7J1D3EOzdzrUE62aehIhEReMDtrlF+VwMupIOHzi/68E7Mue4bvEgoI7xO7hOE9ZOXap++AdAnvuEnoOohvLOGUdTJOFy2BGQwOYceoC5TuQOXUVzEzPXLhUAu4LDm4M5UI0B/VxhaowFEqNUBHYRyAG9hiAMug5gnqGCWW4pe6hu2jZkFNWZgo9B6tld62DeRH+l/Tz5ZJKdvdYHnBiccX5S5AgzQtKxoNLdp58X7oMHFlvAKo2C1jIwTlTq77MHycTiiqnhBmvjDtwxhryqyPCKvFJWeZ3XY0VveKciJaO40WHiy2EP06rZnDjMty4zkK633lgbuCJgc6H56qfqFP2UuFYpznWl/6L8Fh94Ga36rGqoqJv8LvUicXdd3e6yQtsbeFyOD4uq5XHY/l97Gi1qMTfzcWLBeXlfAGewBeFeGIRQMUaED248h5ESaAcFzgNRTRYa8ugyRSu3AP+XNFgs1AoNtskOAdyHf/o4t/2l/uBsvNe9G70eq5t04zVWEHGWbpl7pyewqDXfrStu/bsTcvSsbn6zHtzDeXi5Q6Vh4ip4dAxloC4Ib8fer7RdKB9oGXldUOJ+ihipEa23HtJjWpU0O2paH2AwKgFilYt6Bn0BjXy/O8R9zPHu8Tx9rpVV6+Cww/p+bXjPwKFEkikVRKQaM5+MhL8zZzy2dEf70HQU3cmHL6buwKd9UatMS3b3KC1qAZM/KcHt7tEx7elO+2bZWVMbxVGdrMfQv8+USa4eM+ydOi6Ze7FkZzW86+5Vo5ed+WfX81WcAI9nEp1F4cVUKiYbQGqRtNNDXFn/6rzXLppK+y5ZctdqutrPHvTNK/npomkF4siKN4GukDgIZO9EhE5AsWiTH9kA/1nlIdN09ei2tqvi7zTHms9hEd+Ik4gOBnHlOsS/SqS6tx5fJo7ManC0J/ODKftIiU+FYsiV2jhbM4YPL0CRUmXayPZ7LHIDPkM0wsba9pJxXsJSAQrheBvLMHEgsJ+1iCnsPAgh0Ue5IklA7xWlJeERA2IJGG9tBmdKiaNNeBbWHx+KwtPN5L8NpYmZ/fv+/Z9dd8diBf6NUgIOtqMlIByyBjE8U+PXJuBcCI+Xgfpd/qpyEn9MFMhYfckomaUy4YOjqtswt43avt6nhoHmeFxwGWvv8ZDXMnzFTkdRgbhqA0zPI//n2XY+fOZcZOXXVFzcDPwDTyjR7nieflAWsPxZLk67iI3B3VBqZ5NTqv6rbb0cz7cfBPoTquBxJhmIWYltKjaoAqrLdaeVfuBc1Oq2/HMI+H/EyP/OtXk/31jrLL2TnH+o8oW7osLhUXsyUxaPzYUHHOI4AbSXfi2yqTwzixkSEtJGiFJSAue4qZr01aOHH8uwG1JZvJJGzwgLVY1V+onPNfrGVWoFlTdA9OQgRcCe6O59yd/SeOh0WO6ftvAda95TaEhm3R2atpLtixSlso+LjtBBrkF0al0NxZmIqrsYSlZrfN8W147NZPxCC8Lkh3m/rrF2J/JRGM+zpxubGepWdPm8KjEWILZrLl3qrNUuXHtIUAHjuu4yAtS977JVbOsUaW7uTADa8rfQ2br9Xxb/v8m5RGXm982g7TJBifYW++HY3ZM8gQu8tFTedQHypr0BxdFbag2d0E1vGk1mWZasK2Qh+LHBjaScSEKSSIBT/AAfNq86QqSaMJw0d5qndhJC+Khi/n0R8r6vA/va0cyz+3FkohVwZ6n3NLr1CkJA3RseH15EiEpzV4GdLc2OIYIBrvXOtmaMKX5XWOE1MN8Bnp0hirPnI7gKVbTawxREclpOTkV9IyyEkFC4jZw0SG0QdU9LcGvO+ESCSkVb6sUhAd0DUSmR5Z4xTuXhecFR7mRIqgKCjVaErGvGygsh8guGqxysAZY8Y1JwRkMy4Y5oxO6dsewTT5WCkfHrSgNLY0Dzpt9pdrChN7+NFviMNLl8vmMpVkiCANZ2WlZu/zZ29vd/ljc6fkNYP3HtQXwQuxTjetx5PIs6zrtM1868GHW+EpOqhSLV5CDlgvJL64sK5i30liB3OSznTnNlKDjNz3Q7oUMOsi5569QK3ya7OuQ7hwrMwTRGBAx1Fov878Lseqj/DiRUJqhCsssP3B8bZ7B0hSfkFG+zyRJ6/KiwxL9SQoNOQ8mXV9H9XTNYQsl5muL3kVdZ6/vPpkiFs+nMLpn8tZh9xMa/IQChl8FAZvosx/X4CPgM8P3/EKFyePMv7puEXm4Q6fuSVVwkeYDbbjpCpwmikSjhaWRQYZ74bvDveAxaNYoUc5u84vTurKtkUXXoDlOPKk/q9wg9vuxEClEaxRAGFqFmkE9vP9klDkYntqYE+dch8bXjgSDh2oosVQ0lB3NSVMehrH2tifYs3e4tjiVeodJU9xKYtHEIsRdaS5ifzEWJy+uIrLQVepdeEpLLVBvAm0FHXpOQO1/QXuMzPP8M5YnvVO7cr2t75/bVGuZE/PdGT525p9TijYTPXsOFAtmtlXlBb6THaICp4n4PuIkEkmYIBQSsAUK4RKdrl+woP4k5i1dV/DCgFGqAg/IBL2wvqDGYEeomDeWHPyE8fCTJ8U5g83d5xO8ENbtLhMYWUwtV4wCFYUSXuXyeplzqRFAq06Kq5b0oD8KAJehXSiI7neGVv0+AdfXa2S+OV1eQm+JTjgkW5w9m+jhsuzmcli+cufOQSAKy1iA3ndXviMMSx+UgXKL5aFA0Zb5SOPdK2iZanIinBjaDLRz7r3cfXXt7vmh3Wfu7wapT0ezeppBVKbLkoC/PCCUTiLNQoysbXc8J+PN9fk/7i8rGN0JvLLYRvfSM9vPPLxYZW7Z6NuNXv9Alf9z5tVmROFWODP7gICX5V9p86nPMem2V+UYCfWVaSx/Hj/bX9TgvJUOrDfv4P+8v1xPR8OUyenORh7JUNxT8X/MvN4cV7S10c3y528wWLH7Csaq7boc06uoTM0G7gFxw+IywOTMoYOdzTaV580VNzeYRsgTcQApNjp1RCPSvxbXSZcv6qONjDTAKQeZPaqsbZdtDN6QAaHKfjE/EMhG6nk/cNSKAMejMcy27vWJ8M8+67NoiLrzYVKWvma6NLDGcuTv4wAS6r48vIHE+u/TSoI150PKS6eftC3P8QKhjFIxwJn9NevvYI51t2Cy3zor0Rfpj1bXDL/VfHhOqapFN85C+zbVlrTAuZ4ZvzVqeAuWkspmSAA4uhzqOIWFQpUx9XBIz0TLreenLLzz3v1DbSo/Zz2C6hjbnkbuudxzKezxfRRo3FgK/qbr4+dzP3W6P7g1v6KnRrYOEiqLnUa0tSxznsszjjeFO1PXQ8Jf/fEWnjtaNJyScDhHJ+FRkFiqHLgv2XUHdHv+GZWkIwB73aHRSZ3GCboJJkKrNMqUxUQXl0Fl/w7lP/LGIl7X8Z+yLBBnBw9l/F7xY2gyQra4Que9bz0iK2nbKVBmG2boAW3yZvUygMod+b0C02G/eAbSqERgN+SHZMQblgoa7snvFADpiW7B61mB5a6NnND91wYX7yDNQrSbPydi0Oj0Zr5coVocu3hddy7Rx+nezVUyfRnOLYPHthQUhPCcrp6QVOd0IRKGq87Onsf6VLu28SimYhos2wQ0X/bJOmTAMYG0Chkw+2n7byhqhv3RVimC85xVqs2s/OyccT8pyYOS10t0OzY7MgPo0DFQBltjQnu01nStKa1hjckqY2qvrDEpAhzJn/ocjdp9FksxnXtYlSoBOlq081C8UuK2ADTPott/Q6u3WHSeRdObXU6Qn5ZFT4sJkUn5KP/51CTfvTlpaH8PSqXaU0+qqgzs5Ja0xuDqjsiTn+TVkJfOVzSKRklZA57Xs0PYW76Mu6nu/3a7xQIcvS48Xkj/9xjH6Z2L9TGFiIguAQ7aKUnFIHnuYpmTEV4TUsmdPUXMq7smYT2vHyh4eS1P3PhUIPr75BprNXBNz2Bww+b/naTm9EzgrjcXn4SQa3duib8gk9YTIyihe33sQA+fEwqHsfdzbE4Ykg6Z3xBHlwwwEONUFvGILqtMMVuIvlMaWgx5Uzvxxe2EBXi13Tj9iSeRrqyPj431o/PQ/mSoInQXI4e14Xd9vyTnPpaKGwxpk0aHFRbDMfgSOFRO9qzFHKBn9fiwo4HPlxb5+P8IkkfVELIruMvLrsN97QENKPA/aFtklnOPHTwiTE/Kq63r/vflCDM2MQiXUAu0zaa0dWaL2lUe5LE3kkZMa0wjW80mzMAW0yRN3veH083qR3WB0oi05f14OKVSPZITOVOzns6arGRQMioYVElfX8eerMgasKwaEOcOUT6qzotiLkfy+ZfMB5mdAuJ9qWDjbMomAS7QBEcjhBTow7JY2gpqelaj/xZYj4kuEY10TtJwv9+dblLfq+PU5XB+GEXVPMb9oUMX7UKxU8II/UjTni7l5JIs/6N29HGk3znjhDFlX+3xiZwomF8inbwT3Z0E72PPW8xaOQNog+56TsWA6VlgtQLc5kB29cDq82D+oq5udjQytf1dLzD4bGXVhr7rU5TKjY/8qv0eLe9JUAUdYFM5Ui9spyH5eUltkaa6CuKxNnm4b31kkRd4KLGJoW4l84E7NIWzG82yv/cPse9kd0gElKzB/IOAU2eBeGpmUdMxvdiKaJlabO+YWex+h8Ci+Di0OliEixZgsckCYJiz6ppLL8Dz/tdAG9NCUp2DmUVwqPaNhVV7aoRNV300j/bYpJmVznyle0TV0Q8jn5fQyXiZBZQnyIu0xDn6aeA7uyq56GE+62ZFObfxkN9hBvIxV2KpLU5sjVNno9/525INUM7wMBUdhShGaTSNclE+Kk2C6IYXGkNtjTji/wIge/N/4x64LzOynnG7i0v0NkVixB6YKAMTrX0J8ouf+/o5//jNcJ3fG1ar7lZzPjSvk2Y9vibpbaaUEALmseuctJPFlAxqqSDg9aIQmBOXE8LYBYzUqOj48IoyBI5Qigi746MRYRVuDo8vH+yu1kTvzuXN95TvhZblIEolyFwkF4m3Rnxf3mFtDLJIgjQx8MsQMNoRk0GisEORUl4MAxmnbcObzu5rz7SYWNemGQNuvoEEAiQQWTry3NUOmHMkReqkrjAgIZdAkTAav3bh0HCUEBEsPKIuQCQDN6KxYtchFSJEUifyJRciQirynHnd5fdCfUC6WQtNHZq01zvVuxxevOtIZJTrKC8hZx5QUX8/hqDvIhd/TiLBnw/71XPQQAaTnbZ4w0J97byORquiUSpUf7ZzVMA7XqtqVG1rvTFww7oU2xzSDCLIWsDGzgK6dMnLJ+I5AY6pBwDFmFytBXTIzWLMqi/jx5xSUTkjpEWoVmWkob6aFVaXzcky/skmPy1m5AhiI4rN+9UoAiTV/VEkYe6/AAzUsyDZtktE9qd/Ake6WdlUJo+KqiKAuzo91sMuXSL35LWLWgysiV3yj9Oovpvl/g4SNYpAelXBQbTxSQeYe6Pi3RwcJpfDQFWSCIEh9s4k5yzcOTuJhbVkl+r2OMOjktuZOx9ccCcxDn8GIEule3GK1q/XL1I1cP86QNo2GS3JpsF2c5G7kg4+Oz6LgMV58CnQ0mgBgwrbxUBPIIQAsQWS0Qj3id1B+7jMGMG24f0AKweLiDlk5io3A4VpJcB9inKCwv8yLHISkQn4ZmGapXcAJIkBjrS9TgeZTDIAwy7Fm5JaoIH5K2MMB6H3GotzLQlA+rq5dPaE3cuxglUkvtPa274JNONNRNlqTzVwHJc/0BP3PkvZT4qU+TnHrkvjrKYPFUqQWUzKljUM+OrKImsL9FOs4vS9BSuD40wVan2iMDaCGToeMfs6z8rMoqQCPharniRUATcIWFVa8k461xMTyN6NBPcdLhAwOKqYPv5w+nN/QjouDJqGi4SlYaBh6Zj4cAeUgwPwO+v5x3sPkPCw2WYfWudTl9CefDqakIdOSpNNJvGLj2BTVXhdSA4vK5qwGxYOhfLrdjkTh7cOx8fzk4mUuqNxhfJFMrkLM7ssygrFdSTCXS44KJBeHvfsYU3eZ41qe9FfPxUbmFlAvLeauZSNfFyPLxqFKKCEjVIGW1uezlR+e7G5mAia3HnCSjYqgK5ugVVuq3O5nMZsE2bn9TzEKF8aPL6liw4rrIgkaeqFySE+qtngGufGbdfJzFaR6q+Xj//jz89lJ4X4auZDZS4NrpdTGWrRyOqTj1N0O5pIqD7+jF6sgcce0JZeUafhY/yp8XNh5S4Kl2vk7HZhw+tR4EfWUp0uwBac+jZYqjbdzEtz+pV/cDQ2F7TSPkt48vKfrHP8+XdyfH+5pAYwEkRvurSI33V3AIL5es50IWbXXfPsfWV3XfcHrM71YwWadjV1xqYlzLea9ZJhoaojjGsDAo1dF59OqNv5TE3yhx1rXJ8+v4zKO2NtOUi864rfQyma+z6aAkpvTeMWYnqWKXVe1LTm+HSdOlXgppZ7OM7mLX52C4FnImCqOw1ts3LHwBGGbMXdZDkfpI1sOVFgfbU7ZpT21Y6az07IMc+sxKFN9hECs1XvVytVNJpQQaZyhewSTvautH0wUlUdhd/fM+eVcLsGuXrzmFg4ZcXXEA41+Y5WgJV5Bb8h9hWGI0CF/T8uvFWxRNorUegGD8Dr2nfzlS1Zo9RVdpFbS+JXGbRcckZNQV1GYO+3W89svZy8Wmvm00qT8Ld12zeWMvfOHYfObeQqEuwc+J7XDxR0hocGPC92wPc9FT2vvz33U2dMZ3jzjiZsayvPmKWEF87+NOv2SDMMjpHat1pettze5gTkHUlTl9wytg/HNHCl8uDjwHrmhG9AK3c+oNtQEfOBk/EfaiZzMcO2Xjq1iafC+7xEjbSNzPSKV73eCy/WrxheNOYGx/aVBerql9jt+6DefZNTQTUNsEHGWMfV1xzLLIu4Phdvt21VzPQFqOr+nWWVWJF/gmAGHmmtO7aouK39u7Kjgp/yXO0fUfz172/K6p4ru4/BToiKTiMNgRWz6Whds3J6EdZPBpat3T0dLlllvcXLrIYShZhLppptFxEdwU+PlYYqh88kTS7srF04OI0UbpZ7vHM3ZHPVs9BWJatbuYojyevg/KZeu969zdAFOC9fDeWTUfC/OXpCdMkCW2QfwMmHDrIbcfSqLmyVt0Dqre5DUnT0xtMdQ6IxlNqtWEDIyEwun4KmqbBCgO11lf7X1qpOXwb4AmKDtYKCYaRjp2CwbchAmIDQaKOSS+jp0x9BlYl0IJo7o0wSGGsF5fSCGXjuT4WVCTxjowDBKmDkw3LiohmDD06+ewYoS7NJ1dVek+PVmJSmbVtkUlaKJFkx/bzh4i4bcNZubk5X9ijOzmYdK/QQ64dmBbZ+IW1Eu9pd/9Kb+Vtf/fJeg63gVPcJoXxkETAhu4I//OQZczpDHy0oLENrHOUSWSeF06JY9bWuvuJdNnoEbZo105GdhlY6qUkMiNo5VdrQyTZ2jWKYLPfWOYY7OuyXXK7jtx3FqzcuZkawRn0jXAEvEZxY2K/xZEWxKBhtDurfChFXRNzH57WOcM2js4UNcveAVnZ6B4BNpGX5VK3M/S96E+lsysditH34wWpka8fC5YFLjcdSCXUGaFnbuJ68B/BNdmxlEnZtiRho1kvgsRbIz6L88ecrlCpAMv1vrlHlS/+1n8HGu/qNu+ZkH+dAWK/AzcTjOEwCgUPH4bl0Gn5udn5udF5BSG5+Dsj68viq+oYHh1bqmQ1rkLM6DAwLWzNAnDMI2VoZlcKlUBt4BnkPUJi6m3fSO4k6PJYCKYNaMYKrsVaiixBuGPRxt+7BlajSmDh59McOavTU7kNIpYUva6hXVZ3ckTz9447OrUZ1RiPEjIRFsQDWKqKw4VFRZJHjCYl0PtudJo4mqKSMmC0ppObLOcZ8Uk3nmAWdxzRaf9zuMszqTMr0h4QnIpuYRA6Qcfg5xnxjhdcxiGDoOTR5/bbK6+WN69c5/uhT1BSHV2bk0WrZ0J7K4kfEuuwEfkpbbeKuF+Df31jhYhk46d+UMFBXq8t2JrvRJv+OUdsixYH8bS93uaX6gViiWwhUoRqLEl0EdxcXPe4aFgKaEpK7DiAVZp68plZb4WFk1Ggebjnup0cVFw+h2n0L5RTKgGlZTDGFJYZ5FEXHipzEKZVDJSOKkZJutRrryX0sLmXy8wknciyr6uajd51C/EsZcHyYWK3nFasgdWUjl7l5HM1WdeVWNQPXxqfT0xk5sJTF65RCd3fq0rtSDUMaEyKEsu1AyOqTfv3/bBLF+nI68ym9Yuy7FtGm9rf79csLodJShl+vQCiuxUWn/770ZAmS4GRbAmEpS0Cq4ZCFnsosiw8IN6PL2s6181q+mDM/+L7Fi5LcBttHU+RcLU7feuUY/n5ghf3W+dCfyNsnDctqUPBFF/IbuPfJR9IZT/mthqVl2Z8NqrzlSMA5jG6KpEdc2NK1iXHlW9XMpR4ZZXdgx7UqMUO6sCvuws74ERqzUrsEB6Ubr+X/8myX3jFL/nO5zkfx2db8S+pOzXM3S0vtgXEnkK/i4eX5/FaZtRWQ51Rc9Yggu2OZJxC9sfpIZxk+1fwl/pqoaa08+l4ljkhKiasX+epMXm2apuLKidA0Ae2L9sn8lSDj2P4pmvisx1B0M/3mPlpBbckndduaw0ML3r3HPv1yKFj8Y5EGK/jHhwNKM1Mmo/W41QTMM3WGgw31jqUzac2ak7zlHSNPqsoLKJIExsvbZM/aFpOvpYrK0U0R30xLPQhtGD1anBUoB/TqprNVB0CCmG2HVt8Ez63GV/p3F8AzzXZ8hdhGaspuoNVbcXTaCUTpPsBsOqDodpDORDojj/9xmwTjmGo24YdLRXDGLj1liSKrDdZ6l524RDPGsNJF2XkwYNU+4bx9+snHxCD/FygXBGJRnfshwqPlOVrwzECKdPY4fSP+amxOLIifCuKDAMcK7rifnEYVeKsQCY6/9/hOZQ5xes2nrmSmIa8cvfdvdHd3/mrAt+QXx/qVkhtFb9EnvWppeBHLn87jM1PfebXUOlsR0xSbWCTJVMRkhbeWNKc1EnhaKrpGkaGIbY7PNiSSEJr1gJ/i/3YJHJeC+xM7BvbG8eb67p/VNHz7ZFnT4XcDj6NARSqMwuSzkuXJXgQ/6xeoDSvmwpEkLQ3tUbD0Me461KGIF7yiww7oDctrGOHu0Dp2y4Y9jB4PyzIUNKI6CipqRhWMKX239cpRep20k2Dy8ObBcrzSLmtssKlJmFKT1vEC2cXKtGpNrS3dz/uXvXTif86S3DTtEtDH2scPKdIUtWOgTHsyE/GcYccU3iLvEWkC8Gnh3ovqSWdHrCHaNXLgt4bKDNK+t6CSF7daq593pVMEiPRGvoKJ4sMxVZn9ayuXdRFgpW//F25lp3peJYG1uVnG4yQ9Uk2b6FCoEYq4YcLsbk4a1n1Y1DJKOe2gpTkoHFe+8FCZNhsprBrhPA2t4zJvsKYGLNUT70rWr88xIHsyC/0GncP6MXb7ax8ZmJv0PJ7JyiKWCzQFb57McG5v1iXzyulYyPpVs9JVHpnakQb59omh6XDoC1fJ7EY6xJWbHVaU+22h6B9gmBDpuLXC1o/dTT+NQDNRv3xwOSjH+gjLQHhwEMVGv2GOQzVs6I+HLoCUpSo2RJxepySUFN0twGnL5BFva1iw3AJkFewrxu8UOc+jYyH1sYZNrJyCltziDeG2AF1z2zY3FKq9I/WsTlkR3+XiJ5T7MQF4nS6naEpU8KRsCVLIOMFngFvRcZlquLwkKVdHqBRfEzBC/jRSA2G/bNHMH2J3vPox2Yi0vrrgIXRno9k5D9fT0hMfGt8ViK4HeU4R7g08qlkgoJk28F3hAlJXDV8qqeWTOsExq+u1c3h5UeDf7kOFIkB730jG1M7jd8JRGD/aAMNeffXm9WvX4MILSVh27VcLuoxRHiW949NHQCaXnIxSbpDByVn1lWyZsDqPq8uQmwqNDXvxGT6n1E2o0CnrM3bHWc/GovE9ObQX+ozWcAAR+aCxsLfstQ7DUEb2ySjFeg2cBKnFMtGI8bS6NeY1/v3hoG9Shu1NFOTlQrOUdG5xU6YU41OdjuxBTiLNRnYushufiewsB7tPk3AjAda4uL5l7HV6EXdnlCgKcuH+sKBINZAmJKOLczVVVfu13cUJR+VtkbJsNwzH4/UVVCY+sHNO32+WMfiifM6cR0psdDPAsaXF0zoZJZA/Ed2Z52/dMqPUCn9eTHWCHNDL1vxc+fqVr+0++qdoF5x7t6dYbRCCwI9t6afoN1/+CqmTaJp0EzNiXbxlTcTu8FXHZavzcupiMv/cvCkmcvevEhJPpNsMJ9JkiU+LIfvSQVidFj1zYjmY59+rgstr77u56uSkzcmbe+Hkrrk/ETIx+f6TXbsfguzEmKLoIESFn4uuEbySBOjax3Gef7lr5iGUD2RYJAj1yeNoWHaTUEUnCMuR1sRAKLfDGgVfhjoj30NAM+FV3WVIvBwqDLusvw2rhdih09qX6h1TSHdlr0jdXbKNo0H6zdypTIBYLJP7bG1s5REL+7hCXyImEKQyvM2QEvApjGm3N+tLJyQkS5RJgdvZnA12ZEXOHQ40jdCQtyAZUsadqjziTunMIZBzc9kH9kFzMuK90+BLfvfELz1zrIC06IO08krD4TH/uMVYyamSKBFkD0GiUA3kTa9jf6XRfwpMRV4F5mYZca2puKq1+j6s6Fimf2lz7FXoZaWl1LRd5UsOJtusjjBzzBOwbcFMHeNyBzd+PkZ2qiRSmLSLoeO2VB8MgtIY0lo1qs3j67MGrdYzApz0gIhVnydMCkLomhKkhhb9BLJyHFKBhvqhH+qad1BrFd1CVVfJTv7kUu1hf3MstV2/9HJVrcL7Bj568aatlI3I8YgkFByPWGpK9ao+MgnACr4lHDz92aGAoD9ktPiyc80IVCoPKOtXzZ4rqhMHe5ZOMvFNu3Ix00zmKu1vMzpKAMPosibDLADB2OrqdYAn40GDRaQtsDvSPoTMZoS2vxilyceUJGm/B/bG0/bitgZNBZJlRB8gN5hU+f3tvnvo53ugLihUo7hqdEVij0csrt+z+lPz1CvDaJjFddS7fpV87n4U9/JhHHtI+bfL4zuas9Km5XMrN8Qb7Qh2aXa9UEIdpB/XRtU3OsGuKTy5aiKlTbvlveQMqojbLtt46lJmGvKGaPVlW5+5LDjDLnlLv3+KZGeO3xryppZqDkKqo4EO79DURJIahkTZlNKCo0oZzlKKIKiVhLgPmPgPHk1WU/iEc4qZFqcuZA1FFFqCtqTyB4pSoj7LhKMR++x1fXQuq4duqyf2ULGZFoK+94ESyYHBCvAw3tEO53TjnfhILzhuCgSbRlftWszYhkbUz/TDr1snT9QM+VdN1C161UQKSK37OIqx1UplB9mhpPSpYK3reMRBTpx2Tu/LGk6YO378rSe4euJr3oz5gJS5pal/kjtTy0b5/zt7JW8NzivOz+H8ebqU0GNx2clOHJsv3Jc++I9z9y/dwei8BzHNxRMiUUulgObqYp4r+CwqSfVI4scKfCOwUyPO4bava4+7e5LLjHAYimkvFH0ubFtTh7WiEMV0fFPOrthjYZou3nNhG/yTsUkLTckfpX7cNAZlgNG5H8Y1wjj5SVtIflQQhdVFGmfS0vAn1n9skdQ7qY2bJqACgJp/voqt7WpDwTt8x40LxneHaWZvSsJYYRrGBIxXcnBvEUBPo7FVkcaZTWkFqPX7G8mwFYo/r9enzVGBFToBeV5e52R8KWzp/1A/lfZPKbDU396KaeXK8CQ6o8nsrb1pnzYU17f0Vzd/VR4jM0ZR/XZC5BTqQmpQEievt2jQcihKSoIXiaW057+IDSiRPTd+E3bOsNfcbmRrCq29+k6oe/3Tp+nROQ6q2rJ1b7LeelBum6lBphoIlW8FXcKYmqCj4QnKNuv/JO4pCOfiB+erYdqxM9I18/cnA93IgpW1Q/JKmf2Gy/xILvlasBI+JK9gfmqt+FFQ2C6eYmaMfFtcXxK5z5Rq6Y5LmDYpWShYs/MdQdn+aZrorAcXM5/u2Ecq8CWcZZf3/n+jZKu0TnZzjR6OIACZCkYGR6fGpLfjjXlR3C3pWjCB4O5f4dxgLVeg849aelyp1I8b2Lplz21h884RVonOT3tGxRKb4Ixi5rdPPdj9YZv0a2GW1VcjRUDZFWQd3nzoC3WIQlxeRRDrXHOM67n3Ilygd+Eh0eG1myNCpDlJoKYlWD8Nypt6HamLkfw0PMhwKE1YWwSNd2zKLN+EtiBhvwapIR3O3MYUK7JBWt/ok9mq4QmmGEN+TaqPMD2s7Kyrka+YsFyiYZys7bQbMAfeQFVhlBwIGFRn/PRO+SqPKHiBKbSOvf0rQeb1ytKlpnGHuOGZILxh3G6kpp0SPJn25ttpq1vcIEMSRt5+g1mTRWGNTewJPhM1ZrKko9ZRXoZksZBI5p4xJ1hMs/Uom2LABJ8zsyvuehzddmioyFsvSRgLV3eZCw8eJBSEGEkdCeLG2rVC9xqht1Yc71qnmk/kGVjpcHe8xFsfKuKumOs75Jn6hQUbPW33x51zlbmmAwfsTKDl56fvX1hbhoWjUX7+TTKGedJ9zaOdtdFVPaFYJe9/8LhoWQyy+/DDrkdBcgWvice+yw2+JwpPYdXPz7eoPWwPqIX70Df2FNLYbw+2jAs+fQqCuYadwRVz2+59NsgiwDb+isi4ZcuZ507aEgou9UlljFLZ3C+hGzc+XS0j/ke+CixM28OX1cGt75yGrPTZgzdvYeypMmJkJEaptIa0tb/yxZ1DVLzsX2H/PwCgldBfoYLi8HsFTQRb69FmbdD5Ts1IcVal7K2FU7YX2ET2aHkCDw2EjVunEZlQ9JlYxhpLYiUlLi+WbuBSvRAOPJ+N97v5gCvDnhctPxLNSbkeHd02VT9xT+NYxq3vlpdbFLySr2CqcPgtx4rqjyZ0Em+Kd6DZe1VIreinuO40g+5wZ+8sX2+oaQa8kSr2S9u2m6j13t1fyN56x2K1xNyXUXdiXIE4V6ktkEulsQfQ4ozVYefR1vAy+eBgbdZesPvhRVrdbAy97EbKBe857EFlf4lnYiYNCkbESfiTxnENrfvDD5zY8MezWvjOg6vCFNjF/5q66+PQEusYWL6Nb6CHGRbioyjSlC/syykW9E7zU0/S/eBkPaISAlrcp8fME5wfeiyfWUvLSoS10l/o85mcBED2AjdPH1ehrwEa/Go/12O1AtjCmUb4roXO/6+Y7XI4thY8+ZK5JgzKh0ua2g+u2q25P/Kcmn1WJsDN3WJOvvczXHu78Snrd+8E+okrGA7thB06iXpQB1kxOO6G2/j9aJpklI/5qK3JGx/x1TEbO5Bj4OPqMS3+wxhfnL+jUz9oj83OPmzwNRg8NM6y5b4PrSckkFkISBT7vdW8ZdZAg8XJ4f4D1fEcDEAKjD20qe8ZK+dMUa0xn1G1le2P24G8XK6SJ9MDykjlxD3p09efFvKrjnKlai6FPECnkwfniC2oZlEzGPnCugYaxBWEJieLEKEViOh43oZfySYXQIO5YTXeIcpwt4fWSKSkNAvxk1s4I8nkLh9Hr4XvKb1j7ZfOfnvlx3jrucpc9WCDq4RsevfNVrlO2/I4p3Ym5Cpmh7JUVIjzYnrfYl2GCGEgGLljK1Vmf59EiW9RJdIyVYnIFsqPNQg1qU6MV3efJ2FRLBx6vCQsCYOCSfsMBq2P9S0Ia3yxANfYeOkxnrbPBwK+i1IQW+lnKndePKbpmD5Wj+TC0faOmaPdLypjqrxGna6qstLTMBi0XuHXVVe028uIZ4D7JtncNm7FNKM4Us0/fOD1u/vwXImcJzvxw9SushTLZxbTtB8OZIaR2rK5m/TS908vp5waTRHQY2i0liULRvHf3TTyMPNTFgjEhUE0e9c/EtcdvcG50Bd0Xnb2n78HFycJh29iS87be3Nz+1rsg/aL7e2AuGAjarIQccDaaVB0zdMVdjKCcgE2N0jYckvWTctQ/C3/a1B6S04PTunvkxUz+vmq2bb1Tjj00jeo8RrST93c7SFELaz1SY/1+K47dd9tZU19gBI+yHIPRh6mUFy+hAPLLtiTl5Vam/gtqMsIb5yBiXVsscshxxpwy1jLxdrn1gp+ME42LIvgwyuwn5/YNCtCx6Fg+m0j5y3M1L3t3Ambdx19lZonDSpcW1L41roNvkjH8lR9+MX+oLqbanNxx7BmdgjqzMgydqIOx/LD2gl4UIArGy9ua5Z1kU171N40cGE4z4bhe/LUGTxVV01th23QyJo0piH4ltmZ/22/l85vYv/KM526nJnan5WI9ZXnfYgvxs0LFin1DJrgSYjzRbL1o1YPjv28dnF8c4o3K5hdIaZi7P5xQo2axab0G5uPyj6JiPyhQ2Q1/pCgRUQBPQ+hliTrPhcBy6hAflaqthXHIhsvrR+7R+SnNL+KqXaqLi+YU7eP4g5gVgN7xa4CPxOeI8NzI7zd7FpFf2kVO8jEORNrp/TvH6qgkbs7kmIA+iNewoWPIV6eF06UsQgp8ydqczqZoupcFq7Hd6q7G3MpMGOoobS8q9+t7dslOG+y0rd1yNX2MV/lpcKP6jVeK/tXdlrAq1JMj6NVCZaUI6guLhtcuhmsb572PPsbbXb9DBbIEiEyY1kkP3U7TKIOKhpf5+9rsQ+TvWea/hbJto8hb7N5sfnHnzeLJhKvRgGsgl6sUrqu3hUNOQiJZW0jcfEFVUR8xSPc3AmA8Mvv5MmQxu/FfV9cS6XpDecVNXzgwADpwVRVSj88ii1WMKvdpcQor1MPL5crA+5Oj+8qJXVMTWhp488OZOHeDrU2ZHNpe+l+/IPPM6rUBZ1e9VwWdHl4LMwVdCOHoctztl6Ve69qqY3GJ1hTPnZP81swTyeBJJgoNjEp5tz9XZq7QI7nvXJGnbytfppXNZ9dhEVQx/DHM2/jVTO/oK4RP9h/bhqyrfTJ3282nE4evqaYpMTYJw+4f9/BH1WBXJapJqrVY4tPz6QJI0cdgllavWaTVuPcn+UdLb5jXeijDEnGbs6nJoxS5qNlSv8YJf43ClNbh6iQ6FjMYhhfx55iW3OTF7PSiKHhhGAJ/scM5jo7Y2ypMjmylV4hQQRLOPqU9/tG892khgtB61s7h1/0PcASptbxCTz0nZPr885Yp0DO1KVydmUvxr02a07uYt/9LO2QJij27iaKmjVJ1/ING8L4nGz94Y80luykwr0lV2PbWmNZr/ehT8HoU9coV/NInKP/S3/PuId3UfQIhhv0hdF+9q5j8Dk3bN51+cNLX1I5v8115WhQuxCz/Tn8fgBElxCcAEz1jGo3foVmBV8Hk33UMfsLWnqTRO8mDAcLqe//OHpK9Qej+N0KDybF37/tEem0tSDkRkngvEl4C8P95llyJ3ECvYvEiyLi6UcntqyA3s+ruS36iF8EESW4pd+S2IRJXH3aXvpr3E3FzUs4IH2OGjIvZNXiF3gt+dOn1uU/kzkjPiwc504j45tJEGfuGG6WzE3pJb5cfUJwu9gfWPuV5Py85kRwQA5of3ujeZFGq+c8YqwiiLeMxHHx4fTMltzD4FA2WarYV9yJqYl45Z2EN4LrWczrFX0lCBbZC2SwIKyECWO3IOofQvL4K9s/JyoBdnOwUGDhQCpx9zYtrZy0cMXxsws+v0QJbsfl/6vY4MajTsybnFK3e2TFghTxpLg2PZhpqLaFWaLvVwrK1koKu51to5eVbXUqxrjIQcVNU9N1+oawyr/erFJhLPVQjTlo3LwjplSQLwhIQXWzjGMrbyHQIIXEDVmvp2c3YRSInqOYvvRgBkW+lp+vKPAB0vasu6yQQBjkKMTx17dh8RJMN1GTjkNW2Xz2fWBwjzvCupYZ9aRSMDNcgfJZ26ag4IJ5x3Y+Ufp9i//1vC2bw+gVOKkPWXWRl2x05M4zgpkUGaywJwzVqLpxTN2JucsvUJqzG+mbxMYjvwyeq405uoZ8VvvS6TSgE4xDIlEEuxhcPTi9YvuZBTssaRTTqp5aWu9EcEXRI1Qh5fid/HFz6bEoQfI/1ffUUhGAoMYODQbKBcmLUZ69w8V4f6twl/HA9O3I++d9r+ZezSxc1GU8k67dfkOYPG7CoWxGU79eBnfzgvwLyU5ykDx2N+sKRlKl1Tr41hJ5UrGWMYU4nCyRHk6eQqgZxUkwCcdUaalUA2AKE2yoeS32X/40/klBcDF9Z+y6SAsq0yekM4x1GAp+qFQEZ07rKScostoLTu+p+vL0RpQNPEotPRbZ1MyBQMUmkfCTFdy3oCKmTmZSKDM+7OI3h+buD7aHnYYsIxkF1cR76PtPBds8e9ZxYjMWhYqJTF2RiEAjW+7eoi4/nZrOOZMu2yzvyQ8W6pQ8yKRr+11d5Nkvq8Q3i1+cV/dz8MuyMssQs0tvmsA3wrBUejAdflBS12EdNAG/rwN07vKtIe9sex6VW5UezOxUNjc9vwSOy8H9ie3bALGReEDH3zr/596pF8czKjd3AK6WnuwWDVOlCmp0rlwmC6SFsepyRZnBbImWnt8sOL100+BNY/GZacSqzR6MjvjPtXs+yXgrYP/TbDcRPr7ZexhZDW0YSlowDS7EYvTAf7jBNVwj4ItEGcKUPW+88U0UVKtg2sqqp+SCOY9Xf/5IptcYEGs7uWO8ToOYVRSEC2y5MtaBF3zhrYUt2vlCgw3O8p2Tf7wdsBzd/L26Tiw9LZhawkNg9JH0eLNuZkdy7Xv5eJPnS+cmjT1kOIckNlIuKdEXsG11IpOlSzmQXlxhvtjhYjtO/gD64geZNVqotmsjU8f29bbhXfecZenbTjcPPTJ6B+IzHuTf9NQnIn8r0+Kh4ZVuEp3umeS4h5g34JGET6aSJJ9m18kHpqDvzG4sfdoastiqESaAeAH8fYF+HY+3tCecf6S2ghdX/HqcP9CcL1ZRr33zdW3iGsC5nmMdrbnTX7z9R2zQg1dAxGJPF1FXFMwX67RFp/oKq/nmDrg7n3pn4Px36u3Ac35xhtf8WxauwvfinckvfGLfcy9OP0RK9CWWAZ/QlwDC4xP8CeJfpn56dxtX//reHiLsEO6DUMtof/p2OeeSIX7ItpZEf6IWE/eP76Ap8C/fXqdGxz/egy9+chy6ZHUGeZVHXmkqDaCKNRTfbsCRtcmLT1WYXreMumL38SUYIZ8bFqIZcz4kcr3RTTjuriwqxbaD8+VRIXWQHWwyLcvENdJuXpOtt9Pl7u+0IRyhTxgLGO41BQikDPpkdhNHKDEOXwJuLqmgoAtX/T5fnJWexxc8pdUhjrZ+pKS/SSnWCvVqL6576uIj90oCeOdv57dEPx968MLBwiPLyQaZLcsNi7VEHAwVxX8Y/V00L2k4viGBFIichFhYqCy7hBuGIeDuVjNSl2D9itlEVd4aS4jxzWWmUyKLI5DARyJjB9HFt/Bsal4Qs2V04FWeOaZm/QiYtHCrGXMNjFXXMQ/f0RP5wXfXWtwrCb63NqTf/LZ27cQtr4cFFuqV/d5az0drSb/nLcgr5t7atRa3Ax6Ur1l67H8LCHohv1d9rLqfauXJe+fnzG5mP93BCgEPeZq/eeHMZsdnr91xovhML2Eia9NN2Oxlv454D27n2LC8zawB5narNGTD41hgMP5MFCLyQjsIWULKw3Wf193ebJHQbbYmQSR+6xnBZkyCa2jFHAs8xzcJPhY8Wsh/nA+VbR9YYP5iP/sV6bdEerN+bUKxvW+X3VUqC5UbKQu+cIRduZN7jodUL6mBzwT8yYfsja/wpTVX+eyN3z35wLJ4NbdG2kNagr6Xr77d3HtgUZCMQfGT/e/2bu4JuCDAo7D5+P0vgpD6OMtbpaveLlcpfy+rWHVKuFC+8v1ypepdWdnKmee7a+OPN6WQScqUhOO1u2sTTjSnksjKVOQJIBlHfP/ISMajyx79vVcbax6d/n/F4+2JomNM1/3VgMeLAYf9TR2HF18sBi81+f1LYOHG5OvOntKy7p5DNcOdvWVlXb2a4MVqrpHJ5BqrF6t5ZpbzAN/AJNA3hQIwITd/kbEVYMWfpCJABc+rVS5VQi5YVxkakW0Z3ybyOSjCqyAThZ2Vcj4buDu9pJRXLONnhG9PJmUSZrlsA35zK0jKNfa5m+d0Ju9s9x1c6+axbm3BDJoHUCoDGxCGEj1Jg2JZy3hQzC8wHxTrke4MuuiGZAZdGALeoIsCZPSNVE7LIBnUbmvEbFtVeiZ7WDafemQHKx4+wFrnNF5F+CosZep3/1YM/fsAt1Kux4TOlO4Bcbx1VGkuaivtmLLL4rRW28/hVYIlhsBbmG5W+GB4pNSg2UROZAN3h5dMlKZMYyiRdm2ZJikppTEhPUdKxSFlnE7I7iZl0uUCeUUcA7DCT4Pl/B3hByHlmvbczc4KyzvbfZZr3UKhqVswg9zgR5qH96yv+PyNWYDGVzOvWxUPHciA6hRrxV7mCKoe4O76WsrW0CxTBVnNtmBGhH2qEjMpq6OgkmwjFNsawPIwKKkPsD5BbohjArJh59sBL07sBxG/TGGWNinCS4Fl7RXhLyJfwJZMiYL/5uVd+UrIH77U3V6aK98Ox5TvB2bezlP4tn+noi04tQ000Q8SxQjFdqNQ6aAEhAYDrGsnUWd92ADCzWqwuUk0ujQrZf+eAxitBm1QiVmqBaAgSiOWsvUvOxT5sCjW5cPZ/lm+oVctFejDtk4FuW1zxl4b0aZcsA+UivX+fn4dh4uZuoJ7Gdg7kB4XM53GSMpFW+xl+1FUdd+1+6w6KOUdbMGp/I3cVVw1yh4pFyfiRFGXDOmBk2IYijVkooRlImMs5fcIXwEpk6SUcUTKFS3l/MEdco/wKCx185WMFDQiZ9woeFvFiA9ulr8Fp/JahspULHs8CrLIpqOLTBGVR+d06tmQXfDSJped0UXGYw28jDdK8XjFdhp4mQyH9AB3w9dSpooaVDG8AqC8lOaIlvQivMpKhNl2+6LStAue43MW6i5x5UvpKvgSToKzXfhdmjXVhz+C/sO62jdcVVwQJ/IhwjdAJkqepZwOpRZvqyrL+BLZq+OlTCosl0XAb64GSblSZYfOyg6+lB0KPuim7Z8pibpvLfrUuz9RkniBGRLGsogtWCwLGatXKX+r9pWjyr+fUjlZ7qkXcOotjFTd/TZqHYmN3SyXUBXf1YDqLFVXJG8AKbfllFy7yrKLbkqQGHLw2mApDaEXdsZL4ReQkN2J5fyMwnpT4Xhiiy/BqeVJdU6jP1jOXf3FBXoUhYlHQIeHrgDiRNShVHdndUpGB4hNGwaj95GXcztipvuO8HcoxAx0SjEo5jcoHXBB0RORx6m3YyZu16SBWBUToA5mitRbofQMAHsVs+NvCerQaHS1zP2JVPJUXXf/5khvJKpDsjL3F0g/Bjrtc9DqKVe0peWbgOdQAAdYKq0D62pESz+ux/A2ZG5AQiliLTKZkdUtEDjbVNgqNezes2sF4EDmVuG1bt5oaUBuddTCwdqBX0wpnFGY1tHW/Kbe1o4sYpEMuh78rS29JgQUc6RCvG6x6VDrMmIFOhtfJVTItz63XY+E36lb+SHQLY9A1tfKEaH88TPAPYN3tAYUu9sYttrjT9RFVcCXBjf9LHGgtTj+W8wW/+ytHnAdf6hTWevc0lLoPOhR2xI8mN27sx/HFEhvW4trMyy2LUgvtavbQQxk960hHNul+/7qbmnN9tt1Xwfqv3+gxwbO3BSO0K2y6E+knnPXbdRAhqpMz5Rzpb+DL7iRht4KCIv5MUceaG5FwnG28HhlCbk0v7P+6QejzmYllgbAgZLMRoEO3OCg77dMjSszp9s9XsHwmzMQU6vMhdhSZ0she3zJWOtMBFFvchS8Pfpb3xhWe2sOaF2ziJxbXiN6jmyInroLi8HOOLrWq1y/O/XRDNZSZ+K70qwlw8FBTY/ybMBhLRNsBgQMM0kuDl/GoZtclf9WoK91by6zilY1MTZ1yBQVsMc6wuVcOavU9yocSifzHs6zZ31LrUFh5t8Ba/d6kG1Z9CdSzWvouonaL6Mu7vP4GeYY/xQM228EjB2iaVw2jHLr7S/Qm1j41lh7uq3EgyATV8AUfBHeZjREhjZzYcG/DGTqKUCwfxri+tpO/gQYzxCltZn0x0auyUumusR3c+nwsLolc6VJgnzNbnl4+a4y9BSqsE5kjt+QkLwv9V9yIp/r5KSPoJRj9CNUbHO5VndiMvxWUl27AzP6pTGM32ybAWPha842eXxO3f7HJy00xaIiatYsAtR96IHhVSyBc3KhMYRV89vFtwqKmVasGgekB6fGI3P7ZepikGYzjCIM4x+FMOZTsxEIetpxflMYY7KPO367Gu6fHZIgFCNVmcIpwCYZmgLD4MWHixZVEom4pXhxykgROeoElRzP2yRrMydXvdg5pevb8I8Zx2sUF5wtZGmdhcPPNNOdcQY8xMXwCF8ko7oeWRY1B0YPgCrUXsAu4I2jwAe3EF/KTMZhL+5rFK5Romge2fkJcxQvxvmwr17gXa1vpVVzyAjYTNT353H8kocmrkMHmD03SN81FUfs+QOtyWbPP39ZeRaMnOtfHYDhgLDjYGCIqJEv075Blxf8uAvdnz+aXaoVmRJksHpze4cgrA9ZfP5f0r6HGwL+dxfDascqMuyWRcEKjyyPrDVhNvhYMVvcR2aHAw+1vdcXOlidcsQJY9bhWuCeKstfX5NtB4SmHruAHz6xHKMGB5rsFOhjG56ci+JmmkUpnSlkwD7LKNm5UayKHVBOMN50UniI6kDD/0bXCAsuN5MuHyNJS4DB3M81SJQx7NgRun2qGr/Sln8QbyAag/J++ppB7Z+8QW9kER+PCnP3/VGQYLoYnDON1i/IZS8+fXy8zLsIuc+C+wOklZm86ffcxXRLtvnORbS76eyk3LY7dGcbTFdvHsdY+KFd2kMMBhrdDIYCj2SS4TBBxK8acA1a6oPDnFEnXcQZp7mNZlYXsZjSfZWfg/W5iIU8+rh1NFMtTjTct8cisvpofuBS5zj6m3lImHD3wz2wr+wilvKKkRjNtpaj6cBRGl3gH1d5bLSF4uyHvknwugjTc3xCJhQSNTt38HJWAFUAbeJp3r5WXkymisV4XopD+BPzn2rYtGaXmPh/+Gefsf/c5riIC3mQdX8R8zwkW4nrWqCGetfSIEZUbLwP7y4RJr45xE7p31JuKMmxYh63/A5vgyX4k69nCRwkBFlUaZCz736mxMWmP2V/MD3bB5hq1rQAfgwPcTE8wgPEg3KRxADTm4ccAVwC3vg38aE4uB2CHxVH+46duZjNZbOiMpD4PcqHldevAP3YOoVvZ2AlzJct5cnjx3UpJfPKHasz/Y9mOZ+568u0tc3KmYssJ+/yIKV5ZUsura2/MDq3kS70b8cgZfeZw0hfM41tfVbOZL6iAveKv0EsfmPGe4w4DlokJ5XHcHBwOLSM7uHj52C+uzCbWIMnW/Xqz1duFOvgFbQABNULD2iplMBhXcFNIdLw9Ld9TkYYKMwF9AJzboQDm4N2NpKBelxKR3bnnSMXPUfmfwDFZeBfeo4y/zz2KnkiSzTJ0i8W0oobxYxToh8q46ZFWFGbAI8yDa7V82HBWv1SDz63QutBxcfA56AZoK9RIA5Uf2cOc1qXmxI5TPkTFdQoqZ2rtvv/VBFhptmIWGQuuhLL1rJXQObKPTreOa9UAmfWAA7gAKDTtgDoA+3Jlqkgn4ppEy8K2tgIoW0KgAbas1HRgnR0TFwZkjNwTF2X+RCZE64kZFeYY6wXC+Mhq7t6rCCCpGhyohYsCkdBQYPkRL74dQGOMEVf7HBlzKSeUW1XgP5MuSKeKef2QHvxIN/O9uiLdZol6RBH5nb6YoEZTs8olWcS+I2XwR0ux6krC93w7J6JbQpdrvprWPBuO/ei/ky5Avvl3IyLDxAoGrxNeu8jhnkgE3DUb/P1JWArauAdH9K0LPwP6Lklt1xS/WVdwDQoCDGQOQfPZGQlAcdJeyWERSWntMwkz1x664Hv8APLQyUO2ry4OXQc50DhSC8bPWHDEwbeoM6dyg9EOz0vR8A7eNJ61CFx5JOSjHJwx1Ut/zKJbst0R5LIKaKqnyOrvLuYZnFZx8ph4PPTo3a6xg7qyZz2rxJcj6d/POfFWuh0VVIw4nBoHNXDIbzNMNXrQn1X/e+VmMthBtAgX5odK1SIxRlbPVy/JnrL40Vu5XFveMVrqdPRdIjeFLyPRC8KkD4gfl/D33CR0fam4JIkelDwlMJDIJZdmCp+8O7aeZ7C7EPKfMTOChaC4nhqlfnEfCy7grs7/wvun5hkHuwkuUnOJZyfWtB1fNPq453vgZVbpn0enfkS2QkLFN6dw8E1q4z+pgFDX/a4IMRGdacGgZ4UDg8cVjOCMps7zhCCWmd2V7Wl0zVOE528IfWsO3Q+Q6zTebZYY3tc44jBLdJK8gl97ZNGaPuWTBnjItCfzRjdXJLYIeUJpJNl5JPaD4WAxMZNJ5OFnNw8oGL45BmlU4hR7I1bTiuSXKbdccjojvgYvdHRU4wgl7nk5JnRl9WVyA2Pn26qAXLLMePG26zu4IaTpx5JbV7Gaa8cvKgfSRy8aC7SK48tMeVLPTmJQ15Xcx4cVZ2+jtNZhttBc1qlLzfKEo7QY+K4UyIJnbR1fPXC19a/ftLp3PXW2PHW2O3k3iY3IHkO6tweSqvfuxVDmezSxDk4F0/DM/BMPGt89uDSsrqXagktgkHBe72DBJ4Apy8xEhzyZLlXzHs2EV+fM9dn/OBBN4sD9Eyp5HJyrSn/WeWEBJJB1/7fXNk1ebhDDahgGaxyV9rZalAgjgUOdTy7/8+m9h8CeoqeeJYaNx88+PfBI2VFT3vaz/ww/CyY/3nEi5N/WTgDQyMe/WX/piebQnAyzf5J5xDFa+4DqZ6sl5D2c+hMfBrgJi9ORtUgjuDKiALsdd5eZ1735q72UkYae03w/ieC4GSnuPpu757DXvrf+vPzpsaKfMhi29L+bKjox7AlVW+uCfamczX1/U/mAzZZ/am7HbFPv0UGv4qCafxkzGofVr0DYPeCwXQK4avmzAEw57DYneI0wuvV5i1Yh3rjEKZ/HD2Yhl6L0ImgRYsUQZNSorVbnSkgA4J1swZUeAKHQRYwc37k69UGJjtSzwr2A5Bga0nR8adFpxPaOwtCTz8gkBcmI2qUGFLrFdSTovUFTcZT0XByfN5htvR0B0TMq1+gS4y8oX8rt1MAB7wBRY0AvLgFWXhjGa5YvHTG06LRiaNZQidipjprO15wWIxOdvfFamScFcS1yVzSAdD9gxad7r5aFuRqFLcEOyckR0+H9G41okp651MYsx1tyahto1ryot8k1s7iiNpsZhIsu3uQCYoWkycOxVTBo6Y5cZiWTwyspJhWE/08XXRqfbCViLzFnLHctR8utHpJmvh6XDQMhq4ot6R0vYoFk1r//63jBwacj0TM5IzVKaDa65WJa2RLAszEp90U9CZNlk5GkbHSluPneHnTfMc5p1fVs0W5NtJheWzKYJW4Ao4Aa82jPI5L3KogDkbr3WT1BGKQqsSmdCgvAGYCky0u7QwFY8C8ux95h9UYjhspZ4WEAYAIfoPafPJYxTamOcBVSzG8Q73FMlJ/ihjZDaN4SZvk5ekUawTS1ATDSSXVMnTZqrYZ080Rh4XvpEfAWcmzU0Gga0nRGUuLTie8dxbABOwB7Z1cBTGYJewRZPnkTJNDH2cr0to3hZeTC//bKCUHxHohmKh69Nf61qGcm2MwBN7cil5KLO4XDikdmwLewJWEOJ2oJm2M0RtTQQE0a2MN81nvNz8gGJ+nU9gL6nu5OmmpHZGnJjGqVr0iuGOgd00/ofhCwXSKkJl4CThJpNyx+wo1QcNhhTkgd6/qx4vrRnYWV+iAaskb6EQ08xK0w00c88XC9MjSgNAC6fhHp5KsG6+06oBJtM7ZqwfrKQjOP9zxg1ea4h11jLLDkC06PhDf8TMC+UNKoVY9nYgtMwKF9MjBmsyB3Q//GVpMMsX7Pxx3diLMZNLP5gqtcvY626fsdPuRsyxLMNcr2RaN1InN2oDbrQfegPffiFQgXkxG1NbJsPXlTz/cJGCXOuqfxdH1t2+kVhE1FQKK3p1Uk4dQOmNiyWfr6VH1qvcmou6Dtu5OLmYf2X0s61c/W8YfHhbg6QJ2mrJmFcq02jZx/cAQNyyKg3O7ekAJu6nIMERcYuSOYrmKpMkCocN+irxEpJ96cx2DMAfQy5Knc1kYDwudAUGv6uexujWID/uGLwChnxQSzmYfrq3ECdSlLE0EbTiIO0FdO/SdWNSi4eYhxANhx5c65TtCt0ivnxx5ZTi4IiNGa/nGXzQLbc+HAUxLQcc/2kntq38smpYbEDh4nioow/BztvdWPbyRY5AUMGezB6uGJFNcV0dR2x6NqqHQkLC1eguzRjB+sxv+qUX+guu/qoMlUF+qeWsNXR0x5mkTSM0spqpsz+iAoFf1y1HdO+CiCq3yplfLik39Hk+Wm8uexR6IiDVrYpR0x+onYlEmLPnxOvrvjC/71MdhwsmqRlxn3GxNVscV55avhdqk+rf6eG+lFzXSSEbXLGDxMHMqmJOsR9pKVD1Ts2/eulFzK8UY4dgzs4AGvnT/Y9IVUcxCY4hlbZGMYvevCGPZvb0xe/ZAaclq/5fg+DLCHWGZDQg8ubVDrSqwF0L1EwvpuztUShu9faD2VSqk4VC/DC6FwJXvG8O0nMSXbAJiI+7hFXIh2B0O2Of6iT9trk9mVnhv7He+nkgt7kGeesbZryiVZYFanbp02kqr2hwV3qc3oYFR3SE71BI50x2OAlEPKkKfyDDNBR7St59lUzEGMdEDxtVKUAR5ibPF9YFvm6BWzEYfTaK+ou9T29iH6CbeAWOShAz79AhhY/747CTd8bxx+ESI1q//qGHDhpTbbxJmVArUWCvZkVf6PmpZHyNNTxaY7gfK63bRZ67UZ7p+Szx83KC/QIwtPT4Dcnzpko712hZh1aAAvmj5vKITRVGJUTlbX67YZ2BOIG0K6qXT0nIEpjReNtWIX/cpBCN2T21BVXEr3T1hlJ2iazuvZ4IqXUQ7k8WuFEO3wVolnmARXsKx6rFeTo4i0fmUjY6VvBb9vZ17XcMZCPV1H8tG5Ynvvr4uJNzFd1nMwvs8ZwknHZO/9h3NGlKz6PobW6M+FsMwarb23KXBu7C/GntaH3WYP1fBTKdtPKQaBZoWHGZ2zT89klDz7giLFKMxylLQ4XjECDKuZhItL4YVW01WIDtW9Nbf5fHn7QxpW1pp99saDGQ2OZs7mvl0DhtpZLU6s8/aC4/yzgg1RsLtRhqtP4ccVn4mTYftZ/W2sOyfT2x8egLZquqINnKLvLpBeLz8itNRWUzVgBFr+nDUgAf/zZ0veC6pSK62SHWRaRwFYD08haewXj/NDTUlNb6V5xzybU0HquqB0mPl9aL2zwdSEr0K4UguBxLSBNRSbiNTSBOIa3J0UFrXqxGyOVEsLhfq0wqljWxdVv4S6DzadYIoSydn6GM7oTRGC0VZruURoyTSkJRHTVihGmapyC9jGfbkTiGRYjAwlLLVoaljlYc9aioYOSASXfg6carz3W5uIhVfCei1s5RjryECqcLxpTPAn5IPiFikl5R7o1JDGyN6p2qMuU/2irZqoljPS6kf4kWIFVLpjnnZbJ+MqZ0U8LWVEl02JVO/6hcQs2t1uFPhTnXkDGLVvPE7MgQ5ONkwUhAn61WkU0erMbKIMCV42uuztcPuO1a8TYGFpjlcOg2q2yBhinlbsRJ1M1RMSSgoxe/Qj3jXF96UEZdELaxPPDOpPvhqP/fpiKJ3DtbCVjFvF7fstNQnb6qbHw8aZxfOLdGnPdVcDBnKFUz2L6RpALTAMqJP6xOdajpc6VSE2UTtFLUqVE11norW6ZPepBLDjy2pyfiXaWwtkm5veBI1Wv10KmsDljriDfMpJkMv51Q1sm4Y0mhiZ0lPyBrjjWXEqFafvA+tI8zL2xGzV+w8n7JocCXfFDYOigVaaqwaPFWYVm6sFsBtrmhfW0EFgVgupdnMkL28uig6KIZnoMzbgY0g1rdG9qyaPQQydvSsigzu+1BhtnJAUukjqJz5OLpJx2Ri0jHrOJOLOBsbpWRU4f7Q2hdtGSfW+uzNGs6qLVEys16cZYT1OsxWRmFKcN/Rl2dztoz4zM6WgUOUAWQyoFt2n/xKUawcNstxhq9TlSWxwxkNWG3vv5dad4jPP41k/f7w4PWlElN7x9vRQSRmQWD/FiGxMSeNzHpn+ucuBMuc9elshJ8b6s8G8KcadXmmk9HDKcOkpwS8dFh7RmG0Grl3ZKV7PKSZ5nQneUkodb8UpVJ6yE/MW8LNLMQ95iNTUo8G4x68nhNlOReR7l3ASuvmPNwAP2/KPA4xxNhlfrv5ezo6vGtsPaeSmXcRXlZYsIqke93lbfXflNVP9/S453kbYYpsqVC+F3/Skej65Yk7QIcd40bexXQVeObp6PHOwhsRFbe0pvOD5xWjR8Cr8XHwwrwXrc258on0NZlez6TveCGW8+BSkv3VO7MY7nVcAVdArHRuhbs8bNHm96m3SrQq6kB3UE+aAPpEumi0Yo/h2rkERwwbQTV1kkwTYYioLEo7VE7m4POdh5y9n8pKBc87cda6HNC6WJQIatf1CzIT/WJ0nZfTrysQh7FWKZJ2oDDF2+sYe4+IadbP4v8lF4BpGGBh0V8ijpaRp1/XOFiRuiusLGSv+wpUnDapWk1q1TWNiKkdc7CWZa1pkq39nx+5zd8DH8fDIC6EXdwN/4iO9bEj6uNk6mZgfiqRki2NItWlcqyHFVzkKq+HQ2jIDa0RNiijZTwee2vj0uqLpdRyXaoHtVnBypZSbTE6pSqrdmWoTC0aEmpFl0W0rfAYGe9xetyczvMy/fP/5vB8ve5cfat6OXpHq53t9s7o8m7r0f7cLfNOesglbvawJ7zmq6beccS0i4Ek94RTTFdyUp2uQKZzKjfyjg1wRFnHMBe4zwYx8tS3yXV1qa6cq10ztULbdETPunZcirkemx07FrsYeycOGhcdlxkHj1PGPR13Ox4dnxRfEI+NZ8Yr4q3x3vie+Mn4+fhvEgwTjkESIfkQDIQBkUPMkAZIN2QCMgc5lhiXmJ2ITKQkihNvJ2kkbUv6Mmk7OTw5ITk32Zi8M/mHFF7KeMoLKf0psykbqWtS41JzUufTNqYlpxWl4dLYaco0W9qzaX/SptLW0sPTU9Ox6cx0Rbo13Zt+Kv3E+I+9cR8N4Y9cdGIVqRCiBpjImGMbV8BhEBWMEQaFAv70prnkS+mUT3XipLlLAtupkGVF0RA11ZP4UmuokCgVtByfHnntN/NdYYtDLrpvf35fRmVK5mVp9uVc8VYwIlj870qNFMsEKt/b/tk9N3BFDVJT6tp9z15W19SrKlUfaTu1jsPfYwa/x44jBJ+F3h5qnHJPI6fZkBH2CfPhxjntXHpuOZ+IOEWekR0XLnIhchA9FB26arGgWDTWccu6abG/AiayDFmL/Ab1CLUNdQZ1HZ2MLkRj0Uy0HG1Ge9BdZZvKksryyk5hkjH5GByGhVFgLJgzWAyWia3CurBvYkEdXhwV14TrxX1efqV8uvy18lG8Op6M34b/lHCcQCKICHsIVwjPE9aJEGI5kUWsIrqIj0i5pCXSRdJzpL8VNyuaKgYrjlTcI0uQneRh8mHyJ5RjFCTFSOmgjFNmKFcoz1PYlAPqRmoytZCKpbKoCloOrZrWTOun3aB9o+3TMfQyOpMup1vojfQe+iR9mf4Ow4YxxTjEeJnpzXQzB5hfMwdYHKwElorVxjrHusn6zOpnw9ix7Gz2LPswJ40zxvmG85cLcKVcI3eUe5/7lTvE4+Gl817gg5kav5s/wZ/nB/mv8z8JOIIEQZ4AI2AKTILLQmCeJmwS9go/Fv4QEUQm0fviBHGv+LDEIrkneSmFS8OkndL3ZP6yOtkp2TXZa7KfcmE5QW6U++Un5Zfk38oHFFyKBcX7Sj0lTDmrXFReUN6pHFFZWkmqfFL5T4VTZauIqkpVg6pLNakOUUeqU9SD6sfqbxqoZr3mY62tdlgb1H5XZVNFqZrXJetsurf0nnqhXqev1b9t0DZoDDbDtOEj40ij03jUeM74s0nFRDTxTRpTtanZdMN03fTE9MmMzJHmFHOBGWNmmGVmk7ne3GnebN5tPmI+Z75hvm5+av5o/mtBWyCWPAvaQrNILAZLraXdMmKZthy2nLPctHRbflohtz2tCuug9Snr7zZ7217bLbumvcV+wyFwZDtQDqpD6jA7PI5ux7hjzrFYnVwNrW6s7qk+VX3VaXF6XRGudFe/qweqo2xwQ90EN5+STMmg5FJKKQ2UDsow5QhlgXKV8oTygfI/dRf1BQ1Fo9J0mRvrDmZqMy9m3qYn0dn0UrqM/pb+LyOekcqgM3IZYsZhxnvGF8YQk8vkb0htaGV2MnXMG8w3zK9Zosa8xu6symz9bL7s6Gx59svsTyxxE4tVzJKxLrHusQPZ0Wwl+yD7Mgf44DgnOB8fK+SDFrELRmEi5mED/4wlWIk1hEr+IXqys9CCA82gCEqhItqg/9LdRYv2LIchGYWJWJsFLGffs1b2HxtnGqZjL5lpyZIgj8kXCmJRVhwrSeU7s0T0hLeEL4RfRIyIvyenB91D6xGKUCKqKE9ULmoQaUTvRd8LIcy8N78X23uscFK8p48pRor/kXBLNki2SXwkYRKEhCjJloglckmHZFRyUnJV8lTyvki8HB7/CxQcEIAcdEIWVEEbDIMCC3AG7oANR5CHOreGm+G+84f4f/O7PM4zfEH4jUilaOnrEpU2Jb+UlnipIkM58k9+LQtyVfmO0q08UaCi4E5UMY01XIW5WIVdyOMsnsSbaOER4sjiI1gGkrG1s6ZWk9uEm76Qj8mNcp88I1+EY1VWeXLzhaAj8AVU8M2QcsgyFBzKDy1PFtb72RSU1FJqL/WQBkijpVgpTZonLZM2SLuko9IT0kvSB9I30m8pSJmFzF7mLvOXwWUYGVXGk5XK6mWdshHZcdll2SPZ77K/Uznl6+XOci95iBwhT5Vny0XyGrk6uMk++eS3wnn5zTrbOnbdQt0vBU+hqN9Qz6q/0+DdEN4Q35DWwGqQNMga2hreNx5olDf+pvRQ1ihfN4U0tTf9yOJo3tDcoNqs2qHyU0WpUKp09Uq1hXqLeqd6vxquxqkZaqG6ssW8xbrFpWVfS3hLckt6C6vlcsvjVtdWQeuD1ldteW0lbbVtqrafBdaaFM2P86OnGG7Pt2HMYDIEDBnDkjglFsUtb6MfQg/v0Lv2nqupkaAyfWVc79yz3R6oPXC+81iX+cGag1e7LQ5t6Vl5xH8Ef4R+xHXEe2R3b0fvYO+ZI9+P6hylHjUedR596eifRZ5FarFgEbPIWqxcdCy2LA70y/rb+0cGHI4dHhgduH1s6tjqcbfj3uNnBn8uhSxtGWobOjQ0O3ThhPiJuhPPnpQ9WXaSeXLv8Jdl9PKVQxeWh5Znl5eXkW+lP99j+cfLLVpf+Uf9Wv+H8m62B/bsS/ud9VfBC7n/0A/yVx4YmvnL8OuFn8ibxfN0EwTnLvJt6Tm/KyhFsbTKiq3ox8NHSRS5i9wkFjkkMcKSKiUo9EGjtEw7aYbqrH5UHze3tF1aXRvRUPfTP6W/Np4w9gzc4I26SZq7+QnL3frbobZi32rP2f8ZzQ62kzWxPsazafaVqazuoMZpPI2aMW/sPNoV3ozpIGCncHoaD5gyptaazPUljb7/zW8tey0RS8nS/WosDovPIltaFOzEbnbeunWHdetPGHzr54AkvoXYgCgIyBMUgMWVoiG0q+657P/F4+Pv5UGqwBUHXPHjbwdzL6MA5wNFO+5+4FDv3ve4b+x4sQOWQpAWKtzORjyqQElmwEF2LOfzg8yjOf8BfFH5pOfTdfDc/9AJpDrI0UO1/6F1Wz+/id396KWVr7LPZt6igJM7WEGvLgd/O4bAl2DUbeyP92x4ebhPuHVvTZmXcBs8pmQ6tZonqwnCscsD5kxJD8h3bjXa0rs6bZLBg07DitCUyoo9MC3Oqei6OvF8oxRjgwrO0x1FddWG7OWb8uy7QM5z2KJlvCXPJ3pb7bRJwbeYmMXocKD9atJs+wmNa5TL91rD+RZEeQiyqn5vkFgkbLyYUKS++z9h3KzGfPaNaypyMDZpzZ2PU0QIetWqAZsMZnBjzv4i2F6MRIgipDWV+8hBFJSbJTad/jMo/XizMlB5p2v16g92bsoTOChGzbQPZ2slzoKcTgDhWoQgIjFCjtZrQ8VP/pP/D1bz8NWOjxmAq43MbrwqgH/csXtzU3Np47UUKD4oR/Hffp9JMbnvP5bbXjy3FszZeP498A8QTacgaeQGUQu6UnG7s1EuT/PdD0xw5GVR5b/evQa1f6Vbf+IN5x4RY37r/ZaGDCDvPIMVn+r9IvyEDVVfnITVR88bi7U57YXKxGe+Oegg5O36tgdbv/SfgxHYw3vvvB3s2cXv4NNQbAVGdZ8FIViGN/0HZG7J3PrGk0BAlBCF37n8a0A62qPzYP/JMAAKXQrZWUbMc6NokEulqTchl86pQMu5wm6IdA0OcEQ3sA9++h5YMHRRz00nnRNO+op5mdBn5Bv0LrGdXiP20RfkcfprcbS5gZk7B/rRYJRU8QGX/Ru3JR+ASiBJmu590LLgTonmNYmDUJkeTb8JeZedqsAiW9X3SrUZ5weey7Quk4yecDiWyK0k+SH2iI26jrffNQWaxTwTUuHErbc5zWqGkn8zzg/+5SVmOUlhsOW2D0ddiwSnuq7Wirz9rhiYe1XbnSrU7v6ArOYnLGrRkiT40zJhKcSybriHSJajg+HFsLMmeRL5fMniTLBlD3soXe3K2w9g60uOStzBE3dIq3oSbkz56HQ6EaMXOHXSWw/z9oOiPNyr/RnwHKe7/BvujFd94M1YBzU3z3Tr39CsSS5DPyAaPQeVxybloB8KCqsNULpegd93p9Mfj0I7axoegM6H+qvj0I6c+oNQXO+ehnblPKrAUe34E+TJCVgK1XXgTojJMRdBDe2/HwoRfH16BdZgI4uGFGm8sHVte1/0O9qfVfI6H18t61Nd0Sg/Zcy4nqAvLb1ZNoyGIwQ6AZyA3Rd4nGfHc/upqxjpcDhRfKThacpluSD03UlYJsfLtdhMl5XPCovqd8t35K/byl0b9KWYwoZEIX+dqJZcS53x9YVhHzoEzsH+zDzGE7YLo5QQq5Qqk7Sib/gBZceJa1EzuSdVtyEvmWE9xQIpXL/0/t7WjtIf7T+u43W+EzDrw0VCr27Ve7fpxxb2sKaxaChh57bc7ddel5dDld2GDuPa+B50pH5LufNF6zpodEHVqmZshsvCipVlvS/6dqTb7U+tU59jlTbECYVZ/aPx5e74utwgrbODabA/t6zlGf+MynhTtZaeZZz6u+X0hVmLs9b2dkOzDhrQC54I+fMbPntIbQoB+LZyxm2bV34yumssdGkEbcYeqq05m+ArcEFNcxOYlk+/xWtSGv1+r7erDI6alA+WDdPRljn06KMXF/v19mTIR03wnKCTs+k7HMvC5uE2xQ0PrESumQEXSIRzwUon6RaPKh0IqtHptGEIx+9l9xGtC7fHp5uVHVwR/k8eCHiTJctJoYmzJcS8geDHggcWElOT1F7qUYm7Gr4E52SoTGC6lN3nMSgNLo4ka7vAXpV41H3FEJmljjx5fpEAW1zET00SbF7nTyV/5lnNb+qbox3+vmXTxW1jDu0BwiUcU9pClSGIyypxcJu8WewShky3YIDd/kHYUF8MVkfMAfTiecSsqR2FI2ohuuBaVgvwnfmr8hGAXAxwJOPWKokCLSc9CnG3dF5DDBBPsGY1pfRTOUT46hHIM2u12C4zlf7g0IL0ZIaImYpfV5YLJa4CC8BA5jwt9s6F353qL78hVzAyGHuDbz1I+mDk+9+LA5aiiPWfXu8iZA14eRRwx2E6AnIrrR9U2ddvr+BV0ahd64omupEHaYNspF5QTKvZWtjf2zA9PVJ0ruaGylKhRFVCr0lytoijm5lbwj188ysY5ZU+FFsPhv0Q8l+6JKSevic9hGzCyxUwx0EmgAIk526xR2qrJq+oXrYAq6tlwWV9kCkdOnv3IoJAY4pMryHTIBjSc+L1QQCpKqSDK7M9WJb10GDUUUtk2anp8MIs2043hvcfSLyMMq+P7VO7t/B+koGnH0PYOFzTpHd8kGc7tWOXipwABDh7xIQhV4weCL39ZfW16eEHK4MDxmXIr99DP8gRyMng7gr0obRineaeQmEMctht+8MG/KKAgAME/cBbwDvfgwSXvoPNrdg7dbfv/4sNGhTXwuh8Mwv+Iz68xQBIaEYi2tO6UfIz8c/evHTp/OdkxJ/vgVnwkXsEeOCAsTS6wMNO3hnGQPTkM80XH+ONFtr9krYZ5AgeeP6bm0yP447rWxxRR/4Z4C34qwPfJVPqGxee49UvGFsJVti14I0vK9abuTViLTD39V8fvAPWslyFtMcaLRmk08ScxZnOZi9p7AnCfEy4IpOFO3Wn5+UEL4CtOoZQg8E3ee0Q4fbyKnXiedfmRqnO0pJaz7u2syr1pD3HEhik1pO1pItQMA1LQmjLbt7wqty4vQjXdpfxdRRQsK73A/vGUzWAaIawyadvY60IE1UmN5/oiUSunlulFzUIL55P/2BsCwbS4BUOd/qfcmaRZuVfsxTGNSc4j0xHi/QxBS45U2nf7yGq7oYOqmgtCxFE/qoMYXJE13EGPH1CLKSL5Vy6IBz0QbO28HSBHKSzopPeZ8YIfUqO0l+Ij+lpoh+mxxo/1aPPKCBeg1a4QnCC9Z+jUhL0VyIhZ1nqKFkGUCe+Lz2TsOgCQKzaE5Pwg8WWYIwloSIpKarTz7XHtGORX/feCsF0MCzH+tzcqp9xgAcFXw7BAdI7CoPx8/opJQstNXjge7X7Ovde/oPnJyHOTUD3Sq56vpBwBMhUp1uAFjeNj+Hfa7RqS8wrEyFdoxOU42Hq88cS587fK/ZUSEGZNihr9o+Y8DUKkTmbYDkInSUmGRg/o1EYWJvsnKJ860jif+HPhuS9Npn2mi/q9U65cVIuB6wVClOjVP9HZkZ6R8fw28hm1l0dYaA22kEgUFN/6ilVYH5wYDR6R0mrHKqBOU50+JRUPc2Ogh9gat9XRdee25PPg29/AcZOqSMAoTAHVwzid2sg2kTLxiUMihPI09JweJoiNRoVeY19WbcJiTWv1gSvDVpAw+035uImwTocgHWJAfY8RSlV17ZuLUNntjo53xyM3hGEqYWqIwsrSF45WdtOZd4HqAwKu9f03PX7rswbwOnHouSktSG9F/6qbtZ6Sa30+ZxK8uRm7EcvqcfBu5ezdXxA3yUOlueLX0cC93+0eQGs2mED6CPJxo5tZwqaDREhF0FgubYg9izT+PQRMY+CJfe60SgIy0nAoDaHOwH4EfXS+B7UEGu8eyXI5TPhq9M3d/veyd0WOo22WxFKuZwLy8RCni6ChDoQxCynemJzOEhDtw7hLwsf1Ga1oJdjPu16XTJ7TF1lKjXNTv/1q5GLwGFWKsm+9vaZ6bIfPpfRVRTo7wwRddWXiN8ouvypMoWoUb/LeGMj5Pefpqhs9/ke52a14B3VPKPRG78mLh/yXfiTDTdyvNKzp3dffnnveude8k3+Y2jbAD3imppK+q2m2JFMhUNBZX/HDhzUd4HqZr9/N3IpBRGQe2v1ytVOGpXbFaJVEj6hmlp4vl2ec8vIGfYt7jfC41wAh1HboBBqz/0lhXqMF/ox78kTMrxx+5ub+B3X7w05pk/r0ae3f5fcGD/HE19sffFQeujWl/HN1w+qzqkzh3xxQCeBcESwUC5O5ntcNCbNEoJeLxczP+8m5fqG/QQ1SNzvSmu7i4sHuUyeeB/fpssKafGe941blDbSKwiJ1WVxzOX6rfPqdHNHpvxm+VHq5OJi3FZppFI4NStgY2+xUrjPUxKGyzetknR20H1iyqjRPG8ACLJw+qmwEoW0o9AAUFwj/X7HxXEcvquuD6xu7ZL1ErfIu3kIqyEYoeUKilgAfOsQvCCpa8yq+W+VQ6NQ0XYaksx+O3C9IBziBjaQ3Q/F0BTSVBJ3s0allfKJYqwvK/absu8FZw1NU7M3C0+jJy4sxKyVRiqdpGKJMOmt+mOgIg6Xrm/D8ht64bRe/0wB5Q3MC6gRUiw15+U6GQi4tX/wu8YfFMWeQSFvRiO3qTvMvPDGg+0EyI5HFxALKFCoS7w2iLJIMGnuyNBfmwrXcbOpTzfdleUHQdlDz42HLQASWtNtGFlw69tsK7IgBcVlc/8+rqVWS0XcC63+/bEzc9S87uaNUhJuvz6YkggTxxqJmHkRpsPgBCKoXFa62eat6uXN5b2gvMn8d7ORxz/G69ibalwpG7CSUs9fE75u6+LG5Bo7u1E6Rz5YjBanrw4TzTShWnCIhc0kaZm3tqEvlEH0YBpggz5l5xi2usmZd0vE8xYdmpFHt+V4PgbGL52j58VMZq2lAB4R4g5mO+pQVfnXuO4flbz9n3wJST4/iSfH9lzff9t7yKMXYmDDCRu/qOMd/tjbcMFrfMXEyI7rb/3uU+Tp24NyzFQ4V+jjLxY0xO7UcvsXFh7u02+9uGcSWaDDM+tAueTjX3gD9/b97EIsYGjJaUNjXU7bH967/OegcOBfANpjEAFb4O966NuHAiTdtzdhYoYw6Y0vIUtV6Xkd7QK49u1kH8gyC/Z/uwxb/K8vBinE2D3CfX6w4lgCklbYFrw8HySW+87c/QGw2KnqVAok4xXgKle8SoDT8WKwyU2tmJsaviKadXIUD4ri32msyocBVIeqgUkxMUvyo0vkBXTJnCL0OXmC/lqEEVykkYftJ1NDFhtr5b+Um9TlPkt3TgZAqmL8Yc06mQ0SqRP3aTaFzG1t3nJwclLVQCLzIngdgzAjyJOJD5ef3B28ODsWYqoB9n3m0ZwtoXSwX1F+psl962vNwNcAfmCXDatM2+qeeInlo++inBfpaxNmRNqhF4pDMLp9SFx/YdlxBgg9CenPiXIOhUX5FaWuPDZbKzzToLhJns+jj+QsM0rNcvH8z7WVWmgjvAAcAI2uyljNev3Yqyy3gXK2uvsfpaI8UKVYGmoT/8CVnosXAA5gKfiSadcok+8tFjcIehgjWf/sE5jNebgFgtHdHyZngZexGN0up9535o+OF3nmU4UHn5kFDoRI4KZtAwldfHsS1eZ+3KdRoKDYe5G/7jdPu96xs0GwgaZ818rF646xpxnLqulEeav/d0Nlnn46+Bu9D6wQv7Dwklfpvq/Z9dEfZXiDMGS/nXDjYpG0A9wwVcDxHaGfG/kEx7Ylhky5H/nQROI+/GjxaXQF0OCRtc8ulwZfm8RaMkv40AYCKv+N6W/wuwchYGeCwIXvjj7Qd5x9zZiKUcbWMyP3U9D/5k9QJJrJb7ADUAUQdkAJIvrlJzWx/0UV7/AzIGdAffY7rg8dBN7DJuqxizreaVZoNvqtQVPuc/jFO15HXv5komlIrO04ciwRGOXlJLgDoN+RAwCAybGJDkhaxUgB88GDfNsm8vkzYBy0cZgm/t895HMnGWSEx5hzlePwyRgaFlm32XskAag6WXL6MPLgSXqZYNeKM6eRf13fxQi7gWbSFmXPYnM5m+2/4yMjbW3gOOj4baEzLcvwGeOq0AeN9RSaxWCSLNdqgCWgUydLU7v0cioCfNBftt+OXvSI0W5mhqbBkbbcNw6y7dPKNhVZkIlGG0ASmSb5b5QOYIAGcBdwz8jVffxarQoUNrZ8gbd9Yncx8Z1Xbhzp/KtKxRt4wvxBGu5DErATIuL1FWRw6kXQAPPunn1917u29xUK128QBS78X38D6Bol/oKPybyZsu9aKdeufOt97Gb+33o9T+0p63ud8CQAHRRMwXRBzb63yDvesz3O89cNV8/81g44AnDCg9QD2ANmAsncXmnJKHyAyngb2CJ50jmXwMhSofjyaTbPpBJ0XPaloHPAHl/y+SRCrLsBiNcWHGDZD3cUfQ1r/86GL+AaIH9czSIf+/OFm7dJruEPhSOy70mti2y7ryu+eMwpuIOtpAv2pWDhMUK28gt1SqxPwRcQY/+dyj6agHZVfU1LWDvkNl18a8YmVrOGBzkJXkgSrMP4V//+8U35jj8ch8+ADvg48I7DUQjclm35q3/4AFiAMuDp4W476QYgkzkgiVGzYJHZMEguhBzgKd/6PU7KpROZuC/sk7shUvvIvJdRbEG1ssg2pIVChXV01x6pTxF97M9dgcccnBDNp8Oa7LbdrNtVqbKTAey9ZruXX5/nJ2AogjLrx6rRPYi5zA/eCoOmpxHzJ5MTkJW1Sxf+WkuAxZeeR9zX02lkGViW4wJ7uPHRlX24knAQgAH8BZMmMDLIX3GhNazOYU1J7mkEJ4CBlDTaH350pw0KSMULNoPRPxiHB77QSuUn58pH6QoCrqrndBa6By7qBwKn28VTSN1x5p5thg8cfwPFoxuNgd3Pb599qiyTDJ8xzsJ7qKhGKyaOOT4RPI8axJfu3/QHe9MP/T07tJchofbnKLCl2FMYfc4X2DFsmkrQbEgNRfXwrtru0jR3x0k2j/AyCYd7YUyLZiM1PwkAzf6Hr2/WMOBT+7fCVTR/fOQDsydOScNQJs2tNzhEAkKVxY2qefCdn+eDLFzu44LarUw5Q0PycYqePDUPm2VFwGhaP2Lt0xXLFEEhxTGksNHbRj8PACvU5OjOO84reUq9KMiNbf0nOg2IYIQxfrKs7q3onu8BVPg1BjoJ+MJpRAT23xETLOSIPo6FIFhJgWSfck7XzjiPnFGb0DGqZ40jZwvSifML1r483bj94nft9qk5QnjxJ6k5UnjxS/PNNC7QB7SjnI4mQAoKkDCYyCX91ic0eksKe3mwDU1FGM4NwBbIyseJukI2CdMhv1lpYnomu4pBc7IXha1XXetlRau+WbRXRyNbUSXtx2kNWXuy39N47+l8q+fbCF6Cz10cA0gZWd5gJRUMyTsvlXXFs19uN3RuXOzcVDckNzdu56aaVu41QGhdUBNhZI1EsaGqMBHXBzU6W957cky0Lss7++C2/MRrbAPtssF3M0YH1TG5mYF8YZ82/pp7Ssfn0aPaGglBFSKACQ0h3Zkfa0L3dUyfINIX4X0vAERtXh/bvrRYqYTc+xVxMnJFU9i/XRKj64rD1lvYonisSP651KVNdpayHhfC181SXN+cWXl5rv9FyXqs2KTTHVccYWwcNmakAE0QaMvx/lw22O4ewdetr3pTk1J4oUTeHQz4waudAIBh1QxExJvJ1+LJp5YVROxSrHwOh6FooHk8uVhFM1bLlPbpJgJVU/vssyYwXpNqarWMCYX/nh4+tqa2md2kjID2aTWck/1azasA+ct0mi7US/hVaZlUhPCkeJkLKxeq42ssO7N+/0UNMzMVannHVweE4Tc58bkc068xGE0mEVeysQaFg8PDr+LqBZPjiFaql/+ranZFwnkmJ2g8WnlKEvr1RvvywPfexVFTweEcXx0Yhd+UqZqc4sk1c9Va7fd5lo01TOqok885D4KHBvcIK4QOvYEwNekByKz4S3o/QJaymADRSazKFwD0FDIcpodMX370QTmb/mF2E/oluZ9+LtL0q7LcfM32oLoVCahLHISJ7lisg8Lgt3NpMxrbEeQSLTjBUU679ltNyUhNO+d+Ol0oBwv71uEM3K9eqmu99lqkJC+ow1xzE3VrNUlbN6rRcYSpSOMCTXC5nv/FfExR8yf24iCJ/pckFzUxafgnUIc7krZe9Mw7fDE5YrNCFOjzsuGfZCLC4LC7tGCqJ/JgZP7ufrYfnbyXC9KfRWNzTYZOyXtaCxtutzpOkxqHWRoPu8KOoNbm9cj1yME7w/brb4ZBP+0oVlx2fcWz2FmqkPSteL7FgpnMQQtLKPWIklLJHMA2Xty5mlRBzncktCsJ+/UWCwwJO+vaHKCgNYh4sReGS7m4gpSMpkk5/P4Q7Z6VO+aJl/tM6aWTrIOBUYQDOM6cuzxxWabE92xPuzvVWu7UhQhqvILdetu2CZfM0IgI9c5yK+WGf/1rE463XBUZqHeSr7dmxlmJXTf2SK77fFqbX9KQugr0WUOYXwtS7lD3l/dOfJ3jXhgwaYMifsneWhmTFcERL3b9IzhUUhDYbCuOgzaCCkWoK17f5c2Cwp9JaCwJ+9FF5eX3Z9iR6ibuYXHUq9S1lEGznGFVnZOqROzx+IyMQNMkq9ROJqp1sJe2DeTEtMaViewj02/eudhYW63HMW0ch5U6mD+ZaeXqK2uNxcww8Pp1E44biwVrQf8VAbMMHiyOGdTll5eR2YheEH+h+8z+sy/1RaMi7BaXxFxX9Mca/7pH4r0xdRsO/Oh9Pf3/mD01pwVQGMjqIqGfC8zvrQI98Q3j3rAS7avVG76kDtfeKtITXzm+2qtM+/I/iA1jQa2Kay98oysP4D6U0GwmC7DMZHVuvLXAvBmP6ocakGaasKjLL06tqLviKTKXvMaK95Llmk19qAI+gzsz8tRURueJr+25KGPcHj4UaXaUx8Sy+5jIonap1FbxSoZPVY8vgulw34z0TjknfQYzJnG3ctrnNU0XcTgOrYneexfct0YyXUCG21veu/6VsPrcGvgK9kDylfFesIw1lLBeUggnm23FEa648AcLyY/aYV5Bc8vq0XkwFfa7icPjM/6lXoSmFnYC8zwFhNfPe+Ob5S+3BudLDbYNWxqlSdz3CY0dnfSeGA1YVkqu2gbyqX5K86GSoWe8ce0TKPGkD+K9tnb8H0N+2myUj4/BEATKatFldEn/v5JQanF0i0hLSyf8T7fG7J4Kn1cLpVLnMNz++IIvhb4q7sE3brAdcxE9Tve9df1Ka8KYzeLTmO+KvnD1N5rc0zF1/cKbPG07eQogYKybvDh6e2PX/sv1QagoZglcc3OB4Ysgkkzr0Ucvb8i3iT9k/tPogV/Q1xgGXCpBI+ZdVpILiOIDqDs6d20/eQXOq7qxnt37lFIvhDdWnLCLHbPYRWLf3rcnf/0/wd/uLoGLRDXYHYbiyJnoMVR7mlgZ3SGAi0Usq6AIJp9tCSehRCKaqr300tHFGwos3g8/NdX1Per/KAoMIGiAzJBnNxA4rJrtc+V3E1egauW+8Jf7Al0QLjY/buVDc46rRN7etyP9i2cjv95VBBtWhVmmKJYyJtM7VfEZ3vncaQvgVgvHKtmaCwaO+PD95tXmZcmq+9c6AzZYA6s+eR4AnWKLEii1a55QIS9l8k+ur1eyspkaSFjdDTezhWpl/9vgNSTmEuOL1udpnv9xmz6vj58TiWSRdyPpcihbQJzD6XRctGvfaKDwhg34Gi43EKy141OyFkBHW1wUwvUOlo0d1Gjk1XQgqdRyUlURqhxfqR25pJ+GDN1E2171FvkB3Jjjwv1SLFTq9349uNDpW7WIgywSo2d3IrpyjzNQbVhAWqramb7M4mezmrDlwCVgLLZniQr5/CFKswmlRRKq5ZPWztieTQW098qkQqzHaCsNZCKpVHUoW60X4DRNrSQhhH5pzA7pSU6SdtB6nqSorxX6ljx/A41H9qJZEXFyG/NS2w9JHesVw9/bgI/hCgNSrqUlJXG0TWliJZadtZO4M7xrKh2JMapSaClCQ+IlKTRjM0JGb6En3ghnbjVHKQ3aoimmu1T6tXV1pPppUHISbo+lqKhIoXpNqwyBfNtu8UO/Ju55bwqcge015NMRPBKjpKbikcRaZf9l486pvWC8UCjGWJdO4VqII8JFG94QB/Vad0fWfvJvvb8mTG5du/TKXysAVlorV33yUQA9tjCB+oasjzVYYB9Q1p7QVhuwieUEOYb2um2dPtD81tM+vKW4yQFyqqJmmes/iJAnl9b1lXsiDhmLGME8mAJ5oJxwOhxvDYDEzklw4Ib6UG+qEocefixRUUjHjOqlshGjeVjiMO4V+yMMKw+/a7Kmro9xE/dGLmso5LKPh5fGA1F6GCoFHHBsm/YwQ4EHgpGhTcjD2hv3D7xl+vQqi6E4I090tyHQM2PblXdzFZvlycv6bkitXW31NnmodBgWvgzQihpUtC38ZN557ZtEMrgn9N7fPvnOuk2QqiD0wZXiQE0PnJ5R77rxoXeHUpngvN9Ry7GZmbOvNwTRb0PHXoD6x5nyzHBG6J9Awd8Av5eeQSonuXhEklesa+fBkOoqgHXzJlw7ZwZBxy2CIanFakxyw7KGZG9THikdbnu34dDxViETiz6jtrZs+TrUESMclxb+BjihWrKgQgtQMV52P1opAdfAfmqrc/83Sjfi2xNDWfQBNXl96dwi7qjA24Eb4LU1Vo+IsYHpjDR7H5p2gcLluQNRGtHdbfg7dQ2UreecizzuxqimQPXYE9C91nohXkG36QuSbHbstn0hfQDjfv+qut2NZsbty3ROan0omFrvZD4un/HOO9ldu0c4r3tRFPODBKhd799vi5Db7VWi7DfB2ZortLXX299lsNWzFWvblp6xmNlpcexRV2179g3UEnc2mQz7Q3Va7iyvPKsFx1rT3T5rmg9JXndpW8utSRPsDzFQusSvr4rqNO8VNHaoqlLi5xxoQuvKdL1uhs16Xabr2XmDaKuq+v/+OqrGnFouy35TFZ90jr1hBkBjuou2pvl20esqbhbcQgzkAlmwNaE/j97wPYEfv6ysEwUe7PZy/IG8M34yOA4gZeT9mz5mAkYkKzP4Q6+OG8+eotCHpCf6bycsLD/I8vhipmyDfSVuQHrZ+l/CUg+YgD0bWK7AYn4zvTKNObe32jfX8wiVkAV05IaRv4//mlDFvrVXnPlrVUCE1GYRPC4rHfE6qkCiPyNDBDiiEzBB0Jm4HQz9oHcTnfRJg1PRO6RO7zCjBaR3mqkzeo/spN8WRHMv64BjzkgMecEYfzRoZBla3B8+C0sU+7oikYpjEPf9udLVNRTgIg4HbRAPgrmtBcu2a9lAQJardnWwzae1BaXzZS+dFqy/gH24ETyulZYglORKaG0f2GsTXAAM14PLbDNLHwPLtMGFhXI6k+SGLGCS79By6xgSd9QfzfBdD1ZyDJGwq7yh3R+FviySMbS9LO/x3XdTGIjvJi5+N1+Pso2GUGH1NUS2SJtm9139gjaQzJdV2fTU+1a7cV2w6UbnD0ugwe7ZbLQm4YwoKoU65RHrDCHV9VIjdNc9KpeJh00qu2frh1+WcskAelpWDR48jVacxEcZc3F10O810gwxZWuwRtddRS7QF+eLqnRS9WblTlSrioq+5CWEq7mWR5bit101glHQ7HKQVPDiMy0jUow+grEmII0cmG37zsh/hmTC4n3hrWdSi/aKdU1gV2RelnLu9WjFfVaMJCaO5uaiwF8EqkdQfQqL/PQXS0AiqswgQf3pHtAEBDsgOA2EjELCUKB3hxkQ3MX4fLDih8F01P4G/B6ZNHspo9zVgJecE+dq/ekzpSf3AysfaCrc+P1vbTR+Y0AGCoB0EZkeCLXurBZfP3TEs6ZSfzGt+/T3twt76M3OEfEI1bG2PbUv+V0mdbkVEKQg/j21Qo34KPF/pTUT24SleyTH3OJB/BkDq6fxPjWHxOX336a7AYGJSvDSwbf6sF3TPiCHAMj4wbofrDoALgMZh/2/PtU3oT9Qhex/R8Q2TTcx+tzN9Pf7mKApGIPwCiKygfARtz5wuouhb8Qb8UDl/pRsidYMZ7WBMbM+Ff2WvJSuFDz9Z+luRpkFP8p4WIC65/nxT/zwj+Uv3zwsdvTggB48CR+kCnDIRIQCHLGa4AO5P7ni+icu5NfPLQLRAjJvAKGuF4sNkpKUUUHqZz/246cKv/WVHyp6wAFeQOUNKBncY+FtNV4fof3/2b71lfev/78EhGmGlQNoZ6KmpGQwmCrt//7uXLyveALsshnECnDeBxkjIi+l/vJzM83femSgCx84AxbJlwIoOBvOocat1e8iX/1Iw/VA+k0DsAoQg6GoAil1N6rOZkYF7//Z0fN1oEpZ3wfCN8u/8wIdgCX0HAfM4eaQDak6OVLLmWhQ8J8g6v3L2wYLSVhzabrjJUuPR50+7nL6+B37+DNb4+Z81h67YB5DXvQX3qaNxqWlZ8icP4uO+1z81NRTnVcjt7+/7SDm/ThQUmpQ91afSfEzTF1SmEeFP5cwTvqTU080X40dOLIFuT8F5EWtA2Imlo4I2wRZmTe/0TztC7dmr/rk7QBKs5kJuG/mYFd+zDyY30nVJDuguQVqI/Bp5nOBcUPEowzb//qk2+qtmUp5PB5yWdHYtJz5gbETQW5f7Tch0q17YKKR9e6M7uOGppjyxVlVomCAEThurLyDeO5+mOBpBSdE70Reachumt+7Df6hY1oRQx3fX7NQbipkTcg5PB702P00yb+7prIlfo/FRxd0l0CUomk/Hh4cHY19cT0B1VzyrJAcakc0ppX6WaLscZkkrl4H43Cue9FzgXjFZDZbRQquFSbfcqUL5UZ3wXAEHuuEBt5jU6aS0RxTJjCjS5gDpApSrTuKrHR9BGbnTWBmQt/368OD6Vb/Czz5I1wDBViHxax5efiPCUjeAzY2Qn8zeVTKszAXTb2rdB/7v/m1+jsMGf9Gcmsxm9LUgY7Ru1d6/RJ+K3wRqEq+kH2TNx6R10pEozRqAR1ILIbeGJKUhBYrOomLhQYhOSQ0pDHgjxXVdFAyG1taLTRM5cbtBsl4ygS5Xx64ts4/xXJNQEJiA7tBM9YHe7Qnu7WmrPFVrFVPtHnM8Cx1iW9qEBqlrMXc3WuPPFD6sNkKDgoWnRdB9s60sfWGeDPUERUbDY8kN6EwQXpbPhHNre+4c5s9ODyvq8me3O23UfNsbq8QiKbRCTUbc2dhKqb6qGFDMD1dfkij3x5mVjWk3DQBMtVMLRpE+awc9izkoiRrutLVkIHnJmpOhwVX63CZB7F6AC6N92IeDwSbHPHHA1b7U9OgEWYW14jRJ+Cs2V7zS3kc4ltlB86UNWioqLexZi+gjfGipNa/ddKWZsdk9lTiZU3P5w+U/5N8Tk1vg/1cbrZawTkEbLOarzWyb9ucQ91iMMzzrdE3N48gbhsJY+DfW/Cx0QstgLqjq8DDzdIo4324t/bokEO6BBz0mKs6ra/0+VXG1nhY8DczGwwazREBuyzWfPgMNaO0RDGykn3nFe+zygjrRs0xsU0Rqc3z6fDpowh8/YInyCQ04ff92v2G5m8Opx0n8Igi9SvNXFMQdk2Iz1uxUum6sTwti2eYFzqRfDvxSDRdaQBY00uVCREJkQfgLtzDHWJOpJ2HRsd5s9I7EI5EcD1EJnVHsplsKzvjyOPe6wbacMSXcJwZckp9qjiKlTK4PxRDrz7zeXUvXF4b7MKhkP872WpGw3cEnxJHyYxp6R4hHjd8SWIyicSHvDqrw0ISpeFYJITEcgFAqqo51mpOrnqVNM7dxMmk/tzxaDKRVMRYAmPJsDdo2BvmiOBQ1bMXog5DgTlL0PlC3Q62NUWiUg5/mSFeNYmWSg1FxGgnHzcllnXReeWXMbe1iIJOMPXAiVeTxcq+C+a2N/rtK/aXP2jomHH4MCew0GS0i1qjpTdBuF9rnjaxQR4q6yltwE977KTSKYRkxR8I96ssRcr7InKjP5tdzZdbkttkoP2rz59FbfIw5OZyviOosxU/9Ww+ly+ihmNaPbfYoBomi/M4kERFKzG/RaWiMPpxl/UgCt7DgUGUatJbVBtOYJPteNJ4wTZnXERBk6kD/kiKTMsTnRbvtq4kwvtKP8kXd2P4WC3zgcC1/JrDaU20WAH39Ny/qpHirnm00xFXxfImSJLOiS3Gn2VRlpWjC9OuPbgxoAqnSOd5vR5M61ii1zVfd7kdQjPBorRdPA4xBwLgrWf9IBgZdYxV5NBw1O8UirAAGpCEtZDA79Vf8wEjkINlZYggZFwIjB2kzGnUdH3M1vYxSVf5sSDDUJRa+6HXyzB49ClJjyyelXPXYczfXa3XM9ACdzbawqKqJIlinonMqlo9eafOhERPWpKizMugj2yD6Vw+ssEpMPHDBH5/IPhhocCYjftgltnr8zPfsL/QQContST43MZnj4prvCbFXHgRxd8GFmjTkUGc6w8u4u2eJj4FnBZtlGrAGC4d6mC1AZL/bnn5T5d+OX0BZcsL488tADPIGq9T50Fn0PiAvEi0O6jq1iX7eHBeuNUB6fu49Cko3PNVfS0nvJztRqE4QgabBKyJgwF7McQyvL3GOX0CTH+A6eCEAxQ+ETjO9jeRiOdtCo9a69hzuLO5qWOSzDWu00eR6U/mEot8wqov8/sBdEfHiWHCzKWt1Rc6Oo4cmlp/IABaL0oCSgJkKHeKOWDv82xPwxVY/3C/eQwtgK8Q+94b6pAU8AcDToP1TUe6w/oUK0C+4w80/NBE5yTbDmrh8Ux3AJlI2pijOYFjy1e8jhKKu48Wcslobj6YUVveYPBIioC5ZMS95DEIC0QPCtXZhs9m0vJIxGNEjmyunxV5OJyrDUVZCDIM+67WNXjs+nf6C77+j2bfPbjkA+PUlva1bXt79uHStePzBzfKm/XG1pVxER2096WopCIWButVO8kwo3M9uz50HvL+aIid8Af2xa8V1doIolrojKei7MeGLvRkMu3xYqmSQfuJ0/ORSH67KprrbJIRpR5aENJx/v5gpJosd3aw3wIeQVyUz5g4IaCQtpvC7PbwAjjDMa/LQkD0mVRTO+01G0ooXPfSoRxO0gAWBpaIbBbAxhxjyKYEqjJuaP9Z5FzRkTaISMFtRVZG05Z2/4jC5c2rHo8dTOZWTwWDNwki49KD87c8LleQb2E3QzMUarI6pm3bVjeXDAYCUaqoI8EdTWhemwFDAVHcsizJ2WAollb6ne28kaJp6I0AHTxHdBBKdzrVNk43o+kCKKkpSyEztsYkzTGzEbJmxrqzWUnc9gNVPCgdTCHOCE+I/SIluK1YYa4c+dzUfoRQFcDm624iyPX7nyBzsJGKACnc+mcad8/uljr9UUbiOU4tT0R9dtt7wdOoPmmaDq1MZEHpJ9DNdsNDhAgM6S0Fjv29z4kxGte+0WYkg1Df6iK6kDmaulc3OU0E76Cn/32vxj16G9J0NpzqZDwehpwOZ1KhH7KygYcDeHqourhYsHkN6VkFgMsk0AWBYzqV1VHItqD/WFyYaDY6GI/PThGwhZPhX+l99WOQZ5tOfJpY18804KPmU/NPOnBoniTNGhojwa+eoJNf6oAADAE9qYSXoxeNpvDOGks4HtDIuZGA9sliLwqThvh2dsEIfHytmQbD6RUZ7wjN4SihGd/FIt/erbweLz+zgl9XDZW93Pv+VqdLHgNfFATf3ERqayn10VrtQtsX3+IiGIOPf+YQAREAZWRmxKtXG9YIgU8TxWTycA9FEnQIGwGD4KlQSnHXUkQ0s4lEozdfcgxLQx8c+dqFbY1dqfQiGAGcH7nD9uuh541SAgftw//Zpzn1Ymbolte4nCGxND5UR2IU0xeLJ1OioUfqsmF7SXoXPv6hHJb0zPbZiiTjYAzQ4XQTbZHI1bqJCXDh3GC71WciSN7pej9ZIOg6hFIl6IAV8Sf7rr1PvTaF6gNb/iho14m3fWJQP/3IvS+CzXhh46Xn+G3/gek86ANs5Q177z1yG0jt9FkQcL7+Il8xSJf7b6HNdk83PKOmUQNcq2CuOuHZmkOHmioQ/iS+G9858g6/QGfNM3R4RraBztg6fywCd6ja/8EHA3408YRve99BAPfn2DkoK7YzS2LSJiTEthN8pZfA7VOqVZwus7yKOoxMINqRFhxKchGsvutpVa5LFak3xwNbWRQ/vg4AE/24ECwUHy1UI0QZE/BxOWVdmle9vtj7Ucr5Gol2TUtgBMYWg32+VE7KE1BNk6HEK2w343RcuIVn6aGJEXj4soFC0vELIsLG0uZ2QWWJxKkymy80WbctU9XG0pv8luEm2gyeBS2oe4SYORJBm5jeZes6QqmDxVgMO6PkTJJPqmygSwCltm686TiaagHNLq2kLMuXqo88EnjSrwf1qS5mYuYhTdabcRqF54TVBtBUhps/3LoVWC6rqA9G8EgYmfpsdQ77m2oNaFqPtHNPQrQQ7n7tVTdvOZEOVGVcAmq+EckuBXkIIjckt+c2gwlINCUVc1WZ3m3zwwLgo9XGs5/iohGQxuVaTFh+3IMEWEE9xyEEUTGVui0U8GFmZKtO4+XokXxfcR39HjMwxDwWz0oVIcSyzyAVIjSveppRwRVqfhrvo8mHoMZmpF8DwzCHuVnunRZkmHW0tek+Yzo7PyV57EjjiwM+jgqlo7+g5zR20SdwGI/eX7gfGcAN4iNGGxAwCO4CbV/kX8+5Uum9JfUzJcuiTm60Z/RZeSmHAtuVNF0Qlf+TxECn+HizUju6H9VjBIJsaszlAp35PIw+nAc7RXHBcdI61wnIL/rHDDOW1/pVJoeNi7Zkzz59hiQBXzRIcxuG8P1HR1J2XXBv4dj4O/f0Xh0YhQdKPs0I2sHJfQUa3O4g07G9E3SztbJazLYBWLA7I+GN8kJ1HI9aUI5XvR4KHIGzfl43IEkltsxxywmtxUanNm5ZAQ2pjvUDS5vVJYXXoHtgxYrFs/ErjiGxaGPtlDrZ2mWyO6B+cQG1gh91eT2oGksNfkh3DMXa49hV4zUjYBSng3SxL9JGw7n0TdHumHdLGPBr7HEntykOSQArVGX+3LzbHeUtF6yU0apYraraj7sQvkCujkhdANcTt/HoKDbHkWQk0OCfY5Sep02oHkzQMIhM8p4VNnMTL/ABCP1vZuwf7QR6XBAIUxPKuiKSADv+qhMVQPWx26hzE2Ug9GTruhm/7UkeEKspbKNlznTJYMQ4w1ZhM0qeOj9z1rox9WHERpJsH4dBmwAoxEDnoxdZ6UvHiPAEjCEBU7q+I01XFCIgWXENwRcrDL1y51l43XMAffHJNb8HTQWJsJdlFpJ5ltIxr3FdqwQgjLh1j2cAqTjOKlkBLskOfC7dkf+q/535xdiFgRL8xokbWml02uzbIPByflGWJ879ELo1uwW9YCKRvxklf//1dJ5jSCIZDQbUB6NJgmS4fBqIZHrgzguHWPZQCIW/GLsw+BR+I2KdeHQuCwJL1cUsXWiYj8JmXYUMIyOjUbfcp2UlZp033S/O/UykbjNd46VytVyo05ST+SmX4KriyrZ4NBqL+K7itvPTYCxUGNLv3IuCcXBN0l0VvTVy9lprSGt2XJpVXlOMExwt4Qn1+Tm/u6HosvnN1z2hQQyU/VZX7Hsu2X9xLr2kFQonXCWqFl5dg28BCjZik0wJqUh8Z8A71mj3gj0ldBGX5wvRsH3q9sTbqKq8Go5b54cIE5899oluKPBmOHrOvOCep3JMD5K0IdiHDiOEAE5iavslXSLGJqDb/oPEb753nM6AHoUe/5s1t+Grdmc+hJwScgh2ssTzSHGGnaHbfTsNnmZa3+3Zsw89i84zzuiT/P034MS8vlqfvGVC8d8NAaYddbsXFvYOiCF6/jpzUR4EVuoU53lT3ZPPs5ciG90O0ralLlUVF7LZ1oxupww4Y35/Kyaq5q8FiBw60hGI2mHQ63ZIXi+VdBabtsbEUnlVFQWWFSTlFNJBoiBdRyF+tzJIGJgmygM9yM7Fvnpkymbb6z7OkRLohkLBCeBoXTMkR/pzdrnsm/9wcL5HgIiKSBLrfj0fBAKd2rQBr9ygyQSX27Sfmww1O6wWFuRNMtUwiOfm+4UwQk6eX/ReXO4Gy9sR3LMh1SMIF67W9+eGze8olS/tBWIkgAIwRouPjBESkkya7W+Hi/7I3W/bv2jY785j4XX8jTtygq9eQpcgwB0t9AAfpO8vbYn7xuEn3yznOfL3bp9PjU44nvcqKB6M2jc9/nhdTTf5FXtAbJqr8P6uOOyDTt2ROonrOQNU268Vq1EfhxqUZo52VW2tEds7xlqhISXc6YhBqmgqgtUoZaXolF5BrMgt9K1+jecDAZ/vl+bY43WmCo2kzPu5Qh/9rcjeeHr3CqigNbNdhRVPhTTWWMrlfturBjQa9MUbQI7G1hDdatTrLZ7KR7zpDCzXdMVrNC0rc5LY4euqjk+XIgpj5QiFSwgdgUChP5Zks3dcfcDnlB7l8mnrm+X1vkeqvuZuRi7zQ0icHYjV8oWQz+0OP2uQqzZ/qP0XBw2HRrAOucyELTQlaLEpqbH0j/TztygmI94x6Adw+DHRR4QHQskI3VkwJA7XmYbzSJ3KGcvg2HHZgiiyssQkFy8y7cVDuxeEA/1eNeD3Jd8dlNeUftiYWqA4Tn+J+10L9OFaqtGpmaPuCIJnn+AXy7dIsAnWgX+STK9ZGlCe5rDFWfFq4Cf66LGZH3f8d8DC3QpUOXOJiNx5c0cF7IHECM7hWm4owbZcezT6QaPe0csXtuJuZ37ZEDFkuktNHg/rUyQhLzHuCtSiprRt26JFZh3Vt0TLLeITNo6emyJBBBLjBGSJ6kQHy4PnLwwa3cBOI5pWuijQW/OkjPu1Kvag63lk+Th7IRg/Bgjo6CPiAnqvWZ8dvctMEHqSmI4LREDwnKVbphH4DvuDgIjKSrWyNrJoU6sVS7WfLwVOzcRf7NeMqIOf3qy4BpZek0Xl3oih84KNckaQf9h0H5sMv9yPN2bK3dJcq5qwD1wqtZTeVqlUTDEioTAJwj0QCyavXDYg3+oas+QtOJgBaKzBcwUHeJFf5r6WdEclG+rKFS05yWMorpSUOQ+fbvmtvaR5cnvWJIo6z2XDv/tLRvmeU4BKlH5UzLd+0T1fd8e2rRAzqfRcc16AgAxMQ2tisYXQbswFwlDOMmJF2TVcYbOAOMOsIhc25JSqCVWTC11WIfca142mvqCwjAIfz/4ICwi/GP+8cQnGKjn4BmyEiUJZKVaq9UaXtWYlJ5ZU1/GpqN29c/aeeqvtbT7PcpLWsmaLtCpZjv3WHHlsynpUXAkDka45O+fKkqpWDaXHqFaLGb6QWJjoROIT3BJnvvWGEYfbRk6OobFSh2l30PuZZ0CveD0X0VZXDKGmgEdfYKNGyDS+6K7AXpo6OYVdGCibFI8hT0krAx6l1PYlz2LTU/k8ZbNn3nWRhQoFNIssQMXjDO80j5bIYa5jfrV+Vl2tJsLeDDeSrGHBOIQ9UBCTObxc0aCEXs7wT/jOTgdfgtioBAa26XzFpqgF03n0B+lT0+EeaLKKtw/eBWq2lHa9XirIi5lBjRsz3mt8ZdAq6XkKK1zsCg9ypXsW11fVgTCLW+xaDWJc7HsJjTmmEKKlmtjLeSxgSgIyXu5Iqs505JEylmYKuICwrVy3+3gazkvgLAdS6wTnFmot3tAB5GA2J8jZKukfMtwNG7l/K9wQZQmY4RCtb3fRACgahOildbjuEtn5rlMZ2QoGsQ0HqcS/rU3sgPbeBQXPItE3AuhlrqZSZ6vaA7+aNZtvlKJ4yClRhCqQ6RSRUnf30cPV4PZ8wGoFwwiRtFQ2FNSgw5MN5ywtguFkKJFyXp5Bp96S+aXji8lDBZ+cpcwFE2U+HzNOR3LGiMdAZPzJGrkjkoTnxGAWgCpqFc+/f3Ss7jym3l3X2Slvcy+ojIKDz4IV2b762LsTs+OiKDdF+Tg50/DXOaSbqvE/hnNCQLdIJ0OUXdc0178kqFjCCtW3jgPeW4/NbLcBSztU0U4SRxWene9HqoaP4fkQEMJc+U4vU+vczgsPFkhGeBTeudb1PKLvskCkHvjnbK/5JL7oP3L0/94GiGEf8Y/fr488efADIH0uFoAAG470Vk1BWrOqxMM+VqxU+iNl0poQVOI7xFBcKhIMHW2gpVLc5rrkve7lMaq1jtSaUuxicqdxQwXyYHd9eorQ8n/stbsdqzKBrmXGcXY02oEmTCazbFlK8iHIR8bbop/epnwOvZzc6gvnCIkrYtptoWaj8w5niLjoiZTXuIOlzWqwYxeSs/r4lvAq8n60A87C3PodYpzekua877CmFdA1q2czkWWbGgXvA+fLwhs9K0e9yynj1Qdip+q7B0ZEd1txATpOGmsOdrpkEmD90QToQO2pCfaI6ayATkdFhzYwYD9f2EIYeGMcJr8ahysPKFqsJ5HuK/ggtLRa5XiiGRKr/6a8XgFYAikiLYjnAOQQ0qD+iTm/+UnppP/9vgtXLGyYIKCNxWIfjAAITQD3F0HSgPPsrfzlKnZWN7uJUcAPx6bFUvn0tEBuLxHI0NmKAWEocfGZrbZ52ef1+QJOz4pXoVhyDxjAwyIhAjbKgdq3fZfRO8aB3WdXfTf/bwm5Dkv41FAx3xWPU9T9AYCvU2a14kHrGXKaZRaU/yn067ZuEhQ92gz+HNaxhsOCaN5Kr7zzcE39JJuwLqVjK6sLCxGZbMndNmQZRYAf0zR45QcfQ9wz36wsOewfeahUrFX/MKScdC1xIw1KKunWgL6omTpyqafRMRoyarGGRPTM4N+uA6EnhfIEUMu9i55w/LhiZGTEmt9PYr8B/wFjRVl7To1KzKXdo2SobD5v2jooYmecjrJthNNYUAR2fPv9A49BdpGr94+0VDJbPTC20JxBQwEwK5b6g3KjCVvHwxcdqKTSqsXuq38JE1yuiHaP1jx1YhMQuoxAHIQUMG26UNS4YWZ6SpZeck+5thM1PA/L9hX4RT16E1SM7rxuAqQ000g8lBgUjcfQblA26PcelyTJcN9zhziQXGrb5bRoS5NkqpRUMolrwY9Xu6V7HaeUwYfbeQXApULuVHHnurkhYL8o8kgqwxaSy71ep/NWcQh2NWQ2UCDkFPl27r3aA5kksLldcEI5O6UsxnzeUMtybdLs8NO+X1u2BpTuMItjl+HsDGAA6fAjzICFH37mqBto3A9Af9PcKAd2gPDQkVSaNI+J3ONvFZbjvNfexhoZDhU5z4w38VsjFyYS50XEMM4m5DroBfoj6zkV9no0RUNBID0OpYGrDUIh8vyw9YqsnUNGLXjGUS0SuoCRuNY0gnNPXhKZH4JWWV5KKKjSKFcB0Y9btFcghheiNyjoqtAm5yfzX30HAcsBgttOxmr/ZTOACp+51dXNOJngFhFpx43soHatdjhXkHFDO42Kz0QNUEv11okp2trqozajICYxQ07XCO/f9i6/HkOawxJno9LMXes1xMl11ahxS6QuG4d7dAsJvLm9Y6Rn6+RU4aY/ECuaKlSZDlE85LhTnruRkgJOLpVueC4zwrmr8ttITlqqWbqhSEZD0w69Ci/VIx1Sa/NI9+/TXGFWXtVYNcBBe5bl7Ion/ltDJy56/8REWapTt0zxX6TrKMJI0edlXaO1QhtBlA/j+InpxSwGAkVLl27mlrtfLxe2mSRsWqxbfFgWHyq82+1dRWnUUEk0KMN9nhH25YFbXMFG1VZNUyS92mwOP7o1b1ZZonnYeQQOGv0U6nH47NAsuFqWTJP7JXMz76bE1kxCZwzn6jJ3MjGkx+o4TqCVWpJT2hMZ1qzn5sFHFAVXaYkF+Gw01+b2YyN9KE6CNIBnDOrkUIAA3GNYDpSnlBa3pDM0g8yW2ZliV9rlEiP06RyZEkgqalkqgS/wD/NJNsb/tKbOGnjJHoYCkyRuK5RiGGOs9/vNQj6PDHmhSrmazIse08mkR2j2RQu18uCW1hZsDG/BR/5leyU0xry71jvP0v0wpVQxRj09Mz4OnQQWrz8m2CsrYbZ7e+SeCvYeCvZBTj5QHtdDNzzx5xo/QRs/P/jvfxvxfTcO5EAu26Yf3SR4+Pkz4wo4mLxw0/5ycAciLqkvFNE92PMl+AdQvYhYKTxDPsp/OXZULEy3et+wlm+oR8TIFOnBF4CH4NtEcXBivYc4GlhBqW1YUfZ5O+5u+9WM5XEy4AcOJD5c85P7GPPoQ4/8T+byO/Cx9Wv8AtBDFwpMkvy8kzvvX/UdzIEU/NAt0gfKLQ9IaJoBJ1KO3e33H80CF69Yz5QWGYG+fNOtwpAs7bUIHHDkF5PhgmvAAM6AeLErRZVkmCNhkASxujyPuuEDGpS+/k4ZfgKfZx1PpYGHQ8eUyrlSu3yeYZFYJ+yc3G0hGwIrlcrFXJWkneSPwM7ZuLwppElVci5uPacGM5DNzY7RACFUOrtVOb6DAOj4CwW78p/sdnff+PDHRU9ZMskEm9+6AOX4FdhNeRJyhfGQ1eWyeCmOSsZ/QPyU1rWUNZ53xVdywDloZwO6IZs9NhKCcJM7dB2fwaUTvS+cEssUKA9/Fb4OVPIgNVHK0sqlca7BBqO5+zVzyhq5N024hy15x/RPrF3Mo1by4MxdBMvA1aOMe7KCDnt/Qd0F4Vc4NAzc3fvSMTj/PRbQkAZ2o3ZCOUWIk8vG8uIYi6KGVMwRBt5tpRXiuEdqg99tqSkxag1D7SRYMSgr1TI/y9hfozu1X/MNkhSC6CIq+L8Pr179DI1P6PkSFZzAVwSf+ZMau3eFN9BE4Z2ev7bREI3GUWPxVrUPERZw6Z5HlpDKmjPTd66PHgfJjYOgDBCKNCuN+ekoahUABFIt68at1ZpG8sLFEZR3TPbXEWTc4MYNzvQs7GuVphDmQzEInjDHeuy6mhfCMXVzqGUj3Tbamgy+clFYKJXKoFkzMuXadXf/WhkQtsQ7Cbjv08OXp0sdms/5Kn0Xeeb6qDB0B3yK/amvwhx1e9Rz+JJxMq3RmzgdiGcl3uCqy2Y2XYutJ4QdNXgxGfSnGRSR1TP4qhqMAvBc7oRzyAtMf7JakS1Iq1ZL2Qa06Uac85BennrS5YIs47K0B0KJUq7hQ49t9UUJNegz5n1y3Q8G6qMPbtM+nXjsr/Um+aTI4g5vmc51BQN8Eif7l2tysj3Rkk4IaEnItde8sxPAS2CJ5kqHttVWLs10vbSzJ5PPJNNRfLSzIYsfCh2LpZgxLmAIWAgyJSJjpjuc0XrrOmpXYjFLBoaPUt0OYBIfkvSN9UUA2Qkvg5XpC7OkSbzfNN1R/x0f39okgFixd1zor2fLcsiosq5+RUwkxEf1CgAblsD+55h3PTa++CixRUa+w+vgycPiXPfvKmDB6v8PIvTbI8NjdwUp42w/Z3pTDf7YAjZAzweu+pRn9X0PavvQ/4TQF14L4mVuJ8clwKIGtePrE0c/u0flg/FNEugNs+F2F1ePvZMko6Zi22IdqtL753BSjfg/HPT9WBkLgA7+xVDEHM5VwrxmxiuhEvtdp6OKGtusJflTqn5k96owo0R+ggCStEiILH30fpcPS84DEzpO5YuVljrSLXssUZf+Gyjd7tarqhmoQTh/SdVvPhN27/A9E3KtClvfXHWquetb3fZB13Y9xprJEDanEloWHJjR8AumQNnhBKobNRRKlhpC92zzau3oeimnis6j1rnBWXpEvTNaWVXuvnq2SjE/A1eqdP+mA2Iz6D2lAKImKbAJu73Goo7PNyymQsrtm5j56ORHE0AOFrrRKCeVqhyLgYDUkNWZecbu2PDsW6y7wCZAwA8LzNXu59fxPWx66k7cdwFqJQwNJm3AOQIZwNq0/6Hwox+29DRBZpJhn2/HMeC+HMDMYBcV0b4ROTEKHzYaMrN52+YSMchhpnnAOfcb9zcKuQhhKDScsK9VZ2/JtUh3Cbra+UFNs9N7+dT4sONCx9L+kqecBPnmHG8yc6IRZFkl19VC1tb5jPXkfCJbyzEy99Xck41/lB9XxnzaNWTp+vpu6EoIQGHJ5d5T8B0kOEc5ziikYYtC61eLOz/eoov2+dq2ExydHfsS90gHyUJDWrN5d4vjpQzJSGaKMlq1J3cPkLgjQNM5As4SZcBCLX6Avuz/CQSC8KFWZOgnS4x1Mvn51V+z98jgMQAuQ3AsA7iKNkA7Or7oXrzr8dbd2Q/PexkMEG46BflCkqhxPeRsSeshANoJ8T+Be37lxdxXDZTYYju4KwtgTVQYqhMgp/lZkuQ8Av2ApF04mClt4SNI3v9cKGgO4Gb5Zt+1nG22Pebp7p3lf2Ze8P2DQk3zeQpA7E+1R6J+P5AafmOTZhZ8lxEqZ2dTEu65mrqB6dnDemrnzyGm9vdLlpzxOIFlmjLtaWjDvE/oo+Jcc5iZsIHg/sFbtA7ES8SHjIAQ6WHfcq3iSwBa7hiHl+GOw3eNhHNyDMMJPMMIksDBHZHgoWaheXUkvKmLAOnCl5c3Qu2hX1SG5J3XaQeUS/sOzPnzjXq15vu1WmO+6c/963e/gRfPX+v3jhuqAFHtt8hzi4Vys1ku6oHOEg4UL2jTnv+Bv5D6KEcqiNlo6DKmhRiuMWp8XQ3NGEKVSwFmpGY8v75lNy6tRJecmvEcJzmB5nqtZRo9WR91x/qWzmJzplk9q4OcNF+U0VPRFj0tIq8iKtFSp9tNmmKypGCwfhQkURvrv634LBEMqnAQchryxSoD1XUEJNUVxqKNgaDKoQb5MOHiAqFAsY+5h28HH+w4IrmeWKFSKcTcBt5pUj4LGBJC6kOM8qpLibLAUwVzGoSw1dDJYMPphGAtggdUbs1qZOr0+SctstWAS6nkYNUDwj0V92gHQ5M6u6ovRWhi2xrwWJX11U0vmEPPSyCwNmHHSXQ+Xzjs9UcKj9caIhv2O7GwwzJPL9JgE+hGR9kQ/tNssPRgYwBtmxW+kW3kNh1tdt9bs+JIS2TVbHEiygQSy9Q6Hba6ee0iDX8m6ErlaKvVvbsiuCEVvFuC6SfUqmOVcijEty4H3jpuHxgSLBZlNRbXMQ05SEJAdtkuv6kYGoslGomFY4WPCZos2/L+Beg1Za0MfiNmwf9hmobYAVqtRnGpdFceldoKz/4+hmKeh15P2B/PsCxJboitWuWCHqXrGCAhQ7fUo82H4K7g/qnDsw5dXPgHdHj9mU9JcOCH4r9M6Z/V8vCPEMo0Ep//5cJPNntBs4QANQhSs/gKCTncnkQeCo9Ej4IcCkVeIvye+x11mDU/Cb8EgMoYFLxe1OsHWqiMVKDYH7D4DTeCkk+bWD3mW+ePI/XYQ+74deZI/uZfSuATQuQs/mhMD6m8O4n4dp5KHYVJfirGB7euT/9HQWIA/wr+vIK/9v6weqzvsUkLuObp6W4pUGfWXluAEcGyi68D/4BmasQhCctndoMuTWy80NRT0ViJkbuArYkZyKvPoSMG6I+i0Oq4X6CSRSwg56Ty9W4phAv/WR3ALcH13/7SR9/ri56kqQyeCJ5h3/Y5OADhAv37/m6sz94/144KQIHc/Zyp8w75sQI2GT3/2BMdbR1y6WpmoOPfbfD5XPdKb2A4vAKCfpktcMPQxMPP3jx59Mj1TXBdvGEVaL8OAodRxE63yxPLn1dPZ9OZDDPLxg2Fn+yfcc06LxSNo9b1KHjnMmsxQMtf8fi01hwoiOpBGOodLuXbRvPksPlzxzrHVyiibuXntAHNS14QuW4YEN0GkmVJxpMdCvzCntsU3owAXVrSJ9BwFCiOuUbD+S49eKvp7qdGm8BCmUTC9NrIy165y8wsCC93Z/gdBEvZdTDzydrse8JbZ4lpu9NlkRDg9v+KDikU0lSdph2eT7yhH563ngCVYuw93DK/fnXwaCRUaCCZ25TX/iqd26nI4DCN0N1bwekmJ2j5HEm+B35Wyn0WgwB1vG/Dz7yy10cRGO71ZtcJGEh4xjN/0F62aRUBX09kWAyt2er80Lh020jdQ+H1+5O5OiJUIzZNmagpzFGr1dr1skesoPaoyzzWOvbJm/3VVzePAwS2cbVGLPQv64Jhmc+2G14n8tGA2xp1WRcdm1HwEg4ekHKGXrPB9qdZ8L1tbDAe14JydT174sKPUZkqpcZHjm2wD5op479sGPJc4I99Rp+h9RMw5TZfUzRrFef+8fv7JHxkIRvSkzFiSDlucjpds9bwI6OgBA7zrnA8nRldE8vXDKmRWrsIdLea85+ZrLYVyhc7Ctqv1lVSgnk1sOtGDIxUUdXwSqGCVudg/1dQjhh0vrXwHDFfzD5H5ZBBAWU8Izdeakx6NIddcEhgC5uhcpuAzarr+gtPFsPcKUeWrogARV2TrczlM+Vy+2EKzNvlQgU8y/vWBu7U6Gn2tfvwbcT2S/QbtH8bQMgC2BZcgl8A23Eu9upPtYfuV3+AmdM889mxDXcAFgGh7iAMGAzvnPVjk1sjjDiTVpSp8Ms64DvNOFP7BvKg8mG9G+2rdAsCeASWvyC+5VYbPThsP0PDd4Xfr6PJOB0J+4SUGCXgUdvsjXcWOyyqSHsZbwNtFCan+5zenE6C2gKWm9YuBLU3j+JYuG0l5JsCfaMw1KjIzPot68qlokfONI941B+Lf6Xa7TTLqVlL2G+k+afDsfWl6rlcJiJLbjPL0KopTCwck5I3mbZIggnAmgbuGijcPGrcf7XJ8+m9hoJgdahnTjjOTY+n0Wk0XPSHzyOQ9Qea5YGv7mCPzbXhr6uDPUnCHEgywV71b1NWwcd/9zfuQwNqjsPmYWJa6975x5BzneoPJFxHsR4ygASFhop+BoGF0HEpMmVkKvfen8HucPILNPsNcw1hTKaLlWKplxMzosese1hv5r+SGyYgaVpyDldnFEbzdjX7C84O3grcBz17kHrV4J/FkrVAcPsJHwe2kLiC3sVjwpoBfC9sD5PidwEREm78kgLY1EnRDzibMZWegUNttL+OLWIX6XTJ/9bzqXIxnwr7XVQUzO0ovf53yxcq6ofC0A24tKUl1yf8l+uNpdvx/voyCALP+pQIbhgh5z1MPsP6FN+4skqsTx8OgtH/NTL7RT09kY8VnD6ILUIUr/pef8amzirzJlF3soUU5q0xj5fb/3vsTlfhT3n9DmjvNgPM47fDt3lpY0sSKHV6HgV6VXD2kQsouIV1qpStHya7V1UFxYYvBV+n5KY1YUd/lk+NBkSvjW5DdWgZO5OKZwUqtJzYGb4G4hx9AN0Q/WjP7N6BHNItct6TUr17q1gojiagLGdyxYqm8OFc0vXXMZl9VaEHWmP1Pj9mju/cXSs0mg3mGBd/GtKrS5G5UCZTDnAN0pDUDvv9zrbMEDVwxhQcWAa9XL4Z3dSsJ3jT1aUnkKXCVrvb9Br8vPcZRfJmHkXDhYoOa/0Bet752oh95c/tBWAPH4fWpKWoF1B4xhXs1Ws6UzaSty/e4V8sOznurWjAMj8XJ9QEMKvlujledC2doEl3nAS7ufj0dHzDT79pN0i50Mtg53WLjb50Oidakcthj4mIxmw0D+SbUQCu0UxTl9vBpzNJrQ5TbVkpdnya9tsslsVU0GZw5xfReLM1qy0si8RTEm3tESlwnr7IFG/+wGdHDv9PNFlqCxdu1DlVqKHdrTdQvWokhB6uKuWrDSJbkEW/l9viSGQBXAdzlYmGQce09jCrynHf6yKZaZnb0cX4DC0aQrntNhqsCXFfiLBbycEFEOfQ42D7XLvr0m27EXrsKrWgf+yFBrj6hlEjdUthvZz9lD/KN+ihCl7i+Gwg+WS8p+1tfh3dz0IG+eJq6lk9RdWJRcHSM588e4zahVvn3A3BysVco/P088i3kSv39eOpq9432ZpaaTiglB4qe4ML0oXp8iS3gq2QqojWdb2JquHkhPt1SZUdDJdLkp+xEQxDoAGzhXwmThB8xWyBFK3bQZvAU7xnkEt16fm4N3rSFNygoDSHIFRYiGKKLYRstOotjs2kSN7nUqoNw7RrjqHqZqNiIqi0TDhdBpcA1dhqGs8BNxf0EZByR6qGmnMV0I2JZXG90WyhYq6h21DncC3Xz0ZyjXktb8kevaYBB9Ld7FfyO5dbZBnADSfdPmmf6g7/Pd075QGqhlk/fOYxx4v82gGX3Dnfp9cis0O/sTEK7ugJkzDdidFyIdD+MGpc/5yXvOQNH/5cJN3s5mZW+vMc/bv4vShdU6YXTKRmD2/bg7ryeYRkGEKVNDdkAz3SuQoSfixGT+mqiWHufmX/wTJmER/3L8Q9weedodsemBZGL780eMD5xD9GY3M+EK4Agcfv60rFXnMpqn3dw+l+Dga2N98b2ldTw/PE/MpB0wNzjIDGCuVPZPPx6Gx4raf3EXeTdDeyVAL3EpRUmxVXieVdZctblUaqW1mwIlnfMeIi0EE/yPYpUApDC1yjoimevcrkUguGxskHNY7v4rupvmbH4HW5GoO55kZuZo5dvOvpOfz1AdXzpYaSnZp/oAUfgkBtgCgYFKwYtq1f5+H/CW/OfchOTitzpMgjtbJ1/ju+3vtatrQ7CbjvseHl6fr+M3yWrH4N91YvAgWuF1JCQVAywlkztSmaboNyVFl43oPTLlMgBjMNJsnrQrEFkG2UJ2iu/3pnybB1BG1ly9suObsqLJDHJsPHiYsv0QEJ4pw13hG/om3/Kq8rlSlbnL2FML6jaxxCMLIXTzXNJpP19HmXRdC4bt4ezU3NRAfoUWXxpdr5X87H1xVBqKayGuNVcvl9NCrwdMyWarOKBxTyj4KABNrbpz3TpixilCqe5B4EBD1YhYYQGcXnwxUlglHTZOp0Or2oxO4NsegfqE2FiXdrkJsdXeMQwsjuH0Awm8z13+oTD5aj7lC+VNFosbpTfNXHi4AxgD+q+awZfus2nuNCqUSAt9BRgWVMk3jRJWD/7H31ZDGXwym4ejvsg3wU3e1FD93Sha7QgrmumsrE3IxQng2tGqW7ss1eEoZKm3jKZEq5Xzyrqvsd7r0Xr2Nhdq5WrVWPmYePN1qHLRbM+8qTdIVyewSjxhodi/1gD/rkTOyVASvRz+hT0c2Kt68BXXAn+ZDJ5HL5UxUmRaXG5ribrl8ATtyyZ4x+8LIz37AyH0hfWe5yvQjigAOGoiXOtC+izN3Vh8Jt4ztwFLDDoJxNfFjnKrjhnN040EcyoXEEREz4nDBu5K6ZWfbTQPBwBYAfMmcznvY2efLS7om/scQh7eo/vnFq85sLY8y7Kg9H2sa381mVBBic+o3SfMK8XzMz/wMpAAzkF9nTsMqcmxiXNmNx4AIcgndu1EyFkRzcqwJm2CfRJ9vLoMT9KFw7CmZNsxISB7sb9z0Dtr0ZpCoH9sIHHE7K7gGLUTDSTXMfgx/3ic6/r7htdn6aOrECOxV/58RGJYqccr+swUhDi4dIHw491KKq0NlzXlXtBc6VkaiI4xiuYQhMcMbu9a2vT6qx2WlD3c+pifDlcokQ93O/qG0osqqiHQGgkTM4SsP3Q2jwkhmF84pWl93VqnYUi7WW3SgWwyq1tVpgpdesa1ameR06TBHQaNtwli+PhM1qZkZXoX0q1IjgHzNLWqAskFOBS4Ctlxs326qM62LFVmvjFyMX1G15PLKey5vdesa0IaFC22rRGWwbNUG3CRqYVnZBs5MxOxD4wDQwpYqh2W7ub+g6wH3F4Zc8w+YD+8U7AIOrV7kqfU+3JA3jqi+Py96QoeeZ7ruKvHaPOqPvPggsrkE9nq9+DDEfkqv6u0hEjY3XE/n9fERXIMYWi4WVYjMV9zsdHxCbBUfetZx66MRaXYqWV/m7UBIv9RkpPOBHIFlhrYMb79HY1+WhYvFIpj/Bsgl65uzGInc4PfzeBqFly2KbdznFvdSQa3xGBeAIEYIgkYJF8skPEuJEM1/d7NJU6RyxlP/3x7LC/Xy4XXby0ggM4DCMP32s71kU8A5EOElySOsHWAhsvvLSTeHLzVaXfx6vuf29ougc7rjispoBHX4jSXPOh5KFrQJw9my4iDfrLV31XRehlIIRGi2TKt2AVDTWFTkQTbAUWwns5UqtxVoNCK3UNaTMPZuTC9HeLzDEouSdMmdGeEVq+xnBT+LojXpxjQtVuEDxpiGZredoEuJLe6xgBVjJLzrDL7HkcuG4nVyOK9wZGmMdBIBMszyWupq7UQzgS9C4Ajh07QoGJHFEbv6/NsD6NcbKR0JQuQfj/auoI0JFWameeEPEdvPFO9X2zepcFn7F29yAgGzZffLzK5cbCwHjiyFNij2/ZAeLDUqwJjB1C4LdHxEnrzLhaQPtLq1RPHxpDb/1So01W1dutCiqp426QDG0BwllsjxGQnBaEtctrY/t3EAZpbN443mZQuF5AGjavFiiiH5gBGMO+0aM5pxUbozltSgdNkAG7cTuc+Zuy8pYl+Aejs/3r7NlreekOnxG2eycWpgaUlNhPIzjtNok2bc1pZSqo1XMwIW0efY1TUZj3UaEKRerpQunQgU2nOgOhw8OUiMLJznuFgl0oMDLEYMTW0WZ8i3jyJ0XyZJakplIY1CKxxqdPeswssgxt7wLIgL/MPBk/iL7rRTNmiwZHQGFWdRW1uZhvOjmymOUNIpj1ixJvovlBD0L2kmbLdvyiuK4tOU2aEVkBC6ZizE/DFQAxUZrPAqBJ8w+YAPWiTRcsi7xhR0L33Hw8E8UkwZnEkCvp+HcAcM5kJafCIZb7zR8fn5m4PHB166HAL4NALuqqr21zRgMPpPhRrs8C34lzlF5LIVc5JAcTosh3Gdf44fVuzVhHjMbDWwyXj4UP6LhgLdzrW8aMobBk6nk7R4HQ2EbI3nImp7HUmx9teda6uHSNBBTzM9jf6xUR23XNDic7EiW38p9U/i1cnVuAmzgWJKoz0E+VNgBH8Vo1UkQJ8MIE6syCTHEvJ3/TW28UpSjLS1RWRQ3RoddGKiFG9/x0TRmaGpDiWNW7GQGx4ti3yISliQLNB6GyIsISkWjyoj/uwLhABJg4y0TK2ywQnZJ2FRQXPw+CrRlH9gYwXZlkVA8/Q3zw762eo/gOz+lo70nk8NZQ2TSYtlKUD+ueJbEjNsRz2bJts4FKVBD6NeeBhHA232Af+WvtpCSl/ZrABgP8eScuGF4Oet45tYAbCKWp1MDOHt1VPUdpxtg2D62vRGT9kI86jmlvKaGCl5EWUYKXQpMchwIgW3JD9TOCbBw5Vhb8pVd+PZUIe1cBd3j84G448BIYxXWZl58xP47wGWnCPC1AMboQhPc1YNrpTzy8oERuOA7yE+zVf9drGh997FGh40/g/7mwHscj6tI4udoUOzK+J85JNGTri/fqweoIREahdktoWeOz+kVZkIvvOUxP2PfFQG3EmWGMyDly4TF64T/U6BzJipuCMiyIhPTUcu5afDXd8HIlMH0o6CcexOsgBpe1mT8gvoifqfbesXkcBi9FTcVc/iDoO/sFLk43tf0X7SMs5ZpLThUg0/ZDJb8lMtVLB1P7gmSo80QIxTqF6JL0L4vJyJW5ZbEe9V00yaFH15xrM/PeAOJWJG2xIXx0Ua3pUq7LxBRiTjnLK3+ZdI0iFUiu37wthrr1dFY2BHJdX3pW7T7KwutNGnrnELY74OPrprl+W1+kJxET1//TjmdDoVdq5BPN+U/Vn84yuk88Q1Q6Xw2xT0Y0gnVW4hlFeDD4BI1zk+H89WQ5AXjF18lRrBsZnvKHBXLQo8oFurxdR4ijgyNAlmfMyAQkaH/jC1kKN+0TXJR3V8o/TtRIdRRDZIXEy1141NWotWeJBa9QFjBbk45HFPaEnMJu+eS+0XQ/Z7daJMk00AwKbmt9EBnDk5O+VZaCDUR6UfdDRJGecZTMimI6PV7dcwJ5ne9is+mGgwjSnQ6xSEw6hffY7R6iwuGGyPeS4G5Tu33xR0WPJVr8APXiWhTiQDw5RMue41mc3H3IKBZVm6Q1hgOZdfHULQBB9T6pHmfDwxOy07gpSf94uY78cOYmM4T/w1/c2nsZAOgwUNr7p0vIXnhr6GKiXIQf6GxQHXUQo6vFXdHYc/KHSvA4YJLGZL4zgOS9xkt7C1k9cYlP95HTHymULYLzycSBZVAO9kBdspNOJt08oJbJKGxTpH7jRW5JFAkI1KU1vY5VxywDm8Yyf3dNu2DOEQw2COSJiVKZL8Agw87YYtXqUCAdMdAhKjjxiPijEqjiQEqxf7P51cj1q3xHm96S+ACtXF4bcDzboE/hZsccXm9mN3vNZ5HbSeuzfdD448MrfNDOA4qRTLFuWJ9LqkjqSZ3626qi8HlIbheBYH5V3QiEEiEfL5oOr31WCFLCd/DEP2Q8JliZG7bHGLk6DHueZExU0F19AjYOP9mGon6fKFEIEBOeuuZzRcH3C6lhmOpTQVrjiZiTHPheZaJsb0fTLnQ2Td4isrJDK2tDsANsVdg2uMK3qxpgA0f6TqMPDzJADj3YYsF/Bvd2feacT1PiALWJuw+MX/5fK1lU4lZuy+XWxM7aBo0AGw9+O96a2mEvzC3wbUUAFdbMQqtfzbOxmwNZ0yYF4RWMRAOwi8BCjOATanGSgfzOeiSaf9ncNPmdaw9qz5IXQlxBosPoCPP/dAbngu/TA+QYUPLUx08JIKK7oNWAbtwUPjml53TWru5wmgg5BPLVv0PHVtl2BtrZyqbvDAhMAoOhefccA+LydaM6ll0Vs31dfkY4emaUHR1V0uWad+4Z10yPwWGTxlC8AAR3xGq3lffABEWZkh2Xtgwoy3T2CNbeFqmWjuD4bRk01VDv4IJtIk8zdUC/uK6sNFva3Dp7VRd5X3F75XHxFotxEuWsyfOi1I9rDgO2RRB0VYP+ycyNs66ejHnE1fBVyDnfsltk0JIAr8QQcJHkQS/cnx+y171PmsfUinR4zDmPGVtjUPQ2IhwHGHJ6c8lR3GewPQx73y5PD2sUPlplt+iq4FaQy2ThvTTMMxSkbs3wxVr7Fs0m1P3PR6vz+f1HK8bS1gsidyQaYxgsiInAnC+qQtpyZUaBw2tzRhC46opkua8YH2laZu4TZbjxNwsn5uYXObTE3h8f/SkkgIkWDbaqJ31nxs6scijD980yzAb/LB8Xgk0skFLJLSoP9obdhuKlZZaCwCSgnfVQb236VVpgE50R1XThuyWNM2zDk8fTcBB3FSve+1dseKUPSPzbK1U5KVaK35gbNJ36xrgUNdN8CtzXXDDqZeJKUelZPElsbNMKuB2f8h79hR2TAwaCd4IOUxfN54MpxGi+NCQa5MbTLTDLuy05kmVyulIWLQrzVKIZWs+ElrRaNTVdDgSS6S4msJlAlbrzPCvBul76KVHFeOmZDUj0Z5Quu3h8C9/Qd5W7QwixuF0u9P3LPBpz9M1j+H9V4tHzisOqjguQyoc8EVIVqorXmyWyrmlkq8JJZMP+KP5oF2kFDbr/OdOrVOOUmUUIMOIPRW/C3adCcAcpv+GIjfgvfrVTRtc4baXRew+g+LpRNWubglSfQEq1++YTYBFH8JS2uh5LNhhSfAqvZYznLVclj3UZpOxq4EGl2VsuLGYeNh1B1dlKopzvstY6OZjYodEKKMtdgvZ9AbXAU1kaFGel0sM+c2ISkSZEaCHYRODdPhwRDlg9JiVNT2B/V01cESNO9NTigfzZrm8zYqUJ/n8HHxBZmRl+RFgD+6Cb/m1slJ0qBBydqrnCNBOuwJ9vqcZCzplfg6kD1Ywh3eU0r6esq9qE3GIzG/RbpLci3SZXj+1b6iRH5WFRfLS9OAolwdOwAbw9u3wOIwyaiPsIN3emV2u1qNPRbxBsgzCfd98R8QFsjeNs9m5pFR7wBVfoa9CTy61/Krmp61g4hZ6YpQ0vy4K7zSrk5QgI/ZoLnffTz/NpMZaV0QVfECNp6cbrwy2cVBFYkxrr6v1+o3Qyz6XhSBWgQ5u7PL23JmaLzSvrkeQGW82UOOKyiqPRrJX6USaYsWiblNCJDlRtu3Mi/1SvkGg9g5lWJ9kOg5/dZCNMC7CXPIcubimKu3zOKhxOG98fc8hd2qqWsgLAOFvBjZdnk6YBM0CVg4StYO69AKvRgAmr4OAeO3XzpPnrcT/MR+YAJ14TNCuu/bXJ2z/2CiqWwGqUmj1BhdAVjVi1r6PgOSED7Rf5fUDOucQsDruz0QRxcG3Liv8UPF9dM73aa/n1IUrO+G3rqhed0+vmSpqC59OLR433YsG55E+b+UvLIBGzngqNeBCE2v9DEowNp218A8iTg8cAlM24LsPwbakAUkxAd5NQOkFn4IKr3wuY1WjVafHzw9YfBabjDWEasQSBzk27n+pz9K0vvNf2py+7vTiaGMsguJmnZg+bAZxUDf6eWoRoI6+d+mRW76Rn4WZhjRrTUEcUuLE2ZxO7iYMyFaKcZcpeMvuJnGi+QdeKOT2bxfd/GURCD2NpMzXZamdJj1/S7adNBdXOxw02inMQ+jG/cTabhqOctTjuRfduk4iL21aVUVhuUt/YgpXcr3L64NdHzAknwnbSpGnax21nQm9x88L7IR8dbxKq5TN+Mwo1CoIjl7fcPhy6ppqymVxzwSdJ3AqcK7r96Eg4m1ykOAQRd0LLrr2fMHtr6j5ZwPBzditoJ8jSloMREGoMrI4rvPHWaOKeopob0Jg8NovC+oFawablmwPYZWdBWwmVFxDUX40Ghyjpr3E2l4/9HLYi/0evNmhxtK7blRnFe7p13D08bqHl5Thgs+7+0+bEtxOV3vYgM1hC8SrIlWyLLGOy8z3uuEazc7y9uvhGZMzFA3F0WSUFuXCa72YEZyHZ3UPdB9Ja6evyfd7wV5s5pFK09Jto+OaZhiFRBsRyEJnsu125cpRbiOLGVrus3SEYxyJ0QFWQkMgLK/liQFBAi54LHsSVKFrRXEOp816DGcrVDLfJN6NIoGgwqhWeSokkxZXguyeDnAjGbbcxjFsDbYHwGeIoa5/EHj7E6jf9XBA8LLRISjrhW32YChl8qLz/KCFlupO3cVsNZ90WK74NPGy63XTe/mqTx/x9bdNTlsku2COEb+Pj/hkmdfDrGiIJ1LupeiWKYXnmx4hgJSyWc0Fx/hPspRVtapC8WXdfp7WZf1A4E6/xsUCTos3+1Jru903oUWpOFZu52uerZAMfbw15L/yGMiiSC/4xL34eW+16Kcb9nHTgrTUyXJJlKyujajWeXyEnrDP3AiEK1ZvMt/Rsx1mXrjJJvKfq9xQtiGSG91kHYCQiQQ+tTv9+rNoYBMFzOrM0ddnz1YzNyKAxTpojSCsOdzHsGtzZIvdh6zu818z3xZCAd+IM9s1HVjbhvo1Z3uF/H0VkNgWw/dfvhN7/dqM3r4m2Vc9fl9BsukeQXqM3Iv1/QwNNpWah5CvsCBgemxsKf2p2EO4LaeoP1oTr7J3wDi1W77PW3D6COAApz1nb/99Lq/v59o+ZXKF+NWFiXR+Dc02d/2DI2AmsrTv+RYIhtiM2NJP4A6mRO955x6WvytSZ24h6CNyObYPdvE8SD9yH/rmim3rqV2IL79QUoZmE/5Q0BrwL0TsdtD98H1G1kIRjAdn8spOxa1+fkC9CD6KRh+hOvM8+ePki3y+gD/Is2+Y51FkfubJ9xDqQzTIGGeHN4iuEJo+3uJ7NNKS3UvwHMsqKumzGQ394GmvYcw0FXx746+qA95UK8xCnXgrn7o992uXJakki8FWX/MiMiH5/eJtvcVxjyhZ80vW+fMyMAllc4PPEctAKjc39K5t1PaE0pyrC3V2CJQZVkXVbDSt7lQvhdyZiszinCyHmZn7RIEPN3Quo4sOGcAJ6g8gtt9N1fmwp2+lJ/JKozX3lmpAVJlzpYycxqw2fQexQ3uxacMW6Q1pWInHm29SffrjBmSbVVd+d7f7VKrMUeEGi4qrk+171DWjcnWjDLtkYDUmGPx2hdO4LhrRpdYEQC/H5iEOlC+cUOHQ40GjxwGxbXZSMF9VDgxLgyqrw1Cp01ukF0ttEtjFe+SQ9PurCDQUnFbBCR9QQs+kX1yqPUieYbr04v/DgLprJ9wok1EgwIdu4zcZi6d1ZEMpGzHhHxZDoex7/VLdLdkC5SvWkS6CvMpLEtAKQ1ptAqJJFfwXJrkEOr92CoDY4WeVJOMTWZLk/27fQ0phJXYZlM3xAm4Gwc8mrbxjX3lmQ3r+Q+wKsZhRg/JwkN7CT9p9+UCFFNtozFuMH3w61vIxsXwFxKk9xNvO4C7afXmpg7BSZ/OI4FHmTMssu1QxFMkGOJRJLRmgFtWN8Xjz5Yg6bWRayZXc2ukw35m2Qa4Ry1yxjKoPcDlNBwI+q2VXTOLWVNBLSyefh9dV2HezWCJZqLPacX6CmejKOjUYQqXW0nmDwdaMwM7QmDFBFxB2Qd5PBjZ2t0sOrWSvBtraUAuqEPAMyfTzZCYDeY0SXOj37nuI1IvPzYEU3BEOXN0Ga0Z1GMZqKMbu5HTNKzZqDV3lzaPpAaR2VRkWxeZF3u29kmwykXT6ckEnsTvQ3OtirLzD4lZJN0y0RPFAwucAp8AdN3DR7OB2NRtEQkvHJNTZllZX6GqPlNwwVLg25Ub9CSx5doxqWdXNk+bBWjiT7k4ACvmw7BoReDdZE6RtDDpoIYNDmxiaWAC3vGbDZ9c+JjmsM+EdaWrfhqGRI1aHY5LESmSuu1quNk1VazSOXf5Pfkkc4Liymu1iB6YVop+9rLHHy4Z0PBRwTE/fy0YtCyWH0+kOk2BwqqpjmK44QpVWkiVUiQSwGZhOeq3tOtBO7Z58Lq5FNZ5itUxmptIwSUhJHiepAf8qq1PFDaXNZh1xvEPsCKajyezN0AcUFjcIiupqpFgXStCMG0anUKQig7p9QfOMx+1ox87FsFydZY2XxzNL+Qj88N1gMLMspm+R/Irq+5uc0bQprZiXahi28u3WzISe38SQUcC8algOh6R4qZ1ee4Ieyxn0sEsAmSwE38eNMcNhpb0iRKeAXaxVAuTFsZgOu9wLrQhnosGH8IEyQM8GnTZ0Iz9ibh+rFcHL7NM/kzhjvW73xC2kYs/M8C4cav2kqX3RBP3SHnfPWrygBrjHXfbeZFrKtNOnjuLTSmVbG76c9ZppYYZ2iAEDUKi6HRW3OIa11+uxR91uG6HgktUsp+hXqc5O/hgZX3HapK/r4rsXF5/NVHhudpWYac+Vw5DpgRzgoTquU+NLEu5+Dmwr4zhdgQ/dIoOORcPfqHUgQiMNy96eLQpOJVXg3Ip+Zd4JXhW8FKlYHhSrGRQK2bJHqHq8s6/fpPQ2hGDoLVT3tOCffAGJSKcsfYcbLG6M/qxQiXJ9UoIW7P97ich0Bg/UOXR6OpkgbCMGiN47CMRSpnsQqBpZccr+qgpDGewh37XATbygdeheOmN/UmwPODXWa/GOhWCUZEmwZvsiMUzWYRiPJN2GD+T34DaCTXdEuBH8qnV3OkMbzc0sp8rb00XsRDJb6662a1Umi7SqrJtXTzLltlsX/hpMIeYZuc1LqaWQ5GT4krfZawezz4LIXZn/gQVAtWo+wcUBPDWIRO31uowKJnoZR9vfqC9BKhXz6YRkAYQHZidLtVZTaEeOT38EGgAnaJ2K68BUVhCUUVXNgJPvA1nFcYF6tywTNdP44y9RNanj9W/ND4/xOjTeV5sUC1ux6aeKc5FW75+3a+PUQUOYXnMVn/f8GDGisLQwSkDnzpxp6A7CltvhBTHka2eipEDIywx+8pLe3+evoh1vRX9m6P+uZ7Ph7M3W0xrkwRmrgivu60ACwGMjJElAFRxBWwe2Xq1yaZ8jrtoAL+I66HDDhUscTYTsjv/KlSq4Up6x44My+Vbgn/Ye62bkXJPy/q/QBBecnnSeBb80Ma2I5cOlZC4336Q8JbL1iHDjoxOvpjNCVyib8z8CWxAaaa83ny8TpVQGoqBjlly0R9j43hhAN3ZB5TQbnLs+562vdwAnwflWrovvqT5PNroubtUOf174PfTTU7s30fHSBxzRzZShDPHwPHHRjuPvZ9iJPUbJa4F0tig1fWPYVlaOjiq+q/daPNEWLjqaWtgI1x+sjIHZhUtsqXGT4fzT7ew9tpM4fzYOgU3u6SRLlNp6fHt4JsMbrDsiwSgNpEd+Brp5qI0TENU8/ZQEt+qyEy9Lh7ZGUj3rLSBm2iajjs4eIkN96U1EX/OYRQzx+qodUJTTcQK5Zq7x0I1Cgtq24aUtmVDXFtPvSQIDiTWzYNpPCPMgoi9+DIErowo0mssmsoI6D4Lo6z+AqDJudZrwByOpCaK+5UNIzktiiqcYBkHeOkyy2hpOYqw635gcyxSD6pZ2SvYSpuL5PUR3uj7vOMzPkxP1cDr1gfP6A+bAnTE7+JUGGf7svMmGkV+4ONWPLakF/Wwxlc2SBLiBDE2g1nWvCmbJ3AqbqExenxO3hohV4ZCDcpEa1RIgzOWuYYhAiyjSRAOV8hK0CAi0iYIFORDt08XVpBDnIumw9ZLaIelTEpVOwpJQfK2YLhHmoMKJXCsM0CbgIeEe1G3lbhTnOYHa8c2aHLhg078I/DILWxfnEnvDf1jk548wDp5/FfhW12/begSUUWAS0E2rmp8vvpzzXlwB76wVA3QAZWWqie7cbHICH7VeVsonjFTj7f1gNQdfJ1d2/FyyfKsOvwjQ9wHfP84gSu8oLhrLrskGSSoA8g1isPvOnwB0CIUsrruLGsgTffKug3RABFZ+80kE7AyG9aDecXD5yxG6Wrezx+VPnL0k2lnJYSL8//VVyFWLqtZ7K3yuedY2zatb/GoVycIxHZde6HZ7e5qopRGZrfNu8dDF3P8jnYCpzcHljSpLr+ItiDrKVFlNx8xS7TCoyoireaFtu2n9pl+W7Hcc4LvK1PXnsDOi2hGoeqNkWcE5SgiCpgk5BH/RrztwcsK4AFYfsNQx0GBu4w00j3LPNz9f2GSbNXvp6oE5oiT+k7W0bO8MKibrRvcktKE17LIxXlj/rYmNV7zQVp70FGAVNCFKhRoh8BKqgkI01p4JRRkX7YVyTUep3ISLztcX7BmVeHcnLhdM04xQeSAbXnGBIaWx63YbHVfpHwB+Rm4YoAjbLGfL4ToTu4luQD5zcHAcDQGe+f6XX//uXNl6CJTB7+JnC7I988LO/dayZ/788PJj9MwD7nFdUWzPt+204kSoZyS5qgFFqAl5Jar5z6/jU2QmeFAUPirG4Lb5w5e7HB7+8fZD51rtAk7uUQ0+zcdWcOyN2a5yYcNtly/57R4yrEvzre5K2DtHR7U1O7kGD8MLV03T7X4ckrWeoM/t2yoZoLLhWRGHKJlxNoudkF2T0kamiTOPXDTLaS14UmzCNX4oeII2B8lDmf6ixLuMQYH3FBXhNdbOOTfUujhMUMxTYkUGNiV0Vmu7WIZmv+NOh932pi5BIkZc8K9CaZj2uOATPJzZNuvj5hMV7MRMiqJr3lSfajD8gYAfQndxuqHTgwk8Fgr4Ze/jFG6rkIyVdXHrCandZBPXvKKgdNvOiK3iBwA8VtrjSRQ9WrUaUmgnrMrOGVRa8Y1QuEAtemfJ+bnOMRe6gdNY3B7ahOms/fXcBizybNF1wdi47D4btlq9RhMBrz+GPgtoM8+OyeF8ixszC5eMsZTL2gXZrbv/vj41lcRSaoprz1HjhW77vnRgnDAqDXsx7QTbbKzP5xljSBni4BfoNNEiqK3OdYnOG1SgLdlYm9/NPJ8dsP282+m2Ux6mQi/wV9J/IxQnc2zJDB63L88TlKAoZDLqdVzYb9GzMHm2W+peQOdQfSziVxvJ766d4pp2E4wQm9UTp7PVKeMsunq2ekFOFn0+1MhaNwVZ4kRQJEnzakTLYCWTfNLe1+SvwS/SSUJQpLAqpVo8Zok7XW4n9nu4aqqOncpF5mtgMpiMwGwAVy9pkEYYMWUCplvWkSFRynrZsi6Wz6BME4j1JyKYOgw9c0jHe0wEDOuoW44dFjEHqtAvcuGchCJyJ5jvd+e817rED05SB6pPxYctyAOsv+NyuJnVtw3cK1zhRH4honXHsy8txwvbhQVtwOcVdJXs2V+OxGsuQ+95bbocg3LgIrJKNu89ATrpTFVrVCMSsGczMz5fQPFGFqJlvpvDPFRZgWvsYZHVKDlfD4P6WapDwkZLnX4t5MVmVMFRqx65tXNaE+hjx4TzbXMaJCRGUNmNijg59+41jLE6GGh4RZK9ClfoDOh255dWwLOh85e3rcDjdRQaZCwfQyddOgU+6v8qAtI6nDdzK2zrJg0y6lD5xTpZJQOYYeoBVBmDBrQrj3IcOgVnjbQ6q3erM7DU6mjxkh/QgckSAWFmt1oKxcAwQ9QeJENhog2PYS9TEuoA4B0XNQXOOWNIN3ZNHHj1YuHpr9lYDhCBwtZREBBlYLbiEN19Szi4aOAN+Um2lcYwZ2HdrIKN9qhQsvQE13VEqHE4qFP47tDTM55WY9nTCr6i25s6XyHG8GlDyEh6WSikB2LRZdFRDVB7+melBr0PhvK/kN0Lq8AQbLue6sztQWGQ9PSwas5Ibd0lJuXyHsSTVBDcDoepmrsWTvqdlHvW2ygcP6mscBHuGdJ6jnYfwnOkX6IMHlf+nA6LTBkouC+oFj2Dn1sZvy1Ohwb+YTEvg0+QsIwij6LzpstGIaHY/ananqnOaSRUe4v6MUe6hF2Ojsm9XEXGUoln4fKErRAbK6tu8zi2xgUqSzsTCGe7So9dxWs8xctcutsf5KZuEjmZqvJsdnWQfoEVRPT9fLTHTz7MSkjRsanesJqt7NlVzzLIsRafYdkwo/e/cZmweEMmQU//TnYBAVG81y4zLrZ5Ab8LmEv6OvCD32rcWF3r+FEWSRKBGprdxanZcHWjA51UgGaLgih4e8yiBbqloY46OTdkn5L5jJhyhR/B7iYll41MW2jNhG7/6ohy/9YUW4e+pezN0u6LzlLNV5/tz7rN8BGR4AGYy3tAh0R5IqrNRJkFz8rsxfH/3sslAywOPVOIJDhCQQVjAntNwJ/9hiBMberS5BtSFl9lOBLQ8ZxemDPMMISCgyeEfjbS7bu9SbXA6a5z80IE0PTBYHCzaTwwBGcG1TBU/kAndcfqS6lIUBwBUnd8CkFs7Gh2t+2+ka3RBifOwJkdW+qpcjlJZ/zMMOUAW5nlVmBmERy13M9lHIyk3t/Lnbg6qnLQdGgl5zqr1tB0lyRxhXE37z4T+4lSlsB7WMBc8K7OXVFIY07V9k3b8fAeIfALzGf5H8UsaOKg1SUI9+rFuasZBpOLUqxlmOO2ab5WArndSKCeD6eObrKfCwOzRFxWWI4pf99q0nhLTyDHDca7W0W8MR6+BKNUaUlmkUyGfI5ZusgZqJC2552rsObmQOU1bt4plTiaLPSd06QyN6Bn2oVkq0udiFlOAzpY6rAMW6w70MWQEq6kJ5qRgb8aJbagTVSujY06ikIeiyktBa5zuHe3jnHGm45XGIBQAUx9w4Y653ShfLDOQFq1Dnt6F6fn3AsSk3LWyRRDdNF0MIFubkYMseG2hmC56T4oWffUlVMhGwSQz0Q08XXwXISSIwkC0/eXMRgh8duQBEXi3mwmx1oimEmBUPQgkLOgBR9zMWutxbyG2SJx441DWhIVhuuoc0ZPCdWfPO5N0jrMo2C0T5hDyxMA/wET7QQwQJj9tZt/R0RxYFI2ROlbIQuQMwwFsEx4ND1QLkkg5VpHrJnEfgZJcCcsCB5XG7OcSck0jfGZ7lTUHk/9h5B8fjcju9hgcuqVfQRqChR+iRthJZ1Il2zqrRaTyYpFVYSDlSbzylOk2AM4TLKEFFmrq3Yjgbl4f8WwLqKM0XlvhcR/9oGgu9tFw+2ML+P2fJjValnyeZMVTySRoU4aDXS84owSmRB2jS6dhboKdPEpRuVzn9Wy+pFQiuPO8vu2sG0y4ruHHFFZmkvYvWRy4YtmG7z3nz++eqKYJ2loZ++nW1G3YwHe4tpgyazfwsIwzHY6SKDdEkz8X3+qqx//7DHg8SJ+7a990xY+n6dErDbUdgSa62qcJr1SNJc0NTW4LQadUiyUG+qbPYDP0cRLGzxu45dI+u/hYbMKabDxO8brC/shdwZ4C+42Z1VW7K4Ti9dfdQf+T5nNf118/wdP728GJ6HXPwRRVQxXIVdtrtA/WHKWgFHa9MB0cRQ5M5Ps7OtF1mLXqmucdEBmek0K+MZ1mzKFBPwKJcGmgCHMzkC3n2XZy890psASLEus3UkwXCMfc8jh9pBO/wKnFPMstF+hcXK7x1quQoHDsOnnt+1KAnpLiZ1gLQX/MmpJLPjSmuxnEwHsYuL+AAOBMl7silJi9glrOSCZL1wU14o+obo96sNUnOua2NFLeFmByX0hm+KKZJ1y3ENJMhdqBJC4NBzrgjWwDLbrco+VWG3yrmGbwhJpazSXVquzjpMj+N/C/O7Tl0sPcNKD+cbiEqcyl0htmRpMkhmkTKETpKLQ0ncBpi+qX2QpeY0vGeDUZeidpiedsW1tycpCI136rshYKarzYY5qxG1fWIlO4It+bCVs5BNcU7YPLsmdzk6mgkEb72zJdq3Hr3cGG0EX0hEG59PAEIi47dj5z9vaOjWSJdXxhZNtHntgFMHGu3I4yCkkjxQmYwgbwVAbXOvIbDJUHqgPqTXecbB0qnUKOTfj2E9c6ojsdTioaBztmroIPfRzI4MS0ZS/hEVbLQFixODRszkmHShlqGTqCvx1HD5z0obntSdtGBpRcA5t/GHpZt52zHYjWowOmGcPn2owHcel4byGCs/1fCLSbtgVry+DhBhhRaGf76q0ebC98F6lLDWAJNLZ41p8FD0YqX5qDQEyT6lEKLtzkxqHyD+DZyJnJJ7sqtdufCm06ME1niZ7mUKn5/RYi0xCr4oGT3EJCtM+i89glEHVV6JqV8W2f49JeowaYrPpsg1RyndlTCzdIjFVF3DE8i7SfFMqWFkVEjlGkN5eX0NcyXnV7Pa43ueBYA5xY6ltXDOkPRYQ79x8uhjQhAGF0rQ1je4aDoI7392mdPjhzv3SvZ1JzrwrMTBLk4fnJLRGozO1uNFw6ggD8nmOshsXRWNBXqRSWIFojuSaXRMb0yMCwk0Vk1PJVZUjhqXWzziZbeWGzM6fQ5z/jFn4gf1LwoexvzraZD6d2uEnwFdBtaGXyu1yz6wGNpdrTKnmc2GtXqmHqgq74snEb7qVTemrVhB8PwgvI8hSSQAUV6U+WMtzuFyX6njNekNGQzpHj+mqNbc3SD6ClMHhjrnPKBdqXpnvlHCGkunRHV2/WJeqBiaj7bCWftZD6xAhgOhvsWypbvNzGyqcqRgDLaIp5BQcriqBIWJCiL4DMV2c4Z91XCqWAsZy+PJGGNWGjSWjlFkbli6uYSRHBibzwZm1LLthImt4qq2fCWbDj+DP0Mue4y0QcsJPQDzUrN5sMk/JXGWG9lyZpVzXBorInY1t7nl+EJyB3S0tmKhUyuFMlIbC87UlWiYga2qKYO+aPVY4T1oqnMKoL9YdXMtP/ThRIXwWcZYRuU3vQvMJgoE+iHmKHmSxuMcpOod1XXKI+JhAy6JmpPcyrWHvBluWdr5iVTmaqsplrDsPL4RGfK5+MTe1m3RbOdk1NJE1/dExezPvlNh71qR4vOznx0XX5Niv33y5GFE98+deiFXasro0e8qqLgIveV17WxEgJSJTS8r5MBhjrxaV2qjjkJkgWWSRlxTl7eZyHfREyrwWHGVS5TnrWkfqyDBy0BOu7bsfhx7z5357VaLrFZATUh6guBKL/iBvnFIpzhW0O5Btse9vMRMNOcEI0YpFQ5VmSjFdnvudz0YDbBjAycAP7fx0g+UI5jB9DlnJYWIS6GJvNDHeMfjU0+Nq5fz3a4piWwl+tX/QMrXtj4Es6vJltwky/4sunrFLpQkPtsQbGbp5a4gju5KQ9+lE8hkwZPI/Q32m1f2xbqr6qwGxKcua0to7heExJB3TzF4uT+55a1PNlmKa8FxXmQRr3d5+p6mKQ2QLsRKj6XrxBH13urBtV9IkOvb39OJIH+7ydGKG4fKjXiapqYstZLUhVZSgOY6KjnFjdV2bWtm2XaetG0ayie2cH7O/nDNYiULuXS92I8Y43hk+hvACtC91dlcSiuCOrm5oLJgtMrktdvG6kFRbbJkLaWXtBKQotNEBRFnhKVWoYtLmh+qmUUrDEng5b9pbDOinzfiwkkzvTZMjNsXqGPjhdNtWrPZFemN8K2qeTkDh8tpmn/7WwKuSORTAP76fzfzhA9m0GBlJZn6RwkBvwFMgxcOHRdNUXhFy4+52gHnAwoe3nkQdXoD+aDFABArSHNuLQam5u6Iy118mSXzBMnM3w2j3CY4iJ/IbX5LuX/Pm5DMZ7VBcb7aqcWeawVq2vTCwGuR+YONBKaIlljJ0zQSC8bLjrqifw9TiK3WT4tC+d+qTd20MN7UuRotg8jLWgaQqEc7Z3EkVYjahMERqcd8ipSLg8jX0mPkdhkeSq3rpzADrdWO/8SUh7LP6WIKnZFykLRBJw1s0y5LmAiyFNk3LsYCrO0Z1WF/DiGNX9K5gOcnVO0f2NwvRix8+Bc2lvBua0xM9N0+S6B8TdAGu0nba1Q1wPv15/41oOJEvVpRNpxyK30LmhZTVSnuJlZizIXgNi5EatZzFSt+exjxu36vMYTuDtEB4d1Thvb5bQXzyJD7eq1marwKxDkbV696Gwo9JhcbEZD6fGRfFTpuYaveztLPgUcl0ltDzCu718lZ6jBZMzjjJdX7Sa7A2RCoVinngLgYo+U67lQOmxmigLBg3Eza95jkFp4wOznvxwY3gK6V+7wWMhwa6eGTWHsttQmgq1szn4ufCqXgADLHIxap5lzW2ATv+Y6Ex14G6GMJni2MBaQLarw6K+SXoJR9xVLIjfsX7r2Q5xFd96UomWuq/so3VVVPNKm3VV1I5ytJtHvGmqklHoeatDBXZRmBo/zGGFOdLDDSLS2OFNqclzBFLIi2HrwMi+HY/HQzbjAmIEtbAGGSSoxjHIUGZhEFnljvEbU2WjmMLqolYuwR3eqwlN0RaVTzLwF6dJdDPlCGgpHNVEmWan8+RF3G0HMrmbjh6Ov3pDboqUjxygqdpwJTIOm5oVUiNhVtVEuHk2p+G8rLfqFJi9GfKho3JXsDeyNMQXol0cjge9Wo5dYhwWeN+jrJZWhazYX4OBh2Do6kOy41YMeTxgaVrxpHA9LVClW3NUsBSpzNUaiUt2Jg353U2wFLEAT9jExn0OsEE9CnvnWZXh6wmX3YLlqWLEX2rPibLCEVww/kkI1dlx6YQdQRWY9lK0Uvh87qNrfA3mzdNZClTrPC11DbTyQlZ4JyWJPWfA8SVBFkiGrVd7xC4h7CAUVdJcYODqwf084cmJCKWJHttQRnKW9f5/xwYJZTr3/lqNaeIMBnHw66DPTN4LbUEbPhaSXvvHz9S0+JRU8fuDX/A1q40+Wn7tT20lfnhEFfq7OH0SwrnIeR07rkIFAAREl9MsvX5xa0EjPJZMxpUWXQzpK+yyTxeIldqOQIFKP+X7a5kPNujez6Mx5NQVOSi9sdBpaYG/IAOs68Usp7cHBroYuDku54Xfr5J7L1R36QHbWUKMOI8mJYJD6dIhIX6UYkLBeEtGPhsh0kd5xYHzLhgx7ONaTOsdGupY4ZvAnpgJzj8cE7eeyWomICdoCA1G9IgEvKxPpq8x2x3uQkmlgioceRebuOvEG77EQgKI1qtrVqdNCbT4cDjJM0YSKOldyN8EmuZcLkcS8g6h3iD5c6t2ZhgccgmpJq11dhsNiVuMhwlyTjLPhGJxjguxnq0LAZXJRsjpAA0aVKNiKZCbqK9baVu6gQp8me/3UKohTLTlN1IhwvOUOpYwFeIQeqqf8rjV1VJotchaE/FtSAPCgb32+hDMwwh4Ta1P+rtAeadZ772saDjzDzEN77MbZjDi17sUR0QG5HLOIthABLqPfE0AgKP4eZ2Z6buSi3vOJXIiXjbG1mtTIHNx4Er7QRtrtrvGoev1+pFjrwYuMTXeKAw7/iEqD/+th8AvLXN6CXEe/Td18OVG2yeu94JPpZOAJvHQ7DjmRWHdhO0Eg8jRXydxDSFHI+hXAYMBjdyuS7FO4AAm0Vfude5cGZduon7EAJkS13GpE4FBdT8b/f5nuXbl1p498qhYCxF7enK0G2ShO+5LYq+wWUUgK/bPWTTzhiwrk1e69fW/bRz+BlAAAAvStrBrrlJ8uSbq+l/vxA/aFphPQyDTlCe+xc9dCaC8ZPK1snDlihAcNQRr4CBTegxXZ04QKt+os3MXVPLJPJUgkFrdYUG+8Jr+T/2SiqF7qCqj77DlV6GN1fmuO58uhvvSobVJAcMITHOYLo92UZA5N2riUDTAZIjRGSBusdLEdrWdG4bttjU2mF9yCoIBC3Ol+NA45DSAKP0sh7s7w7IFGi768zrU+nNzBX5vYfC8JB5bD7oipLUSWb+6p8OJm6vyBkYF8by07uFTw4xXugB8xXctp4STj5Bin+Kija53t80sP46ugEawH2HnQ5gUT2hx3FjkV2JGh1Zis5iC7SSUIZsR7zyukQkrN3fEkmp8ciT9mAetgBQFozXhrqM23m/yIaKOeTEFTJAWL5xZbVcLulNPb2/iwLzD9JpPTbEJa2YA2WkWlMzL5RHJYILlPyj+Cc8GSzqKazX440lTZd1VNYBy6ood3cqHWuiviWnZfhP3GtA9piiuVu3O49gBAeg3cu5sTPRReaSpKxz02+sKV6QSBJdhLwLDLKsT5jn0q/dhi2/IMnk7F5WwWVgFxVSeVOmvEUMn+ByCEePn1BLllgg8UtThWoo5JzlxLRaRr2i2BlQ5zRpnHtRFd6Yray5xSZiramVwQ6g7aOa7YKGmB4dZynzDKPqQJlaKJSWdyZqy/WWamTDwcFR7qa8dVOXz+DQbr4T9yP+4VFUML2luYAA3yuf0qHFs25oORDYh1dDG6XWeRHxdAKfKLGdXOkCcxOZi5FltuHaaFxiAQMSYoujCanuNkBhHDr7ThaYYDXstHER0lWImgK/Pze0xIwkv6yoJTuCUm7QSdZih05yNKGWB/L5P4oLu+36+2dT4zX4GXNDFGTYHRDm87C4X31jtrhWr7IKY616RlmLdrz2WlznHYVbA4OL+o7iKfxcw7He3wdm77qY9YMidaQ+gsmAB44xLAEQ9DHoPkSIVnYhnvQF7mYuYsjtwccZtWqk6dDc896w/nGOPn1EFmTHfrMb4A9ekKxdv6lvg1gyY71P3SjlEbfmOHTyDluzLqtIHuZ5QRDzODUTFPjv9BRJ/Dh76EMfYzEgyqml1Ryjnkz5xeicBzhguJ7rfQJtjB4wyCxECDYCtAtBn0ed3c2rbLOuMjxhhWtpz4O5bDyZmvnfgujNByVHncGposNXcqGvP/xEB7NQaiXMQtwZ4lBuhTkYd24Yr2WmqXOTeGsgXEmw3oT8neiUWlsKVQg2KS5Ah1Ctp7uB/EN7Mh3LAi2K1NYNSCwY40e7iJpHu6tRlzFMP5OS20OArIPkndYj83wYBjIbelwBwHCHj0zW+BiFBHwvPQ3KR7uCMvusITWzYC7A/ADDyEBoKdHptdzlamGiEoHUpMA0G61Ft4ChRR5h4SzithjrJIWKMDmNJmlvJTUYAm9nu1ZwtuePx5WNosj0Zi1oBtramKLckC+UVsINlUKJ9ApopOdGwr59PEPYqpU7/r24edM7/7Y/PU3oO84r9nf0tZq59lWv1QxnDotUWvCW94e899XvyOwqqepMYPLWmEe7KtsTa8b2I77FmIZT1FTX+ji2UHgr4bE2YT2xVwFD4ossyBuFqjhLaF4Ew0OcZrrmFrP0XHt34yAEIFENH9g4SYzRwtQl/kCL4vWUzsGnlgTDiMd0U4JvpiXPBvD18zmuR91spHFz2G03dmMGY4uoE5UgHrMLfgL4cutKBVZQSVtLa/YlNt4FvcqzyPn8WKS3YcvLMJxnagvubEFKIU1adVU06T4OCfd8SyixRFBqP0pVCRqtshgXsyHGyPN4FmynplQy1q9jevYnWrVPa4RqtPuSNbNbE67ak2Wy+RZmUTfej6GBRypCLlcEo0+Z/hDXnk5a/kPhDCdIyfZgAn5CxVOmn+yyjbcUwfLGi1A/iPpHoNrszehkp2y5ln2sUR5083TlWjpiyCBhvppkpvkewvU4+B2c9hPP6y5GtJDOUtjZIwQXTIzaMN2A05RzeQXOoaN/HXDCvmdKPpaXzpPeoAoMwf1i7VlFQBjDY4Png4BB+1E37bdcmhDyqXHfjJvrtkemY/vldE5u/iORj4wQ6jHWPbPiUomrQuXOzZwfHFvuqjMkuydQF/HovNioSPPJLuYI2GS7JaLSF6KUnPk8Lu8jYsNrKEwRt+1WUUnpFBbT1/Yz8EVHZH+dH2tX+ALxalfxg/FfNTEsR1nDLmBUik9HoiWJdtqUkqY2w3rNuMu6em5+KQt0K4y1O9nsrW8c5Wc5UIDBc1jaV9UsoUE6XSpVk2iz/UjBJ2Is3wbuHgVr+BWhLplMyme+iQlS00y2biuftJ6cVEolEqp5F7ouDovEqPZZe6LpEebDx655tcxtSaVRCizectlsQQptR/rVNDiuuMD2Uy9RA+nrJiOWBfi+SPhGJeIbHsUE05sb8xuosXAzdzRbbY9Wl0ptpZkp7W4O6+xq+vAV6PMP7oskSiJ6oQsSZwg/b7G4EgXgmPpHQ3t/ff8LtYwic/1QNC4coMD8/TwKrZ9dxaSHa7Nn0K79oA537WFz9QQCdEcSBGYF6jCsRviCInkdFso4in0MhSgzmMvG/f78LOtkjhttfoSp2WUhoIxlcVXPgDrTO1fnXNrmW5vampdXA2/lFxxQLidvk/4+4eeShJQp3ATNvil+1ZZOYwu/n00bcHMYa9iMxDVwsyVKKY9zzQv7If1iA4OQR+c9mJNsOb2OhQ9vhpvIMS2ej+PTQezsiCF/x7r4R7zfsFTAYZxqPkK7bELuBes9DdmNPMsjVudt2TPN7Cr8pbTjYHMl6ZlOuZyvHkSieGBFo6ILN0qhyvpuPTJ43yN8EXaI5vjCxPAUHXvsTMWh2dPv9s+47eafge1bBhyXXCF2cHGNwZkLmbJ4BMJcmbSGPSsrSXiFqtuRUm7MNOvQTLh0lc4V+ZF97yxdImKGjPa/PR3cH6DpdmkYmzFOdGdIxELBO0X9fgGwS33tceOiUh3AXoQddankSmAiUUohJ6+CPLo3bctLKX0RemVBVD/29MH5SnLRlPisK+ZCIOHor+4mYYgiyih5jkyyd1BDF6Rp5GPf8DkZ5JDaepMT2tNnjmSq6zsbFAhYcx4SyYTqsLR3MhfwXTj+HkNdl5+h81ScpuPW48M69qTfstZtObs+4SdXqxnGCCEHgCeVRrIncUaT6ZLaMISAP0YH8WpYf1+rNALsQTHM8TyX37dQTxoX7zcgfyvsqUdlV4JSqULcjs8jl9C9ZUexnzGWmUWrkj8oCJy+WBtfds50ozXlPchR29BBkK/cEJD2MiX4IdHEEzfg1QK6SgdL/sB0MCkZqZfUzn/XPPFKlnBlSjMHus5bVmcsxdXtsjEao/NFNMCAiyTB5P3dfkYEe9aGARiUcSmakKjyWftsyFJUVOmzqJzlAhOoIvGDGbe6CrI8J3pxfS62m7jpBBWw4UCtE07AJGjBSLYIxjm8h4a9KSfN+1CiLgufoSYP169M26QX3akddEeiccei+rLiiCTnZR3E2Kr2C2k3mQ0/rHmekEPERsUojlhr2FvYy1cRtesm/XEP1PVlziFhO2qxBe0q+faDz/AuQ4vJeA0LRsvtTRDQ1DV9EIMgCmuatj6JAhp/ztRiRhFunBu/k2l/QNNkpkWzxhYDCk28gDU7jrEkzgaAFuLIX8eFuyQOOZn7LMAPsXfkDhEbQO8z6CzHJTRYs+CPCjNGhxPAjQiaNe2WUn7QwN7IIp1+eEhBDaDDGAZwN3Qzic2MpD3vKDCU4g2g2MvmBtMPugB8ESjDCFtvJ/2eMPbz7+7lNglmBcVM7y+2EZBHN4wMzVbWgTg+SwGa9DViSL2bnjK5RAxamiZ3M4hmEi/9VdabNpmFBPkEPWgvdBe50W5M6sjlLqzt3gJi3VjXs53ccbUmmuDtNVYk/+3j1EE8aIMv/ONNkNzdXYOdWXw+B1QvV6McTNOP9SwyIhivwVVI9uyJKN0DtIDEQNb9lr4ukJMhCAxm9T1MQSe74KxuFkysdyG6sV6vouQ8eok6KgtfLR/Jh26AGR1CHl6m086TbAAooRl0wtqUbQ5+CUdILngSwjP0IpUfoEMuUyRjO/PA6aD6OUoTcHZifGwPtoyIqBiDyhr2I65aQ4Ba3DzC0ClStXgeOk6bvZaDMq68AnTR8tnkW0VnLW2JiswME+qrg3xpYCowH3DM0hLSj+vHxr1zhiCtD1Tw6WHp1IQECzjrqlLWv012nfN4NX08Nuzmre37OChUoWBCs6LWwOEb4P6cSvER3QdEo6bywZBcDxPEwhzMmPY0OYWK/Nw/n/xxKn1Y9z2k7g8WFJfCi6AUf6hTqKRowO1OZYEeX4HJ6ZgZRWSO2ksHsYbt9sr0H1979teTIWuhh6/VW2dVuZqfTkFRGO21rd2WGel6NBoeBUN5zSyQAdMw8T64lLhU140OHHWk/0cdIHhgnLbtmaPAxhCrU+GOCT1zVIaglvXoc2aleD1Ua9kDgIwHcWrmhHbSUHDqBlG6w3VcDVOfZDxtCeRoL50VjgIeJSFAjITBeRyi7nJlMAXyoxNTcR88kEtE4bRxngfHGZ//T5z+0vbXjsH/nbLpG3WizOyKWRUhA2+ypahhoGEkvq9RiCxMWDfoK5BoKiqS/6XJgyChxjma7O9JiQj1NwMxNOAsBn/RIehIy0c3e26TOXwaPMdqqCW3xO8f/BGP4DzPCbpsJNwf+RK07GKaxU+OJ5nNdDoSVF67+ORMJUkcyqO1mgS1AruurLHLD0Xy5t3Ls7EuhB4yT6lcoZDGvPUVUQk1+1aixpMtybS4ZLbULJw819hiq9wqxRy6EkVzE8FLkSSp1TUvb6q1WVtKrW3M5C4snXK2TrXQzWUBAXDkg+Ha+y4CAUtfh9YO4ar7mSM3HkVPWCByL+xOL2y8/JpRd2GlisIIad7ZFnJCE33Eb25ZpVGyjLm2jVHbuXF2/r3QMpCkruTZRBz5q9N8MJxOv1PVWuuikyEIBJDXgLphaUqmHiBWfnVx6Pj2RHDocoAbupAQpwk+iJ/pYLwEEbRA/nFCgMZlZk1v2TD7yvwqHx8Bcno+2biC7lyfHww7foiyWICxAQAA6ESc3kGzx4H0R8iJQ02tSiP34FR/hLJie0aJoLj02PmC9PSG100TW2AGbfn310QAVlMyrR4UTE1nUG6RMMmamMaj//4VNHcE4Ki4jXrRFlR1UU0p7INAq4QbMU65sbYp+6PxajiczTDPKjXOKsH34ehyj3F6c99iBWoZml61uRzRVUDnKFkyPEknK16czstAtB3JY6+6b/hsJI/kYkYr7c0uEwVDhTv1oWsTimWjJdQFfKTWz3KeWjbgRU3poMTzu+I+a4hDGsVSXhTwPh6SEPgbm9oWtRczwBB39HOVQDoZRM084ogqRNus4lizuSnScoOE7Gc5a6kmhSSo5o00MSGg4JNhRgWCM6tBSiyRRNjnSMNJayq8ZpFDlWcgckb80xb2sYZOpo294AjwDRhhoFgLgAXG+W+iJEj2eLHAdqOR7FoC159J6OfHu0i730a9fiUcYrNVenk9YQcFJlTDgAgg9h+3/FUG/CbMIHQxjeDuOuEWmhO+vUC4RXnL1BqS7f6HN0AeDd8bdbXbRuPhhKZgZ4tC9CNNAFdILgqtkwZpPShUIUTXOaMgxD1GgscEgsxhQhVTBgR8NkJu4ErINbdgeAZijxlsUeVLsSCsrDl/BGjtFc55XVFwQKSRS9939ed425oi/L7sbw9NvbBL/WRkrxDIp+uNxy8OOz2s1teU6OdTePj8rZy2sXulmc2WPPfDU4hPBBityQzKeYK2PcVGXiaYcsbkNY8QtHwWHO+myYCpXJdAMkbWTNN1CFJ0w/l1MQHq3n34ioj9h1/1RfLqMD/ljJjWfyAEgZGfYwHjuUoMARKHEFUAhFTMmtZ2Nzjh22c8r0LubkKEU4UXGaGcjeEC8uzsKLpj8eN/xIggz/Z4bQinYxQSp5mU3IA1kt831eYp2/YURGf/X2vI+cqBcHxaatyCr6bhbl3VshD6hxPv7AQ5BtPaOMJku0ZiQJyrmeIcASmaP3w7rgXPv7n/PJyPDg1CV46cZ8KUsL2cgiCoGj1XOKLyFUWfoM8BM8NsLhTE/C5TWeQik1Zr6KyA5WTiV3PaxCZtWPb9p/PlLlCEBhKIyYyS4lvE5D3YK76EuumbdHmDUb9C3xtdqNON9OUD/ol41EuvIwE28/YlXVrx0P2S6DAX6fNI/BwvrrbkZyZW4EsYrHlnwtbeUpYNnfZE+fRZ6QVtyTzN6LdOT9861Wu5OP+cuT8MP60lOfutt3S4gJZbtd9xe5CA+3c7+oTUoD/pN24GxiIpWmx9zOU8zwv6I4TepEtGPUT6SENuc0IvLwEH9jl3Eu6q6CBKdOzbKnUgGzuQxqzEzML57PZ/ftA0g9ExHoV6pCGPcnJJg4HV5HwbiQA34UQAo3TsKzg3m23MIUjZtpkFL8+uPdKNOIUQ3nYYkPZpGUIP+uqUOfyZwCMfo97A1qKJhnoiYFhfL19JAx6BJBDDKKv/UizM2aw6cYAjbUJASVRsX4xX3PO5XJNmGBNHd31afbDNvu3745a/Fx/sAmdLcTcSC5z3ZvdzVdIATy4U7XeFQC+LOxx2i0HnKIXdU6agvbC1enwFBf+SaA8mVroDt1KYuBq0Oma8c1syLU20HuoiW5bbSTyqvfSEzf/Pg/uuPbql0jyP90npTfgYF0xEFDVcXk38OiDiIsuVM6hKbkRIdazYSDS145gyoebWwoKBBSguPRwPJRuj4wf0zdKwHh3wLlrFBLT28zh1LT6QfsgoYygEDGbEbrKhmBm1UXhnu8PldD1XehMCoIPXut1vU8u/WRuh+WK9WXdz4JX4OIb3ehZpqOcxsmLTaGic2FmuDBfeSIXDqLz3un/2siuzKpFFT/fHEziepmCfzsz6/Uy7Oozl0HnhvXQ4V/+kzwzNLunCFuPgBvRUKhTDeJzUcwfTXKE0kaPNZxRFfcZk8ShbY/jawlYBgcHoatUED3SNZz4ppvbnUJPNXrywB1rDyfWuG+Wz4XJHcUPctSjhYkljfNW1T9is0H8Gfey6ejDbsEW5ViZhDwii00Evb+qwacsUNis/YdIzOOh1vJYda1fxjdYwsYVowAxB/eRyHBMnIIlQ86I9lw8MLX0dIpY4sjyergKeGeVUP9evKhzXxbXeMYK/4odKHl56KUITNCCCENOWDwiFFj28ubKdgCFXqOWt8ajPbgvz7sNP/e7OL7muIupUgkpEez1YCCZKlfwodMgCOQYg9zFD31H26JM3Ij7fElnQqEWe0816TodObkNGom+sZGA/yzPW010/tnxCmUTG1hldovSPfMnstBiNK/HcnV5QaCnT6nnK3n6maacEIG1j5cZi9KFPICC74J2y5KjljlUsLt6fJopGFF5vKr8jpPHaqjRtsxkzIHKi81Rl/ANkPpX6ZNjilySKQhGKwFpkFjXgZfBNMbrfeP141G61z2za6CYsU4MAJatzvjhpjqRo+aO+UD7sPdTw8YNDlsyvlTDw+p+RqPI1yHWBgBFoNFJCRKGYlPRp8Wvwi8DgFRRo8tL1HVP3tvIV5PeZoHGJt7Z8GmjqBIpolo0hFg0UjxO7ARDoEirtwNA3WjP0Y3y3AJ3YcF7ZGt4HEH62p0Pb8vXzNFVTpQT9cQ7MdtHVSZC4ws2AiP3xQWCs1ZzIszSUOgLOjTgBTEulQCrDA9LrNe4fqYEQ4rG+0Anfuc7zHRAp952XRQ9CFhhCxmWzaeMzeFHhOW13zjiYAeDgnRiwizz44Xgc0C5bfQHeOoZu3cD00mOIubJkCH85GhyPx8CoM7XXfvSSgSkD9I/gwTGM6SQHqmPZFDJrqzqoj3SDIJt6Txjhcp4MQCgSP4vPg+nuLkEijgLs8FQcXDqSAL3B6feeQ6YmebUEpHczJhumww69t5Vdyr1W/JMxgG4w2CnBqI8BMzMOujU9BeL9OejOuvMvEPOahjugBj3ab80bfHvVfkWMxQfbtm2rj8Db2A/muSw1DMoZQbBKZUBfxgg4rdKAz8iDvYoESxntoE1VwakRCKgLTvIuSB3rLkOsl2TBSM1pFiE8/dYo1FU3pAyNz8aFWYQcW8QiZ1lREwDFnSDvnsW9pGbHknCMURd10F85aCIj67IL8dY07YUm6friHVCmY6yZ/UILboIF54nm9jEhqNRhLXrXMQjnvOqV/OmeMQ4/DVqln6w4bHrwrNxkk90HwiZ9+Qypsv14PLB2rWoTfSiMZHKaG2CyM7lGEwC2Js7qK+VQoK78ACSYbRm8kjUOQibq0bslS78EGgNoLyvWjOf+ymQfm7gNPSjyYcLvq3i+e0aoCTAzroG5bjo/kKGDkGqCKRkcEFUWNI9hjwqGbdKU3y+ZsIOozToMtjsxdopFkacSEaSPMHu3gbJPXOkWT4AzziFllj7QtLCXC2bHtiPWH/NFcGRamtcMxy6v6dJO+cC+wmyYEUo02Ko1pO2mbYKPYEGHwO5b0nafSYLDGi/TCc5sTzbsZS0L0Gxm6h1alQXshxkCIQ7G+FSPN2Bb5eBCPLS+BgYrocIDW+lmKDigoljoa/dD+R3GZy17t5QPye7uN7Bzpeq6L4LGJw2jlwKStAMKVl8QHNqnYB2MAIxlQK/GgMkrPwSH10HsHU3oUxiW2/AuP8ctJ/vADgL/FQpTe0PckcTpRT6fw/XfgG4s7xX6ICB5l1PvwedTn1pvVZ+qd++WFpzC9kGszwxA03e9ArLzuD7k+SyDHfLsCBatIwosgrxfjmene+XP+QyjFLZWC9+NDgwCV1L38vUfNmx/dbX3ANMTK/ARfYb/EIWdm49GSZNNpxvSQv7D5MhpB0mq+3V/6XWwv1v1BuJcup+8QsN5l6yyLCxDM/pqQMKzNPjvbw+Le4+R6nJf7IuzXRe3nOSNCFjSRe9l7JQMJMDWVj/6BPLBgG/CqBTar07AOKhV86XRJSQS6vNM4pYD1W14yudjy3Bq4UcWo/Q9Cwyobdw7EvxUipLJrXVY40aAtJhJA5InTtVaJHlEHXGnPRP49R+Fm+HDItCRzzznPoJAUeZ2yNz95Vd3f8dic37ngQ/en+icTia1CmP2KXATKmOrKiGE7U8MOT2qRRQO/0ffQkBlRS98G4HJrJWac/fTIvzstejFKdYZdFiNAhmPa/0zHawhM7Xjx1Mzosp8bC8ylmi2ZW7tfPBgUAbxV3d22FPRms8f6q9Ums3HcWCywpt3n1U75ljiP65YaniCcob/s0KrkHUbi3PbdcRjaSlwtU/bG3ECQ9vsSqmeik6nb2wB9xpvvIHsdyU2xGLRDqdPi+BfXjvd5JAGxCw7mSiB39JAIbkVSzGq7i729HkHChYtd3MLCDfmWPBMBGxnR/qNFrLWiIBjOYJlqjCNCW2pWRTjAAZvGeq/mg9fi64PwVi7dFr6cJLx60Ygu+kDoyHsQ9mtRl8ff4VCeGh27y4IoEskLcbbZhMbI3diIKJPfUYm0/OeSodG161KI539sH8wVbgs6e4gek5MTSkXEjH3yxlBGn3cNMrO8BfRXzfXOh9jS1a7Ht/UCjQ+N2rSWiCWrPJlTu6pI6qmLYb2fiJj2X0i2AQP4HT1EZbr/qiWuFgnY2sHXztWE3dlx/psIGpcmvC4Cun6WfmZOVmh+DAQZ6wlzeRjUFKLx7FDrfqRtRjm11zjxeziMA42wLySSD/C2tPK5TNmcaQoU9hIS7cAPdgJnaNryXY3BM51Nu/OwqqHqkk5i12blIx5zHaspy2xxbIVjuIzyzn35XMkN8A/QHbuZrdktZLGkeRdem+VreVvWY8vnQDbp+9NHlUOvTaBTLU9bVdP6uzLr5sSN6VqxmDEhDQeBboQ0eQ+N1Trf+eSdBIxvdN1oyx7Ffu/WHJNm2P3jfQk4ZcnUZCQW9QHTgE6k9afRpfGlKiY7QaejVFSh/5ZJvVgMLgCxvOrmkXXF//12R7g/39mCO6A/9ivvVpj9TEEwTY6MenwYEK1/bs11r++pEOjRG7bhBdOb687n0+hSWeyFM1gSGUz6RSXobPp+IVSWYbbjNXFUO+Vb/h+/qsldvAbBje9t306Yznk5sFUtu/WYXyTSppoOmDztY3ZfYJwTyWCdD20O2OIwL0vuRVOJoPN2EaD1uhs8qgYupMpObrThndyZpyY7ZeboCB7PGS7dip+dWNM09vJfq7vNx9VhzX9lM23jHxPBcF2EQhBSGS7Ad9GTru4reaLx7OFQjpVLqcT4XC6oHzr9z+/8Ged2FyZ04dFjHICga1gtOVBO75Qqv9zb+TKNa9+/xIre9xhJ3zyGRDsJToS0aqBmIF12wYG/E9vbBOZ+s1zl/0LYFxhasirRiBAGDitTCcMTWQNQNqJ+OixXVPEAoCwj+aQDRRr5Re1PlrYUWsxFb4DK1WXjRkLAZ4mna3lnBTxJqwKboqeTW94n6Mj1+817XhDQtpyuK/AJnv/BOG4dWVIW//qUmtPyJCtzST9lwGxSG4HyGr+ZWlL2CRHC+vDFQCnhDHasGAoVNUlnN0rTd/670c27TXBeQNw1Zw/yQZvbNTcP8kGOWNpDD87US9FJKzdNQ+yeFxpVSz/01Cxk8v8Qh0ev4R3094jDF9sfvIZ0gIcHrv5xeIVASYU/UJ+wOcDM48YrwyKmQdjdhRe83qwCJH5nFge9hnJRDh1YkJVI/n8gefRGxTH/oLXwFCPr1cLKyUJn4X5MQeNzHr0Fl6sNxFMix6DSP5gzA6vaxvOVYLC0SWf015stdbu9vqYSa3UCafPiaTKQFQul3dtShxoOvtiXIqLGlOeYSwiIBh1uuqbMybU4FBbhSxuOL/xyB4kHw8FdOxBmPXWai4qNM6OZiWBcMGem/U4onoCbIxjpOqkA7Ock6v05ywcjq1i9h7sO9Bt032ediadAuYrhL9Wh8idgE/ZDADR2N+skoEHtikVTHSuMoS7YO9BssgfVbvrA06HxkC5t/lKMBhxWrBDEv03zrH5O310x9FT+RctMaCvbjFAkEBSrVoLy5iFp5Qzlyh6p9bU9D89Ma0cTuxoNSK96jXG5sL5E2e3/c8/AnoVD2RahD53VF5rsNe9Ex0eCuFmsUQSei/ju7bb5QtYHISjPcSFMgAPUjFIR3Pvhhqfkxtwet37WljgKI8kIYskkr1MNUXOz/kIQ7s/T7m5Pbqru5/gBGAIzX9N9gpppP4u9/75cJ69ROCoP2xS6mPj+czYw4kObL8IJQZXEeErMH7Z7nRXpnzO5zHR0HjDqovOTA/382gC1q188Iiu1Zb86Yea99G5yjhGJiJx12nxZM3hqBIYPT7DX7kUXi87aNH1v2oLO/8Oy+wN++XX400NILFenuc4X6TVxXRwmKaeFiF2qxGMHabICfJDqX282FvIkIk1oYwIRv6gVUgpe+x6saTWWcIB7Z98OmY6ZsrFYLltshBC6vGV1gcS7j0wc263VYy+gFX/3XgEjMnwQefM8BnY4RZYZQBrQXfAAEDTlAb19O5VB4Qe03laULNPRhDhiajuURQX8H5hcc2bPBYwSgv7nXYY+ZOTq3ySsU4KeBgKrHYr00xJWZvuu6USSXJU0XTwLVjQzbCmlCd0AGe5vFsTCQKzpjCKsq6E3G5XeBlG6X5Jfsoy487PhVUoK5HMqBMMN0Pj8wWnB9S3S2I+Mv4J7zEfPcmTJXQ1pcqxmvzzZbqiGT5q11bGUjnuM0FiJggI4KBNB4OYbm4SF0HFMFNY8WX7L67wluMhvqdmEcQ+d3RvkJKvsBKGkxVDoSDC4XsUezHhXwjTE/h0yHSZ9iU291bPzDRBvKjzKHqaHK9Bu3PH7/WY1vUpW4gaxcWCsQ4/Yc0ZD3AByfUf5kqhnL5hqkyjtGhOBtPOsmn6vlg1VBaXLxappb6HszkKbo3emIDJtH5NSQhgjOtjFtrChM12WGQaLc2+bTCFAg6C5z6qWFFEK82b1PrdWq3ArNWCPuxcG/a62qaarFXv9FpPbN6dTTdhU7ktHS/bPir0ULCTFINq8VjISzvAxQuo6+C3MHObi8WV7txsnbtplQk0YcfYwZcMoxtHylTuNZPRkwu0c3OJdaGcaeM3z5ts3qDfLU5uwBKN0fwEHPSmzacu3e5LrOwnnpUtwrmRj1KzhvgcG/WuATOpS/dGx5KFfwck3lw4ujDSUF5e80Ft7174/2h9s692qukZvfz+/6GI/VgeodVGO/dvp7gzOoOCepXR6NpYm7Dt+C5xPj0ND44P3JNrYqDP97hsXp22i3I9BR3mDlJ5zDdqjcHff30L8PYLcDHSTynFSSR7BankIyuuc4FVJiSgaHnlclj5NxOxQeR//x2AINtgYK9hiyHL4HDB//5DKLzvPPaQDI4FUtLcGzVP++fp4mxOe+MNB1TOoiQzUmZ2NWtjPmdwMSnzbNQOikZs6RtlS3nVVBetYn5KbSpov1xaJeY3eyaeMHICEE2wsr5Qa7p5clw/mBD0WV9vneNCwZbBVIu1FxtWgE8ep/T0IasZjyktILNER/+YNYKbkQLDBVeF64Ja29nmY4LyWSAz/qxgMf1MH2X4eQUQ1r0HS8B32PQoqHEQS6+qrhBDxkPQZrdHIBU++E5GqprBwhmFCy+7MwtCbZyvDYWliwU0Hh4PztuNqZAXqVudTdJesku/6/q3cmJsdGIqGFlS9cZemxz5otDZnNaEGLkqg7JBdAb8xyXjMJpc4lRNDWgcjWkNs+rcXKtLlN1yvz+akc1FXr8hSbFoa4if53Crbi0KR6av7KJTMZxsCUKtVk9z4aprQNXlymTyX5QpLpuf8QNpuUHn9oMTL4RE9PBbkOxBjcYAzrltxzFR5YIU0uB2WGscV+GDzmxLz+JOJy5PSi5+d3zEAgXM92Nh5LPB89mxQ6uNraCeicN8VIXak6TxWmHCBi48/zjpc0LUKDtLqd0DIvM8yt8PuglxmhrhOEJXH2NTOJ8bv+8WIBwPPX5RkSSrYk0omCNbJMSOiAMHX3jIcX+Evtag7Zh6Ygt1jBbSnGNcEKHIiQw5Vo97De3xNw0D9k8KRYVdoQY/q3dXQ9FIe0uyCDWur4BVcwqvZ85MIFYUoJblEks1ZJvXm9jD0hXgbGHx+EJ7l7PUIq1dhDcM2iLAwaghxoOTV5bJlKlWL1ibT7gNf8iCLbJkoFmAQa0IXnCYqw9psELDMlXDbPC201x3QAU9pJ8wN0AzYu6qD80ma1j4lYeTE1zjIhJhUp8ZT/qvKD+b/2Qo7ORyO/PJV0iZLJPVxHcLdYluDm8yDZvP6SeUt4xLRGZvPaswOMuJ4XfjMXgcTyR5AmeqPIl7lozROAnvAzpIvFRGXxPgcKobe73u5FRmpHcSkmqf4/3osg6GYKUJzwbQvM5tYNod04BQY0xl9LWJESjgaMiN8zleRxVaOC0lgsq1FGj499EIm4leG4H7AQcvonqQugRxwaMMW+C4KlU5L1ezZLq8k1//Y0TP5HnjG7Ut+57OF0gkxocQjiayB5KqD86shJ56fKRGJEnMc1GSFS5LdY43JdLnkiPIVz+H2XHPTLoWF2CpvL6mg8Ouq8pR5zTnkSM9yYV5LZhiZdNpsrd5pUeQJXMp6JEgbhpCyRMsMt2yKAMuVp8dBMwS4310BImv6EwnLpc6kRrCov04usrwiOcy8/TzozZj44ohdUpaSmo1Tmd9b0vTmnkm7inutFdMolQYOkP67fGIE+7TQXqcHB71exwQ8iqCGRej2WNy63hcinSF1eopOvis901+zywMnEF2e3uSkCT/yxAGBcZ6FrMPZ05rUjONLOUyQ9j3yrli3dWoAQ2KEztJ9Yt0EKfTA/gJiydYmFvGpJ1eNc4EnLkV6VTudsXZjogYp5yhaNVnukjcTaJkmS1HqE9vt4YXYjEfbKLvrEZRQN+jlUTaK8xalna95Lbp4aEpZ7l2mp6Wj+vKLwqykYBJlloqYHK5c9hlunJ9kqxgPVt9I55K0TEmqo+XQ3GeTLJMBSeLohpJrYg8RJK0sZdHE7GgpgXLfQHyOWZcRLJK12pe82KLX41drVsOrrSOHpm4elGrNfsLlbW78NnGMTNfV7Ak55fzL6ejEPZadcun1SFmDKt9ZU/EpNMmQBRlKTcoArXW2gkKsZZTjEWUMIRiuZXCsV/5WsOtLhcKXcvBsdVicR4FIZH2PjMw2sxMpxSg5MP5P1/Zg6iYJeHOhDaSdzhPdAqvMFJuuLq+SsAorMn2gbo34NKpxWuHiquoZc65gmCwQ6RQ9x6ZL9IDSfyX5AeJmK1pnPqh5B6PD7QJJCzJjd0q0RF/SwIrZC7ZMSZWkskQ5vUVmEdmZpAxE57krGgfQu0ygCFgmLRl3pEtRJkpHwqrCMWjXytTdd98+SGE57kpdapWugEwMmwoGBVGMBXeYbX1FuPqDwQnqeJWWZNGPAZRchx0lZMy+8S1ZWKdbCP2Dt0qf5IFdsPUkOVQNhe7j1dOZjoiqZTh0gnlVHKC8iqF2I3cikieJSM3zAmyXMsOiV3ZikbKZbCFmDf6pAknjhVVNqqu7VSbI8mrZD17ZVY2qi6guYEvq66MbJpkXN4aG2JxwrpzfO7EqAEycoz/EUKYruQTYBIeQEMYUvZwVxFgNhkaTUM985iG8dpRyMeteiy1eW25kgBdkouhZJW0OvdDJXdTGLNQV6cYnTGRHany36nrJH3uA3lMOeoib/dkkJOA3Zh5e9cTnlDp3iONhwMeMn322nqWO4fZQISzppMv2W1CPr7nghu14bntKsGM3nYPchz8RLjdY9taWNNYrQ+KO2CVOr5639XgA+iGDx4QrWCPP6L2Unx8RfqLk0xXxVksLSCmaEtByJ1f+vwy+4FybTkrqwz6W73y3flYWnM2s6dsFdisqDzRzs33A+WzAbhNl4FNk7rNK3ZSBlf9JXPJHbrnXcjsB8rqe26FMuhvycnsLL0ZZxtVt4qTLHWLOME8V9Av5dZwV8QiutywExYeRm1d1QgkKDhcjNqvARd/4hnp6YjAejUEyJPdsk8dJ89iaX27kmofOCpIHESpL4eskfUJ1frPm557HdbmdUUXehM9s5qCW0nyQllX5BBYJEVwBCHr29BYgxaeZSP8lF+cwG9xAPI4NC4PxwXJPTaRiFIG3RQZ7IDWj35/QH7fJ54rv+ouuuQ/Ok48VfcaeN6PuhAC/eo5v31PrU+ofc2I9Qw00hDqRQavsEp2/ykKO1glmztm91NVbzPJgVSraYusQzSNvnh7z1WeElpXsvAkKQI1I5uvXLMQ/7SF9QIER0hS32E5DZ+0Ce+hF9xTknztST2kuTDekU/YwRsNveIRGUEvyCfg0KtURPspG92fidDVEUOigrljGb4COt9kIm8QWRHg+q9dRUHNM/vYfXakab9zA35QqyfDcXhYzCVSxB+Qkb7dZ/3u7HwrCaXUE87FZHnBUO80JTjI4RcE1+LaTCYVU1k30kzFphkKs/4ceurc4LAxtsjrNdxbW/nAhlOU1eNdX+n11n6sxfsC4u0aH7h6k5PPxFCqYaO6YzPp4CaoC9+zxeeoyQD9vRJpaqkr03tqsZAOr1RQQm4jqGveYDa2LWygeRx6KD+v386TCvNwj0bvp1IQbReAN0TfqKD4QbMyWXe6m7hqH2kQ/JkmIgQTtmvLHOh+KV3Q8oNC8Hact3pw7Chtc6wc/z/t8IaWPSG/O55zE0EvyDuInQKzQaiMkHU6WzBZwecIvzcAYeCi0ugpvx0lA4AB/k4rE6dosab5t1oKgezI5pmWX8qxlasEPFTu+e3ooZlcmLsJvyhJHe7fFCsn8W1X/uBNCaV+zev5OzhAlWJD4OikUaCIMXBb8WBtsg5Hf2SzlYtvR7q3zM4D9wXgp6Rjctdv/HMFQajX/wmyQOTJY9PdM15vCpqqlXmfoXrZc53B5Dx8ZTy2M7CjU3VgoYpIkR1r7xs5UV3F0ABVx9XNjras8loAHtITcg4qoZpoqVQdSe+XjriY/CQAqtIeu4D/txbAq8Xp+qky4eewErLmIzpk8zI9phsLuKCkxiMOE4QW4zmH58gx1BvPImU7/60c3k8diMvQ4GG/6ElaRY/StGoFi4fJ0S4pHc6iftSXqxhPPGd9H9RVilVNleGAIW2nsI4wE41yYh4fDnpf5KXGlovNf+e5/NxSPx/pOWDlj1o8RxCinApdqzkUtBYrKoBWYHMYqRCwrEn3N6CtLs+q0r2Q7M+DFT4JY7EO3lIW4BzXS4VdMQtE3uPELe3jnmXahjkOVWNOhVmZrjxsy5+fQbuKc7kseh3EKW2V4KLMk1TMTHFiAcw9XRjjn+UE86Jsb9dEzMLaY6tVX6y41G1LpaPPOdxeNskB0eRFOVlUKWZBQy4AAGtJYtt/pyxRnBZRpzvK+dQBXifLegSfhe3xjTYrVItjGf3RCcLKK6pEmKFkwLCJ5KpQUlk2dtxYQupZvDEMLFqG5FSP8HMrO+0OIjQrIAWGw7KLhlbJegADgZYFqVtGwb20u8g0EK7rvrx4V3DVvTeDv8BKSFnzCWWw02nHwjFDCULzrGeSkJ3e5qDp6BqBsHXOO+TKwdKM9j5ARAhrQqstw9fgcMk1Poe7OjUJE8b6oCR5MO29AUEJa1lBd4fVvexsraWl3lyQVhjP963Z6d0Pio7TZQaIhPnrp842IrWwiYiTE1VgX9uQ+VY2SzSMSWZbTVphJIMD0Ow5eB9XTWL8PAmop5T++obLbofzUK3CZJpYgWz5iqFH4OQB8HVTuGLrsIqcj+CVPYFKfCROsBh6nARznhyd8qdNwyfyLbzt0zIKFGYrSKZ/8jwATnuT2Lj6YNN+Z58FLLfM5lOvhIIk4lFsRweIfvJI7aw8nmJexQlOnXcyAF9aApzCkJGSlu5g662K07rqJH+AfZbT4MvE5zDiHBU1bV2Qw954gBm3WD1H6nsnI85ZtXMWw0IKcj6MV6QQlCr5MCeUZrdNwIUsj4X/yOX+hGR0Uui3s2qHXHcs6dYIvH0nzzlzRRJyTAbhynVBr3y6fR9Ymvp/HIPFa2k9+bt2XBoH+BR0VJvPa+26JupoQu9oNHnPdkqtoQ3NksQVsYZw3G4JRVeLEJpm3GoCCwnNP+iqOoLiUqgBbNNYo4OFX7ay2hjvB22NulLP8FGcNUxzrXHlMCD2yJY0eEBcBoAaScXt/PxnAyO2pqCxqnzWKMTXsIEyjmlxlZwF7Fy29+goNN4cHmkB+y6FKxaLX+w7Z51Jvg98XzHt4LE7KcTdNuHXzChaav0IHJlonlU2plMp2YFJp5CuVB6JxJloXsah3eBGaPJQnuCIHKfnXKb76H2UfruTNLP7RoeR8SOGVEtnMnr2eMgxo6IrFksgj1ZVyXYY88L8dn7qTcQpQrLsBDqZbWKLypLr4VIeTVrsdrWKtPWkNHiEv7gAEUdsV/gFHGloje9skKjMWYK+022awPWY+yf7TNNB07yzAVdDqwm5Zp24kB5VrpEXWRoWraeFfW38Yus7jrS6UKACEQK3lsL5vtDB0dlvPVJKm09QnYWzkcO3IN16881UyUYdRlmXB+fIi47EYKhFgCVP3SUnypoN+0KpbDpqUSRxFNZoOpcKutzURQn+PVuy6aAloqvriTOHrUFSggbYCCJU84Ut1f0DDLqQ1yhHwhI/im+4CCshctO/wNLq7FGWpix1XkqngnaAp3OjrLGhQb7E2RNai1YeiGaqrVYKigbX3AciO/75+UovnzXJ2VqKplckvXUP9/oIYyrXm8im+2mzCbcunc7lc9UK68BokpSX8ewz09N2n4+nXLPhdKXoSAEIFjNTlQDvtAq12xAQ9oAFtDNvZ08rFFeJiBAY4k2BTBGLFhUBGfizXmLLqmDldQGfApk6vNV2+JPp9FmlYVWlU2CSQfokotWkAdYdnztWrABA/RZAEJzD2QljhJ3Ih56S5JwsYdfiXVudbwpXSrWLu8c6XF3RPvgCtMc7eKi7I592KZxg/ORJnWUe4Aek1LRe2dRdny/GDIjMwAQ5B7iU3ZTx/spz0mue9hJsZdyn9nshyjholzvbYTsXaj/0kNIWyxSSbpPBMT1kndPsKKIyUdu+0qHXO2K5TMyqlFI4lPzYWyQrikewsBb7FNjFaV+1bltwKGS6eU0luQQMpstUQXi4W41SxuM66dGpXVy8k68Xltak7Zlpe/pc1p8uLHWyXrcvWuwsrq4fqibC7CZZha8G67CFVoGlXd5sZ2lhC4JP0kmkivDh3gzQHtozBtfAod6hD2kGEpNWqLkX0G/70A+Ppx3YCP18B3Vw0J0bCpBhTg1wpvAHOBeitjD0ix4ckxxNJUpU6yMJB6he8PGcqt4Wgdg2NwXB9HdOPah4iTBkKOu1xmYLDBEQoVGqC2vQ9W6uaEAsd+f2uGTADLwpsPljx2K6Z8HYg06QtKD2PtyGr+49VSCocD2QlrMXUMbX5npsBj2fQDtg0DySeeOOUQJGmO72TSITS4J2ntrgzagZj8Pli3mAQfHVsdQq+9soTFDYA4CG8cgLJoJBtu0NcARjIW6fYPFhWVh7g8fnWq4FUcjomWNJ09ImFbwoIpC5N1z45gTIwYisjLIHZkelOShWTyM2j1NqvqJSR+vkcHrdKgpTFOctvu2pqPGYetA1nZZfxJ3jNjkKYQoDEDoxxdUtRi65zdtuSfJ6z+EEWlpaBchCoqFKjxlf/DqsCFZgnNiU+S1tGBWkHO3AqupmwMDrNhjFVre5UAJXsuXhY/WJs1/QDbz2dnZpmSV2v0Mnj9QV2hr0QDU2ZQkfyziHoeAbEglFcuo3V9DhaqYaCKxmwIKeo0ow871qcjANUT+8rMBlPVMUG6SljVOUHk9kA6ud0sQ+PSGzPecnAokEOcpw6heCdqNoJTc60npGPEpVW4ghVcwT29guUHhucact+fIqIzUOFH8nouE4vCL4umsNo5CZZZ6gStPvPWWCLKE2oUKUezmQac+NdAlC05LPBRgRYiwxbRuHJixP9AotufLaE9lRdJ+cRfQHGXEMrBC5m55woWr6hFoUCzNQUmzBrX6MXtZiN5RyP/TEqHFce20dplADtXA21ChyyrUasEQCsRoHmZqDR91GdgJQeJ6NmBbTVQYUbtkypESdc/v8AZn1jrDcVo5sClm5rdDAPY5d8jHGFNpQOnNnorY052c19jSmAHXLcood66GyfhIVOJccTre06v0uYyiW5q0QRAGq5tNJEWUSNGxVNAw4EIJYsOd+GCb8sVBgfVpUL3Oi3bPRyrKTVlbXNyp9GmzwDVSdsAXKPTXGvvjAbUC46DEqFz1RAs4NyWAPdBQHo8CfUiswn01m9HVnoRVRzOiM5RJhbxN2I/ajhN9YhZLP23CjsEg6M2XSLq1xj1XBjchtzsSkMVw3yeewfBLGetkyY1GsHE/lZESgOgAFIm+E+iPpWnWT3M4Zo/ByiT592g3PVKbQ4sev6MifCvt07iDQ400OSbkFVEgLwtJ1jwJblbjl8tttgDap/h/HYPHqEJkwy+Sjup/g1CTGMQvptY7ARjCGDI7x0Myw3uO6j0ZhHBE9OVqibva5CfoZzpArTrgdtofoUxjfY3oKaeBbOUKnsN4E26szlA28sY1Qt8TQhihTBsLUcpwbUNBSYoLkY2xuzuuwAXuS4HOEaIhZGBL/b8Ny0aGzSkEabGelivTEe6EewX+033QeGUDXXJNs1sL6IPIsNg+ZvFLzSaFjB62HmoiRsMGWfvznRzIXOIBnaehBkMPnYJA42J7QXMt9D+dz1YrLlHqsb5+Kke12cdK+Wnb5PHge3SrAdkx5Ixy5rOnAVdcXpzsqolNHhLn9qSZ39e5sxhgBD6z2KubZi+H6jG4vaUyEwaIDXH4cDnCwmRtPqzsyjoqt+bdqrgj4MozbY0Xwcb7yWT2PxrMjJol/S+fPqG8wwWYwDmuwU61Z4jfJaiSJHJ+KxPbhBe9qsRUnSI0ab93Daoinh3ByU29seIIxMm/XsznG0tSnwM/zXDiBt9ZkKTGHieccs4nrAxd12e7TeJ8DxzRCL8Oi7hmBNFR5FgiB+3ZyPoCpPRkK61sL7xWPRJIpd4tJd77SoaW0w3UovKaCUgMjyWEr2BpN8Vk1pY9EMgI4PwH3x6IxnsJNJ8eWmF2OwIzlfI7byBKr5Mz7wEAtBd14SoqUqaDF98X6+NOuQEyQChyOtuc1prHZAVaoyRXqB5CFSh1ZhUag1T8b0lRUrTZkfQZgfH2KcFAdVG0c4h942kUnQFcbiBb4D9rm9ssC3xcAujAMADR1r0A0hAlpQjgGADq1UyqpCQfAMNi8FVcVY8uOoO7Bo2emI8mizWm7PZOOaX6/VYfyIMc5i+eZSTaHQIxhGDc7LfymyBNVGwelGueeZ8amUSrHR405LP8GjF0CrHxPIwbaTm242EejM6kG+1LYbPHF49k+jhnnwV13gE5kBkj4y5ul3B4KlDwnBypUiqkky7tprSs/hcIgMfbJ6nq+arYoYgySjDPshs4gsfByyMnArX59lQm6PBA6511xawIM+k1ZVbPNTrRVvHBpiB4uvagKb8ZzAI2IOsc+l+nA2fUuh0qBQwQjlMjuoRIAuBYLboOOmVtBd3NhrplvbJ/NU+ci5fZgG8dVkbPaARIlL9ePg39Au+U6fAs3t7P2uG9vdPXxPB0Yw4oZ8+HZOU2EK1YMCoKklAk330Iv7cq6jnBdOmrVHNa5Gn54smckOzqWNR0hsGg0pGEz9Ba314qEC+mogbP/AtTsVR8iM30SHQ2J5rh+OdsKoBLTAMyZQt6n+R+87tv29YeZtyJgEpAzgoJTmG/nH5VAxAmRgxL64D4wBpAccD7NEMbHTe/HU2en50b/pL+9X9vKPpO+9Y3ZL4lrRwCXDIIA5QMRagAhDngAKB05nB80Tx7U/2QXdMf7NwjNzNj70vgL7uef94A+iAhEWPMTmdAG7Qj8h0GXVNFnnQFcIQfVX7ku0IttZXiK5EEbOFuw1537Of37rrXuugvIB7a7tUXahnkEgl6Zu3D/EALTzmQa2MBOHsVurz/QPAq5VSBwkxOTQYa3gJ8zlPVNvYFwD/fzQTBaQng9AZ9rRKs6rzR/fK19MvcI8HlBIVVefS76UyC0y4/zqdLIWzdq0KJ5Vx4k/i/JRM29IeP/VRVOyW+knd2UMUL22TLd98nN65fWvvzaYTFXngECDMEHLwXQMnDrBxNDfKUvPIWAurj6q50333njbaBYom/DS1/dJIF03wUMH8j61p/hrFyp6bxd9IpyKBj8Oj535DTglMEOaL1hqexe66nHFUmWTwKSJ5q9MSg78bve2ibmvhVSiVrXarOlUFxcFA6DMJBm3s0BBwCfjKBIDBXuYf+OTM79TB4DV7bX1BBmmQDrZkDBVpc1vdg5ZoVuVStBabFlJVH0Gx+J//9F0zjPVkp5sB/9neuyFhiC2bnG8rkBRXz8E2u0GAWs4H6hTavMVQm/FiSpID86bn28DuJSGn2tdUvmmhlI/6Eg8gtswLjLOlhraDMCQziY2g1ChRQQWrz1LdFunZsVX3rbPvT1mcYS15OWRwlAZGbfBteLvaEv8eMGPuSkW5jm7v8zkbe7wqDIRKhtFwnGS5ARMO2uXhn8fhJgYP5Qm/mEZamz7Fs/9JsOjJf9XEcTFxYu2IJXv+tDfO9n/XJsBfum7tv5sn337K1m9/wOLNDj/saatQicymyCqf5J2VylfDf9PJi6fg84ddnqrVAb9ANNjKPcj8KWOi0OW8VyeSzxuTuo85OuZpyNuVgKdCVhH8R9ajMz2tWBndp4AiLiOOyfqs7ajRWzGoEPvqqu9zV7V2mmfR5zhcYa4/GlWr+kKSqbcntW2s3pPOMGD5ADcZ1GEAXj4Nj4TEnxlCun9ly8pgAHP9jz/lCP8Fy49jY5DfRBxFGy1EC+TksclugmD9lvafAjO/DSYBu+/bpj9Rx8DHZPlA2FNMr5jTZCaSKEyQ0N8GLfJDoRmzKo4RtoQ0GTDcXi7tWZS/FYKKs+IkbcylpdcWOwug6+1XD8VN+82RTpQaMQvU9rKSG9+XKwVRhjrT87P4ETT/vnN3QIL+w41kRKc4Q7auhiuQJEVCkV47FPZyYn5x8qJT6ZvjmRlyAVEJOC0rCwbnLC0WzR9S277adnh9Leew89uLrNi0RZ6PMwybYvW9zb1NUukSffu3QSp+81sqoQdTL4VodSR/lPbfrw2VLvbjq1+eYDnWpwEId9YKZYaYlqq1w89Uimb9p1OvaiFm2Dd4EtnaAgArIqilQbqW0eQj01M5K/xp+h3ZGMg0EVFTFS5INMgenKC4K5mAaudWnneJXXpQ1Gn6oOl4KqRaa6Zu4BLXqkdtWBeNdy0KvxdwoiEYAB7cr59GP7dhwlzgxjBpAND/zzWRXc4bP32Ex9pPWw08lkguk77AQGYAj9/+tyYP1xQduCD9LNvHKOZNID4fLeuKJPHJbtQ84V3KtLAk9K9gXVBkW258IccIAoatqZfEJIrZgDEUxZpHNtEaf1STit2B/JGmy5hyXJWW/e/ZdeT57eqJPo5jVsDeZ2ltJ5iIUQMw2Lh4VcnTsbAa9JV5KWCMthtpz28mbPrVgzBcpcwdYcrQ/MrXILqOlja9HUb6VpqfQleRdEs3mn1mZZp3izNqMtzBz+h28ksvDOd+C8aiPhQJvQTCw1GihF5Lq0kO76Eoqbya/BbQomDhU9doDUwqlbA+agvQaW9NthHSp9EzO/8FR/367hKLmC8cqLyeMDKVcJtFXuTISkU4eTsX3ZXYbDOjL/2dxwgERqjGSlMbCXF0a1+P5qQ4E0AZMdD0Hg+pJ2U4Yi5ox0qSYG8peitqOY+eTmHUoHc2nrJDNaruqg32evo0sMzyWEvfpz1wiQcBUXvhHNWKJ6+v67ghZZQk6yh7ke4CgKBLZNE7XVgYziet4wLCkW9997j0z+UWOuFgXZSEXA2PaKw3S3b0SwV11vIdcJbG9KMost14k9K4dRm1Bca4NGt5CxDZbGU3VpHsmmuD4x7cPUYEfiqZYUZMqgn1F1wBzuQAudE7ZifW1kqxGQWEfsWKHgkoW8W6ARDZEHhJFGcouRzCcsPmRpJkAmmVoWktUuf+ZrjVKBba7apwovEulS4bC9jIwqyhCQqmHbq0ttj9IlLBK17Wt3s5p6f98FVetQoonCVB0MIeonRb4IhfWydv3pJGnKE1ugaTVu8VeMuEMGy2Ldb9Xc9Z1qN/UUee91spzvUHdgD+WL26eM/TzEnDBS0WeEmrs262DKc/EVbO3DlpWle1nKyOjO810YtRjuIWUFehQhsC3RBySn+Y3lpFItBMlmuXj1UzbSPwXfoalIz4itSdcwEtLNo7gKe3uvnD0P9vQZxChmCFUoIe0cWquXqukbKYZhsq6O8zf2ok4IS/GkCiza2OOBuA7YxZd1MQ6wsjLGFwKKchB5SkRlQiWBVphSIhspeysOG79XNyNTQCzKQtK9jJAmihEQp/uxCae+2kwkFYH7dD/TThq4dcZ1jlSr4CCSGRupWTjDuccBBFT6K92x8RfWlJilw7geQc0VodKQmnw8AZyANLP9K3tg+wNl5F3WfOapXdsal2htNl21hK6nDBBGLcGkduporCTmE6J8eWNYZZU7yPefc0OT5MoldUBs2b2ycSxHyfVIaTvnoHk+nR/f+GUO1v/D9zs6bjKGGEnyqahLOpmhL5luDFWNK+HEeJkK1AgDi5+uDIe3HoBRvizO1JCBGjWYxcFwCmOJednvHlsh1lB8S5gLWT0a9IbPs4GpQjnWq7iOCSMg8h3Qav1WP86lxwyzKt10C2zttqk1jUBaq21RlPgCc5Cnjn+fKrHfD12TKpaTvRj1OOBhZhUzSEzxcQiQYhwboEcma793xwakC20LyIb2wKNX1R5ILQY4vTv4eI9C+2ff6OK2OcQTNhrX92ioTmXHaIJyQigjDNQIWvdNeCJiga3RVmV1gq/sC9QPWNE11YNtm0khxZDEGu5kDiM3KZA8l94V/vxShGmCFNNTbQ/2sfzB8Zg/9sbjd+ZAIvtus1zW7a6wND6Awzok6N1hVveE0FKelUnPrTSPJ1tiKx3Y6zCs5fNIHC5uD6DQse1BOnuSEm79OhPgFLsopzrb5vbt7HaMnUvH7WynPCTS7L/9UHeu4ax4J9e1VaXy1pUGHJo7UL9tRRpZu2nn5g8I5ZLyDtpwEZJoxodYxGqmE1kPYm3U2XmMaQjSDjZbkwrMQkS0DAfL6r48ZWazZrkG58t3JPlfuIL2cRodarivWg2pn+SLKvlgpbpApMMBd/sNLVOq1wIY1ayPaCuplmjGa1k1a7UPUkP5G7Lqo1DrguNL6RFThg40WHFTlXxldVSIkJxwgigVCEfgtmTqgtaWbwe3L4l3Eq6xVAp4UNZlutq2C0TZ1rg4wa4dpNX10Y/Pgd3sKyncKbWFjqLLCu+eobBFxRBkf5OxzNon++2aIQrZYzgeuPsSE14b7QItFR6FN1oC/eD7OdnXBC5ewcptqjpQIe3VjnTSWCT4yLPUHuZYm+Vp8xYfJeDBHK765H27+a2BXxNf6+GxQa7bapdCxBFIZepFVHkizaqXFWsAj0k7Sfiaupi85g7D82VAyylBFEYXPqJOzAQ5ilANHCyPkhOywwQMjmAKfP1Gjjv+GF9vEeQKctakZH3KVqCyHCfuwXAyyBCRWl5FsK6UP/DxeGByiUS6ehwwZw7wPs6bz2tSRS58wA5VK/o1BfFIjLx3N53M6Ln24QJHscGVQOwhspDFEj/s2gx8W8Vz+4ptPU93vlFz06f6ZkRRHvBSWGLOGC581Il2Hh24vSEQThd9C3mwws1IvpMdetG1w0/fa2BGhRcVUoy0n9TLvaDQv7i3Z+ExezrVxH1UsbxO0CLRmQ8hZlh8aqAoMxUvUn8aURJqAtv/Yz3JG+YedwVIv9ed1NbE+1azPQfZtdBMK0riVnAWxsazlhTfPoo9Ido0PLmjMErNGiFdSSMRMRgv1gzmu1bWqH1MsyLesrsfYKMYO3Ykn1y//upKt8fcNkIkG9uXcTV8RseKdu11tIAG+zfRftpdZaguZrKiWYYkK/rkE9SNNcaUgbGlMWr9to7fsUSOIEiggnOP/HDAs2B1IwrV2Ettb9mJWDa7jvb6BbTNvEjuKX4Nq8Mi+sjDsCLS8yQAc04k3HSYdFTFeMVoVa0depGs7GCBKRV1QBs1sgtjjTGsYnydGNfLKBoC9wFLurCuNXuFXhs8TLLGSpla9XqnMsz2O5Y4BBDDs7o3CWgTAg0dMmFQhTYTAYmumxgwKg4TBb1SltmMNZG5sPeK8kx8fFuJJhVklA5XVAVxh10NAtip60wIlOlVEwYufWgiIOwJEwN8+rMTNQFuBWLfsUMmDggWxsQFLqtr4oHGkrnf8IHPXtnJaZzkaeD5mFtZWl7n9AVAc8Msts1paDY5arIcxsbjnWIPjD0mPtaPMxmZ8sxJaHISxu4s9lovaAonzdaC3QqHi6mJmoMJCLLT5DQLTueFeo6gqO8caSB4QF7tmQtLptVdLtTuGuT1otW0zCmAqjaIG6o5Br1BU0lhDYOnipbHLNxVoDib0XnLiV0R6WcuHKB7A8w5Ye4bndV6HggDPcLasMncrbNgjT9ug6QgvbAKxvqZMhFqdPCYiYETgxeJXAtuLTsIp5eYII/1YQzCO0JTAD7iwYF6mjMdpw4BCJhRbLApIgCxolyww3CeyHHfs9bWggmRx319nC/HQqk+4wPj5npw7CQfzcS2a3I9Hi7iEqjQAvoE6K2GiQYejHBfJCKUTt2yBsG6DpIClgOdwQekN3+25GnWxBqyIJDQ9oC5xwm7vhM8rQUM9JJXvvkVK5cQUwQvU+KgCMS1NhaJxn19WqUGy1ZbF5S/YLK0m7g5FhVrNkLMdhw2ob2zpy2uiaSPu4YnJcuJZQ4lz+QgQIhpjUMtDgsDGjDTPVa+PT28E52LbK3DCZa7gJzEQiYsb/fCkC74gdELkwleqk6g6TrUBG/gOt3O6DwLmP0cX/c+CSFmEqRDDV7QfScx5Bsf9lYFTNjExFo75mZg208S1c96gDPqeL5/CBPBiMC6EIgiFi41hLiIh/hICS60FqlAWsZIDerD6hbVIyYuoVdSiuvaJKNPVo4/h1dAkUhAkn6W7GVF+7MnZ1U1VAUNGTZilPtSQ1PcBHvzMGXaDED1Zni2+yzxPEL1sbVY44UOG2Qw7rUS1jN/hJFG8aEPGm0M5hrEQkMi6PNK400w0SSTsdRG0WLEisNK2yRI5GpfNNU0rvUVrvdV/nknN/q6FKnSzJQuA2vdYpbZ2OiAbDlysdWnzJVnnvnyFVhAgu3m1VCJXSO52KpijTNesgkmnhxmHMUUHuxnAf6sejO4pNsJlsl6z5tlNhu9xJ/XwlbHzLfAQossxlgJ45VaZjmBKrisQ7yke3lZ9/nCl77ytW/8n1f0F2lW86gpvrbEPkv1vudV/cdGm2z2gx/5oFVe06O2wevWpFmLmFaOZePbndXBcRPrpf0GVKyVeG2TLNYRlshYP3lnzEpKCVmqkyzTKTLlZOX4oHkF8yzXBSVlxlNULbDG1D5xt5LWuMfO1lVVTXU11OSufsLqn3QZ/KdDQutf0cC06YOvVCoYc4tA3uyQJIUXdY9NesCPDHE+AHfeMngm5pYwTjOYQtFQcNqPLVHeEEKw1IgkhrnwZGvggQ1mbA1WgllmzxBmGm47VsVqWJCbP0yA+4UnGBaOYIKPENbm135yG6KiY3hsuyHNxsUnJCZxSJv9ySkFUnnIcy7atoJca3ph/t/AdiJyBxe3vIKf3q5ixTnK6UTJUvSZM08+I8//8yrLD+h2sjz982FgvpUYnF+VqrVUg+f2kQqiZsaFcNxDl+tS2KOU+4grBi2s8GBFFImeVwUvuphiWTtr8rFEmzsEheZpct8vhyy+BITU11+t0PykRonnGZhnz3z/WYWDMhWYqPOk3fsMqmyk8SuM+BWMc94SE58DR1VwxA7Pnt2KyBp39sVSiVsabxndXnpkVuiB9r4oUaOVGZ1hSthDRgOdZ7J8PlT69XHL4Qu/P33FEr7888ZvKpzcryugWIu/lKjCxPRyvQX7VmAvKv3/KyqqaPqvQUMCS4oU3Wk95Y0+IWqZPSur7HLK/YdQse0srGgfuzWlpl7j+a221FpbpsxZwrJmy54jp8zzaJGiU8fWJZpLlCkbuXdsP1Nu8diPnE9MSk5JreCSy6646prrbrjpljXrNmzasr1+7O70l+Z5pw8Oj443kLWFcDa3vfL5GE54SYpmfLTPJoQfClO7XCgcicbiiWQqnVFyni4US7P+7ldtqdWPT7icb3JxeXV9c8sLoiQrqjaebOlWu9Pt+T/XWeF6KD8YT2AYxck0RZhQluVFaQJNbfqOFExJfLxoUCyRyuRDw2e30bHxCYUSFvkqk1PTGq1ObzCazBar7UY2dc7wwi9fMNKKZ3P5wq1sCrVFRH8sfi+bz5YmMlmSgjSTYzleyIuSrKiFtuuPaOO/9BoY0/b5b03kGc8BQ0RMQkpGjlBgKVEcnoqaQENLR8/AyIQpM+bzzX4dazZs2bHnwJETZy5cuXH/J5lIptKZbC5fKJbKlWpLrX58cnp2fnF5dX1zywuiJCuqphuNZqvd6fb6g+HItGwHuN4EtOU1gWEUJ9MUYUJZlhflrKrnd6SAEooGxRKpTD40PDI6Ns7tPFepUk/e7GKzVqffjBarOnu4THu8PoRnBUMMz4rGIJ4vkkylM9lcvlA0kTwLs6I8y+FkeZbHC/OsQJDmebdINBbHEz7PShNCzyIpo2cxOaVn8YLTsyQZmVmF9u4Xyw86XA9Qm2vqdV91oVgqV2pq5da3XN4ii7LtzpTq1irI2z3CDXKBu++24tyEjqGBJtSFlcKxFnMtCHa2cpWvQhVHY+Gf3EzbPuO/C3MxneuxEIbu1oL+TgrW3K3kI8E3IKuEe1CeblPJ/L6TxdwO/pgAcNdYQuj9jZwxWLwz7iIdk1Mlr2CW6ms1y/BvQKPUCltzTcbD2Aqz6ouSpy/v6ax9qURj3AhB0lkpu8nCRBfRBjS8tRWI0QhKpV/jMXn1QQW7u115f65KVdWpa2VjQ4ouTge/Zi7hxrzL2jspKZWXhx29YrD8vGRsADhpeX8SUiKkso2+ThA8/UtQX7dJgQQVMvhGjBjIUsjrVm7onGmrtV0gViMopY8NhZKSgXK4Juq5yr5fstdQMhihbHPwcDckDhA4FE/Swf6epkbrdpVbtO3+NXlO26VxpaFTey1vh+scWnPF29SCAdq7QtrCIu4kc9qxL9GTbKxyw+4S1aV6GiIGQNLdRWDQxiPVmQqaVtQ3NUt/qNI10oalFporjhuvPEHL1j4NMZ3v6Cx8qcG0XGaMU8PjSX8IksjG/5lOqlMK8Q9rwv3t8OUXvG6NmH3KI3YjHyN/hfBObuIJut30BiWsQw2CJ0eUFwOpKOUiovrYNqIXpvCLexuqJrdUb/jGL4JPHPjbVS2IqFKzbtTIKOpK4yhsiyc+KibSCpPO17cl4xqTqGSUxiVNGhnTRSr5uVy7/uB27bG03094a4eAFqr7HJUKOShCjaY36I3cR/naO3RLvC962RtTUlX6S9Bl6WAINZWMalRr0JBsiGZjfJXIaAU9LwwPLMUHhkm7e6/lkuizRD9X9HTdIKVNdU5m1Gel3ukStzQ8MYC2UVb4KrwxyMRQIReLW40BJ0ZT1wLiEz4xAjWMIWuYjeuWcalIjYyhUw3VkxQ1ck0K5jcCTj4jRBbadDmbpQaIj4+kUUPTk36nzXazX2Nf46L+Xnmy7Fsk7a5qZ0Lbt7bbfLytSSVV2i47npSPdlqdvaUjOxdvQyeA2edOJGq6X/gyM4Fvw+fuOH4uwc/z701Nu0/jkbEd/CybSasMTLExS3MoDkWLI700r+LU5H+b+Z9GZz6cuFVt9DOzWTUo7/t2sPHjHqOxWPLXeR1ld9gNdRjHNxslN2xy3BLH+hsrcA4ocRHipBQ8uuaYYgFAa9gnts9L0FZOuuUs/7vI6+J1Et0mJC8FNZnXTOBSxUCbbKxB1EftBgKmhHWQ2dO/M5dw8jat3WGkGsx4z8EqSYsZO/JYB+GgY6iCzCfiA5BaMFwCLGM0VKA8S0MVljyLhJgDABjAIxCodwXXbiZeV3u3Tpgj7zt/I76FRflxHiB+nC/cz+eBVowRLzs+t+42XLMNkQUI2vxkFYxZ0Fk2oIP6WTlO2+N86cQO4ERk+j/SY9kBFMXxGKaz/ZFNG2z9Jr4EKCeAg9nVcLdNAp38eBEUFHriZqsjCxWeqwa2XhYgSrOgx35DoQy7K9kDJc9DYJFV53x/UVKm0bSItukQYQ4AYACPgDUDlz0LEHdEoPHJMxNXLG6bmsfp8QtGNisj0MM9IX3eUfF18xtIQA0NO2cyUys1W/GQbvZpHTJpfpQt0JRss2WPNIeubwR5+FNYgOubocm64LGCYwQAzIHTUg10m6PgecMvOMQAasgwrJiNFcLdfS2UdIqfJfjoTrCTlmqG3HUBAMBcgFTcxtzy86ETOs+3OWY5LYxQGoZhxVRAhi0hWTJGXOcQZ7AdtA1vk06ujII6gOXXb9ReR0kl30NdVaArD5KraL7FE4ITb3lMeFqb1i4aHRHHqoy5jnkuiFf5DQFAQoU0cRMBEiqkir6wX3rmTD4sf8Ww04pkj3YTEFEdm4QIE8q4kEob1+ssBiDChDIupMp72geloX3/H//v/3/58etc9x+4fEAH/FHO+WvIf/Gv3FLd5AEdcK/zElAQYUIZF1Jl//5Of9Fsjbveb3EfHrsUSPx9y27413P1xq5oskz5fR/3WiibjlDR3xicdlrqa2BBVAgXJkVoUVaMFxclZMlZQhs33xnGforG0E7T6lFt2bLXuxwUJDLntLSG1uhsxHsOPKolGbLR6TSWHrVFLVp0GiLztKSvvq9Eks+2ZelhW8OKzWCWfFVD6+Vr3PNccFSLOmSjswELFiw4RcleslKlaunSpUubMmXKuLFvW280htbo3PO266a20FJmq0r0/Ie7s/iYnaPBoKfnvrrxvRvyGlAw6YyiT60xuCvr2+Gbus82x7iYSdbZEmjTK1xmzrmiTMyLf7XtGrYtH9ABp5x+cRxyZ5cHdMCdOeewmFff5z2iHm77kN21FjpoJjAY9JXOkDvrksIk9WwlmYMb7/Lym4Vzf6Zfi2sKokK4MPlDvmw14MU/WovibPHpdhWzZR/3praMv92LixLyKr9wo8YYqlNrdMYhc3LS1Ba18Bv+hA8EauJOCkOLAYgw415sCmHGY1KFqug0wiZuehjXi82IyEwKzgLYUasDqbSJmxNSZZ/+4axpPeHr8WIfb5PauF5sPoAIE8q4kEob14vNBUgo4+IpfyOQDkSYUMZF5u/zk4W+OktEX1Bfk9LG9WIvLpfqbJTK5D3jg/g/hKAkctq5i/A3waNX9mfdYz5tKwjIeMbndtXZA5UqX+T7yo/Yd61Zs+QygwuptIk7PYxzviKQShvXi80EiDCh3oc9s654N226EFJp43q5f/W/Sp/bptVA4l//FhY7J866LAhlXEiljRebj7CIzB0336cb0BaodM2D592P3HetW/d6ny8/YnPp1XzzHCDChHEhlTauF5sBEGFCGRdSaeN6sZmQ+OlduwUu9H3RR+zhlSZDKEs/bYd+s+KIbc1MVPbZIswRZXozpXysJiHChDIupNLG9WKzASJMKONCKm1cLzYHIMKEMi6k0sb1YvMCRJhQxoVU2rhebD6AKPk0A+qSFJkqGBdS6W6i5XmeZ+3jNpI//dDbApUqX+T7ko/Yd61SpcpUGBdSaQOZrJVyGLnyY9+sj1D/75sC6/+DS8UG/uhIAu0YPzROk8DKjlLQupob9O3SLBsUZjclwfP84O9vhzzHC8QN5vJjHAAM4BG4egwp/rg9SwAAAAA=) format("woff2");font-weight:100 900;font-display:swap}@layer primedesign.tokens,primedesign.base,primedesign.components,primedesign.commerce,primedesign.advanced,primedesign.ai;@layer primedesign.tokens{:root{--pd-brand-50: #f7f6fd;--pd-brand-100: #efeefc;--pd-brand-200: #d6d3f7;--pd-brand-300: #b7b0f0;--pd-brand-400: #897fe7;--pd-brand-500: #6254df;--pd-brand-600: #5347be;--pd-brand-700: #453b9c;--pd-brand-800: #362e7b;--pd-brand-900: #272259;--pd-brand-950: #1b183e;--pd-brand: #6254df;--pd-on-brand: #ffffff;--pd-radius: 16px;--pd-font: Vazirmatn, Tahoma, system-ui, sans-serif;--pd-control-height: 2.75rem}:root{--pd-space-0:0;--pd-space-1:.25rem;--pd-space-2:.5rem;--pd-space-3:.75rem;--pd-space-4:1rem;--pd-space-5:1.25rem;--pd-space-6:1.5rem;--pd-space-8:2rem;--pd-space-10:2.5rem;--pd-space-12:3rem;--pd-space-16:4rem;--pd-shadow:0 12px 40px #182c4810;--pd-shadow-lg:0 24px 80px #12234526;--pd-focus:0 0 0 3px color-mix(in srgb,var(--pd-brand),transparent 72%);--pd-motion:.16s}:root,[data-pd-theme=light]{color-scheme:light;--pd-bg:#f7f8fc;--pd-surface:#ffffff;--pd-elevated:#ffffff;--pd-muted:#f0f2f7;--pd-text:#17233b;--pd-secondary:#52617a;--pd-border:#dce2ed;--pd-input-border:#8290a5;--pd-success:#13714b;--pd-success-bg:#e5f6ed;--pd-danger:#b42338;--pd-danger-bg:#fff0f1;--pd-warning:#855100;--pd-warning-bg:#fff4d7;--pd-info:#1556a2;--pd-info-bg:#eaf2ff}[data-pd-theme=dark]{color-scheme:dark;--pd-bg:#101725;--pd-surface:#182133;--pd-elevated:#212d43;--pd-muted:#253147;--pd-text:#f0f4fc;--pd-secondary:#b3c1d6;--pd-border:#35455e;--pd-input-border:#7688a5;--pd-success:#77e0af;--pd-success-bg:#173c31;--pd-danger:#ff9ba8;--pd-danger-bg:#492333;--pd-warning:#f7d285;--pd-warning-bg:#40351e;--pd-info:#9ac5ff;--pd-info-bg:#1b3555}[data-pd-density=compact]{--pd-control-height:2.25rem}}@layer primedesign.base{.pd-root{font-family:var(--pd-font);font-size:14px;line-height:1.65;color:var(--pd-text);background:var(--pd-bg);text-rendering:optimizeLegibility;-webkit-font-smoothing:antialiased;--pd-brand-soft: color-mix(in srgb, var(--pd-brand) 9%, var(--pd-surface));--pd-brand-text: var(--pd-brand-700)}.pd-root[data-pd-theme=dark]{--pd-brand-soft: color-mix(in srgb, var(--pd-brand) 18%, var(--pd-surface));--pd-brand-text: var(--pd-brand-300)}.pd-root *,.pd-root *:before,.pd-root *:after{box-sizing:border-box}.pd-root :where(button,input,select,textarea){font:inherit;color:inherit}.pd-root :where(button,a,input,select,textarea,summary){-webkit-tap-highlight-color:transparent}.pd-root :where(button){cursor:pointer}.pd-root :where(button:disabled,[aria-disabled=true]){cursor:not-allowed}.pd-root :where(button:disabled){opacity:.5}.pd-root :where(a){color:inherit;text-decoration:none}.pd-root :where(h1,h2,h3,h4,p,figure){margin:0}.pd-root :where(h1,h2,h3,h4){font-weight:750;line-height:1.45}.pd-root :where(h1){font-size:clamp(1.65rem,3vw,2.2rem)}.pd-root :where(h2){font-size:1.4rem}.pd-root :where(h3){font-size:1rem}.pd-root :where(small){font-size:12px;color:var(--pd-secondary)}.pd-root :where(img,svg){vertical-align:middle;flex-shrink:0}.pd-root :where(img){max-width:100%}.pd-root :where(:focus-visible){outline:2px solid var(--pd-brand);outline-offset:3px}.pd-root ::selection{background:var(--pd-brand-soft)}.pd-root :where(ul,ol){margin:0;padding:0;list-style:none}.pd-root :where(fieldset){border:0;margin:0;padding:0;min-inline-size:0}.pd-root :where([hidden]){display:none!important}.pd-sr-only{position:absolute!important;width:1px;height:1px;padding:0!important;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap;border:0!important}.pd-container{width:min(100% - 3rem,1280px);margin-inline:auto}.pd-full{width:100%}.pd-grid>*{min-width:0}.pd-stack>*{min-width:0}.pd-text-danger{color:var(--pd-danger)!important}.pd-text-success{color:var(--pd-success)!important}.pd-text-warning{color:var(--pd-warning)!important}.pd-root code,.pd-root kbd{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}@media(prefers-reduced-motion:reduce){.pd-root *,.pd-root *:before,.pd-root *:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}@media(forced-colors:active){.pd-button,.pd-card,.pd-input-wrap,.pd-badge,.pd-dialog,.pd-product-card{border:1px solid ButtonText}.pd-skeleton{background:GrayText}.pd-switch-track{border:1px solid ButtonText}}}@layer primedesign.components{.pd-button{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;min-height:var(--pd-control-height);padding:.55rem 1rem;border:1px solid transparent;border-radius:calc(var(--pd-radius) * .62);font-weight:650;font-size:.875rem;line-height:1.4;white-space:nowrap;transition:background var(--pd-motion),box-shadow var(--pd-motion),transform var(--pd-motion);text-decoration:none}.pd-button:active:not(:disabled){transform:translateY(1px)}.pd-button--solid{background:var(--pd-brand);color:var(--pd-on-brand);box-shadow:0 3px 8px color-mix(in srgb,var(--pd-brand),transparent 82%)}.pd-button--solid:hover:not(:disabled){background:color-mix(in srgb,var(--pd-brand),#000 12%)}.pd-button--soft{background:var(--pd-brand-soft);color:var(--pd-brand-text)}.pd-button--soft:hover{background:color-mix(in srgb,var(--pd-brand),var(--pd-surface) 84%)}.pd-button--outline{background:var(--pd-surface);border-color:var(--pd-border);color:var(--pd-text);box-shadow:0 1px 2px #00000006}.pd-button--outline:hover:not(:disabled){background:var(--pd-muted)}.pd-button--ghost{background:transparent;color:var(--pd-secondary)}.pd-button--ghost:hover:not(:disabled){background:var(--pd-muted);color:var(--pd-text)}.pd-button--danger{background:var(--pd-danger);color:var(--pd-surface)}.pd-button--sm{min-height:34px;font-size:12px;padding:.35rem .7rem;border-radius:calc(var(--pd-radius) * .5)}.pd-button--lg{min-height:50px;font-size:15px;padding:.7rem 1.4rem}.pd-icon-button{padding:.55rem;aspect-ratio:1}.pd-icon-button.pd-button--sm{padding:.4rem}.pd-button[aria-disabled=true]{opacity:.6}.pd-button-group{display:flex;gap:.5rem;flex-wrap:wrap}.pd-field{display:flex;flex-direction:column;gap:.4rem;min-width:0}.pd-label{display:flex;align-items:center;gap:.35rem;font-size:.8rem;font-weight:650}.pd-label small{margin-inline-start:auto}.pd-required{color:var(--pd-danger)}.pd-description{font-size:12px;color:var(--pd-secondary);line-height:1.8}.pd-error{font-size:12px;color:var(--pd-danger);line-height:1.8}.pd-input-wrap{display:flex;align-items:center;min-height:var(--pd-control-height);background:var(--pd-surface);border:1px solid var(--pd-input-border);border-radius:calc(var(--pd-radius) * .62);transition:box-shadow var(--pd-motion),border-color var(--pd-motion);overflow:hidden}.pd-input-wrap:focus-within{box-shadow:var(--pd-focus);border-color:var(--pd-brand)}.pd-input{width:100%;min-width:0;min-height:calc(var(--pd-control-height) - 2px);border:0;background:transparent;padding:.55rem .8rem;font-size:13px;outline:none!important}.pd-input::placeholder,.pd-textarea::placeholder{color:var(--pd-secondary);opacity:.85}.pd-input-adornment{display:flex;align-items:center;justify-content:center;color:var(--pd-secondary);padding-inline:.6rem}.pd-input-adornment:has(.pd-button){padding-inline:.15rem}.pd-input-adornment+.pd-input{padding-inline-start:0}.pd-input-wrap:has(.pd-input-adornment:last-child) .pd-input{padding-inline-end:.3rem}.pd-invalid{border-color:var(--pd-danger)}.pd-disabled{background:var(--pd-muted);opacity:.65}.pd-textarea{width:100%;resize:vertical;min-height:90px;padding:.7rem .8rem;border:1px solid var(--pd-input-border);border-radius:calc(var(--pd-radius) * .62);background:var(--pd-surface);font-size:13px}.pd-textarea:focus{box-shadow:var(--pd-focus);outline:none;border-color:var(--pd-brand)}.pd-select-wrap{position:relative}.pd-select{-webkit-appearance:none;-moz-appearance:none;appearance:none;width:100%;min-height:var(--pd-control-height);padding:.5rem .75rem;padding-inline-end:2rem;border:1px solid var(--pd-input-border);border-radius:calc(var(--pd-radius) * .62);background:var(--pd-surface);font-size:13px}.pd-select-wrap>svg{position:absolute;inset-inline-end:.6rem;top:50%;transform:translateY(-50%);pointer-events:none;width:16px}.pd-check{display:flex;align-items:flex-start;gap:.6rem;font-size:13px;cursor:pointer}.pd-check input{width:17px;height:17px;accent-color:var(--pd-brand);margin:3px 0 0;flex-shrink:0}.pd-check small,.pd-switch small{display:block;font-weight:400}.pd-radio-group{display:flex;flex-direction:column;gap:.8rem}.pd-radio-group legend{margin-bottom:.6rem}.pd-switch{display:flex;align-items:center;gap:.7rem;position:relative;cursor:pointer;font-size:13px}.pd-switch input{position:absolute;width:1px;height:1px;opacity:0}.pd-switch-track{width:38px;height:22px;border-radius:20px;background:var(--pd-input-border);position:relative;flex-shrink:0;transition:background var(--pd-motion)}.pd-switch-track:before{content:"";position:absolute;width:16px;height:16px;border-radius:50%;background:#fff;top:3px;inset-inline-start:3px;transition:inset-inline-start var(--pd-motion)}.pd-switch input:checked+.pd-switch-track{background:var(--pd-brand)}.pd-switch input:checked+.pd-switch-track:before{inset-inline-start:19px}.pd-switch input:focus-visible+.pd-switch-track{outline:2px solid var(--pd-brand);outline-offset:3px}.pd-switch:has(input:disabled){opacity:.5;cursor:not-allowed}.pd-slider{accent-color:var(--pd-brand);width:100%;height:30px}.pd-field-value{margin-inline-start:auto;color:var(--pd-brand-text);font-variant-numeric:tabular-nums}.pd-otp{letter-spacing:.6em;text-align:center;font-size:22px;font-variant-numeric:tabular-nums}.pd-color-picker{display:flex;align-items:center;gap:.75rem}.pd-color-picker input{width:42px;height:36px;border:0;padding:3px;background:var(--pd-muted);border-radius:8px}.pd-inline-edit{display:flex;gap:.5rem;align-items:start}.pd-password-strength{display:grid;gap:.3rem}.pd-card{background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:var(--pd-radius);box-shadow:0 1px 3px #13233b04;overflow:hidden}.pd-card-header,.pd-card-body,.pd-card-footer{padding:1.25rem}.pd-card-header{border-bottom:1px solid var(--pd-border)}.pd-card-footer{border-top:1px solid var(--pd-border);display:flex;align-items:center;justify-content:space-between;gap:.75rem}.pd-badge{display:inline-flex;align-items:center;gap:.35rem;max-width:100%;padding:.15rem .55rem;border-radius:6px;font-size:10px;line-height:1.8;font-weight:650;white-space:nowrap;background:var(--pd-muted);color:var(--pd-secondary)}.pd-badge>i{width:5px;height:5px;background:currentColor;border-radius:50%}.pd-tone-brand{background:var(--pd-brand-soft);color:var(--pd-brand-text)}.pd-tone-success{background:var(--pd-success-bg);color:var(--pd-success)}.pd-tone-warning{background:var(--pd-warning-bg);color:var(--pd-warning)}.pd-tone-danger{background:var(--pd-danger-bg);color:var(--pd-danger)}.pd-tone-info{background:var(--pd-info-bg);color:var(--pd-info)}.pd-alert{padding:1rem;border:1px solid color-mix(in srgb,currentColor,transparent 80%);border-radius:calc(var(--pd-radius) * .7);display:flex;align-items:flex-start;gap:.7rem;font-size:13px}.pd-alert>div{flex:1}.pd-alert strong{display:block;margin-bottom:.15rem}.pd-alert>.pd-button{margin:-.3rem}.pd-avatar{display:inline-grid;place-items:center;border-radius:50%;background:var(--pd-brand-soft);color:var(--pd-brand-text);font-weight:700;overflow:hidden;flex-shrink:0;border:2px solid var(--pd-surface)}.pd-avatar img{width:100%;height:100%;object-fit:cover}.pd-avatar--sm{width:32px;height:32px;font-size:11px}.pd-avatar--md{width:42px;height:42px;font-size:13px}.pd-avatar--lg{width:64px;height:64px;font-size:20px}.pd-avatar-group{display:flex;padding-inline-start:10px}.pd-avatar-group>.pd-avatar{margin-inline-start:-10px}.pd-skeleton{display:block;width:100%;height:14px;border-radius:6px;background:linear-gradient(90deg,var(--pd-muted),var(--pd-border),var(--pd-muted));background-size:220% 100%;animation:pd-shimmer 1.8s ease-in-out infinite}.pd-spinner{display:inline-block;width:18px;height:18px;border:2px solid currentColor;border-inline-end-color:transparent;border-radius:50%;animation:pd-spin .7s linear infinite;flex-shrink:0}.pd-progress{width:100%;height:6px;background:var(--pd-muted);border-radius:20px;overflow:hidden}.pd-progress>span{display:block;height:100%;background:var(--pd-brand);border-radius:inherit;transition:width .2s}.pd-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:.7rem;padding:3rem 1.5rem}.pd-empty-icon{display:grid;place-items:center;width:64px;height:64px;background:var(--pd-muted);color:var(--pd-secondary);border:1px solid var(--pd-border);border-radius:20px;margin-bottom:.3rem}.pd-empty>strong{font-size:15px}.pd-empty>p{max-width:32ch;color:var(--pd-secondary);font-size:13px}.pd-divider{display:flex;align-items:center;gap:1rem;color:var(--pd-secondary);font-size:12px}.pd-divider:before,.pd-divider:after{content:"";flex:1;height:1px;background:var(--pd-border)}.pd-kbd{display:inline-block;border:1px solid var(--pd-border);border-bottom-width:2px;background:var(--pd-surface);padding:.1rem .35rem;border-radius:4px;font-size:11px;line-height:1.5}.pd-countdown{font-variant-numeric:tabular-nums;font-size:1.3rem;font-weight:700}.pd-dialog{padding:0;border:1px solid var(--pd-border);border-radius:calc(var(--pd-radius) * 1.2);color:var(--pd-text);background:var(--pd-surface);width:min(560px,calc(100vw - 32px));max-height:calc(100dvh - 32px);box-shadow:var(--pd-shadow-lg);overflow:auto;overscroll-behavior:contain}.pd-dialog::backdrop{background:#10172c70;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}.pd-dialog--sm{width:min(380px,calc(100vw - 32px))}.pd-dialog--lg{width:min(900px,calc(100vw - 32px))}.pd-dialog--full{width:calc(100vw - 32px);height:calc(100dvh - 32px)}.pd-dialog--end,.pd-dialog--start{margin-block:0;height:100dvh;max-height:100dvh;border-radius:0;max-width:calc(100vw - 24px)}.pd-dialog--end{margin-inline-start:auto;margin-inline-end:0}.pd-dialog--start{margin-inline-end:auto;margin-inline-start:0}.pd-dialog--bottom{margin-block-start:auto;margin-block-end:0;width:100%;max-width:100%;border-radius:24px 24px 0 0}.pd-dialog-head{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;padding:1.25rem;border-bottom:1px solid var(--pd-border)}.pd-dialog-head h2{font-size:16px}.pd-dialog-head p{font-size:12px;color:var(--pd-secondary);margin-top:.4rem}.pd-dialog-body{padding:1.5rem}.pd-dialog-footer{display:flex;justify-content:flex-end;gap:.6rem;padding:1rem 1.5rem;border-top:1px solid var(--pd-border);background:var(--pd-bg)}.pd-popover-anchor{display:inline-flex}.pd-popover-trigger{padding:0;border:0;background:transparent;border-radius:8px}.pd-popover{position:fixed;z-index:80;min-width:220px;max-width:min(360px,calc(100vw - 16px));background:var(--pd-elevated);color:var(--pd-text);border:1px solid var(--pd-border);border-radius:calc(var(--pd-radius) * .7);padding:.5rem;box-shadow:var(--pd-shadow-lg);overflow:auto}.pd-menu{display:grid;gap:3px}.pd-menu-item{display:flex;align-items:center;gap:.6rem;padding:.65rem .7rem;border:0;border-radius:7px;background:transparent;text-align:start;width:100%;font-size:13px}.pd-menu-item:hover,.pd-menu-item:focus{background:var(--pd-muted)}.pd-tooltip-wrap{position:relative;display:inline-flex}.pd-tooltip{display:none;position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--pd-text);color:var(--pd-surface);font-size:11px;white-space:nowrap;padding:.3rem .6rem;border-radius:6px;z-index:90;pointer-events:none}.pd-tooltip-wrap:hover .pd-tooltip,.pd-tooltip-wrap:focus-within .pd-tooltip{display:block}.pd-toaster{position:fixed;inset-inline-end:24px;bottom:24px;z-index:1000;max-width:calc(100vw - 48px);width:360px;pointer-events:none}.pd-toast-list{display:grid;gap:.65rem}.pd-toast{display:flex;align-items:start;gap:.75rem;padding:1rem;border:1px solid var(--pd-border);border-radius:12px;background:var(--pd-elevated);color:var(--pd-text);box-shadow:var(--pd-shadow-lg);pointer-events:auto}.pd-toast>div{flex:1}.pd-toast strong{font-size:13px}.pd-toast p{color:var(--pd-secondary);font-size:12px;margin-top:.25rem}.pd-toast>.pd-button{margin:-.3rem}.pd-toast.pd-tone-success>svg{color:var(--pd-success)}.pd-toast.pd-tone-danger>svg{color:var(--pd-danger)}.pd-tab-list{display:flex;align-items:center;gap:1.25rem;border-bottom:1px solid var(--pd-border);overflow-x:auto}.pd-tab-list>button{padding:.8rem .1rem;border:0;border-bottom:2px solid transparent;background:transparent;color:var(--pd-secondary);display:flex;align-items:center;gap:.5rem;font-size:13px;white-space:nowrap}.pd-tab-list>button[aria-selected=true]{color:var(--pd-brand-text);border-bottom-color:var(--pd-brand);font-weight:700}.pd-tab-panel{padding-block:1.25rem}.pd-tabs--pills .pd-tab-list{border:0;background:var(--pd-muted);padding:4px;border-radius:10px;gap:4px;width:fit-content}.pd-tabs--pills .pd-tab-list>button{padding:.4rem .8rem;border:0;border-radius:7px}.pd-tabs--pills .pd-tab-list>button[aria-selected=true]{background:var(--pd-surface);box-shadow:0 1px 4px #0000000c}.pd-segmented{display:inline-flex;background:var(--pd-muted);padding:4px;border-radius:10px;gap:3px}.pd-segmented label{position:relative;cursor:pointer}.pd-segmented input{position:absolute;width:1px;height:1px;opacity:0}.pd-segmented span{display:block;padding:.35rem .8rem;border-radius:7px;font-size:12px;color:var(--pd-secondary)}.pd-segmented input:checked+span{background:var(--pd-surface);color:var(--pd-text);box-shadow:0 1px 4px #0000000b}.pd-segmented input:focus-visible+span{outline:2px solid var(--pd-brand)}.pd-accordion{border:1px solid var(--pd-border);border-radius:var(--pd-radius);overflow:hidden}.pd-accordion>div+div{border-top:1px solid var(--pd-border)}.pd-accordion h3{margin:0}.pd-accordion h3>button{display:flex;align-items:center;justify-content:space-between;gap:1rem;width:100%;padding:1rem 1.2rem;text-align:start;background:var(--pd-surface);border:0;font-size:13px;font-weight:650}.pd-accordion h3>button[aria-expanded=true]>svg{transform:rotate(180deg)}.pd-accordion [role=region]{padding:0 1.2rem 1.2rem;background:var(--pd-surface);color:var(--pd-secondary);font-size:13px}.pd-breadcrumb ol{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap}.pd-breadcrumb li{display:flex;align-items:center;gap:.5rem;color:var(--pd-secondary);font-size:11px}.pd-breadcrumb [aria-current=page]{color:var(--pd-text)}[dir=ltr] .pd-breadcrumb svg{transform:rotate(180deg)}.pd-pagination{display:flex;align-items:center;gap:.25rem}.pd-pagination>.pd-button{min-width:32px}.pd-pagination>span{padding-inline:.35rem;color:var(--pd-secondary)}.pd-side-nav ul{display:grid;gap:.3rem}.pd-side-nav li>a,.pd-side-nav li>button{display:flex;align-items:center;gap:.75rem;width:100%;padding:.65rem .8rem;border-radius:9px;color:var(--pd-secondary);font-size:13px;border:0;background:transparent;text-align:start}.pd-side-nav li>a:hover,.pd-side-nav li>button:hover{background:var(--pd-muted)}.pd-side-nav [aria-current=page]{background:var(--pd-brand-soft);color:var(--pd-brand-text);font-weight:650}.pd-side-nav li .pd-badge{margin-inline-start:auto}.pd-side-nav .pd-side-nav{padding-inline-start:1.5rem;margin-block:.2rem}.pd-side-nav--collapsed li>a>span,.pd-side-nav--collapsed li>button>span{display:none}.pd-stepper{display:flex;gap:1rem;flex-wrap:wrap}.pd-stepper>li{display:flex;align-items:center;gap:.7rem;flex:1;position:relative;min-width:110px}.pd-step-number{display:grid;place-items:center;width:32px;height:32px;border:1px solid var(--pd-border);background:var(--pd-muted);border-radius:50%;font-size:12px;flex-shrink:0}.pd-stepper [data-state=current] .pd-step-number{background:var(--pd-brand);color:var(--pd-on-brand);border-color:var(--pd-brand)}.pd-stepper [data-state=done] .pd-step-number{background:var(--pd-success-bg);color:var(--pd-success)}.pd-stepper strong{font-size:12px}.pd-stepper small{display:block;font-size:10px}.pd-timeline{display:grid;gap:1.5rem;padding:.25rem}.pd-timeline>li{display:flex;gap:.8rem;position:relative}.pd-timeline>li:not(:last-child):before{content:"";position:absolute;inset-inline-start:13px;top:28px;bottom:-1.5rem;width:1px;background:var(--pd-border)}.pd-timeline-dot{display:grid;place-items:center;width:28px;height:28px;border-radius:50%;background:var(--pd-brand-soft);color:var(--pd-brand-text);z-index:1;flex-shrink:0}.pd-timeline strong{font-size:13px}.pd-timeline p{font-size:12px;color:var(--pd-secondary);margin-block:.25rem}.pd-tree{display:grid;gap:.5rem}.pd-tree details{padding-inline-start:1rem}.pd-tree summary{cursor:pointer;font-size:13px;padding:.4rem}.pd-combobox{position:relative}.pd-options{position:absolute;top:100%;margin-top:.35rem!important;inset-inline:0;max-height:260px;overflow:auto;z-index:20;background:var(--pd-elevated);border:1px solid var(--pd-border);border-radius:10px;box-shadow:var(--pd-shadow-lg);padding:.35rem!important}.pd-options>[role=option]{display:flex;align-items:center;justify-content:space-between;gap:.6rem;padding:.6rem .7rem;border-radius:6px;cursor:pointer;font-size:13px}.pd-options small{display:block}.pd-options>[data-active=true],.pd-options>[aria-selected=true]{background:var(--pd-brand-soft);color:var(--pd-brand-text)}.pd-options>[aria-disabled=true]{opacity:.4;cursor:not-allowed}.pd-options-empty{padding:1rem;text-align:center;font-size:12px;color:var(--pd-secondary)}.pd-multiselect{border:1px solid var(--pd-border)!important;border-radius:12px;padding:.8rem!important}.pd-multiselect legend{padding-inline:.4rem}.pd-multiselect-options{display:grid;gap:.65rem;max-height:200px;overflow:auto;margin-top:.8rem}.pd-tag-input{display:flex;align-items:center;gap:.4rem;flex-wrap:wrap;padding:.45rem;border:1px solid var(--pd-input-border);border-radius:10px;background:var(--pd-surface)}.pd-tag-input input{border:0;outline:none;background:none;min-width:80px;flex:1;font-size:13px;padding:.2rem}.pd-tag{display:flex;align-items:center;gap:.35rem;background:var(--pd-brand-soft);color:var(--pd-brand-text);font-size:12px;padding:.15rem .45rem;border-radius:5px}.pd-tag button{background:none;border:0;padding:0;display:flex}.pd-rating{display:inline-flex;align-items:center;gap:.25rem;color:var(--pd-warning);font-size:11px;line-height:1}.pd-rating-input{display:flex;gap:.35rem}.pd-rating-input>label{position:relative;color:var(--pd-input-border);cursor:pointer}.pd-rating-input>label[data-selected=true]{color:var(--pd-warning)}.pd-rating-input input{position:absolute;width:1px;height:1px;opacity:0}.pd-rating-input input:focus-visible+svg{outline:2px solid var(--pd-brand);outline-offset:3px}.pd-chip-group{display:flex;gap:.4rem;flex-wrap:wrap}.pd-command-list{margin-top:.75rem!important;max-height:300px;overflow:auto;display:grid;gap:4px}.pd-command-list>li{display:flex;align-items:center;gap:.75rem;padding:.7rem;border-radius:8px;cursor:pointer;font-size:13px}.pd-command-list>li[aria-selected=true]{background:var(--pd-brand-soft);color:var(--pd-brand-text)}.pd-command-list small{display:block}.pd-calendar{width:100%;max-width:330px;margin-inline:auto}.pd-calendar-head{display:flex;align-items:center;justify-content:space-between;gap:.5rem;margin-bottom:.7rem}.pd-calendar-head strong{font-size:14px}.pd-calendar-selects{display:flex;gap:.5rem;margin-bottom:.75rem}.pd-calendar-selects>.pd-field{flex:1}.pd-calendar-selects .pd-select{min-height:32px;font-size:11px}.pd-calendar table{border-collapse:collapse;width:100%;table-layout:fixed}.pd-calendar th{font-size:11px;font-weight:500;color:var(--pd-secondary);padding-block:.5rem}.pd-calendar td{padding:2px;text-align:center}.pd-calendar td>button{width:100%;aspect-ratio:1;border:0;border-radius:8px;background:transparent;font-size:12px;color:var(--pd-text)}.pd-calendar td>button:hover{background:var(--pd-muted)}.pd-calendar td[aria-selected=true]>button{background:var(--pd-brand);color:var(--pd-on-brand)}.pd-calendar td>button[aria-current=date]{box-shadow:inset 0 0 0 1px var(--pd-brand)}.pd-calendar td>button[aria-disabled=true]{opacity:.3}.pd-calendar td>button[data-outside=true]{visibility:hidden}.pd-calendar td[data-range=true]{background:var(--pd-brand-soft)}.pd-calendar-footer{display:flex;justify-content:space-between;border-top:1px solid var(--pd-border);padding-top:.75rem;margin-top:.75rem}.pd-range-presets{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:1.2rem}.pd-month-picker>div{display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem;margin-top:.75rem}.pd-month-picker>legend{margin-bottom:.5rem}.pd-upload{display:grid;gap:.6rem}.pd-dropzone{display:flex;align-items:center;flex-direction:column;gap:.45rem;border:1.5px dashed var(--pd-input-border);border-radius:var(--pd-radius);padding:1.5rem;background:var(--pd-surface);text-align:center}.pd-dropzone[data-dragging=true]{border-color:var(--pd-brand);background:var(--pd-brand-soft)}.pd-dropzone[data-disabled=true]{opacity:.5}.pd-dropzone>strong{font-size:13px}.pd-dropzone>span:not(.pd-upload-icon){color:var(--pd-secondary);font-size:12px}.pd-upload-icon{width:48px;height:48px;display:grid;place-items:center;background:var(--pd-brand-soft);color:var(--pd-brand-text);border-radius:12px;margin-bottom:.5rem}.pd-upload-list{display:grid;gap:.6rem}.pd-upload-list>li{display:flex;align-items:start;gap:.7rem;border:1px solid var(--pd-border);border-radius:10px;padding:.75rem;background:var(--pd-surface)}.pd-file-icon{display:grid;place-items:center;width:38px;height:42px;border-radius:7px;background:var(--pd-muted);color:var(--pd-secondary)}.pd-upload-list>li>div{flex:1;min-width:0}.pd-upload-list strong{display:block;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pd-upload-list small{display:block;margin-block:.2rem}.pd-upload-list .pd-progress{margin-top:.45rem}.pd-stat{padding:1.3rem;position:relative}.pd-stat-label{display:flex;align-items:center;justify-content:space-between;gap:.75rem;font-size:12px;color:var(--pd-secondary)}.pd-stat-label>span{width:34px;height:34px;display:grid;place-items:center;background:var(--pd-muted);border-radius:10px}.pd-stat-value{display:block;font-size:1.7rem;font-weight:750;margin-block:.4rem;font-variant-numeric:tabular-nums;letter-spacing:-.025em}.pd-stat-foot{display:flex;align-items:center;gap:.5rem}.pd-stat-change{font-size:11px;font-weight:700;padding:.1rem .35rem;background:var(--pd-success-bg);border-radius:5px}.pd-stat-foot small{font-size:10px}.pd-stat>.pd-sparkline{position:absolute;inset-inline-end:20px;bottom:22px;width:80px;height:30px;color:var(--pd-brand)}.pd-carousel-controls{display:flex;align-items:center;justify-content:center;gap:1rem;margin-top:1rem}.pd-carousel-controls>span{font-size:12px;color:var(--pd-secondary)}.pd-schema-form{display:grid;gap:1.1rem}.pd-form-wizard{display:grid;gap:1.75rem}.pd-form-actions{display:flex;justify-content:space-between;gap:.75rem}.pd-data-table{border:1px solid var(--pd-border);border-radius:var(--pd-radius);background:var(--pd-surface);overflow:hidden}.pd-table-title{display:flex;align-items:center;justify-content:space-between;padding:1.2rem 1.25rem .8rem;gap:1rem}.pd-table-title h3{font-size:14px}.pd-table-title p{font-size:11px;color:var(--pd-secondary);margin-top:.2rem}.pd-table-toolbar{display:flex;align-items:center;justify-content:space-between;gap:.75rem;padding:.5rem 1.25rem 1rem}.pd-table-toolbar>.pd-field{max-width:300px;flex:1}.pd-table-toolbar>div:last-child{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap}.pd-table-toolbar .pd-input-wrap{min-height:36px}.pd-table-toolbar .pd-input{min-height:34px;font-size:12px}.pd-column-picker{position:relative}.pd-column-picker summary{display:flex;align-items:center;gap:.4rem;font-size:12px;cursor:pointer;border:1px solid var(--pd-border);border-radius:8px;padding:.4rem .65rem;list-style:none}.pd-column-picker>div{position:absolute;inset-inline-end:0;top:calc(100% + 6px);z-index:20;background:var(--pd-elevated);padding:.6rem;border:1px solid var(--pd-border);border-radius:10px;box-shadow:var(--pd-shadow-lg);min-width:250px}.pd-column-picker>div>div{display:flex;align-items:center;gap:.3rem;padding:.15rem}.pd-column-picker .pd-field{flex:1}.pd-table-filters{display:flex;gap:.5rem;padding:0 1.25rem 1rem;flex-wrap:wrap}.pd-table-filters>.pd-field{max-width:180px;flex:1;min-width:120px}.pd-table-filters .pd-input,.pd-table-filters .pd-input-wrap{min-height:32px;font-size:11px}.pd-table-bulk{display:flex;align-items:center;gap:1rem;padding:.6rem 1.25rem;background:var(--pd-brand-soft);font-size:12px;color:var(--pd-brand-text)}.pd-table-scroll{overflow:auto;position:relative;border-block:1px solid var(--pd-border);scrollbar-width:thin}.pd-table{width:100%;border-collapse:separate;border-spacing:0;text-align:start;font-size:12px;table-layout:fixed;min-width:100%}.pd-table th,.pd-table td{padding:.85rem 1rem;text-align:start;border-bottom:1px solid var(--pd-border);vertical-align:middle;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pd-table th{position:sticky;top:0;background:var(--pd-bg)!important;z-index:4!important;font-weight:600;color:var(--pd-secondary);height:46px;font-size:11px}.pd-table tr:last-child>td{border-bottom:0}.pd-table tr[data-selected=true]>td{background:var(--pd-brand-soft)!important}.pd-table tbody tr:hover>td{background:color-mix(in srgb,var(--pd-muted) 55%,var(--pd-surface))}.pd-table-check{width:44px!important;min-width:44px!important;padding-inline:.8rem!important}.pd-table .pd-check{gap:0}.pd-table .pd-check input{margin:0}.pd-table-sort{display:inline-flex;align-items:center;gap:.4rem;background:none;border:0;padding:0;white-space:nowrap;color:inherit;font-size:inherit}.pd-table-numeric{font-variant-numeric:tabular-nums;text-align:end!important}.pd-column-resize{position:absolute;inset-inline-end:0;top:0;width:8px!important;height:100%;opacity:0;cursor:col-resize;-webkit-appearance:none;-moz-appearance:none;appearance:none;margin:0}.pd-column-resize:focus-visible{opacity:1;outline:2px solid var(--pd-brand);background:var(--pd-muted)}.pd-table th:hover .pd-column-resize{opacity:.25;background:var(--pd-brand)}.pd-table-expanded{white-space:normal!important;background:var(--pd-bg)}.pd-table-footer{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.8rem 1rem}.pd-table-footer .pd-select{min-height:32px;font-size:11px}.pd-table-footer .pd-pagination .pd-button{min-height:30px;font-size:11px}.pd-table .pd-empty{white-space:normal}.pd-chart{margin:0;padding:1.25rem;background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:var(--pd-radius)}.pd-chart figcaption{font-size:13px;font-weight:700;margin-bottom:.8rem}.pd-chart-svg{width:100%;height:auto;max-height:300px;overflow:visible;display:block}.pd-chart-svg text,.pd-chart text{fill:var(--pd-secondary);font-family:var(--pd-font);font-size:11px}.pd-pie-layout{display:flex;align-items:center;justify-content:space-around;gap:1.5rem;flex-wrap:wrap}.pd-chart-legend{display:grid;gap:.75rem;flex:1;min-width:130px}.pd-chart-legend>li{display:flex;align-items:center;gap:.5rem;font-size:11px;color:var(--pd-secondary)}.pd-chart-legend i{width:8px;height:8px;border-radius:3px}.pd-chart-legend strong{margin-inline-start:auto;color:var(--pd-text)}.pd-chart text.pd-pie-total{font-size:18px;fill:var(--pd-text);font-weight:750}.pd-sparkline{width:100%;height:36px}.pd-bar-list{display:grid;gap:.65rem}.pd-bar-list>li{display:flex;justify-content:space-between;position:relative;isolation:isolate;padding:.55rem .7rem;font-size:11px}.pd-bar-list>li>span:first-child{position:absolute;inset-inline-start:0;inset-block:0;background:var(--pd-brand-soft);border-radius:5px;z-index:-1}.pd-proportion{height:14px;display:flex;gap:3px;overflow:hidden;border-radius:5px;margin-bottom:1rem}.pd-app-shell{display:flex;min-height:100dvh}.pd-app-sidebar{width:240px;flex-shrink:0;border-inline-end:1px solid var(--pd-border);padding:1.5rem 1rem;background:var(--pd-surface)}.pd-app-logo{font-size:20px;font-weight:800;margin-bottom:2rem;padding-inline:.5rem}.pd-app-content{flex:1;min-width:0}.pd-app-header{height:72px;border-bottom:1px solid var(--pd-border);background:var(--pd-surface);padding-inline:2rem;display:flex;align-items:center;gap:1rem}.pd-app-content>main{padding:2rem}.pd-mobile-menu{display:none}.pd-page-header{margin-bottom:1.75rem}.pd-page-header>.pd-breadcrumb{margin-bottom:1rem}.pd-page-header>div{display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap}.pd-page-header p{font-size:13px;color:var(--pd-secondary);margin-top:.4rem}.pd-eyebrow{font-size:11px;font-weight:650;letter-spacing:.04em;color:var(--pd-brand-text)}.pd-page-actions{display:flex;align-items:center;gap:.6rem}.pd-user-trigger{display:flex;align-items:center;gap:.6rem;text-align:start}.pd-user-trigger strong{display:block;font-size:12px}.pd-user-trigger small{display:block;font-size:10px}.pd-inbox{display:grid;grid-template-columns:320px 1fr;min-height:520px;border:1px solid var(--pd-border);border-radius:var(--pd-radius);overflow:hidden;background:var(--pd-surface)}.pd-inbox>aside{border-inline-end:1px solid var(--pd-border);overflow:auto;max-height:650px}.pd-inbox>div{min-width:0}.pd-inbox-back{display:none}.pd-ticket{display:block;width:100%;text-align:start;background:transparent;border:0;border-bottom:1px solid var(--pd-border);padding:1.1rem;cursor:pointer}.pd-ticket[data-active=true]{background:var(--pd-brand-soft);box-shadow:inset -3px 0 var(--pd-brand)}.pd-ticket>div,.pd-ticket>footer{display:flex;align-items:center;gap:.5rem;justify-content:space-between}.pd-ticket-id{font-size:10px;color:var(--pd-secondary);margin-inline-end:auto}.pd-ticket>strong{display:block;font-size:13px;margin-top:.6rem}.pd-ticket>p{font-size:11px;color:var(--pd-secondary);margin-top:.3rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pd-ticket>footer{margin-top:.8rem;color:var(--pd-secondary);font-size:10px}.pd-conversation{display:flex;flex-direction:column;height:100%;min-height:520px}.pd-conversation>header{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:1.1rem 1.25rem;border-bottom:1px solid var(--pd-border)}.pd-conversation>header small{display:block}.pd-message-list{flex:1;display:flex;flex-direction:column;gap:1.25rem;padding:1.5rem!important;max-height:420px;overflow:auto;background:var(--pd-bg)}.pd-message{display:flex;align-items:flex-end;gap:.6rem;max-width:85%}.pd-message>div{background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:12px 12px 3px;padding:.8rem 1rem}.pd-message strong{font-size:10px}.pd-message p{font-size:12px;white-space:pre-wrap;margin-block:.35rem}.pd-message small{display:flex;justify-content:flex-end;gap:.3rem;font-size:9px}.pd-message--own{align-self:flex-end;flex-direction:row-reverse}.pd-message--own>div{background:var(--pd-brand-soft);border-color:color-mix(in srgb,var(--pd-brand),transparent 80%);border-radius:12px 12px 12px 3px}.pd-message-composer{display:flex;align-items:flex-end;gap:.7rem;flex-wrap:wrap;padding:1rem;border-top:1px solid var(--pd-border)}.pd-message-composer>.pd-field{flex:1}.pd-message-composer .pd-textarea{min-height:65px}.pd-message-composer>.pd-error{width:100%}.pd-notification-center>header{display:flex;align-items:center;justify-content:space-between;padding:1rem;border-bottom:1px solid var(--pd-border)}.pd-notification-center li>button{display:flex;gap:.75rem;width:100%;padding:1rem;border:0;border-bottom:1px solid var(--pd-border);background:transparent;text-align:start}.pd-notification-center [data-unread=true]{background:var(--pd-brand-soft)}.pd-notification-center button>span{color:var(--pd-brand-text)}.pd-notification-center button>div{flex:1}.pd-notification-center strong{font-size:12px}.pd-notification-center p{font-size:11px;color:var(--pd-secondary);margin-block:.2rem}.pd-notification-center i{width:6px;height:6px;background:var(--pd-brand);border-radius:50%;margin-top:.5rem}.pd-pricing-card{padding:1.6rem;display:flex;flex-direction:column;gap:.8rem}.pd-pricing-card--featured{border-color:var(--pd-brand);box-shadow:0 0 0 1px var(--pd-brand)}.pd-pricing-card>.pd-badge{align-self:start}.pd-pricing-card>p{font-size:12px;color:var(--pd-secondary)}.pd-plan-price{margin-block:.5rem}.pd-plan-price strong{font-size:1.4rem}.pd-pricing-card ul{display:grid;gap:.8rem;margin-block:.5rem 1rem;flex:1}.pd-pricing-card li{display:flex;align-items:center;gap:.5rem;font-size:12px}.pd-pricing-card li[data-included=true]>svg{color:var(--pd-success)}.pd-pricing-card li[data-included=false]{color:var(--pd-secondary)}.pd-auth-card{padding:2rem;width:100%;max-width:420px;margin-inline:auto}.pd-auth-card>h2{margin-block:1rem .4rem}.pd-auth-card>p{font-size:12px;color:var(--pd-secondary);margin-bottom:1.5rem}.pd-auth-card form{display:grid;gap:1rem;margin-block:1.5rem}.pd-file-card{padding:1.25rem;display:flex;flex-direction:column;gap:.6rem}.pd-file-card>span{color:var(--pd-brand-text)}.pd-file-card strong{font-size:13px}.pd-file-card>div{display:flex;gap:.4rem;margin-top:.4rem}@keyframes pd-spin{to{transform:rotate(360deg)}}@keyframes pd-shimmer{to{background-position:-220% 0}}@media(max-width:768px){.pd-app-sidebar{display:none}.pd-app-header{padding-inline:1rem;height:60px}.pd-app-content>main{padding:1rem}.pd-mobile-menu{display:inline-flex}.pd-table-toolbar{align-items:stretch;flex-direction:column;padding:1rem}.pd-table-toolbar>.pd-field{max-width:none}.pd-table-footer{flex-direction:column;align-items:stretch}.pd-table-footer>.pd-pagination{justify-content:center}.pd-pagination{gap:.1rem}.pd-pagination>.pd-button{min-width:28px;padding-inline:.4rem}.pd-inbox{display:block}.pd-inbox>aside{border:0}.pd-inbox>div{display:none}.pd-inbox--selected>aside{display:none}.pd-inbox--selected>div{display:block}.pd-inbox-back{display:flex;margin:.5rem}.pd-message{max-width:95%}.pd-message-list{padding:1rem!important}.pd-message-composer{flex-direction:column;align-items:stretch}.pd-message-composer>.pd-field{width:100%}.pd-page-actions{width:100%;flex-wrap:wrap}.pd-dialog-body{padding:1rem}.pd-toaster{inset-inline:16px;bottom:16px;width:auto;max-width:none}.pd-stepper{gap:.75rem}.pd-stepper>li{min-width:calc(50% - .5rem)}.pd-tooltip{max-width:200px;white-space:normal}.pd-table-filters{padding-inline:1rem}}}@layer primedesign.commerce{.pd-product-grid{display:grid;gap:1.25rem;grid-template-columns:repeat(3,minmax(0,1fr))}.pd-product-grid--2{grid-template-columns:repeat(2,minmax(0,1fr))}.pd-product-grid--4{grid-template-columns:repeat(4,minmax(0,1fr))}.pd-product-card{display:flex;flex-direction:column;min-width:0;background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:var(--pd-radius);overflow:hidden;transition:box-shadow .2s,border-color .2s,transform .2s}.pd-product-card:hover{box-shadow:var(--pd-shadow);border-color:color-mix(in srgb,var(--pd-brand) 30%,var(--pd-border));transform:translateY(-3px)}.pd-product-card a:focus-visible{outline-offset:-3px}.pd-product-media{position:relative;padding:12px;background:var(--pd-surface)}.pd-product-image{display:grid;place-items:center;width:100%;aspect-ratio:1.18;background:var(--pd-muted);border-radius:calc(var(--pd-radius) * .65);overflow:hidden;color:var(--pd-secondary)}.pd-product-image img{display:block;width:100%;height:100%;object-fit:contain;transition:transform .4s}.pd-product-image>span{display:grid;place-items:center;width:100%;height:100%;background:radial-gradient(ellipse at center,var(--pd-surface),var(--pd-muted))}.pd-product-card:hover .pd-product-image img{transform:scale(1.045)}.pd-product-badges{position:absolute;top:24px;inset-inline-start:24px;display:flex;align-items:flex-start;gap:.3rem;flex-direction:column;z-index:1}.pd-product-badges .pd-badge{box-shadow:0 2px 4px #00000004}.pd-product-tools{position:absolute;top:22px;inset-inline-end:22px;display:grid;gap:.4rem}.pd-product-tools>.pd-button{background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:50%;width:31px;min-height:31px;padding:6px;box-shadow:0 2px 6px #00000003}.pd-product-tools>.pd-button>svg{width:16px;height:16px}.pd-product-tools .pd-wishlisted{color:var(--pd-danger);background:var(--pd-danger-bg);border-color:transparent}.pd-wishlisted>svg{fill:currentColor}.pd-product-tools>[aria-pressed=true]:not(.pd-wishlisted){color:var(--pd-brand-text);background:var(--pd-brand-soft)}.pd-product-quick{display:flex;align-items:center;justify-content:center;gap:.4rem;position:absolute;bottom:24px;inset-inline:24px;border:1px solid var(--pd-border);border-radius:8px;background:var(--pd-surface);font-size:11px;padding:.5rem;opacity:0;transform:translateY(5px);transition:opacity .2s,transform .2s}.pd-product-card:hover .pd-product-quick,.pd-product-card:focus-within .pd-product-quick{opacity:1;transform:none}.pd-product-info{display:flex;flex-direction:column;gap:.6rem;padding:.35rem 1.15rem 1.15rem;flex:1;min-width:0}.pd-product-overline{display:flex;align-items:center;justify-content:space-between;gap:.5rem;min-height:20px}.pd-product-overline>span{font-size:9px;color:var(--pd-secondary);font-weight:500;letter-spacing:.04em}.pd-product-info>h3{font-size:13px;font-weight:700;line-height:1.9;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:24px}.pd-product-info>h3>a:hover{color:var(--pd-brand-text)}.pd-product-subtitle{font-size:10px;color:var(--pd-secondary);line-height:1.8}.pd-product-description{color:var(--pd-secondary);font-size:12px;max-width:55ch}.pd-product-meta{display:flex;justify-content:space-between;gap:.6rem;align-items:center;min-height:22px}.pd-product-meta>small{font-size:9px}.pd-swatches{display:flex;gap:6px;align-items:center}.pd-swatches>label{position:relative;cursor:pointer;padding:3px;border:1px solid transparent;border-radius:50%;line-height:1}.pd-swatches>label>span{display:grid;place-items:center;min-width:13px;height:13px;border-radius:50%;box-shadow:inset 0 0 0 1px #00000020;font-size:9px}.pd-swatches>label[data-selected=true]{border-color:var(--pd-secondary)}.pd-swatches input{position:absolute;width:1px;height:1px;opacity:0}.pd-swatches>label:has(input:focus-visible){outline:2px solid var(--pd-brand);outline-offset:2px}.pd-swatches>label[data-disabled=true]{opacity:.25;cursor:not-allowed}.pd-product-stock-line{display:flex;align-items:center;justify-content:space-between;gap:.5rem;min-height:18px}.pd-stock{display:inline-flex;align-items:center;gap:.3rem;font-size:9px;white-space:nowrap}.pd-stock>i{width:4px;height:4px;border-radius:50%;background:currentColor}.pd-free-shipping{display:flex;align-items:center;gap:.25rem;font-size:9px;color:var(--pd-secondary)}.pd-product-bottom{display:flex;flex-direction:column;gap:.85rem;margin-top:auto;padding-top:.6rem;border-top:1px solid var(--pd-border)}.pd-product-bottom>.pd-button{width:100%;font-size:11px;min-height:36px;padding:.45rem .6rem}.pd-price{display:flex;flex-direction:column;align-items:flex-end;gap:.15rem;line-height:1.6;font-variant-numeric:tabular-nums;min-height:42px;justify-content:flex-end}.pd-price>del{color:var(--pd-secondary);font-size:10px}.pd-price>strong{font-size:14px;font-weight:750;letter-spacing:-.025em}.pd-price--sm{min-height:0}.pd-price--sm>strong{font-size:12px}.pd-price--lg>strong{font-size:22px}.pd-product-link{display:flex;justify-content:space-between;align-items:center;color:var(--pd-brand-text);font-size:12px}.pd-product-card--compact .pd-product-media{padding:8px}.pd-product-card--compact .pd-product-badges{top:16px;inset-inline-start:16px}.pd-product-card--compact .pd-product-tools{top:16px;inset-inline-end:16px}.pd-product-card--compact .pd-product-info{padding:.35rem .85rem .85rem;gap:.4rem}.pd-product-card--compact .pd-product-info>h3{font-size:12px}.pd-product-card--compact .pd-product-subtitle,.pd-product-card--compact .pd-product-meta>small,.pd-product-card--compact .pd-free-shipping{display:none}.pd-product-card--compact .pd-product-bottom{gap:.6rem}.pd-product-card--horizontal{flex-direction:row}.pd-product-card--horizontal .pd-product-media{width:37%;flex-shrink:0}.pd-product-card--horizontal .pd-product-image{height:100%;min-height:200px;aspect-ratio:auto}.pd-product-card--horizontal .pd-product-info{padding:1.5rem 1.5rem 1.5rem .8rem;gap:.75rem}.pd-product-card--horizontal .pd-product-bottom{flex-direction:row;align-items:flex-end;justify-content:space-between;padding-top:1rem;gap:1rem}.pd-product-card--horizontal .pd-product-bottom>.pd-button{width:auto}.pd-product-card--horizontal .pd-product-info>h3{font-size:16px}.pd-product-card--horizontal .pd-product-meta{justify-content:flex-start}.pd-product-card--minimal{border:0;background:transparent;box-shadow:none!important}.pd-product-card--minimal .pd-product-media{padding:0;background:none}.pd-product-card--minimal .pd-product-info{padding:1rem .15rem}.pd-product-card--minimal .pd-product-tools{top:12px;inset-inline-end:12px}.pd-product-card--minimal .pd-product-badges{top:12px;inset-inline-start:12px}.pd-product-card--minimal .pd-product-quick{bottom:12px;inset-inline:12px}.pd-product-card--minimal .pd-product-stock-line{display:none}.pd-product-card--minimal .pd-product-bottom{border:0;padding:0}.pd-product-card--featured{border-color:color-mix(in srgb,var(--pd-brand) 35%,var(--pd-border));background:linear-gradient(160deg,var(--pd-brand-soft),var(--pd-surface) 55%)}.pd-product-card--featured .pd-product-media{background:transparent;padding:16px}.pd-product-card--featured .pd-product-info{padding:.5rem 1.4rem 1.4rem}.pd-product-card--featured .pd-product-info>h3{font-size:16px}.pd-product-card--sold-out .pd-product-image img{filter:grayscale(.7);opacity:.6}.pd-product-skeleton-image{aspect-ratio:1.18;height:auto;border-radius:0;margin-bottom:1rem}.pd-product-gallery>.pd-product-image{aspect-ratio:1.1}.pd-gallery-thumbnails{display:flex;gap:.65rem;margin-top:.75rem}.pd-gallery-thumbnails>button{border:1px solid var(--pd-border);background:var(--pd-surface);border-radius:10px;width:68px;height:68px;padding:5px;overflow:hidden}.pd-gallery-thumbnails>button[aria-pressed=true]{border-color:var(--pd-brand);box-shadow:0 0 0 1px var(--pd-brand)}.pd-gallery-thumbnails img{width:100%;height:100%;object-fit:contain}.pd-category-card{display:flex;flex-direction:column;align-items:center;gap:.65rem;padding:1.3rem 1rem;background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:var(--pd-radius);text-align:center;transition:border-color .2s,transform .2s}.pd-category-card:hover{border-color:var(--pd-brand);transform:translateY(-3px)}.pd-category-art{display:grid;place-items:center;width:70px;height:70px;border-radius:22px;background:var(--pd-brand-soft);color:var(--pd-brand-text)}.pd-category-art img{width:100%;height:100%;object-fit:contain;padding:8px}.pd-category-card>strong{font-size:12px}.pd-category-card>small{font-size:10px}.pd-promo-card{display:flex;position:relative;align-items:center;justify-content:space-between;gap:1rem;padding:2rem;overflow:hidden;border-radius:var(--pd-radius);background:var(--pd-brand-soft);border:1px solid color-mix(in srgb,var(--pd-brand),transparent 85%);isolation:isolate}.pd-promo-card:before{content:"";position:absolute;width:240px;height:240px;border:1px solid color-mix(in srgb,var(--pd-brand),transparent 85%);border-radius:50%;inset-inline-end:-50px;top:-100px;z-index:-1;box-shadow:0 0 0 40px color-mix(in srgb,var(--pd-brand),transparent 96%),0 0 0 80px color-mix(in srgb,var(--pd-brand),transparent 97%)}.pd-promo-card>div{position:relative;z-index:1}.pd-promo-card>div>span{font-size:10px;color:var(--pd-brand-text);font-weight:700}.pd-promo-card h3{font-size:1.4rem;margin-block:.4rem}.pd-promo-card p{font-size:12px;color:var(--pd-secondary);max-width:38ch;margin-bottom:1rem}.pd-promo-card>img{width:45%;max-height:190px;object-fit:contain}.pd-promo-card--warm{background:#fcf0df;border-color:#eadbc3;color:#4b3520}.pd-promo-card--warm p{color:#76624a}.pd-promo-card--dark{background:#19233b;border-color:#2b3854;color:#fff}.pd-promo-card--dark p{color:#bdc8de}.pd-promo-card--dark>div>span{color:#c6bbff}.pd-brand-card{padding:1.5rem;display:flex;align-items:center;flex-direction:column;gap:.7rem;text-align:center}.pd-brand-card>img{height:36px;max-width:110px;object-fit:contain}.pd-brand-card>svg{color:var(--pd-brand-text)}.pd-brand-card>strong{font-size:13px}.pd-review-card{padding:1.3rem}.pd-review-card>div{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap}.pd-review-card strong{font-size:12px}.pd-review-card .pd-rating{margin-inline-start:auto}.pd-review-card>p{font-size:12px;line-height:2;color:var(--pd-secondary);margin-block:.8rem}.pd-cart-line{display:flex;align-items:flex-start;gap:.85rem;padding-block:1.1rem;border-bottom:1px solid var(--pd-border)}.pd-cart-line>.pd-product-image{width:82px;height:94px;aspect-ratio:auto;flex-shrink:0}.pd-cart-line-info{flex:1;min-width:0;display:flex;flex-direction:column;gap:.35rem}.pd-cart-line-info>strong{font-size:12px}.pd-cart-line-info>small{font-size:10px}.pd-cart-line-info>.pd-price{align-items:flex-start}.pd-cart-line-info>.pd-field{max-width:135px}.pd-cart-line-info>.pd-field>.pd-label{position:absolute;width:1px;height:1px;clip-path:inset(50%);overflow:hidden}.pd-cart-line-info .pd-input-wrap{min-height:30px}.pd-cart-line-info .pd-input{min-height:28px;text-align:center;font-size:11px;-moz-appearance:textfield}.pd-cart-line-info .pd-input::-webkit-inner-spin-button{-webkit-appearance:none;-moz-appearance:none;appearance:none}.pd-cart-line-info .pd-icon-button{min-height:26px;padding:4px}.pd-cart-line-info .pd-input-adornment{padding-inline:0}.pd-cart-summary{padding:1.4rem;display:grid;gap:1.1rem}.pd-cart-summary>h3{font-size:14px}.pd-cart-summary dl{display:grid;gap:.85rem;margin:0}.pd-cart-summary dl>div{display:flex;align-items:center;justify-content:space-between;gap:1rem;font-size:12px}.pd-cart-summary dt{color:var(--pd-secondary)}.pd-cart-summary dd{margin:0;font-weight:650;font-variant-numeric:tabular-nums}.pd-cart-summary .pd-summary-total{border-top:1px dashed var(--pd-border);padding-top:1.1rem;margin-top:.25rem}.pd-summary-total>dt{color:var(--pd-text)}.pd-summary-total>dd{font-size:16px}.pd-checkout-secure{display:flex;justify-content:center;align-items:center;gap:.3rem;font-size:10px;color:var(--pd-secondary)}.pd-cart-lines{margin-block:1rem 1.5rem}.pd-coupon{display:flex;gap:.5rem;align-items:start}.pd-coupon>.pd-field{flex:1}.pd-coupon .pd-input-wrap,.pd-coupon>.pd-button{min-height:38px}.pd-coupon .pd-input{min-height:36px;font-size:11px}.pd-coupon-applied{display:flex;align-items:center;justify-content:space-between;padding:.5rem;background:var(--pd-success-bg);border-radius:8px}.pd-shipping-progress{display:grid;gap:.65rem;padding:.9rem;border-radius:10px;background:var(--pd-success-bg)}.pd-shipping-progress>span{font-size:11px;display:flex;align-items:center;gap:.5rem;color:var(--pd-success)}.pd-shipping-progress .pd-progress{background:color-mix(in srgb,var(--pd-success),transparent 85%)}.pd-shipping-progress .pd-progress>span{background:var(--pd-success)}.pd-address-card{padding:1.3rem;display:grid;gap:.5rem}.pd-address-selected{border-color:var(--pd-brand);box-shadow:0 0 0 1px var(--pd-brand)}.pd-address-card>div{display:flex;align-items:center;justify-content:space-between;gap:.5rem}.pd-address-card strong{font-size:13px}.pd-address-card p{font-size:12px;color:var(--pd-secondary);line-height:2}.pd-address-card>small{display:block;font-size:11px}.pd-address-card>div:last-child{justify-content:flex-start;margin-top:.5rem}.pd-order-card>header,.pd-order-card>footer{display:flex;align-items:center;justify-content:space-between;gap:.75rem;padding:1.1rem 1.25rem}.pd-order-card>header{border-bottom:1px solid var(--pd-border)}.pd-order-card>header strong{font-size:13px}.pd-order-card>header small{display:block;font-size:10px;margin-top:.25rem}.pd-order-card>footer{border-top:1px solid var(--pd-border)}.pd-order-card>footer>strong{font-size:13px}.pd-order-products{padding:1rem 1.25rem;display:flex;flex-wrap:wrap;gap:.8rem}.pd-order-products>div{display:flex;align-items:center;gap:.65rem}.pd-order-products .pd-product-image{width:60px;height:65px;aspect-ratio:auto}.pd-order-products span{font-size:11px}.pd-order-products small{display:block;font-size:10px}.pd-compare-scroll{overflow:auto;border:1px solid var(--pd-border);border-radius:var(--pd-radius);background:var(--pd-surface)}.pd-compare-table{table-layout:auto;min-width:600px}.pd-compare-table caption{padding:1rem;font-weight:700;text-align:start}.pd-compare-table th{position:relative;white-space:normal;min-width:180px;background:var(--pd-surface)!important}.pd-compare-table th>.pd-product-image{width:120px;height:110px;margin-inline:auto;margin-bottom:.75rem}.pd-compare-table th>strong{display:block;font-size:12px;text-align:center}.pd-compare-table th>.pd-icon-button{position:absolute;top:8px;inset-inline-end:8px}.pd-compare-table tbody th{min-width:120px;background:var(--pd-bg)!important}.pd-compare-table td{white-space:normal;text-align:center;min-width:180px}@media(hover:none){.pd-product-quick{opacity:1;transform:none;position:static;margin:8px 0 0;inset:auto}.pd-product-card:hover{transform:none}}@media(max-width:1100px){.pd-product-grid--4{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:700px){.pd-product-grid,.pd-product-grid--4{grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem}.pd-product-card--horizontal .pd-product-info{padding:1rem;gap:.6rem}.pd-product-card--horizontal .pd-product-info>h3{font-size:13px}.pd-product-card--horizontal .pd-product-media{width:36%;padding:8px}.pd-product-card--horizontal .pd-product-bottom{flex-direction:column;align-items:stretch;gap:.65rem}.pd-product-card--horizontal .pd-product-info .pd-free-shipping{display:none}.pd-product-card--horizontal .pd-product-badges{top:16px;inset-inline-start:16px}.pd-product-card--horizontal .pd-product-tools{top:auto;bottom:16px;inset-inline-end:16px}.pd-product-card--horizontal .pd-product-quick{display:none}.pd-product-grid .pd-product-info{padding:.4rem .75rem .85rem}.pd-product-grid .pd-product-media{padding:8px}.pd-product-grid .pd-product-badges{top:15px;inset-inline-start:15px}.pd-product-grid .pd-product-tools{top:15px;inset-inline-end:15px}.pd-product-grid .pd-product-tools>.pd-button{width:27px;min-height:27px;padding:5px}.pd-product-grid .pd-product-tools>.pd-button:nth-child(2){display:none}.pd-product-grid .pd-product-subtitle,.pd-product-grid .pd-product-meta>small,.pd-product-grid .pd-free-shipping{display:none}.pd-product-grid .pd-product-info>h3{font-size:11px;line-height:1.9}.pd-product-grid .pd-product-bottom>.pd-button{font-size:10px;gap:.3rem;padding:.4rem}.pd-product-grid .pd-price>strong{font-size:12px}.pd-product-grid .pd-product-overline>span{font-size:8px}.pd-product-grid .pd-stock{font-size:8px}.pd-promo-card{padding:1.5rem}.pd-promo-card h3{font-size:1.2rem}.pd-promo-card>img{max-width:40%}.pd-cart-summary{padding:1.1rem}}@media(max-width:380px){.pd-product-grid,.pd-product-grid--2{grid-template-columns:1fr}.pd-product-card--horizontal{flex-direction:column}.pd-product-card--horizontal .pd-product-media{width:100%}.pd-product-card--horizontal .pd-product-image{min-height:160px}}}@layer primedesign.advanced{.pd-aspect-ratio{position:relative;overflow:hidden;width:100%}.pd-aspect-ratio>img,.pd-aspect-ratio>video{width:100%;height:100%;object-fit:cover}.pd-separator{flex-shrink:0;background:var(--pd-border)}.pd-separator--horizontal{height:1px;width:100%;margin-block:1rem}.pd-separator--vertical{width:1px;align-self:stretch;min-height:1rem;margin-inline:.75rem}.pd-scroll-area{scrollbar-width:thin;scrollbar-color:var(--pd-input-border) var(--pd-muted);overscroll-behavior:contain;padding:.5rem}.pd-collapsible{border:1px solid var(--pd-border);border-radius:calc(var(--pd-radius) * .65);overflow:hidden;background:var(--pd-surface)}.pd-collapsible>button{display:flex;align-items:center;justify-content:space-between;gap:.75rem;width:100%;padding:.85rem 1rem;text-align:start;font-size:12px;font-weight:650;background:none;border:0}.pd-collapsible>button[aria-expanded=true]>svg{transform:rotate(180deg)}.pd-collapsible>div{padding:0 1rem 1rem;font-size:13px;line-height:1.9}.pd-toggle-group{display:inline-flex;align-items:center;gap:.35rem;flex-wrap:wrap}.pd-toggle-group .pd-button{min-height:36px}.pd-typography--h1{font-size:2.2rem;font-weight:800;letter-spacing:-.04em}.pd-typography--h2{font-size:1.6rem;font-weight:750}.pd-typography--h3{font-size:1.3rem}.pd-typography--h4{font-size:1.1rem}.pd-typography--lead{font-size:1.2rem;color:var(--pd-secondary);line-height:2}.pd-typography--muted{font-size:13px;color:var(--pd-secondary)}.pd-typography--small{font-size:12px}.pd-typography--blockquote{padding:.5rem 1.2rem;border-inline-start:3px solid var(--pd-brand);margin:1rem 0;color:var(--pd-secondary)}.pd-typography--code{background:var(--pd-muted);padding:.15rem .35rem;border-radius:5px;font-size:.9em}.pd-marker{border-radius:4px;padding:.05em .25em}.pd-item{display:flex;align-items:center;gap:.8rem;text-align:start;width:100%;padding:1rem;border:1px solid var(--pd-border);border-radius:calc(var(--pd-radius) * .65);background:var(--pd-surface)}a.pd-item:hover,button.pd-item:hover{background:var(--pd-muted)}.pd-item-leading{color:var(--pd-brand-text);flex-shrink:0}.pd-item-copy{display:flex;flex:1;flex-direction:column;gap:.2rem}.pd-item-copy>strong{font-size:13px}.pd-item-copy>small{font-size:11px;color:var(--pd-secondary)}.pd-item-trailing{margin-inline-start:auto}.pd-item-group{display:grid;gap:.6rem}.pd-input-group{display:flex;align-items:stretch;border:1px solid var(--pd-input-border);border-radius:calc(var(--pd-radius) * .65);background:var(--pd-surface);overflow:hidden}.pd-input-group:focus-within{box-shadow:var(--pd-focus);border-color:var(--pd-brand)}.pd-input-group>.pd-field{flex:1;min-width:0}.pd-input-group .pd-input-wrap{border:0;box-shadow:none;border-radius:0}.pd-input-group-addon{display:flex;align-items:center;justify-content:center;gap:.4rem;padding:.4rem .75rem;font-size:12px;color:var(--pd-secondary);background:var(--pd-muted)}.pd-input-group-addon--start{border-inline-end:1px solid var(--pd-border);order:-1}.pd-input-group-addon--end{border-inline-start:1px solid var(--pd-border);order:1}.pd-simple-table-wrap{overflow:auto;border:1px solid var(--pd-border);border-radius:var(--pd-radius);background:var(--pd-surface)}.pd-simple-table-wrap .pd-table{table-layout:auto}.pd-simple-table-wrap caption{padding:1rem;text-align:start;font-weight:700}.pd-simple-table-wrap th{position:static}.pd-simple-table-wrap td{white-space:normal}.pd-resizable{display:flex;min-height:220px;width:100%;border:1px solid var(--pd-border);border-radius:var(--pd-radius);overflow:hidden;background:var(--pd-surface)}.pd-resizable--vertical{flex-direction:column;min-height:360px}.pd-resizable-section{display:flex;min-width:0;min-height:0;position:relative}.pd-resizable--vertical .pd-resizable-section{flex-direction:column}.pd-resizable-panel{width:100%;height:100%;padding:1rem;overflow:auto;min-width:0;min-height:0}.pd-resizable-handle{position:absolute;inset-inline-end:-4px;inset-block:0;width:8px;z-index:3;cursor:col-resize;display:flex;align-items:center;justify-content:center;touch-action:none;background:transparent}.pd-resizable-handle:before{content:"";position:absolute;width:1px;height:100%;background:var(--pd-border)}.pd-resizable-handle>span{display:block;width:4px;height:28px;border-radius:3px;background:var(--pd-input-border);z-index:1}.pd-resizable-handle:hover>span,.pd-resizable-handle:focus-visible>span{background:var(--pd-brand)}.pd-resizable--vertical .pd-resizable-handle{inset-inline:0;inset-block-start:auto;inset-block-end:-4px;width:100%;height:8px;cursor:row-resize}.pd-resizable--vertical .pd-resizable-handle:before{width:100%;height:1px}.pd-resizable--vertical .pd-resizable-handle>span{width:28px;height:4px}.pd-sidebar{width:250px;display:flex;flex-direction:column;gap:1.5rem;padding:1rem;background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:var(--pd-radius);transition:width .2s}.pd-sidebar--collapsed{width:76px}.pd-sidebar-brand{display:flex;justify-content:space-between;align-items:center;gap:.5rem;min-height:40px;font-weight:750}.pd-sidebar--collapsed .pd-sidebar-brand{flex-direction:column}.pd-sidebar-footer{margin-top:auto;padding-top:1rem;border-top:1px solid var(--pd-border);font-size:12px}.pd-context-area{position:relative;border-radius:var(--pd-radius)}.pd-context-menu{position:fixed;z-index:100;width:230px;background:var(--pd-elevated);padding:.4rem;border:1px solid var(--pd-border);border-radius:10px;box-shadow:var(--pd-shadow-lg)}.pd-menubar{display:inline-flex;align-items:center;gap:3px;padding:4px;border:1px solid var(--pd-border);border-radius:10px;background:var(--pd-surface)}.pd-menubar-trigger{display:inline-flex;align-items:center;padding:.35rem .7rem;font-size:12px;border-radius:6px}.pd-menubar .pd-popover-trigger:hover{background:var(--pd-muted)}.pd-navigation-menu>ul{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap}.pd-navigation-menu>ul>li>a,.pd-navigation-menu summary{padding:.55rem .9rem;display:flex;gap:.4rem;align-items:center;font-size:13px;border-radius:7px;cursor:pointer;list-style:none}.pd-navigation-menu [aria-current=page]{color:var(--pd-brand-text);background:var(--pd-brand-soft)}.pd-navigation-menu details{position:relative}.pd-navigation-menu details>ul{position:absolute;inset-inline-start:0;top:calc(100% + 5px);width:300px;max-width:calc(100vw - 40px);padding:.5rem;border:1px solid var(--pd-border);border-radius:12px;background:var(--pd-elevated);box-shadow:var(--pd-shadow-lg);z-index:20}.pd-navigation-menu details li>a{display:block;padding:.8rem;border-radius:7px}.pd-navigation-menu details li>a:hover{background:var(--pd-muted)}.pd-navigation-menu details strong{font-size:12px;display:block}.pd-navigation-menu details small{display:block;font-size:11px;margin-top:.2rem}.pd-hover-card{position:relative;display:inline-flex}.pd-hover-trigger{background:none;border:0;padding:0;border-radius:8px;color:var(--pd-brand-text)}.pd-hover-panel{position:absolute;inset-inline-start:0;top:calc(100% + 8px);min-width:250px;max-width:min(340px,calc(100vw - 40px));padding:1rem;border:1px solid var(--pd-border);border-radius:12px;background:var(--pd-elevated);box-shadow:var(--pd-shadow-lg);z-index:40;color:var(--pd-text);font-size:12px}.pd-code-block{background:#172033;border:1px solid #34415a;border-radius:calc(var(--pd-radius) * .7);overflow:hidden;color:#dbe4f8;margin:0}.pd-code-block figcaption{display:flex;align-items:center;justify-content:space-between;gap:.7rem;padding:.5rem 1rem;border-bottom:1px solid #34415a;direction:ltr;font:11px ui-monospace,monospace}.pd-code-block figcaption .pd-button{background:#26324a;color:#dbe4f8;border-color:#46536c;min-height:28px;font-size:10px}.pd-code-block pre{overflow:auto;padding:1rem;margin:0;font:12px/1.9 ui-monospace,monospace;-moz-tab-size:2;tab-size:2;color:inherit;white-space:pre}.pd-code-line{display:block}.pd-code-line>span{display:inline-block;width:2.5rem;color:#9dabc4;-webkit-user-select:none;user-select:none}.pd-attachment{display:flex;align-items:center;gap:.6rem;padding:.7rem;border:1px solid var(--pd-border);border-radius:10px;background:var(--pd-surface);min-width:0}.pd-attachment>span{display:grid;place-items:center;width:34px;height:38px;border-radius:8px;background:var(--pd-muted);color:var(--pd-secondary);flex-shrink:0}.pd-attachment>div{flex:1;min-width:0}.pd-attachment strong{display:block;font-size:11px;overflow-wrap:anywhere}.pd-attachment small{font-size:10px;display:block}.pd-attachment .pd-progress{margin-top:.4rem}.pd-attachment-download{padding:.4rem;color:var(--pd-brand-text)}.pd-bubble{display:flex;align-items:flex-start;gap:.6rem;max-width:92%;font-size:13px}.pd-bubble--user{margin-inline-start:auto;flex-direction:row-reverse}.pd-bubble-body{padding:.85rem 1rem;background:var(--pd-surface);border:1px solid var(--pd-border);border-radius:14px;min-width:0;max-width:100%}.pd-bubble--user .pd-bubble-body{background:var(--pd-brand-soft);border-color:transparent}.pd-bubble--system{margin-inline:auto;max-width:100%;color:var(--pd-secondary)}.pd-bubble--system .pd-bubble-body{background:transparent;border-style:dashed}.pd-bubble-sender{font-size:10px;display:block;margin-bottom:.35rem}.pd-bubble-content{line-height:1.9;overflow-wrap:anywhere}.pd-bubble-body>footer{display:flex;justify-content:flex-end;align-items:center;gap:.35rem;font-size:9px;color:var(--pd-secondary);margin-top:.4rem}.pd-bubble-actions{display:flex;gap:.3rem;margin-top:.6rem}.pd-stream-cursor{display:inline-block;width:6px;height:15px;vertical-align:middle;background:var(--pd-brand);margin-inline-start:3px;animation:pd-cursor 1s steps(2) infinite}.pd-message-scroll-wrap{position:relative}.pd-message-scroller{overflow:auto;overscroll-behavior:contain;scrollbar-width:thin;padding:1.2rem}.pd-message-scroller>div{display:flex;flex-direction:column;gap:1.1rem;min-height:100%}.pd-scroll-latest{position:absolute;bottom:12px;left:50%;transform:translate(-50%);box-shadow:var(--pd-shadow)}.pd-trace{display:grid;gap:1rem}.pd-trace>li{display:flex;align-items:flex-start;gap:.7rem}.pd-trace-status{display:grid;place-items:center;width:28px;height:28px;border:1px solid var(--pd-border);border-radius:50%;flex-shrink:0;color:var(--pd-secondary);background:var(--pd-muted)}.pd-trace [data-status=success]>.pd-trace-status{color:var(--pd-success);background:var(--pd-success-bg)}.pd-trace [data-status=error]>.pd-trace-status{color:var(--pd-danger);background:var(--pd-danger-bg)}.pd-trace>li>div{flex:1;min-width:0}.pd-trace strong,.pd-trace summary{font-size:12px;font-weight:650}.pd-trace p{font-size:11px;color:var(--pd-secondary)}.pd-trace summary{display:flex;align-items:center;gap:.6rem;cursor:pointer}.pd-trace details>div,.pd-trace details>pre{margin-top:.5rem}.pd-trace>li>small{font-size:9px;font-variant-numeric:tabular-nums}.pd-questionnaire{display:grid;gap:1.2rem}.pd-questionnaire h3{font-size:16px;margin-block:.4rem}.pd-questionnaire p{color:var(--pd-secondary);font-size:12px}.pd-questionnaire fieldset{display:grid;gap:.8rem}@keyframes pd-cursor{50%{opacity:0}}@media(max-width:640px){.pd-resizable-panel{padding:.65rem}.pd-bubble{max-width:100%;gap:.4rem}.pd-bubble-body{padding:.7rem .8rem}.pd-sidebar{display:none}.pd-navigation-menu details>ul{width:260px}.pd-input-group-addon{padding-inline:.5rem;font-size:11px}}.pd-product-detail{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:var(--pd-space-6, 24px)}.pd-product-detail>div:nth-child(2){display:flex;flex-direction:column;align-items:start;gap:16px}.pd-product-detail-tabs{grid-column:1/-1}.pd-bundle-card,.pd-notification-preferences,.pd-settings-panel form{display:grid;gap:16px}.pd-bundle-products{display:flex;gap:12px;align-items:start}.pd-bundle-products>div{flex:1;min-width:0;position:relative}.pd-bundle-products>div>.pd-icon{position:absolute;inset-inline-start:-12px;top:40%}.pd-bundle-products img{width:100%;aspect-ratio:1;object-fit:contain}.pd-bundle-products small{display:block}.pd-seller-card,.pd-coupon-card,.pd-team-members header,.pd-team-members li{display:flex;align-items:center;gap:16px}.pd-seller-card>div,.pd-coupon-card>div:first-of-type,.pd-team-members li>div{flex:1;min-width:0}.pd-seller-card p,.pd-coupon-card p{color:var(--pd-secondary)}.pd-coupon-card>div:last-child{display:grid;justify-items:center;gap:8px}.pd-coupon-card code{letter-spacing:.12em}.pd-coupon-card>span{color:var(--pd-brand)}.pd-kanban>div{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(250px,1fr);gap:16px;overflow-x:auto;overscroll-behavior-x:contain;padding-block-end:12px}.pd-kanban>div>section{padding:14px;background:var(--pd-muted);border:1px solid var(--pd-border);border-radius:var(--pd-radius);min-width:0}.pd-kanban header,.pd-kanban footer{display:flex;align-items:center;justify-content:space-between;gap:12px}.pd-kanban header{margin-bottom:16px}.pd-kanban header h3{font-size:14px;margin:0}.pd-kanban-card{display:grid;gap:12px;margin-bottom:12px}.pd-kanban-card p{margin:0;color:var(--pd-secondary);font-size:13px}.pd-kanban-card footer select{max-width:160px}.pd-team-members ul{padding:0;list-style:none}.pd-team-members li{padding-block:16px;border-bottom:1px solid var(--pd-border)}.pd-team-members small{display:block;color:var(--pd-secondary)}.pd-team-members select{max-width:150px}.pd-settings-panel header p{color:var(--pd-secondary)}.pd-settings-panel footer{display:flex;align-items:center;justify-content:space-between;gap:16px}.pd-settings-panel footer [role=status]{color:var(--pd-success)}@media(max-width:640px){.pd-product-detail{grid-template-columns:1fr}.pd-team-members li,.pd-coupon-card{flex-wrap:wrap}}}@layer primedesign.ai{.pd-ai-chat{display:flex;flex-direction:column}.pd-ai-chat>header{display:flex;align-items:center;gap:.75rem;padding:1.1rem 1.3rem;border-bottom:1px solid var(--pd-border)}.pd-ai-chat>header>span{width:38px;height:38px;display:grid;place-items:center;background:var(--pd-brand-soft);color:var(--pd-brand-text);border-radius:12px}.pd-ai-chat>header>div{flex:1}.pd-ai-chat>header strong{font-size:14px;display:block}.pd-ai-chat>header small{font-size:11px;display:block;color:var(--pd-secondary)}.pd-ai-chat .pd-message-scroller{background:var(--pd-bg)}.pd-ai-message-text{white-space:pre-wrap;overflow-wrap:anywhere}.pd-ai-welcome{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1rem;margin:auto;text-align:center;padding:2rem}.pd-ai-welcome>svg{color:var(--pd-brand-text)}.pd-ai-welcome h3{font-size:20px}.pd-ai-suggestions{display:flex;gap:.5rem;flex-wrap:wrap;justify-content:center}.pd-ai-suggestions .pd-button{font-size:11px;white-space:normal;text-align:start}.pd-ai-prompt{margin:1rem;border:1px solid var(--pd-input-border);border-radius:var(--pd-radius);padding:.6rem;background:var(--pd-surface);box-shadow:0 4px 14px #17233b04}.pd-ai-prompt:focus-within{border-color:var(--pd-brand);box-shadow:var(--pd-focus)}.pd-ai-prompt .pd-textarea{border:0;box-shadow:none;resize:none;min-height:74px;font-size:13px;padding:.5rem}.pd-ai-prompt-toolbar{display:flex;align-items:center;justify-content:space-between;gap:.5rem;border-top:1px solid var(--pd-border);padding-top:.5rem;margin-top:.4rem}.pd-ai-prompt-toolbar>div{display:flex;align-items:center;gap:.5rem}.pd-ai-prompt-toolbar .pd-select{min-height:32px;font-size:11px;max-width:160px;border-color:var(--pd-border)}.pd-ai-files{display:flex;gap:.5rem;flex-wrap:wrap;padding:.5rem}.pd-ai-files>.pd-attachment{max-width:240px}.pd-ai-regenerate{margin-inline:auto}.pd-ai-sources{margin-top:1rem;padding-top:.75rem;border-top:1px solid var(--pd-border)}.pd-ai-sources>strong{display:flex;align-items:center;gap:.35rem;font-size:10px;color:var(--pd-secondary)}.pd-ai-sources ol{display:grid;gap:.4rem;margin-top:.5rem}.pd-ai-sources a{display:flex;align-items:center;gap:.5rem;padding:.45rem;background:var(--pd-muted);border-radius:7px}.pd-ai-sources a>span{width:18px;height:18px;display:grid;place-items:center;background:var(--pd-surface);border-radius:4px;font-size:9px;flex-shrink:0}.pd-ai-sources a>div{flex:1;min-width:0}.pd-ai-sources a strong{display:block;font-size:10px}.pd-ai-sources a small{display:block;font-size:9px}.pd-ai-citation{display:inline-block;padding:0 .3rem;line-height:1.6;background:var(--pd-brand-soft);border-radius:4px;font-size:9px;color:var(--pd-brand-text)}.pd-ai-source-preview{padding:.5rem;display:grid;gap:.4rem;font-size:12px}.pd-ai-source-preview a{font-size:10px;color:var(--pd-brand-text);overflow-wrap:anywhere}.pd-ai-source-preview p{font-size:11px;color:var(--pd-secondary)}.pd-ai-tool{padding:1rem;display:grid;gap:.7rem}.pd-ai-tool>header{display:flex;align-items:center;gap:.6rem;flex-wrap:wrap}.pd-ai-tool>header>strong{font:600 12px ui-monospace,monospace;margin-inline-end:auto}.pd-ai-tool>header>small{font-size:9px}.pd-ai-tool .pd-collapsible{border-radius:8px}.pd-ai-confirmation{padding:1.2rem;display:grid;gap:.8rem}.pd-ai-confirmation>strong{font-size:14px}.pd-ai-confirmation>p{font-size:12px;color:var(--pd-secondary)}.pd-ai-confirmation>div:not(.pd-error){display:flex;gap:.6rem}.pd-ai-checkpoint{display:flex;align-items:center;gap:.8rem;padding:1rem;border:1px dashed var(--pd-border);border-radius:12px;background:var(--pd-surface)}.pd-ai-checkpoint>svg{color:var(--pd-brand-text)}.pd-ai-checkpoint>div{flex:1;min-width:0}.pd-ai-checkpoint strong{font-size:12px;display:block}.pd-ai-checkpoint small{font-size:10px;display:block}.pd-ai-context{display:grid;gap:.6rem;padding:1rem;border:1px solid var(--pd-border);border-radius:10px;background:var(--pd-surface)}.pd-ai-context>div:first-child{display:flex;align-items:center;justify-content:space-between;gap:.75rem}.pd-ai-context strong{font-size:12px}.pd-ai-context small{font-size:10px;font-variant-numeric:tabular-nums}.pd-ai-plan{padding:1.2rem}.pd-ai-plan h3{font-size:14px;margin-bottom:1rem}.pd-ai-plan ol{display:grid;gap:.9rem}.pd-ai-plan li{display:flex;align-items:center;gap:.7rem}.pd-ai-plan li>span{display:grid;place-items:center;width:25px;height:25px;border-radius:50%;background:var(--pd-muted);font-size:11px}.pd-ai-plan li>div{flex:1}.pd-ai-plan strong{font-size:12px;display:block}.pd-ai-plan small{font-size:10px;display:block}.pd-ai-task{padding:1rem;display:grid;gap:.8rem}.pd-ai-task>header{display:flex;align-items:center;justify-content:space-between;gap:.6rem}.pd-ai-task strong{font-size:12px}.pd-ai-task>p{font-size:11px;color:var(--pd-secondary)}.pd-ai-queue{border:1px solid var(--pd-border);border-radius:12px;background:var(--pd-surface);padding:1rem}.pd-ai-queue>h3{font-size:13px;margin-bottom:.8rem}.pd-ai-queue ul{display:grid;gap:.6rem}.pd-ai-queue li{display:flex;align-items:center;gap:.5rem;border-top:1px solid var(--pd-border);padding-top:.6rem}.pd-ai-queue strong{font-size:11px;flex:1}.pd-ai-terminal{position:relative}.pd-ai-terminal>.pd-badge{position:absolute;inset-inline-end:1rem;bottom:1rem}.pd-ai-tests{padding:1rem;display:grid;gap:.9rem}.pd-ai-tests>h3{font-size:13px}.pd-ai-tests>div{display:flex;gap:.4rem;flex-wrap:wrap}.pd-ai-tests li{display:flex;gap:.6rem;align-items:center;padding:.6rem 0;border-top:1px solid var(--pd-border);flex-wrap:wrap}.pd-ai-tests li>strong{font-size:11px;flex:1}.pd-ai-tests li>small{font-size:9px}.pd-ai-tests li>pre{width:100%;padding:.6rem;background:var(--pd-danger-bg);color:var(--pd-danger);white-space:pre-wrap;font-size:11px;border-radius:6px}.pd-ai-file-tree{display:grid;gap:.25rem;font:12px ui-monospace,monospace}.pd-ai-file-tree details{padding-inline-start:.7rem}.pd-ai-file-tree summary{cursor:pointer;padding:.4rem;list-style:none;display:flex;align-items:center;gap:.4rem}.pd-ai-file-tree button{display:flex;align-items:center;gap:.4rem;text-align:start;background:none;border:0;padding:.4rem .6rem;border-radius:5px;font:inherit}.pd-ai-file-tree button:hover,.pd-ai-file-tree button[aria-pressed=true]{background:var(--pd-brand-soft);color:var(--pd-brand-text)}.pd-ai-subagent{padding:1rem;display:grid;gap:1rem}.pd-ai-subagent>header{display:flex;align-items:center;gap:.6rem}.pd-ai-subagent>header>div{flex:1}.pd-ai-subagent strong{font-size:12px;display:block}.pd-ai-subagent small{font-size:10px;display:block}@media(max-width:640px){.pd-ai-chat>header{padding:1rem}.pd-ai-prompt{margin:.65rem}.pd-ai-chat>header small{font-size:10px}.pd-ai-checkpoint{flex-wrap:wrap}.pd-ai-confirmation>div{flex-wrap:wrap}.pd-ai-prompt-toolbar .pd-select{max-width:120px;font-size:10px}.pd-ai-welcome{padding:1.25rem}.pd-ai-welcome h3{font-size:18px}}}', Gh = {
  AIMessage: {
    required: [
      "message"
    ],
    slot: !1
  },
  ChainOfThought: {
    required: [
      "steps",
      "label"
    ],
    slot: !1
  },
  Chat: {
    required: [
      "messages"
    ],
    slot: !1
  },
  Checkpoint: {
    required: [
      "title"
    ],
    slot: !1
  },
  Confirmation: {
    required: [
      "title"
    ],
    slot: !1
  },
  ContextUsage: {
    required: [
      "used",
      "limit"
    ],
    slot: !1
  },
  FileTree: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  InlineCitation: {
    required: [
      "source",
      "index"
    ],
    slot: !1
  },
  ModelSelector: {
    required: [
      "models",
      "value"
    ],
    slot: !1
  },
  Plan: {
    required: [
      "title",
      "items"
    ],
    slot: !1
  },
  PromptInput: {
    required: [],
    slot: !1
  },
  Queue: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  Reasoning: {
    required: [
      "summary"
    ],
    slot: !0
  },
  Sources: {
    required: [
      "sources"
    ],
    slot: !1
  },
  StackTrace: {
    required: [
      "message",
      "stack"
    ],
    slot: !1
  },
  SubagentCard: {
    required: [
      "name",
      "status"
    ],
    slot: !0
  },
  Suggestions: {
    required: [
      "items"
    ],
    slot: !1
  },
  TaskCard: {
    required: [
      "title",
      "status"
    ],
    slot: !1
  },
  Terminal: {
    required: [
      "output"
    ],
    slot: !1
  },
  TestResults: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  ToolCall: {
    required: [
      "name",
      "status"
    ],
    slot: !1
  },
  AppShell: {
    required: [
      "logo",
      "sidebar"
    ],
    slot: !0
  },
  AuthCard: {
    required: [
      "title"
    ],
    slot: !1
  },
  ConversationView: {
    required: [
      "title",
      "messages"
    ],
    slot: !1
  },
  DashboardNav: {
    required: [
      "items",
      "active"
    ],
    slot: !1
  },
  FileCard: {
    required: [
      "name",
      "size"
    ],
    slot: !1
  },
  InboxLayout: {
    required: [
      "list",
      "conversation"
    ],
    slot: !1
  },
  KanbanBoard: {
    required: [
      "columns",
      "label"
    ],
    slot: !1
  },
  NotificationCenter: {
    required: [
      "items"
    ],
    slot: !1
  },
  NotificationPreferences: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  PageHeader: {
    required: [
      "title"
    ],
    slot: !1
  },
  PricingCard: {
    required: [
      "title",
      "price",
      "features",
      "action"
    ],
    slot: !1
  },
  SettingsPanel: {
    required: [
      "title",
      "initialValues"
    ],
    slot: !0
  },
  TeamMembers: {
    required: [
      "members",
      "roles"
    ],
    slot: !1
  },
  TicketList: {
    required: [
      "tickets"
    ],
    slot: !1
  },
  UserMenu: {
    required: [
      "name",
      "items"
    ],
    slot: !1
  },
  AddressCard: {
    required: [
      "name",
      "phone",
      "address"
    ],
    slot: !1
  },
  BrandCard: {
    required: [
      "name"
    ],
    slot: !1
  },
  BundleCard: {
    required: [
      "title",
      "products",
      "price"
    ],
    slot: !1
  },
  CartLineItem: {
    required: [
      "item"
    ],
    slot: !1
  },
  CartProvider: {
    required: [],
    slot: !0
  },
  CartSummary: {
    required: [
      "items"
    ],
    slot: !1
  },
  CategoryCard: {
    required: [
      "title"
    ],
    slot: !1
  },
  CheckoutStepper: {
    required: [
      "current"
    ],
    slot: !1
  },
  ColorSwatches: {
    required: [
      "variants",
      "value",
      "label"
    ],
    slot: !1
  },
  CompareProvider: {
    required: [],
    slot: !0
  },
  CompareTable: {
    required: [
      "products"
    ],
    slot: !1
  },
  CouponCard: {
    required: [
      "code",
      "title"
    ],
    slot: !1
  },
  CouponInput: {
    required: [],
    slot: !1
  },
  DiscountBadge: {
    required: [
      "price",
      "originalPrice"
    ],
    slot: !1
  },
  FreeShippingProgress: {
    required: [
      "subtotal",
      "threshold"
    ],
    slot: !1
  },
  MiniCart: {
    required: [
      "open"
    ],
    slot: !1
  },
  OrderCard: {
    required: [
      "number",
      "date",
      "status",
      "items",
      "total"
    ],
    slot: !1
  },
  OrderTracking: {
    required: [
      "steps"
    ],
    slot: !1
  },
  Price: {
    required: [
      "value"
    ],
    slot: !1
  },
  ProductCard: {
    required: [
      "product"
    ],
    slot: !1
  },
  ProductCardSkeleton: {
    required: [],
    slot: !1
  },
  ProductDetail: {
    required: [
      "product"
    ],
    slot: !1
  },
  ProductGallery: {
    required: [
      "images",
      "title"
    ],
    slot: !1
  },
  ProductGrid: {
    required: [
      "products"
    ],
    slot: !1
  },
  ProductImage: {
    required: [
      "alt"
    ],
    slot: !1
  },
  PromoCard: {
    required: [
      "title"
    ],
    slot: !1
  },
  QuickView: {
    required: [
      "product",
      "open"
    ],
    slot: !1
  },
  ReviewCard: {
    required: [
      "name",
      "rating"
    ],
    slot: !0
  },
  SellerCard: {
    required: [
      "name"
    ],
    slot: !1
  },
  ShippingMethodPicker: {
    required: [
      "options",
      "value"
    ],
    slot: !1
  },
  StockBadge: {
    required: [
      "stock"
    ],
    slot: !1
  },
  WishlistProvider: {
    required: [],
    slot: !0
  },
  BarChart: {
    required: [
      "title",
      "data"
    ],
    slot: !1
  },
  BarList: {
    required: [
      "title",
      "data"
    ],
    slot: !1
  },
  DataTable: {
    required: [
      "rows",
      "columns",
      "caption"
    ],
    slot: !1
  },
  LineChart: {
    required: [
      "title",
      "data"
    ],
    slot: !1
  },
  PieChart: {
    required: [
      "title",
      "data"
    ],
    slot: !1
  },
  ProportionBar: {
    required: [
      "title",
      "data"
    ],
    slot: !1
  },
  Sparkline: {
    required: [
      "values"
    ],
    slot: !1
  },
  Form: {
    required: [
      "form"
    ],
    slot: !1
  },
  FormField: {
    required: [
      "name"
    ],
    slot: !0
  },
  FormWizard: {
    required: [
      "form",
      "steps"
    ],
    slot: !1
  },
  SchemaForm: {
    required: [
      "fields",
      "defaultValues"
    ],
    slot: !1
  },
  Icon: {
    required: [
      "name"
    ],
    slot: !1
  },
  Accordion: {
    required: [
      "items"
    ],
    slot: !1
  },
  Alert: {
    required: [],
    slot: !1
  },
  AspectRatio: {
    required: [],
    slot: !0
  },
  Attachment: {
    required: [
      "name"
    ],
    slot: !1
  },
  Avatar: {
    required: [
      "name"
    ],
    slot: !1
  },
  AvatarGroup: {
    required: [
      "names"
    ],
    slot: !1
  },
  Badge: {
    required: [],
    slot: !0
  },
  Breadcrumb: {
    required: [
      "items"
    ],
    slot: !1
  },
  Button: {
    required: [],
    slot: !0
  },
  ButtonGroup: {
    required: [],
    slot: !0
  },
  Calendar: {
    required: [],
    slot: !1
  },
  Card: {
    required: [],
    slot: !0
  },
  CardBody: {
    required: [],
    slot: !0
  },
  CardFooter: {
    required: [],
    slot: !0
  },
  CardHeader: {
    required: [],
    slot: !0
  },
  CardNumberInput: {
    required: [],
    slot: !1
  },
  Carousel: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  Checkbox: {
    required: [
      "label"
    ],
    slot: !1
  },
  ChipGroup: {
    required: [
      "label",
      "options",
      "value"
    ],
    slot: !1
  },
  CodeBlock: {
    required: [
      "code"
    ],
    slot: !1
  },
  Collapsible: {
    required: [
      "title"
    ],
    slot: !0
  },
  ColorPicker: {
    required: [
      "value",
      "label"
    ],
    slot: !1
  },
  Combobox: {
    required: [
      "label",
      "options"
    ],
    slot: !1
  },
  CommandPalette: {
    required: [
      "open",
      "items"
    ],
    slot: !1
  },
  ConfirmDialog: {
    required: [
      "open",
      "title"
    ],
    slot: !1
  },
  Container: {
    required: [],
    slot: !0
  },
  ContextMenu: {
    required: [
      "label",
      "items"
    ],
    slot: !0
  },
  CopyButton: {
    required: [
      "value"
    ],
    slot: !1
  },
  Countdown: {
    required: [
      "until",
      "label"
    ],
    slot: !1
  },
  DatePicker: {
    required: [],
    slot: !1
  },
  DateRangePicker: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  Dialog: {
    required: [
      "open",
      "title"
    ],
    slot: !0
  },
  DirectionProvider: {
    required: [
      "dir"
    ],
    slot: !0
  },
  Divider: {
    required: [],
    slot: !1
  },
  Drawer: {
    required: [
      "open",
      "title"
    ],
    slot: !0
  },
  DropdownMenu: {
    required: [
      "trigger",
      "label",
      "items"
    ],
    slot: !1
  },
  EmptyState: {
    required: [
      "title"
    ],
    slot: !1
  },
  Field: {
    required: [],
    slot: !1
  },
  FileUpload: {
    required: [
      "label"
    ],
    slot: !1
  },
  Grid: {
    required: [],
    slot: !0
  },
  HoverCard: {
    required: [
      "trigger",
      "title"
    ],
    slot: !0
  },
  IbanInput: {
    required: [],
    slot: !1
  },
  IconButton: {
    required: [
      "icon",
      "label"
    ],
    slot: !1
  },
  InlineEdit: {
    required: [
      "value",
      "label"
    ],
    slot: !1
  },
  Input: {
    required: [],
    slot: !1
  },
  InputGroup: {
    required: [],
    slot: !0
  },
  InputGroupAddon: {
    required: [],
    slot: !0
  },
  InputGroupInput: {
    required: [],
    slot: !1
  },
  Item: {
    required: [
      "title"
    ],
    slot: !0
  },
  ItemGroup: {
    required: [
      "label"
    ],
    slot: !0
  },
  Kbd: {
    required: [],
    slot: !0
  },
  Label: {
    required: [],
    slot: !1
  },
  Marker: {
    required: [],
    slot: !0
  },
  Menubar: {
    required: [
      "menus",
      "label"
    ],
    slot: !1
  },
  MessageBubble: {
    required: [],
    slot: !0
  },
  MessageScroller: {
    required: [
      "label"
    ],
    slot: !0
  },
  Meter: {
    required: [
      "label"
    ],
    slot: !1
  },
  MobileInput: {
    required: [],
    slot: !1
  },
  MonthPicker: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  MultiSelect: {
    required: [
      "label",
      "options",
      "value"
    ],
    slot: !1
  },
  NationalIdInput: {
    required: [],
    slot: !1
  },
  NavigationMenu: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  NumberInput: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  OtpInput: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  Pagination: {
    required: [
      "page",
      "total"
    ],
    slot: !1
  },
  PasswordInput: {
    required: [],
    slot: !1
  },
  PasswordStrength: {
    required: [
      "value"
    ],
    slot: !1
  },
  PersianInput: {
    required: [
      "kind"
    ],
    slot: !1
  },
  Popover: {
    required: [
      "trigger",
      "label"
    ],
    slot: !0
  },
  PostalCodeInput: {
    required: [],
    slot: !1
  },
  PriceInput: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  PrimeProvider: {
    required: [],
    slot: !0
  },
  Progress: {
    required: [
      "label"
    ],
    slot: !1
  },
  ProvinceSelect: {
    required: [],
    slot: !1
  },
  Questionnaire: {
    required: [
      "questions",
      "label"
    ],
    slot: !1
  },
  RadioGroup: {
    required: [
      "label",
      "name",
      "options",
      "value"
    ],
    slot: !1
  },
  Rating: {
    required: [
      "value",
      "label"
    ],
    slot: !1
  },
  RelativeTime: {
    required: [
      "date"
    ],
    slot: !1
  },
  ResizablePanelGroup: {
    required: [
      "panels",
      "label"
    ],
    slot: !1
  },
  ScrollArea: {
    required: [
      "label"
    ],
    slot: !0
  },
  SegmentedControl: {
    required: [
      "label",
      "options",
      "value"
    ],
    slot: !1
  },
  Select: {
    required: [],
    slot: !1
  },
  Separator: {
    required: [],
    slot: !1
  },
  Sidebar: {
    required: [
      "label",
      "items"
    ],
    slot: !1
  },
  SidebarTrigger: {
    required: [],
    slot: !1
  },
  SideNav: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  Skeleton: {
    required: [],
    slot: !1
  },
  Slider: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  Spinner: {
    required: [],
    slot: !1
  },
  Splitter: {
    required: [
      "panels",
      "label"
    ],
    slot: !1
  },
  Stack: {
    required: [],
    slot: !0
  },
  StatCard: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  Stepper: {
    required: [
      "steps",
      "current"
    ],
    slot: !1
  },
  Switch: {
    required: [
      "label"
    ],
    slot: !1
  },
  Table: {
    required: [],
    slot: !1
  },
  TableBody: {
    required: [],
    slot: !1
  },
  TableCaption: {
    required: [],
    slot: !1
  },
  TableCell: {
    required: [],
    slot: !1
  },
  TableHead: {
    required: [],
    slot: !1
  },
  TableHeader: {
    required: [],
    slot: !1
  },
  TableRow: {
    required: [],
    slot: !1
  },
  Tabs: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  TagInput: {
    required: [
      "label",
      "value"
    ],
    slot: !1
  },
  Textarea: {
    required: [],
    slot: !1
  },
  TimeInput: {
    required: [
      "value"
    ],
    slot: !1
  },
  Timeline: {
    required: [
      "items"
    ],
    slot: !1
  },
  ToastProvider: {
    required: [],
    slot: !0
  },
  Toggle: {
    required: [],
    slot: !1
  },
  ToggleGroup: {
    required: [
      "label",
      "items"
    ],
    slot: !1
  },
  Tooltip: {
    required: [
      "label"
    ],
    slot: !0
  },
  Trace: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  TreeView: {
    required: [
      "items",
      "label"
    ],
    slot: !1
  },
  Typography: {
    required: [],
    slot: !0
  },
  VisuallyHidden: {
    required: [],
    slot: !0
  }
}, eb = (d) => d.replace(/([a-z\d])([A-Z])/g, "$1-$2").replace(/([A-Z])([A-Z][a-z])/g, "$1-$2").toLowerCase(), nj = /* @__PURE__ */ new Set([
  "PrimeProvider",
  "ToastProvider",
  "CartProvider",
  "WishlistProvider",
  "CompareProvider",
  "Form",
  "FormField",
  "DirectionProvider",
  "Table",
  "TableHeader",
  "TableBody",
  "TableRow",
  "TableHead",
  "TableCell",
  "TableCaption"
]), ni = {};
for (const d of [K1, cy, yy, wy, Qy, lj, f0])
  for (const [s, o] of Object.entries(d)) {
    if (!/^[A-Z]/.test(s) || nj.has(s) || !(typeof o == "function" || typeof o == "object" && o && "$$typeof" in o))
      continue;
    const u = "pd-" + eb(s);
    ni[u] || (ni[u] = { name: s, component: o });
  }
ni["pd-form"] = { name: "SchemaForm", component: Kg };
const vj = Object.freeze(["pd-provider", ...Object.keys(ni).sort()]), tb = typeof HTMLElement > "u" ? class {
} : HTMLElement, ga = /* @__PURE__ */ new WeakMap(), ko = /* @__PURE__ */ new Set();
let Xd = {};
function xj(d) {
  Xd = { ...Xd, ...d };
  for (const s of ko) s.render();
}
const Zh = /* @__PURE__ */ new WeakSet();
function ij(d) {
  if (Zh.has(d)) return;
  const s = d.createElement("style");
  s.dataset.primedesign = "", s.textContent = $g, d.head.append(s), Zh.add(d);
}
function rj(d) {
  if (d === "" || d === "true") return !0;
  if (d === "false") return !1;
  if (d === "null") return null;
  if (/^-?\d+(\.\d+)?$/.test(d)) return Number(d);
  if (d.startsWith("{") || d.startsWith("["))
    try {
      return JSON.parse(d);
    } catch {
    }
  return d;
}
function Ro(d) {
  const s = {};
  for (const o of d.attributes)
    ["id", "class", "style", "slot", "data-pd-theme"].includes(o.name) || o.name.startsWith("aria-") || o.name.startsWith("data-") || (s[o.name.replace(/-([a-z])/g, (u, c) => c.toUpperCase())] = rj(
      o.value
    ));
  return s;
}
function dj(d) {
  const s = d ? { ...Xd, ...Ro(d), ...d.props } : { ...Xd };
  return typeof s.theme != "string" && typeof s.defaultTheme != "string" && (s.defaultTheme = "light"), s.brand !== void 0 && !/^#[a-f\d]{6}$/i.test(String(s.brand)) && delete s.brand, s.theme !== void 0 && !["light", "dark", "system"].includes(String(s.theme)) && delete s.theme, s.defaultTheme !== void 0 && !["light", "dark", "system"].includes(String(s.defaultTheme)) && delete s.defaultTheme, s.radius !== void 0 && (!Number.isFinite(Number(s.radius)) || Number(s.radius) < 0 || Number(s.radius) > 40) && delete s.radius, s.dir !== void 0 && !["rtl", "ltr"].includes(String(s.dir)) && delete s.dir, s;
}
function Uo(d) {
  return Array.isArray(d) ? d.map(Uo) : d && typeof d == "object" && !(d instanceof Date) && !(typeof File < "u" && d instanceof File) ? "$slot" in d ? w.createElement("slot", { name: String(d.$slot) }) : r0.isValidElement(d) ? d : Object.fromEntries(Object.entries(d).map(([s, o]) => [s, Uo(o)])) : d;
}
function sj(d, s) {
  const o = { ...s };
  if ([
    "DatePicker",
    "Calendar",
    "MonthPicker",
    "DateRangePicker",
    "Countdown",
    "RelativeTime"
  ].includes(d)) {
    for (const u of ["min", "max", "value", "defaultValue", "defaultMonth", "date", "until"])
      typeof o[u] == "string" && (o[u] = Ao(o[u]) ?? new Date(o[u]));
    if (d === "DateRangePicker" && o.value && typeof o.value == "object") {
      const u = o.value;
      o.value = {
        start: typeof u.start == "string" ? Ao(u.start) : u.start,
        end: typeof u.end == "string" ? Ao(u.end) : u.end
      };
    }
  }
  return ["SchemaForm"].includes(d) && Array.isArray(o.fields) && (o.fields = o.fields.map((u) => ({
    ...u,
    rules: Array.isArray(u.rules) ? u.rules.map(
      (c) => {
        var f;
        return typeof c == "string" && c in ei ? ei[c]() : typeof c == "object" && c && "type" in c ? (f = ei[String(c.type)]) == null ? void 0 : f.call(
          ei,
          ...c.args ?? []
        ) : c;
      }
    ).filter((c) => typeof c == "function") : [],
    visible: u.visibleWhen ? (c) => sn(c, u.visibleWhen.field) === u.visibleWhen.equals : u.visible
  }))), Uo(o);
}
const uj = [
  "onClick",
  "onChange",
  "onValueChange",
  "onOpenChange",
  "onPressedChange",
  "onCollapsedChange",
  "onSelectedChange",
  "onPageChange",
  "onStateChange",
  "onSubmit",
  "onSend",
  "onStop",
  "onModelChange",
  "onComplete",
  "onSelect",
  "onSearchChange",
  "onClear",
  "onClose",
  "onConfirm",
  "onApprove",
  "onReject",
  "onRestore",
  "onCancel",
  "onRetry",
  "onRemove",
  "onDownload",
  "onCheckout",
  "onApply",
  "onItemsChange",
  "onFilesChange",
  "onFeedback",
  "onRegenerate",
  "onLayoutChange",
  "onQuantityChange",
  "onAddToCart",
  "onWishlistChange",
  "onCompareChange",
  "onQuickView",
  "onAddBundle",
  "onMove",
  "onRoleChange",
  "onInvite",
  "onSave"
];
function ab(d) {
  if (d instanceof Date) return Ja(d);
  if (d && typeof d == "object" && "target" in d) {
    const s = d.target;
    return (s == null ? void 0 : s.type) === "checkbox" ? s.checked : s == null ? void 0 : s.value;
  }
  return d;
}
class oj extends w.Component {
  constructor() {
    super(...arguments);
    nt(this, "state", { error: null });
  }
  static getDerivedStateFromError(o) {
    return { error: o.message };
  }
  componentDidCatch(o) {
    this.props.host.dispatchEvent(
      new CustomEvent("pd-error", {
        detail: { message: o.message },
        bubbles: !0,
        composed: !0
      })
    );
  }
  componentDidUpdate(o) {
    o.version !== this.props.version && this.state.error && this.setState({ error: null });
  }
  render() {
    return this.state.error ? /* @__PURE__ */ i.jsx("div", { role: "alert", className: "pd-error", children: this.state.error }) : this.props.children;
  }
}
function cj({ host: d, definition: s }) {
  var b, y;
  const o = be(), u = Po(), c = Tg(), f = Ag(), m = sj(s.name, d.readProps()), h = { ...m }, v = (z, O) => {
    const E = h[z], R = O.map(ab);
    let U;
    const H = {
      component: s.name,
      callback: z,
      args: R,
      value: R[0],
      respondWith: (J) => {
        U = Promise.resolve(J);
      }
    }, V = new CustomEvent("pd-" + eb(z.slice(2)), {
      detail: H,
      bubbles: !0,
      composed: !0,
      cancelable: !0
    });
    if (d.dispatchEvent(V), typeof E == "function") return E(...O);
    const W = () => {
      var se, G, X;
      if (H.skipDefault || V.defaultPrevented && !U) return;
      const J = {
        onValueChange: "value",
        onChange: "value",
        onOpenChange: "open",
        onPressedChange: "pressed",
        onCollapsedChange: "collapsed",
        onSelectedChange: "selected",
        onPageChange: "page",
        onStateChange: "state",
        onModelChange: "model"
      }[z];
      J && d.updateValue(
        z === "onChange" && O[0] && typeof O[0] == "object" && ((se = O[0].target) == null ? void 0 : se.type) === "checkbox" ? "checked" : J,
        R[0]
      ), z === "onClick" && s.name === "Button" && m.type === "submit" && ((G = d.closest("form")) == null || G.requestSubmit()), z === "onClick" && s.name === "Button" && m.type === "reset" && ((X = d.closest("form")) == null || X.reset()), z === "onAddToCart" && u.add(
        O[0],
        O[1],
        O[2]
      ), z === "onWishlistChange" && c.toggle(O[0].id), z === "onCompareChange" && f.toggle(O[0].id);
    };
    return U ? U.then((J) => (W(), J)) : W();
  };
  for (const z of uj)
    [
      "onDownload",
      "onRemove",
      "onApply",
      "onCheckout",
      "onCancel",
      "onRetry",
      "onStop",
      "onRegenerate",
      "onApprove",
      "onReject",
      "onConfirm",
      "onRestore",
      "onQuickView"
    ].includes(z) && !m[z] && !d.hasAttribute("actions") || (m[z] = (...O) => v(z, O));
  if (s.name === "ProductCard") {
    const z = m.product;
    z && (m.wishlisted = c.has(z.id), m.compared = f.ids.includes(z.id));
  }
  s.name === "DataTable" && !m.getRowId && (m.getRowId = (z) => String(z.id)), (s.name === "CartSummary" || s.name === "CartLineItem") && s.name === "CartSummary" && !m.items && (m.items = u.items), m.children === void 0 && ((b = Gh[s.name]) != null && b.slot) && (m.children = w.createElement("slot"));
  const j = !(((y = Gh[s.name]) == null ? void 0 : y.required) ?? []).some(
    (z) => m[z] === void 0
  ), x = {
    "--pd-brand": o.brand,
    "--pd-on-brand": ai(o.brand, "#ffffff") >= ai(o.brand, "#101725") ? "#ffffff" : "#101725",
    "--pd-radius": `${o.radius}px`,
    "--pd-font": o.fontFamily,
    ...Object.fromEntries(
      Object.entries(Lo(o.brand)).map(([z, O]) => ["--pd-brand-" + z, O])
    )
  };
  return w.useEffect(() => {
    j && (d.syncFormValue(), d.ready || (d.ready = !0, d.dispatchEvent(
      new CustomEvent("pd-ready", {
        detail: { component: s.name },
        bubbles: !0,
        composed: !0
      })
    )));
  }, [d, d.version]), j ? /* @__PURE__ */ i.jsx(
    "div",
    {
      className: "pd-root",
      dir: o.dir,
      lang: o.locale,
      "data-pd-theme": o.resolvedTheme,
      "data-pd-density": o.density,
      style: x,
      children: w.createElement(s.component, m)
    }
  ) : null;
}
function pj({ owner: d }) {
  const s = be();
  return w.useEffect(() => {
    if (d) {
      d.dataset.pdTheme = s.resolvedTheme, d.style.direction = s.dir, d.style.setProperty("--pd-brand", s.brand), d.style.setProperty("--pd-radius", s.radius + "px"), d.style.setProperty("--pd-font", s.fontFamily), d.style.setProperty(
        "--pd-on-brand",
        ai(s.brand, "#ffffff") >= ai(s.brand, "#101725") ? "#ffffff" : "#101725"
      );
      for (const [o, u] of Object.entries(Lo(s.brand)))
        d.style.setProperty("--pd-brand-" + o, u);
    }
  }, [d, s]), null;
}
function fj({
  entries: d,
  settings: s,
  owner: o
}) {
  return /* @__PURE__ */ i.jsxs(Go, { ...s, children: [
    /* @__PURE__ */ i.jsx(pj, { owner: o }),
    /* @__PURE__ */ i.jsx(ig, { children: /* @__PURE__ */ i.jsx(Sg, { children: /* @__PURE__ */ i.jsx(Ng, { children: /* @__PURE__ */ i.jsx(Cg, { children: d.map((u) => {
      const c = ni[u.localName];
      return Jh.createPortal(
        /* @__PURE__ */ i.jsx(oj, { host: u, version: u.version, children: /* @__PURE__ */ i.jsx(cj, { host: u, definition: c }) }),
        u.mount,
        u.uid
      );
    }) }) }) }) })
  ] });
}
let mj = 0;
class Ho {
  constructor(s, o) {
    nt(this, "disposed", !1);
    nt(this, "entries", /* @__PURE__ */ new Set());
    nt(this, "root");
    nt(this, "container");
    nt(this, "owner");
    ij(s), this.owner = o, this.container = s.createElement("div"), this.container.dataset.pdRuntime = "", this.container.style.display = "contents", (o ?? s.body).append(this.container), this.root = p0.createRoot(this.container), ko.add(this);
  }
  render() {
    this.disposed || this.root.render(
      /* @__PURE__ */ i.jsx(
        fj,
        {
          entries: [...this.entries],
          settings: dj(this.owner),
          owner: this.owner
        }
      )
    );
  }
  add(s) {
    this.entries.add(s), this.render();
  }
  remove(s) {
    this.entries.delete(s), this.render();
  }
  dispose() {
    this.disposed = !0, this.root.unmount(), this.container.remove(), ko.delete(this);
  }
}
class hj extends tb {
  constructor() {
    super(...arguments);
    nt(this, "value", {});
    nt(this, "observer");
  }
  get props() {
    let o = {};
    const u = Array.from(this.children ?? []).find(
      (c) => c.matches('script[type="application/json"][data-pd-props]')
    );
    if (u)
      try {
        o = JSON.parse(u.textContent ?? "{}");
      } catch {
      }
    return { ...o, ...this.value };
  }
  set props(o) {
    var u;
    this.value = o ?? {}, (u = ga.get(this)) == null || u.render();
  }
  connectedCallback() {
    if (Object.hasOwn(this, "props")) {
      const o = this.props;
      delete this.props, this.props = o;
    }
    this.classList.add("pd-root"), ga.has(this) || ga.set(this, new Ho(this.ownerDocument, this)), this.observer = new MutationObserver(() => {
      var o;
      return (o = ga.get(this)) == null ? void 0 : o.render();
    }), this.observer.observe(this, {
      attributes: !0,
      attributeFilter: [
        "brand",
        "theme",
        "default-theme",
        "dir",
        "locale",
        "digits",
        "radius",
        "density",
        "font-family"
      ]
    });
  }
  disconnectedCallback() {
    var o;
    (o = this.observer) == null || o.disconnect(), queueMicrotask(() => {
      var u;
      this.isConnected || ((u = ga.get(this)) == null || u.dispose(), ga.delete(this));
    });
  }
}
class lb extends tb {
  constructor() {
    super();
    nt(this, "uid", `pd-element-${++mj}`);
    nt(this, "version", 0);
    nt(this, "ready", !1);
    nt(this, "mount");
    nt(this, "value", {});
    nt(this, "local", {});
    nt(this, "observer");
    nt(this, "coordinator");
    nt(this, "internals");
    nt(this, "fallback");
    nt(this, "onInput", () => this.syncFormValue());
    if (typeof this.attachInternals == "function")
      try {
        this.internals = this.attachInternals();
      } catch {
      }
  }
  get props() {
    return { ...this.readProps() };
  }
  set props(o) {
    this.value = o ?? {}, this.local = {}, this.refresh();
  }
  readProps() {
    let o = {};
    const u = Array.from(this.children ?? []).find(
      (c) => c.matches('script[type="application/json"][data-pd-props]')
    );
    if (u)
      try {
        o = JSON.parse(u.textContent ?? "{}");
      } catch {
      }
    return { ...Ro(this), ...o, ...this.value, ...this.local };
  }
  updateValue(o, u) {
    this.local = { ...this.local, [o]: u }, this.refresh(), this.syncFormValue();
  }
  refresh() {
    var o;
    this.version++, (o = this.coordinator) == null || o.render();
  }
  connectedCallback() {
    if (Object.hasOwn(this, "props")) {
      const f = this.props;
      delete this.props, this.props = f;
    }
    if (!this.shadowRoot) {
      const f = this.attachShadow({ mode: "open" }), m = this.ownerDocument.createElement("style");
      m.textContent = $g.replaceAll(":root", ":host"), this.mount = this.ownerDocument.createElement("div"), f.append(m, this.mount);
    }
    const o = this.closest("pd-provider");
    o && !ga.has(o) && ga.set(o, new Ho(this.ownerDocument, o));
    const u = o ?? this.ownerDocument;
    ga.has(u) || ga.set(u, new Ho(this.ownerDocument));
    const c = ga.get(u);
    if (this.coordinator && this.coordinator !== c) {
      const f = this.coordinator;
      Jh.flushSync(() => f.remove(this));
    }
    this.coordinator = c, this.coordinator.add(this), this.observer = new MutationObserver((f) => {
      const m = f.filter(
        (h) => h.target === this && h.attributeName && !["class", "style", "id"].includes(h.attributeName) && !h.attributeName.startsWith("data-")
      );
      if (m.length) {
        for (const h of m) {
          const v = h.attributeName.replace(/-([a-z])/g, (j, x) => x.toUpperCase());
          delete this.local[v];
        }
        this.refresh();
      }
    }), this.observer.observe(this, { attributes: !0 }), this.addEventListener("input", this.onInput), this.addEventListener("change", this.onInput);
  }
  disconnectedCallback() {
    var o;
    (o = this.observer) == null || o.disconnect(), this.removeEventListener("input", this.onInput), this.removeEventListener("change", this.onInput), queueMicrotask(() => {
      var u;
      this.isConnected || (u = this.coordinator) == null || u.remove(this);
    });
  }
  syncFormValue() {
    var v, j, x;
    const o = this.readProps(), u = String(o.name ?? "");
    if (!u) return;
    const c = (v = this.shadowRoot) == null ? void 0 : v.querySelector("input:not([type=hidden]),select,textarea"), f = (j = this.shadowRoot) == null ? void 0 : j.querySelector("input[type=hidden]");
    let m = Object.prototype.hasOwnProperty.call(this.local, "value") ? ab(this.local.value) : (f == null ? void 0 : f.value) ?? (c == null ? void 0 : c.value) ?? o.value ?? "";
    c instanceof HTMLInputElement && ["checkbox", "radio"].includes(c.type) && !c.checked && (m = null), o.disabled && (m = null);
    const h = m === null ? null : Array.isArray(m) ? JSON.stringify(m) : String(m);
    (x = this.internals) != null && x.setFormValue ? (this.internals.setFormValue(h), c && "validity" in c && this.internals.setValidity(c.validity, c.validationMessage, c)) : (this.fallback || (this.fallback = this.ownerDocument.createElement("input"), this.fallback.type = "hidden", this.fallback.dataset.pdFormValue = "", this.append(this.fallback)), this.fallback.name = u, this.fallback.value = h ?? "", this.fallback.disabled = h === null);
  }
  formResetCallback() {
    const o = { ...Ro(this), ...this.value };
    this.local = {
      value: o.defaultValue ?? o.value ?? (this.localName.includes("date") ? null : ""),
      checked: o.defaultChecked ?? o.checked ?? !1
    }, this.refresh();
  }
  formDisabledCallback(o) {
    this.local.disabled = o || this.hasAttribute("disabled") || !!this.value.disabled, this.refresh();
  }
}
nt(lb, "formAssociated", !0);
function gj(d = typeof customElements < "u" ? customElements : void 0) {
  if (d) {
    d.get("pd-provider") || d.define("pd-provider", hj);
    for (const s of Object.keys(ni))
      d.get(s) || d.define(s, class extends lb {
      });
  }
}
typeof window < "u" && typeof customElements < "u" && gj();
export {
  vj as ELEMENT_NAMES,
  lb as PrimeElement,
  hj as PrimeProviderElement,
  xj as configure,
  gj as defineElements
};
